---
name: alibaba-category-research-diagnostic
description: 阿里巴巴国际站(alibaba.com)品类调研 + 店铺/竞品深度诊断专家。做品类大盘调研、跨渠道需求验证(Google Trends/社媒/Shopify DTC)、单店漏斗诊断、Top竞品同口径对标、客单价对标、品类聚焦度诊断、选品蓝海挖掘、增长策略产出。强制走「国际站后台 MCP 优先 + browser 子代理补缺 + ≥3机构市场规模回访 + 跨渠道需求交叉验证 + 证据动作分级 + 全文实质审计(含审计的审计) + HTML 报告」路线，零幻觉。触发词：品类调研、跨境电商品类调研、品类大盘、选品调研、蓝海挖掘、店铺诊断、Alibaba国际站诊断、为什么排名Top X如何冲Top Y、对标Top3、客单价分析、漏斗分析、需求验证、Google Trends 比对、社媒声量、DTC可行性、金之泰诊断、Kimtex诊断。
version: 2.0.0
---

# Alibaba 国际站品类调研 / 店铺诊断专家

> 本 skill 由 QoderWork 版 `alibaba-shop-diagnostic` v1.0.0 转换而来，v2.0.0 由空压机/棒球帽两次品类大盘实测压测后固化。
> **转换要点（务必牢记）**：原版数据采集层写死了 QoderWork 独有的 `javascript_tool` / `tabs_create_mcp` / `navigate` / `read_network_requests` —— 这些在 Accio Work 环境**不存在**。
> 本环境的等价能力是：**① 国际站后台 MCP（结构化、首选）** + **② `browser` 子代理（操控用户已登录 Chrome，补 JS 渲染字段）** + **③ `general` 子代理 web_search/web_fetch（需求侧/市场规模/跨渠道）**。
> 方法论内核（ABC 数据源等级 / ≥2 源交叉 / 反幻觉黑名单 / 数学验算 / scroll-margin-top）**原样保留**。
>
> **v2.0.0 新增（务必读全）**：
> 1. **品类大盘调研工作流**（区别于单店诊断）：供给侧通用品类关键词 `recall_icbu` 会**返空** → 供给侧**必须走 browser 子代理爬 alibaba 搜索页/productlist**，不能靠 supplier_verification（那只适用于已知店铺画像）。
> 2. **跨渠道需求验证整章**：Google Trends + 社媒(YouTube/Reddit/TikTok) + Shopify/独立站 DTC，用于验证「真实热度 + 消费决策语言 + 独立站可行性」。
> 3. **证据动作分级 + 审计的审计**：见〈原则 1〉与〈Phase 5〉——这是 v2 最痛的教训，**禁止把"web_search 见标题"写成"web_fetch 回访确认"**。

## 适用场景

任何关于阿里巴巴国际站（alibaba.com）的品类调研 / 店铺诊断 / 竞品对标任务。典型问题：

- "做一份 [品类] 品类调研报告"
- "我家店铺在 Top X，怎么冲到 Top Y？"
- "对比 Top 3 对手，我差在哪里？"
- "为什么我的转化/客单价这么低？"
- "诊断我的国际站表现"

## 核心原则（违反任何一条 = 严重审计事件）

### 原则 1：数据源等级制（A++→A+→A→B→C）

| 等级 | 类型 | 用途 | 是否可直接入报告 |
|---|---|---|---|
| A++ | 一手研究机构报告，且 `web_fetch` 回访 200 读到原文数字（GVR/Mordor/Fortune BI 等） | 市场规模/CAGR | ✅ 可直接（≥3 家） |
| A+ | 国际站后台 MCP 结构化响应（supplier_verification_* / get_seller_basic_info / 数据参谋类） | 关键论断 | ✅ 可直接 |
| A | browser 子代理在真实页面实测的 DOM 字段（SKU 计数/视频/翻页/销量 label）；或 `web_fetch` 200 读到正文的 DTC 品牌站/评测页 | 关键论断 | ✅ 可直接 |
| B | 用户提供的 xlsx 行业数据汇总 / 多源印证的趋势方向 / Google Trends 相对热度方向 | 趋势/排序背景 | ⚠️ 仅作背景，**不能单源直接落论断** |
| C | WebSearch snippet（仅见标题/摘要未读正文） / 子代理二手摘要 / 浏览器肉眼描述 / 无法回访的来源 | 仅作线索 | ❌ **绝对禁止单源直接入报告** |

**事故案例（金之泰 v1）**：把"子代理 page-text 浅层观察"（0视频/16SKU/店铺空荡）直接落表，导致 12+ 处事实错误，核心诊断被推翻。**根因**：xlsx 字段 + 二手摘要 ≠ 真实数据。

#### 🔑 证据动作分级（v2 核心铁律 —— 防"措辞性审计幻觉"）

数据等级取决于**你实际做到的动作**，不是你打算做的动作。声明措辞必须严格对应动作，**禁止升级措辞**：

| 你实际做的动作 | 允许的措辞 | 数据等级 |
|---|---|---|
| `web_fetch` 返回 200 且读到正文原文 | "已 fetch 回访确认，原文实录" | A / A++ |
| `web_search` 见到标题/摘要，但未 fetch 到正文 | "搜索见标题/摘要，正文未读" | **C（仅佐证）** |
| 子代理转述、肉眼描述、估计值 | "子代理转述，待回访" | C |
| `web_fetch` 返回 content_empty / 4xx / 5xx | "回访失败，不可访问" | ❌ 剔除 |

> **事故案例（空压机 v2）**：报告把 Reddit 帖写成"web_fetch 回访确认真实"，但实际只 web_search 见到标题、正文 fetch 返回 content_empty。用户一句"真实审计幻觉了吗"逼出此措辞幻觉。**根因**：把低等级动作（搜索见标题）写成高等级措辞（fetch 回访确认）。
> **铁律**：Reddit / 部分社媒站对爬虫常返 content_empty，**见标题 ≠ 读正文**；做不到 fetch 正文就老实标 C 级"仅搜索见标题佐证"，痛点写成"方向"而非"逐字引用"。

> 🔁 **本环境关键升级**：原版必须靠 `javascript_tool` 一字段一字段爬的「16 项店铺基础字段」，现在 **`supplier_verification_recall` 一次调用即可返回大部分（seller_score / 认证 / 年限 / 注册年 / 厂房面积 / 员工数 / 主营类目 / 主市场 / 主推产品）**，且来自后台结构化数据 → **天然消除 4 类黑名单幻觉**（认证幻觉 / 二手摘要 / 机构名幻觉 / SKU 误判中的资质部分）。能用 MCP 拿到的字段，**禁止再退回页面肉眼描述**。

### 原则 2：店铺基础数据采集顺序（MCP 优先 → browser 补缺）

**第一顺位（A+ 级，必先做）**——用国际站后台 MCP：

```
supplier_verification_recall(supplier_name="<店铺URL或公司名>", top_k=5)
  → 从 payload.recall_icbu[0] 直接取：
      seller_score（国际站评分/星级）
      management_certifications + product_certifications（认证清单）
      years_in_industry（Gold/经营年限）+ established_year（注册年）
      facility_area_sqm（厂房面积）+ employees（员工数）
      main_category / main_products（主营类目/主推品）
      trade_regions（主市场分布）
      business_type / contact_country/province/city
  → 从 payload.candidates[].company_id 拿到 comp_id
  → 可选：supplier_verification_detail(comp_id_list=["..."]) 取更细字段
  → 可选：get_seller_basic_info 取主营类目/最近消息等接待侧信息
```

**第二顺位（A 级，MCP 取不到的 JS 渲染字段才用）**——spawn `browser` 子代理实测：

下列字段后台 MCP 通常不返回，必须 browser 子代理在真实页面 DOM 实测：
- 全店分类树 / SKU 总数 / productlist 翻页指示符（productlist.html 侧边栏 + 卡片计数 + 分页）
- 主页产品卡数
- 视频字段（video tag / duration label `/00:\d{2}/` / play icon）
- 主推产品销量 label（如 "130,056 sold"）
- 累计交易额 / 累计订单数（Performance 模块，若 MCP 未返回）
- 准时发货率 / 响应时间（若 MCP 未返回）

> browser 子代理任务必须明确：目标 URL、要数的字段、返回 JSON 结构、以及「数不到的字段如实写 null 不许猜」。详见下文〈browser 子代理调用规范〉。

### 原则 3：爬不到时强制实质验证（不允许放弃 / 不允许 C 级填空）

某字段在 MCP + browser 都拿不到时，按序兜底：

1. MCP 换关键词重试（公司名 ↔ 店铺 URL ↔ company_id 三种入参）
2. spawn browser 子代理在真实页面 DOM 实测（含翻页、网络请求捕获）
3. `web_fetch` 拉 HTML 静态部分
4. 仍无 → 报告中**标注"未取得 A 级数据，置信度=低，待补"**
5. ❌ 禁止用 WebSearch snippet / 肉眼描述间接数据填空

### 原则 4：≥2 源交叉验证

每个关键数据点（市场规模/CAGR/竞品排名/客单价）必须 ≥2 源验证：

- 市场规模：≥3 家研究机构（Fortune BI / GMI / Precedence / FMI / Mordor / Statista）— 且每家必须拿到可访问 URL（防机构名幻觉）
- 竞品排名：xlsx 排序 + 当家店铺 MCP/DOM 实测交叉对账
- 客单价：累计交易额 ÷ 累计订单数（数学验算）
- 店铺基础字段：MCP recall_icbu 与 browser DOM 双源对账（如评分、认证）

### 原则 5：用户判断驱动复核

用户对任何数据/结论提出质疑（"这个数据看起来不对"、"老店不应该这样"），必须**立即重采（MCP 重调 + browser 重爬）+ 重写**，不能"再确认一遍"了事。事故案例：用户挑出"2★星级错误"后重爬发现 12+ 处错误。

## browser 子代理调用规范（替代 QoderWork 的 tabs_*/javascript_tool）

> ⚠️ 本环境**没有** `javascript_tool` / `tabs_create_mcp` / `tabs_context_mcp` / `navigate` / `read_network_requests` / `tabs_close_mcp`。
> 一切「打开页面、跑 JS、数 DOM、看 XHR」的需求，统一用 `sessions_spawn(agent_id="browser", task=...)`。browser 子代理持有用户已登录的 Chrome 会话，内部自行管理 tab，无需也不应在 skill 层写死任何 tab 工具名。

### 调用模板（一店一 spawn，多店并行）

```
sessions_spawn(
  agent_id="browser",
  label="爬 <店铺名> 基础字段",
  task="""
  打开 https://<shop>.en.alibaba.com/productlist.html 与 company_profile.html，
  在真实渲染后的页面用 DOM 实测下列字段，逐字段返回 JSON（数不到写 null，禁止猜测）：
  - sku_total: 侧边栏全部分类 SKU 合计 + productlist 翻页总页数推算
  - category_tree: 侧边栏分类名数组
  - product_card_count_homepage: 主页产品卡数
  - video_count: <video> 标签数 + 含 duration label(/00:\\d{2}/) 的卡片数
  - top_product_sold: 主推产品 "xxx sold" 数字
  - on_time_delivery / response_time: Performance 模块（若页面有）
  - cumulative_trade / cumulative_orders: 累计交易额/订单数（若页面有）
  每个字段附上 source_url + 截图（可选）。最后回传一个 JSON 对象。
  """
)
```

### 反踩坑（沿用原版经验，适配本环境）

- 一个 browser spawn 只干一件事（一个店 / 一组字段），多店并行 spawn（≤8 个）
- 任务里务必写明"数不到的字段如实写 null，禁止用页面文字描述当数据"——这是防 C 级污染的关键
- selector 经验仍适用：产品卡 `[class*=product-card]` / `[class*=organic-list-offer]` / `[class*=offer-card]`；评分正则 `/\d+\.\d+\s*\/\s*5/`；视频 duration `/00:\d{2}/`
- alibaba 三类错误页：`error404.htm` / `search.html` 跳 404 / 分页 anchor 是 JS 渲染（必须真实渲染后再数）

## 两种任务模式（路由先判断）

本 skill 支持两类任务，**Phase 0 必须先判断走哪条主线**，采集链不同：

| 模式 | 触发信号 | 供给侧采集 | 需求侧采集 |
|---|---|---|---|
| **A. 单店/竞品诊断** | "诊断我的店"、"对标 Top3"、"为什么排名靠后" | 已知店铺 → `supplier_verification_recall`（A+） | xlsx + 行业大盘 |
| **B. 品类大盘调研** | "做 [品类] 品类调研"、"选品"、"蓝海挖掘"、"[品类] 值不值得做" | 通用品类关键词 → **browser 爬搜索页**（见下，⚠️ 不能用 supplier_verification） | **跨渠道需求验证**（见下） |

> ⚠️ **v2 血泪铁律**：模式 B 的供给侧，`supplier_verification_recall("空压机")` 这类**通用品类关键词会返空**——该接口只对**已知店铺画像**有效。品类大盘供给侧**必须 spawn browser 子代理爬 alibaba 搜索页 / productlist**。

## 品类大盘供给侧采集（模式 B 专用）

spawn `browser` 子代理爬 `alibaba.com/trade/search?SearchText=<品类英文词>` 与各机型词搜索页，实测：

- 各机型/款式在售商品量级（搜索结果计数）→ 判断红海/蓝海
- 功率段/规格段 × 价格带分布
- 头部供应商认证密度（CE/ISO/能效等占比）→ 判断准入门槛
- 红海信号：某规格搜索结果 8000+ 且认证>90% 已成标配
- 蓝海信号：某高端/合规/细分规格在售少、单价高、认证稀缺

> 模板见〈browser 子代理调用规范〉，把 task 的目标 URL 改为搜索页，字段改为"机型分布/价格带/认证密度/在售量级"。

## 跨渠道需求验证（模式 B 专用 · v2 新增整章）

在 Amazon / 工业 B2B 之外，**并行 spawn 3 个 `general` 子代理**补三路需求信号，验证「真实热度 + 消费决策语言 + 独立站可行性」。消费品 + 工业品两端按需裁剪。

### 三路子代理任务（并行 spawn ≤8）

1. **Google Trends 趋势**：消费端词(portable/tire inflator) + 工业端词(screw/rotary) 近 5 年相对热度方向、季节性、地区分布、上升查询词。
   > ⚠️ **必须在 task 里写死**："Google Trends 只输出 0–100 相对热度指数，**只给趋势方向、季节峰值、上升词，禁止给 CAGR/同比/环比百分比**"。否则子代理会把市场报告增长率硬套到 Trends → 伪增长率幻觉。
2. **社媒声量**：YouTube 评测播放量级 + 博主 + 决策关注点；Reddit 真实痛点/品牌口碑；TikTok 种草方向。
   > ⚠️ task 里写死："每条附可访问 URL；Reddit/社媒正文 fetch 不到就标'仅搜索见标题'，**禁止把见标题写成读正文**；播放量/hashtag 量级无法回访就标估计值不引用具体数字。"
3. **Shopify/独立站 DTC**：消费端 DTC 品牌(站名/URL/价格带/卖点话术) + 工业端是否走 DTC + 可行性结论。
   > ⚠️ task 里写死："每个品牌必须附可访问官网 URL；打不开/无法确认的不许列入；价格/卖点必须页面实录。"

### 子代理产出回收后，主 Agent 必做审计（不可省）

子代理产出**一律先审计再入报告**，重点剔除：
- Google Trends 来源的任何 CAGR/同比/环比百分比 → 剔除，只留方向
- 可疑机构名（Intel Market Research / Accio Business Trends / 任何无法 web_fetch 回访的机构）→ 剔除或降 C 级
- 拼凑/打不开的 URL（web_fetch content_empty / 4xx）→ 剔除
- 估计值播放量/hashtag 量级 → 不引用数字
- **抽样 web_fetch 回访** DTC 品牌站 + 抽样 web_search 复核视频播放量 → 坐实后才标 A 级

### 跨渠道章节产出（HTML）

新增「跨渠道需求交叉验证」section：3.1 Google Trends 方向表（标 B 级、注明非增长率）/ 3.2 社媒声量+消费决策语言表（决策语言英文原话→listing 文案映射；Reddit 按真实证据等级标 C）/ 3.3 DTC 可行性（消费端可行 vs 工业端不可行，品牌站附回访标记）。

## 工作流（5 个 Phase）

### Phase 0：参数确认（强制 ask_user）

**禁止跳过**。用 `ask_user(mode="form")` 一次问清：

1. 任务类型（品类调研 / 单店诊断 / Top竞品对标）
2. 诊断范围（核心品类深度 / 全店扫描 / 单品类深挖）
3. 侧重点（诊断型 / 增长策略型 / 选品型）
4. 输出格式（HTML 交互式 / docx / md）

> 原版写的 `AskUserQuestion` 在本环境叫 `ask_user`。

### Phase 1：客户店铺底层数据采集（MCP 优先）

1. `supplier_verification_recall(店铺URL)` → 取 recall_icbu 全字段（A+ 级）
2. 缺的 JS 字段 → spawn browser 子代理爬 productlist / company_profile / 主页（A 级）
3. **输出**：含字段 + 数据源等级 + 实测时间戳 + URL 的实测表，为下一 Phase 提供基线

### Phase 2：Top 竞品同口径对标

1. 按 xlsx 排名 / 品类搜索锁定 Top 3-5 对手店铺
2. **每个对手都走与 Phase 1 完全相同的采集链**（先 MCP recall，再 browser 补缺）——这就是"同口径"
3. **输出**：横向对比表（≥10 维度：评分/评论/响应/准时率/累计交易/累计订单/客单价/认证组合/品类聚焦度/单品最高销量）

### Phase 3：诊断与漏斗

- 漏斗：DUV → 点击 → 询盘 → 成单
- 客单价对标（累计交易 ÷ 累计订单 = 数学验算）
- 关键词矩阵失位 / Win-Loss 列表
- 品类聚焦度（侧边栏分类数 vs 头部对手）

### Phase 4：报告产出（HTML）

#### HTML 必备 CSS（防 sticky nav 锚点白屏）

```css
nav { position: sticky; top: 0; z-index: 100 }
section { margin: 2.4rem 0; scroll-margin-top: 80px }
h2, h3 { scroll-margin-top: 80px }
```

`scroll-margin-top` 是关键——缺它点击导航锚点后 section 顶部被 sticky nav 遮挡，看起来"白屏"（金之泰 v2 事故）。

#### 报告必备章节

1. 顶部审计声明（数据采集时间戳 + 数据源等级标注 + MCP/browser 来源标注）
2. 客户画像（Phase 1 实测表）
3. 行业大盘（用户 xlsx + ≥3 机构市场规模）
4. 竞争格局（Phase 2 横向对比）
5. 深度诊断（漏斗 + 客单价）
6. 行动计划
7. 审计日志（数据源等级表 + URL 实测结果 + 每字段 MCP/browser 来源）

### Phase 5：全文实质审计（强制可交付级）

#### 必做的 5 项实质审计

| 审计项 | 验证方法 |
|---|---|
| URL 回访 | 抽 6-10 条引用 URL，`web_fetch` 实际打开验证响应 200 + 内容存在 |
| 数学验算 | 客单价 = 累计交易 ÷ 累计订单；漏斗倒推；占比合 100% |
| 逻辑一致性 | 行文论断与 KPI 表/对比表/审计表三处一致 |
| 数据源等级标注 | 每个 KPI 标 A++/A+/A/B/C 等级 + 来源工具（MCP 工具名 / browser / fetch / search）+ URL + 时间戳 |
| **证据动作分级核对** | 每条"已回访确认"声明，核对实际是 fetch 读正文还是仅 search 见标题；后者一律降 C 级 |
| **Trends 伪增长率扫描** | 全文搜 Google Trends 来源的 CAGR/同比/环比百分比 → 全部剔除，只留方向 |
| **机构名回访** | 每个研究机构名必须有可 web_fetch 200 的 URL；无法回访的机构名（Intel Market Research / Accio Business Trends 类）剔除 |
| 错误清单纠错对照 | 如有 v1→v2 修订，必须在审计章节列对照表 |

#### 🔁 审计的审计（v2 新增 · 被质疑时强制执行）

当用户质疑"审计是不是也幻觉了 / 真实审计幻觉了吗"时，**必须当面重跑复验，不许再口头保证一遍**：

1. 列出报告中所有"已回访确认"的来源
2. 对每条**现场重跑** `web_fetch`（读正文）或 `web_search`（核对数字），把返回原文与报告写法逐条对照
3. 凡是对不上 / fetch 返 content_empty 的 → 立即在报告降级措辞 + 审计日志补"自查发现并更正"行
4. 复验动作本身要留痕到审计日志（"审计的审计 复验 PASS / 已降级"）
5. 写入 MEMORY 防再犯

#### 反幻觉检查清单

- [ ] 所有市场规模 ≥3 家机构，每家附可访问 URL
- [ ] 所有 KPI 附来源工具 + URL + 时间戳
- [ ] 客户店铺基础字段优先来自 MCP（A+），MCP 缺失项才标 browser（A）
- [ ] Top 竞品数据全部同口径采集（同样 MCP→browser 顺序）
- [ ] 数学验算自洽（客单价/漏斗/占比）
- [ ] 锚点跳转无白屏（含 `scroll-margin-top`）
- [ ] 死链已剔除引用
- [ ] 单源数据已标 ⚠️ 弱源
- [ ] 无 Intel Market Research / Goorin 1895 等机构幻觉
- [ ] 无任何 C 级数据单源落论断

#### 用户驳回机制

用户交付后挑出**任何**数据错误（哪怕一处），必须：

1. 立即重采该字段（MCP 重调入参 / browser 重爬 DOM）验证
2. 确认错误后全面扫描类似来源数据是否同样错
3. 重写相关章节
4. 审计日志附 "v1→v2 纠错对照表"
5. 写入 MEMORY 防再犯

## 错误模式黑名单（曾发生过的事故，绝对不能再犯）

| 错误模式 | 发生场景 | 本环境防御措施 |
|---|---|---|
| xlsx 字段直接落表 | 金之泰 v1：xlsx 月 GMV ¥163,287 误为"国际站累计交易额" | 必区分 xlsx 月数据 vs 国际站累计；累计走 browser Performance 模块实测 |
| 二手摘要 = 0 视频 | 金之泰 v1：page-text 浅层观察 → 误为 0 视频 | 必 browser 子代理直查 `<video>` + duration label，禁止肉眼描述 |
| 16 SKU 错误 | 金之泰 v1：未爬 productlist 分页 | 必 browser 爬侧边栏 + 第 1 页 cards + 翻页指示符 |
| BSCI 认证幻觉 | 金之泰 v1：xlsx 标 BSCI+SMETA → 实仅 Sedex+Oeko-Tex | ✅ 现走 `supplier_verification_recall` 的 management/product_certifications 字段（MCP 结构化，幻觉风险≈0） |
| 机构名幻觉 | 太阳能路灯报告：Intel Market Research（Intel 是芯片公司） | 必拿可访问 URL 实测（web_fetch 回访） |
| 创始年份幻觉 | Goorin Bros 1895 实际页面 404 | 必拿可访问 URL；店铺注册年走 MCP established_year |
| Tab 切换 bug | QoderWork `newTab:true` 覆盖用户 tab | ✅ 本环境不直接控 tab，统一 spawn browser 子代理，无此风险 |
| 锚点白屏 | sticky nav 遮挡 section h2 | 必加 `scroll-margin-top: 80px` |
| 工具名幻觉 | 误用 QoderWork 的 javascript_tool/tabs_* | 本环境只用 MCP + browser 子代理 + web_fetch；不存在的工具一律不调 |
| **Trends 伪增长率（v2）** | 空压机 v2：子代理把市场报告 CAGR 套到 Google Trends，编出"同比60%/环比57%" | Trends 只给方向；审计阶段全文剔除任何 Trends 来源的 CAGR/同比/环比 |
| **措辞性审计幻觉（v2）** | 空压机 v2：Reddit 帖只 search 见标题，却写成"web_fetch 回访确认正文" | 证据动作分级：见标题=C 级"仅搜索佐证"，禁止升级措辞；被质疑必当面重跑 |
| **通用品类供给侧空召回（v2）** | `supplier_verification_recall("空压机")` 返空仍硬凑供给侧 | 品类大盘供给侧必走 browser 爬 alibaba 搜索页/productlist，不靠 supplier_verification |
| **可疑机构名（v2）** | Accio Business Trends / ScrewCompressorView / Fortune 数字笔误 | 机构名必须 web_fetch 200 回访坐实；子代理转述的数字主 Agent 二次核验 |

## 触发词

品类调研、跨境电商品类调研、品类大盘、选品调研、蓝海挖掘、店铺诊断、Alibaba 国际站诊断、Top X 冲 Top Y、对标 Top 3、漏斗诊断、客单价分析、需求验证、Google Trends 比对、社媒声量、DTC 可行性、店铺为什么排名靠后、店铺增长策略、国际站旺铺诊断、金之泰诊断、Kimtex 诊断。

## 验证（执行完成后必须能回答）

- 客户店铺基础字段是否优先来自 MCP（A+），缺失项才用 browser（A）？
- Top 3-5 竞品是否与客户店铺**同口径**采集？
- 客单价数学验算是否自洽？
- HTML 锚点跳转是否无白屏？
- 数据源等级 + 来源工具标注是否覆盖每个 KPI？
- 用户挑战时能否在 5 分钟内用 MCP/browser 二次验证？
- 全程是否未调用任何本环境不存在的工具（javascript_tool / tabs_*）？

## 记忆点

- 国际站费率：0% 销售佣金 + 年费 ¥29,800 + P4P CPC 均 ¥2.8
- alibaba.com URL 模式：`{shop}.en.alibaba.com/company_profile.html` / `productlist.html`
- 金之泰 = Zhenjiang Kimtex Industrial Inc. / company_id 50016347 / seller_score 4.6 / sedex+Oeko-Tex 100 / 2005 年 / 厂房 3265㎡ / 43 人
- 接口陷阱见同目录 `reference/mcp-interfaces.md`

### 已验证案例（模式参考，新案例可比对）
- **棒球帽**（消费品 / 模式 B）：`project/category_research_baseballcap/`
- **空压机**（工业品 / 模式 B / 跨渠道验证完整版）：`project/category_research_aircompressor/air_compressor_category_research.html`
  - 工业品需求侧拆三线：Amazon 消费端 + 欧美工业 B2B + 新兴市场，再叠跨渠道(Google/社媒/DTC)
  - 红海：便携胎压泵/小型直连机（在售量级大、认证已标配）；蓝海：高端螺杆/无油静音/能效合规细分（在售少、单价高、认证稀缺）
  - DTC 结论：消费端便携机适合独立站(getairmoto.com 实测可行)；工业大件不适合 DTC
  - 真实可引用源：getairmoto.com(fetch 200 实录)、Project Farm GT160 评测 2.4M 播放(search 确认)
  - 已剔除幻觉：Trends 伪增长率、不可访问 URL、可疑机构名、Reddit 措辞幻觉(见黑名单)
