# MCP 接口契约 · 国际站品类调研/店铺诊断

> 本环境（Accio Work）真实存在的国际站后台 MCP 接口。替代 QoderWork 的 javascript_tool DOM 爬取。
> 所有接口通过 `accio-mcp-cli call <tool> --json '{...}'` 调用（bash 或 bash 子代理）。
> ⚠️ 单引号包裹 --json，防 shell 转义。

## 一、店铺/竞品基础数据（核心，替代原 16 项 DOM 字段）

### `supplier_verification_recall` — 召回供应商候选 + 基础画像【首选】
- toolkit=alibaba, toolkit_service=supplier-verification-report
- 入参：
  ```json
  { "supplier_name": "https://kimtex.en.alibaba.com/", "top_k": 5 }
  ```
  - `supplier_name` 可传：店铺 URL（自动归一化取公司 token）/ 公司全名
  - `top_k` 默认 50，最大 100
- 返回（实测 kimtex）：
  - `payload.candidates[]`：每个含 `company_id`（部分含 name/score/minisite/seller_score）
  - `payload.recall_icbu[0]`：**国际站结构化基础画像，直接入报告（A+ 级）**：
    | 字段 | 含义 | 对应原版 16 项 |
    |---|---|---|
    | `seller_score` | 国际站评分（如 "4.6"） | #1 星级/评分 |
    | `management_certifications` | 管理体系认证（如 "sedex"） | #10 认证清单 |
    | `product_certifications` | 产品认证（如 "Oeko-Tex 100"） | #10 认证清单 |
    | `years_in_industry` | 行业年限（如 "17"） | #2 Gold 年限 |
    | `established_year` | 成立年（如 "2005"） | #3 注册日期 |
    | `facility_area_sqm` | 厂房面积（如 "3265.0"） | #3 Floor space |
    | `employees` | 员工数（如 "43"） | #11 规模 |
    | `main_category` | 主营类目 | #7 |
    | `main_products` | 主推产品（逗号串） | #8 |
    | `trade_regions` | 主市场分布（逗号串） | #4 主市场 |
    | `business_type` | 经营类型（如 "Combined"） | — |
    | `contact_country/province/city` | 地址 | — |
  - `payload.recall_out[]`：工商注册信息（注册资本/法人/经营范围/状态）—— 背景增强，非国际站口径，标注清楚

### `supplier_verification_detail` — 按 company_id 拉详情
- toolkit=alibaba, toolkit_service=supplier-verification-report
- 入参：`{ "comp_id_list": ["50016347"] }`
- 用途：recall 拿到 company_id 后补更细字段（映射 RLab app ICBU_P0715_314218C67）

### `get_seller_basic_info` — 商家基本信息（接待侧）
- toolkit=alibaba, toolkit_service=icbu-reception-mcp-service
- 返回：商家基本知识、主营类目、最近发送的消息
- 用途：补主营类目/接待活跃度

## 二、MCP 拿不到 → 必须 browser 子代理实测的字段

后台 MCP **不返回**以下 JS 渲染字段，必须 `sessions_spawn(agent_id="browser", ...)`：
- 全店分类树 / SKU 总数 / productlist 翻页指示符
- 主页产品卡数
- 视频字段（video tag / duration label / play icon）
- 主推产品销量 label（"xxx sold"）
- 累计交易额 / 累计订单数（Performance 模块）
- 准时发货率 / 响应时间

> browser 子代理任务模板见 SKILL.md〈browser 子代理调用规范〉。

## 三、调用陷阱与兜底

| 陷阱 | 现象 | 兜底 |
|---|---|---|
| MCP 当天不稳定 | 40-90s 超时频发 | 单条 90s 超时 + 重试 2 次 + 串行，不要并发轰接口 |
| recall 召回不准 | 传公司名召回多家同名 | 优先传店铺完整 URL；用 minisite_url 比对锁定正确 company_id |
| `recall_out` 口径混淆 | 工商注册 ≠ 国际站口径 | 入报告时标注"工商登记信息（背景）"，不当国际站累计数据 |
| browser 子代理返回二手描述 | 子代理用 page-text 描述当数据 | 任务里强制"数不到写 null，禁止文字描述充当数据" |
| 累计交易/订单缺失 | MCP 不返回 | browser 爬 Performance 模块；仍无标"置信度=低，待补" |

## 四、最小采集链（单店 · 模式 A）

```
1. supplier_verification_recall(店铺URL, top_k=5)
   → recall_icbu[0] 取 A+ 级基础字段
   → candidates 锁定正确 company_id（用 minisite_url 对账）
2. (可选) supplier_verification_detail(company_id) 补细节
3. spawn browser 子代理爬 productlist/company_profile/主页
   → 补 SKU/视频/销量/累计交易等 A 级 DOM 字段
4. 双源对账（MCP recall vs browser DOM）→ 落 Phase 1 实测表
```

## 五、品类大盘采集链（模式 B · v2 新增）

> ⚠️ **关键真相**：`supplier_verification_recall("空压机")` / `recall_icbu` 这类**通用品类关键词会返空**——该接口只对**已知店铺画像/公司名/店铺 URL** 有效，不能用来扫品类大盘供给侧。

```
供给侧（必走 browser，不用 supplier_verification）：
1. spawn browser 子代理爬 alibaba.com/trade/search?SearchText=<品类英文词>
   + 各机型/规格词搜索页
   → 实测：在售商品量级 / 功率段×价格带分布 / 认证密度 → 判断红海/蓝海

需求侧（并行 spawn 3 个 general 子代理，跨渠道交叉验证）：
2a. Google Trends 趋势（task 写死：只给方向/季节/上升词，禁给 CAGR/同比/环比）
2b. 社媒声量 YouTube/Reddit/TikTok（task 写死：附 URL；正文 fetch 不到标"仅搜索见标题"）
2c. Shopify/独立站 DTC（task 写死：每品牌附可访问官网 URL，价格/卖点页面实录）

市场规模（≥3 机构）：
3. general 子代理 web_search 找 GVR/Mordor/Fortune BI 等机构报告
   → 主 Agent 逐家 web_fetch 200 回访读原文数字（A++ 级）
   → 口径冲突必须披露；无法回访的机构名一律剔除

审计（主 Agent 必做，不可省）：
4. 剔除 Trends 伪增长率 / 可疑机构名 / 打不开 URL / 估计值数字
   抽样 web_fetch 复核 DTC 站 + web_search 复核视频播放量
   证据动作分级：见标题=C 级，禁止写成 fetch 回访确认
```

### 子代理产出二次核验（v2 铁律）
子代理转述的**数字 + 机构名**主 Agent 必须二次核验（空压机案例拦下假机构名 Intel Market Research / Accio Business Trends / ScrewCompressorView + Fortune 数字笔误）。
