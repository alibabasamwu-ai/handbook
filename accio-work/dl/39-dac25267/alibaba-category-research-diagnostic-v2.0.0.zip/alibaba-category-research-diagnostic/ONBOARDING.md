# 安装与冷启动提示词 · alibaba-category-research-diagnostic v2.0.0

> 给**首次安装本 skill 的商家**：把下面〈冷启动提示词〉整段贴给 Agent，作为本 skill 的首条引导。
> 目的：让 Agent 一上来就正确理解用途、强制走完整工作流、不踩两次实测压出来的坑。

---

## 一、安装

1. 把 `alibaba-category-research-diagnostic/` 整个目录放进你的 agent skills 目录
   （通常是 `<agent>/agent-core/skills/`）。
2. 在 `skills.jsonc` 里注册一条（id/name/entryName 都用 `alibaba-category-research-diagnostic`，
   `version` 2.0.0，`enabled` true，`kind` "directory"，`installPath` 填实际绝对路径）。
3. 重启会话或让 Agent 重新加载 skill 列表。
4. **前置依赖**：本 skill 重度依赖 ① 国际站后台 MCP（`accio-mcp-cli`，需店铺已开通）；
   ② `browser` 子代理（用户已登录 Chrome）；③ `general` 子代理 web_search/web_fetch。
   三者缺一会触发降级，缺 MCP 时单店模式数据等级会掉到 A 以下，务必先确认可用。

---

## 二、冷启动提示词（整段贴给 Agent）

```
你现在要用 alibaba-category-research-diagnostic skill 做一份品类调研/店铺诊断报告。
开始前先读完它的 SKILL.md 和 reference/mcp-interfaces.md，然后严格遵守下面这些
经两次实测（棒球帽/空压机）压出来的铁律，不要凭直觉跳步：

【路由】先判断任务模式：A=单店/竞品诊断（已知店铺），B=品类大盘调研/选品/蓝海。
两种模式采集链不同（SKILL.md〈两种任务模式〉），别用单店那套去扫品类大盘。

【供给侧·模式B血泪坑】品类大盘的供给侧，supplier_verification_recall("<通用品类词>")
会返空——那个接口只对已知店铺画像有效。品类大盘供给侧必须 spawn browser 子代理
爬 alibaba.com/trade/search 搜索页，看在售量级/价格带/认证密度，判断红海蓝海。

【需求侧·跨渠道交叉验证】消费品/工业品都要做：除 Amazon/工业B2B 外，并行 spawn
3 个 general 子代理补 ① Google Trends ② 社媒(YouTube/Reddit/TikTok) ③ Shopify/独立站DTC。
工业品需求侧再拆三线：Amazon消费端 + 欧美工业B2B + 新兴市场。

【市场规模】必须 ≥3 家研究机构，且每家你都要亲自 web_fetch 200 回访读到原文数字
（A++ 级）。无法回访的机构名一律剔除（曾出现 Intel Market Research/Accio Business Trends
这种编造机构名）。口径冲突必须在报告里披露，不要偷偷取一个。

【证据动作分级·v2 最痛铁律】你写"已回访确认"前先问自己实际做了什么动作：
- web_fetch 读到正文 → 可写"fetch 回访确认，原文实录"（A 级）
- web_search 只见标题/摘要 → 只能写"搜索见标题佐证"（C 级），禁止升级成"fetch 回访确认"
- fetch 返回 content_empty/4xx → 老实标"回访失败，剔除"
Reddit 和部分社媒对爬虫常返 content_empty，见标题≠读正文，别自欺。

【Google Trends 反幻觉】派 Trends 子代理任务时写死"只给趋势方向/季节/上升词，
禁给 CAGR/同比/环比百分比"。Trends 只输出 0-100 相对热度指数，不产出增长率。
审计阶段全文扫一遍，剔除任何 Trends 来源的增长率数字（曾被编出"同比60%"）。

【子代理产出二次核验】子代理转述的数字 + 机构名，你必须亲自二次核验后才入报告，
不要直接照抄（曾拦下假机构名 + 数字笔误）。

【审计的审计】当用户质疑"审计是不是也幻觉了"时，不许再口头保证一遍——必须当面
重跑 web_fetch/web_search 逐条复验，对不上的立即在报告降级措辞 + 审计日志补记，
并写进 MEMORY 防再犯。

【HTML 报告硬规范】每个 h2 加 scroll-margin-top:80px 防锚点白屏；每个 KPI 标
A++/A+/A/B/C 等级 + 来源工具 + URL + 时间戳；必须有独立审计日志章节；用 Chart.js
内联画图（离线可用）。

【参数确认】动手前用 ask_user 确认品类/目标市场/客户店铺URL/报告深度，别自己脑补。

先把以上铁律复述一遍确认你理解了，再 ask_user 确认参数，然后开工。
```

---

## 三、安装后自检（Agent 首次运行应能回答）

- [ ] 能区分模式 A（单店）和模式 B（品类大盘）并选对采集链？
- [ ] 知道品类大盘供给侧不能用 supplier_verification，要走 browser 爬搜索页？
- [ ] 知道 Google Trends 只给方向不给增长率？
- [ ] 能正确区分"fetch 读正文"和"search 见标题"两种证据等级？
- [ ] 市场规模会找 ≥3 机构并逐家 web_fetch 回访？
- [ ] HTML 报告含 scroll-margin-top + 数据源等级 + 审计日志 + Chart.js？
- [ ] 被质疑时会当面重跑复验而非口头保证？

任一项答不上 → 重读 SKILL.md 对应章节再开工。
