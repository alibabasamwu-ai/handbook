# 对话安装提示词 · alibaba-category-research-diagnostic v2.0.0

> 用法:把 `alibaba-category-research-diagnostic-v2.0.0.zip` 上传给你的 Accio Agent,
> 然后把下面〈安装提示词〉整段贴进对话。Agent 会自动解压、注册、自检——你不用碰任何文件。

---

## 安装提示词(整段复制贴给 Agent)

```
我上传了一个 skill 封包 alibaba-category-research-diagnostic-v2.0.0.zip,请你帮我对话安装,全程自动完成,不要让我手动改文件:

1. 用 bash 把这个 zip 解压到你的 agent skills 目录(通常是 <你的agent>/agent-core/skills/);
   先用 list/glob 找到你自己的 skills 目录绝对路径,再解压,确保解压出
   alibaba-category-research-diagnostic/ 这个文件夹(里面有 SKILL.md)。

2. 打开该 skills 目录下的 skills.jsonc,在 skills 数组里追加一条注册项(用真实绝对路径):
   {
     "id": "alibaba-category-research-diagnostic",
     "name": "alibaba-category-research-diagnostic",
     "version": "2.0.0",
     "enabled": true,
     "kind": "directory",
     "entryName": "alibaba-category-research-diagnostic",
     "description": "阿里巴巴国际站品类调研+店铺诊断:品类大盘/跨渠道需求验证/单店漏斗诊断/竞品对标/蓝海挖掘,强制MCP优先+browser补缺+≥3机构回访+证据动作分级+反幻觉审计+HTML报告。",
     "installPath": "<刚才解压出来的 alibaba-category-research-diagnostic 目录绝对路径>"
   }
   注意保持 JSON 合法(逗号、括号),如果已存在同 id 就覆盖更新不要重复添加。

3. 读一遍解压出来的 SKILL.md + reference/mcp-interfaces.md + ONBOARDING.md,
   然后回答这份自检清单(每条都要明确 yes):
   - 能区分模式A(单店诊断)和模式B(品类大盘调研)并选对采集链?
   - 知道品类大盘供给侧不能用 supplier_verification,要走 browser 爬 alibaba 搜索页?
   - 知道 Google Trends 只给趋势方向不给增长率(CAGR/同比/环比)?
   - 能区分"web_fetch 读正文"(A级)和"web_search 见标题"(C级)两种证据等级,且禁止把后者写成前者?
   - 市场规模会找≥3家机构并逐家 web_fetch 200 回访读原文?
   - HTML 报告含 scroll-margin-top + 数据源等级标注 + 独立审计日志 + Chart.js?
   - 被用户质疑"审计是否也幻觉"时,会当面重跑 web_fetch/web_search 复验而非口头保证?

4. 全部就绪后告诉我:skill 已安装在哪个路径、version、enabled 状态,以及我现在可以直接说哪些话来触发它
   (例如"帮我做空压机品类调研"/"诊断我的店铺为什么排名Top10想冲Top3")。

如果某一步失败(比如找不到 skills.jsonc、JSON 写坏),停下来告诉我具体错误,不要假装装好了。
```

---

## 安装后第一次用(可选,直接说需求即可)

skill 装好后无需额外提示词,直接说业务需求就会触发,例如:
- "帮我做 [品类] 的跨境电商品类调研,目标市场美国,要 HTML 报告"
- "诊断我的国际站店铺,为什么排名 Top 10,怎么冲 Top 3"
- "[品类] 在国际站值不值得做,帮我挖蓝海机会"

Agent 会自动按 SKILL.md 的完整工作流(参数确认→采集→跨渠道验证→审计→HTML 报告)执行。
