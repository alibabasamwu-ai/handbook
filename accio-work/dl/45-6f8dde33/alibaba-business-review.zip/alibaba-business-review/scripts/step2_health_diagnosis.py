#!/usr/bin/env python3
"""Step2 跟进健康度诊断 (7+1 信号)"""
import json
import sys
from pathlib import Path
from collections import Counter
from _guard import require_preheat
from scorer import score_health

SKILL_ROOT = Path(__file__).resolve().parent.parent


def main():
    require_preheat()
    inp = sys.argv[1] if len(sys.argv) > 1 else "data/chats.json"
    out = sys.argv[2] if len(sys.argv) > 2 else "reports/step2_health_diagnosis.json"

    data = json.loads((SKILL_ROOT / inp).read_text())
    convs = data["conversations"]
    meta = data.get("meta", {})

    results = [score_health(c) for c in convs]

    status_dist = Counter(r["status"] for r in results)
    signal_dist = Counter()
    for r in results:
        for s in r["signals"]:
            signal_dist[s["name"]] += 1

    out_data = {
        "meta": meta,
        "status_distribution": dict(status_dist),
        "signal_frequency": dict(signal_dist),
        "conversations": results,
    }

    out_path = SKILL_ROOT / out
    out_path.parent.mkdir(exist_ok=True, parents=True)
    out_path.write_text(json.dumps(out_data, indent=2, ensure_ascii=False))
    print(f"✅ Step2 done: {dict(status_dist)} → {out_path}")
    print(f"   Top signals: {signal_dist.most_common(3)}")


if __name__ == "__main__":
    main()
