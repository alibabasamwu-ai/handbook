#!/usr/bin/env python3
"""
Step 5 · 生成买家人工核验 CSV
================================

读取 reports/step1_customer_scoring.json，按 Tier(S→A→B→C→D) + 总分降序输出每个买家一行，
拆出 BANT / Persona / Engagement 三大维度合计分；并自动检测重名，给出"后台搜索建议"。

输出：reports/buyer_verification_table.csv（可直接发给业务员对照阿里国际站后台核验）

设计理由（v1.4 真名版收尾）：
- 看板已恢复真名，但 chat-insight MCP 没有买家 email / aliId / 公司接口，
  需要人工到后台二次核验。这张表是核验的标准入口表。
- 重名买家（同名 ≥ 2）会标 ⚠️ 提示先按国家筛选，避免认错人。

用法：python3 scripts/step5_verification_csv.py [--input reports/step1_customer_scoring.json]
"""
from __future__ import annotations
import argparse, csv, json, sys
from collections import Counter
from pathlib import Path

SKILL_ROOT = Path(__file__).resolve().parent.parent
DEFAULT_INPUT = SKILL_ROOT / "reports" / "step1_customer_scoring.json"
DEFAULT_OUTPUT = SKILL_ROOT / "reports" / "buyer_verification_table.csv"

TIER_ORDER = {"S": 0, "A": 1, "B": 2, "C": 3, "D": 4}

BANT_KEYS = ["BANT_B", "BANT_A", "BANT_N", "BANT_T"]
PERSONA_KEYS = ["Persona_Country", "Persona_Buyer_Type", "Persona_Scale", "Persona_Industry"]
ENGAGEMENT_KEYS = ["Engagement_Velocity", "Engagement_Depth", "Engagement_Commitment"]


def sum_items(items: dict, keys: list[str]) -> int:
    return sum((items.get(k) or {}).get("score", 0) for k in keys)


def build_hint(name: str, country: str, dup_count: int) -> str:
    if dup_count > 1:
        return f"⚠️重名{dup_count}人，先按国家「{country or '—'}」筛选，再用姓名「{name}」搜索"
    base = f"用姓名「{name}」直接搜索"
    if country:
        base += f"（必要时按国家「{country}」验证）"
    return base


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--input", default=str(DEFAULT_INPUT))
    ap.add_argument("--output", default=str(DEFAULT_OUTPUT))
    args = ap.parse_args()

    src = Path(args.input)
    if not src.exists():
        print(f"❌ 找不到评分文件：{src}", file=sys.stderr)
        return 2
    d = json.loads(src.read_text(encoding="utf-8"))
    custs = d.get("customers") or []
    if not custs:
        print("❌ customers 为空，无法生成核验表", file=sys.stderr)
        return 3

    custs.sort(key=lambda c: (TIER_ORDER.get(c.get("tier", "D"), 9), -c.get("total", 0)))

    name_count = Counter((c.get("buyer_name") or "").strip() for c in custs)

    out_path = Path(args.output)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    with out_path.open("w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow([
            "Tier", "Buyer Name", "Country", "Total",
            "BANT", "Persona", "Engagement",
            "Conversation ID", "后台搜索建议",
        ])
        for c in custs:
            items = c.get("items") or {}
            name = (c.get("buyer_name") or "").strip()
            country = c.get("buyer_country") or ""
            w.writerow([
                c.get("tier", ""),
                name, country, c.get("total", 0),
                sum_items(items, BANT_KEYS),
                sum_items(items, PERSONA_KEYS),
                sum_items(items, ENGAGEMENT_KEYS),
                c.get("conversation_id", ""),
                build_hint(name, country, name_count[name]),
            ])
    print(f"✅ 核验表已生成：{out_path} （{len(custs)} 行）")
    return 0


if __name__ == "__main__":
    sys.exit(main())
