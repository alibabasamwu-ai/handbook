#!/usr/bin/env python3
"""实时采集当前店铺近 N 天会话+消息 → data/chats.json

关键：阿里国际站会话按【子账号】隔离。必须先 subaccount_query 拿到所有业务员子账号，
再遍历每个子账号 selfAliId 拉会话+消息，否则只拉主账号会严重漏单。
"""
import json, subprocess, sys, time, html, re
from pathlib import Path

SKILL_ROOT = Path(__file__).resolve().parent.parent
# 主账号 aliId 不写死：由 subaccount_query 自动识别（accountType=main / 首个账号）。
# 这样脚本对任意商家通用，不会用错账号。
DAYS = int(sys.argv[1]) if len(sys.argv) > 1 else 30
NOW_MS = int(time.time() * 1000)
CUTOFF_MS = NOW_MS - DAYS * 86400_000

TAG_RE = re.compile(r"<[^>]+>")
SYS_NOISE = ("翻译功能", "请更新app", "系统消息", "已成为好友", "撤回了一条消息", "转交给你")


def mcp(tool, req, retries=2):
    payload = json.dumps({"request": req}, ensure_ascii=False)
    for attempt in range(retries + 1):
        try:
            p = subprocess.run(["accio-mcp-cli", "call", tool, "--json", payload],
                               capture_output=True, text=True, timeout=120)
            out = p.stdout.strip()
            i = out.find("{")
            return json.loads(out[i:]) if i >= 0 else None
        except Exception:
            if attempt < retries:
                time.sleep(1); continue
            return None


def mcp_noreq(tool):
    """无 request 包裹的调用（subaccount_query 用 {}）。"""
    for attempt in range(3):
        try:
            p = subprocess.run(["accio-mcp-cli", "call", tool, "--json", "{}"],
                               capture_output=True, text=True, timeout=60)
            out = p.stdout.strip(); i = out.find("{")
            return json.loads(out[i:]) if i >= 0 else None
        except Exception:
            time.sleep(1)
    return None


def clean(txt):
    if not txt:
        return ""
    txt = html.unescape(txt)
    txt = TAG_RE.sub(" ", txt)
    return re.sub(r"\s+", " ", txt).strip()


def get_subaccounts():
    """返回 {aliId: 业务员名}。对任意商家通用：从 subaccount_query 动态拿全部账号，
    不写死任何 aliId。若接口异常返回空 dict（调用方会报错提示先检查授权）。"""
    r = mcp_noreq("subaccount_query")
    accts = {}
    if r and r.get("success"):
        for s in r.get("data", []):
            aid = s.get("aliId")
            name = (f"{s.get('firstName','')} {s.get('lastName','')}".strip()
                    or s.get("loginId") or s.get("displayName") or f"账号{aid}")
            if aid:
                accts[aid] = name
    return accts


def fetch_conversations_for(ali_id):
    """拉某子账号近 N 天会话列表（翻页）。"""
    convs, cursor, seen = [], NOW_MS, set()
    pages = 0
    while True:
        r = mcp("query_recent_conversation", {"count": 50, "limitTimeStamp": cursor, "selfAliId": ali_id})
        if not r or not r.get("success"):
            break
        data = r["data"]
        batch = data.get("conversations", [])
        if not batch:
            break
        for c in batch:
            cid = c.get("conversationId")
            if cid in seen:
                continue
            seen.add(cid)
            convs.append(c)
        pages += 1
        nxt = data.get("nextTimeStamp") or 0
        if (nxt and nxt < CUTOFF_MS) or not data.get("hasMore") or pages >= 30:
            break
        cursor = nxt
        time.sleep(0.12)
    return convs


def fetch_messages(cid, ali_id):
    """拉某会话全部消息（forward=true 从最早翻到最新，确保拉全）。"""
    msgs, cursor, seen = [], 1, set()
    for _ in range(15):
        r = mcp("query_conversation_msg", {
            "conversationId": cid, "selfAliId": ali_id,
            "count": 50, "forward": True, "limitTimeStamp": cursor})
        if not r or not r.get("success"):
            break
        data = r["data"]
        batch = data.get("messages", [])
        new = [m for m in batch if m.get("messageId") not in seen]
        for m in batch:
            seen.add(m.get("messageId"))
        msgs.extend(new)
        if not data.get("hasMore"):
            break
        nxt = data.get("nextPointTimeStamp") or data.get("nextTimeStamp")
        if not nxt or nxt == cursor:
            break
        cursor = nxt
        time.sleep(0.1)
    return msgs


def main():
    accts = get_subaccounts()
    staff_ids = set(accts.keys())   # 所有店内账号 → 判定 seller
    print(f"采集近 {DAYS} 天 · 子账号 {len(accts)} 个: {list(accts.values())}", file=sys.stderr)

    # 1) 遍历每个子账号拉会话，记录会话归属业务员（首次出现的账号即 owner）
    conv_owner = {}        # cid -> 业务员名
    conv_owner_ali = {}    # cid -> 业务员 aliId（拉消息用）
    conv_meta = {}         # cid -> 会话基础信息
    for aid, name in accts.items():
        cs = fetch_conversations_for(aid)
        for c in cs:
            cid = c.get("conversationId")
            if cid not in conv_owner:
                conv_owner[cid] = name
                conv_owner_ali[cid] = aid
                conv_meta[cid] = c
        print(f"  {name} (aliId={aid}): {len(cs)} 会话", file=sys.stderr)
    print(f"全店去重会话: {len(conv_meta)} 个，开始拉消息…", file=sys.stderr)

    # 2) 逐会话拉消息（支持 --max-convs N 限量，按会话最近活跃优先，控制采集时长）
    max_convs = 0
    for i, a in enumerate(sys.argv):
        if a == "--max-convs" and i + 1 < len(sys.argv):
            max_convs = int(sys.argv[i + 1])
    items = list(conv_meta.items())
    if max_convs and len(items) > max_convs:
        # 按会话最新消息时间倒序，优先采最近活跃的会话（更有分析价值）
        def _mt(kv):
            return (kv[1].get("latestMessage", {}) or {}).get("timestamp") or kv[1].get("gmtModified") or 0
        items.sort(key=_mt, reverse=True)
        items = items[:max_convs]
        print(f"限量采集：取最近活跃 {max_convs} 个会话", file=sys.stderr)
    conversations = []
    done = 0
    for cid, c in items:
        owner_ali = conv_owner_ali[cid]
        raw_msgs = fetch_messages(cid, owner_ali)
        norm = []
        for m in raw_msgs:
            t = clean(m.get("content"))
            if not t or m.get("isSystemMessage"):
                continue
            if any(n in t for n in SYS_NOISE):
                continue
            role = "seller" if m.get("senderAliId") in staff_ids else "buyer"
            norm.append({"role": role, "text": t,
                         "timestamp": int((m.get("timestamp") or 0) / 1000)})
        norm.sort(key=lambda x: x["timestamp"])
        done += 1
        if done % 50 == 0:
            print(f"  已拉 {done}/{len(items)} 会话…", file=sys.stderr)
        if not norm:
            continue
        conversations.append({
            "conversation_id": cid,
            "buyer_country": c.get("contactCountry"),
            "buyer_name": c.get("contactName"),
            "buyer_email": None,
            "buyer_level": c.get("contactLevel"),
            "tags": c.get("tags", []),
            "subaccount_id": conv_owner[cid],
            "seller_name": conv_owner[cid],
            "messages": norm,
        })

    total_msgs = sum(len(c["messages"]) for c in conversations)
    # 店名 / 主营 不写死：店名可由 --shop 传入，否则留空；主营一律交给 step1 自动推断。
    shop_name = ""
    biz_scope = ""
    for i, a in enumerate(sys.argv):
        if a == "--shop" and i + 1 < len(sys.argv):
            shop_name = sys.argv[i + 1]
        if a == "--biz-scope" and i + 1 < len(sys.argv):
            biz_scope = sys.argv[i + 1]
    meta = {
        "shop": shop_name,                      # 留空则看板用默认"阿里国际站"
        "ali_id_main": sorted(staff_ids)[0] if staff_ids else None,
        "subaccount_count": len(accts),
        "sample_days": DAYS,
        "time_window": time.strftime("%Y-%m-%d", time.localtime(CUTOFF_MS / 1000)) + " ~ " + time.strftime("%Y-%m-%d"),
        "total_conversations": len(conversations),
        "total_messages": total_msgs,
    }
    if biz_scope.strip():                       # 仅在商家显式传入时写；否则 step1 自动推断
        meta["biz_scope"] = biz_scope.strip()
    out = {"meta": meta, "conversations": conversations}
    outp = SKILL_ROOT / "data" / "chats.json"
    outp.parent.mkdir(exist_ok=True, parents=True)
    outp.write_text(json.dumps(out, ensure_ascii=False, indent=2))
    print(f"✅ 写入 {outp}: {len(conversations)} 有效会话 / {total_msgs} 消息", file=sys.stderr)


if __name__ == "__main__":
    main()
