"""
共享评分规则引擎 - 所有评分必须通过此文件，禁止 LLM 自由发挥分数。

包含三套评分器：
- score_customer(conv): BANT + Persona + Engagement (100 分)
- score_health(conv): 7+1 信号
- score_seller(messages): 态度/能力/谈判 三维
"""
import json
import re
from pathlib import Path
from collections import defaultdict
from typing import List, Dict, Any

SKILL_ROOT = Path(__file__).resolve().parent.parent
KEYWORDS = json.loads((SKILL_ROOT / "references/keyword_dictionary.json").read_text())["patterns"]
BENCHMARKS = json.loads((SKILL_ROOT / "references/industry_benchmarks.json").read_text())
TIERS = json.loads((SKILL_ROOT / "memory/market_tier_mapping.json").read_text())
THRESHOLDS = json.loads((SKILL_ROOT / "references/threshold_calibration.json").read_text())


def _compile(pat: dict):
    flags = 0
    if "I" in pat.get("flags", ""):
        flags |= re.IGNORECASE
    return re.compile(pat["regex"], flags)


_COMPILED = {k: _compile(v) for k, v in KEYWORDS.items()}

# 国家代码 → 中文名（用于评分证据白话化）
_COUNTRY_CN = {
    "US": "美国", "CA": "加拿大", "GB": "英国", "UK": "英国", "DE": "德国",
    "FR": "法国", "IT": "意大利", "ES": "西班牙", "NL": "荷兰", "BE": "比利时",
    "CH": "瑞士", "SE": "瑞典", "NO": "挪威", "DK": "丹麦", "FI": "芬兰",
    "AT": "奥地利", "IE": "爱尔兰", "AU": "澳大利亚", "NZ": "新西兰", "JP": "日本",
    "KR": "韩国", "SG": "新加坡", "HK": "中国香港", "IL": "以色列",
    "AE": "阿联酋", "SA": "沙特", "QA": "卡塔尔", "KW": "科威特", "BH": "巴林",
    "OM": "阿曼", "MY": "马来西亚", "TH": "泰国", "TR": "土耳其", "RU": "俄罗斯",
    "PL": "波兰", "CZ": "捷克", "RO": "罗马尼亚", "GR": "希腊", "PT": "葡萄牙",
    "CL": "智利", "AR": "阿根廷", "MX": "墨西哥", "ZA": "南非",
    "IN": "印度", "BR": "巴西", "VN": "越南", "PH": "菲律宾", "ID": "印尼",
    "EG": "埃及", "PK": "巴基斯坦", "BD": "孟加拉国", "NG": "尼日利亚",
    "KE": "肯尼亚", "GH": "加纳", "TZ": "坦桑尼亚", "ET": "埃塞俄比亚",
    "MA": "摩洛哥", "DZ": "阿尔及利亚", "TN": "突尼斯",
}


def _hits(text: str, key: str) -> List[str]:
    if key not in _COMPILED:
        return []
    return _COMPILED[key].findall(text or "")


def _ts_iso(ts):
    """timestamp 转 ISO 字符串。"""
    if not ts:
        return None
    try:
        import datetime as _dt
        return _dt.datetime.utcfromtimestamp(int(ts)).strftime("%Y-%m-%d %H:%M:%S UTC")
    except Exception:
        return str(ts)


def _excerpt(text: str, pat, max_len: int = 160) -> str:
    """从 text 中提取首次命中的 ±60 字符片段。"""
    if not text:
        return ""
    m = pat.search(text)
    if not m:
        return text[:max_len]
    start = max(0, m.start() - 60)
    end = min(len(text), m.end() + 60)
    snippet = text[start:end].strip()
    if start > 0:
        snippet = "…" + snippet
    if end < len(text):
        snippet = snippet + "…"
    return snippet[:max_len]


def _find_evidence(messages: List[Dict], key: str, role_filter: str | None = None,
                   max_quotes: int = 3) -> List[Dict]:
    """从 messages 中找出命中 keyword 的最多 max_quotes 条消息片段。

    Returns: [{"raw_quote", "msg_time", "from", "msg_idx", "tag"}, ...]
    """
    if key not in _COMPILED:
        return []
    pat = _COMPILED[key]
    out = []
    for m in messages:
        if role_filter and m.get("role") != role_filter:
            continue
        if pat.search(m.get("text") or ""):
            out.append({
                "tag": key,
                "raw_quote": _excerpt(m["text"], pat),
                "msg_time": _ts_iso(m.get("timestamp")),
                "from": m.get("role"),
                "msg_idx": m.get("msg_idx"),
            })
            if len(out) >= max_quotes:
                break
    return out


def _sig_quote(messages: List[Dict], key: str, role_filter: str | None = None) -> str:
    """给健康信号提取一条触发该信号的真实原话片段（买家或业务员），供看板「原话引用」展示。
    找不到命中片段时返回空串，看板侧会自动隐藏引用框。"""
    ev = _find_evidence(messages, key, role_filter=role_filter, max_quotes=1)
    if ev:
        return (ev[0].get("raw_quote") or "").strip()
    return ""


def _last_msg_quote(messages: List[Dict], role: str) -> str:
    """取某角色最后一条消息原文（截断），用于「响应超时/断联」这类无关键词的信号。"""
    for m in reversed(messages):
        if m.get("role") == role:
            t = (m.get("text") or "").strip()
            return t[:120] + ("…" if len(t) > 120 else "")
    return ""


def _density(seller_msgs: List[str], key: str) -> float:
    if not seller_msgs:
        return 0.0
    total_hits = sum(len(_hits(m, key)) for m in seller_msgs)
    return total_hits / len(seller_msgs)


def _country_tier(country_code: str) -> int:
    if not country_code:
        return 0
    cc = country_code.upper()
    if cc in TIERS["tier_1_high_value"]["countries"]:
        return TIERS["tier_1_high_value"]["score_bonus"]
    if cc in TIERS["tier_2_growing"]["countries"]:
        return TIERS["tier_2_growing"]["score_bonus"]
    if cc in TIERS["tier_3_emerging"]["countries"]:
        return TIERS["tier_3_emerging"]["score_bonus"]
    return TIERS["tier_4_other"]["score_bonus"]


# ======================================================================
# Customer Scoring
# ======================================================================
def score_customer(conv: Dict[str, Any]) -> Dict[str, Any]:
    """
    conv schema:
      {
        "conversation_id": str,
        "buyer_country": str | None,
        "buyer_email": str | None,
        "messages": [{"role": "buyer"|"seller", "text": str, "timestamp": int}, ...]
      }
    """
    # 给历史 fixture 补 msg_idx（防止旧 fixture 缺该字段时 evidence_v2 缺失）
    for i, m in enumerate(conv["messages"]):
        m.setdefault("msg_idx", i)

    buyer_only = [m for m in conv["messages"] if m["role"] == "buyer"]
    buyer_msgs = [m["text"] for m in buyer_only]
    seller_msgs = [m["text"] for m in conv["messages"] if m["role"] == "seller"]
    buyer_text = " ".join(buyer_msgs)
    all_text = " ".join([m["text"] for m in conv["messages"]])
    all_msgs = conv["messages"]

    result = {"conversation_id": conv["conversation_id"], "items": {}, "evidence": {}}

    # --- BANT-B ---
    if _hits(buyer_text, "budget_high"):
        b, tag = 15, "budget_high"
        ev = "买家主动谈到了大额预算或大批量采购，购买力强、预算意向高"
        ev_v2 = _find_evidence(buyer_only, "budget_high")
    elif _hits(buyer_text, "budget_mid"):
        b, tag = 10, "budget_mid"
        ev = "买家提到了具体的预算或中等批量，有明确采购预算，意向中等"
        ev_v2 = _find_evidence(buyer_only, "budget_mid")
    elif re.search(r"\b\d{2,}\s*(pcs|sets|units|qty|pieces)\b", buyer_text, re.I):
        b, tag = 5, "quantity_only"
        ev = "买家只报了采购数量，没说预算，购买意向偏弱"
        # quantity 不在 keyword_dict，手工捕获
        qty_pat = re.compile(r"\b\d{2,}\s*(pcs|sets|units|qty|pieces)\b", re.I)
        ev_v2 = []
        for m in buyer_only:
            if qty_pat.search(m.get("text") or ""):
                ev_v2.append({"tag": "quantity", "raw_quote": _excerpt(m["text"], qty_pat),
                              "msg_time": _ts_iso(m.get("timestamp")),
                              "from": "buyer", "msg_idx": m.get("msg_idx")})
                if len(ev_v2) >= 3: break
    else:
        b, tag, ev, ev_v2 = 0, None, "买家全程没提任何预算或采购量，无法判断购买力（信息缺失）", []
    result["items"]["BANT_B"] = {"score": b, "max": 15, "evidence": ev, "evidence_v2": ev_v2}

    # --- BANT-A ---
    a = 0
    ev_parts = []
    ev_v2 = []
    domain_m = _COMPILED["company_domain"].search(conv.get("buyer_email") or "")
    has_corp_domain = bool(domain_m and not _COMPILED["free_mail"].search(conv.get("buyer_email") or ""))
    if has_corp_domain:
        a += 5
        ev_parts.append(f"用的是企业邮箱（{domain_m.group(1)}），说明背后有公司，更可能是真实采购方")
        ev_v2.append({"tag": "corporate_email", "raw_quote": f"email domain: {domain_m.group(1)}",
                      "msg_time": None, "from": "buyer_profile", "msg_idx": None})
    if _hits(buyer_text, "authority"):
        a += 5
        ev_parts.append("买家自报是老板/采购负责人等有决策权的角色")
        ev_v2.extend(_find_evidence(buyer_only, "authority"))
    result["items"]["BANT_A"] = {
        "score": a, "max": 10,
        "evidence": "；".join(ev_parts) if ev_parts else "看不出买家是否有决策权，也不是企业邮箱（信息缺失）",
        "evidence_v2": ev_v2,
    }

    # --- BANT-N (4 项 × 3 分) ---
    _N_CN = {"spec": "讲清了产品规格/参数", "scene": "说明了使用场景/用途",
             "market": "提到了目标市场/销售去向", "cert": "问到了认证要求"}
    n = 0
    ev_n = []
    ev_v2 = []
    for tag in ["spec", "scene", "market", "cert"]:
        if _hits(buyer_text, tag):
            n += 3
            ev_n.append(_N_CN.get(tag, tag))
            ev_v2.extend(_find_evidence(buyer_only, tag, max_quotes=1))
    result["items"]["BANT_N"] = {
        "score": n, "max": 12,
        "evidence": ("买家把需求说得比较具体：" + "、".join(ev_n)) if ev_n
                    else "买家没具体说要什么样的产品（没提规格/用途/市场/认证），需求不清晰（信息缺失）",
        "evidence_v2": ev_v2,
    }

    # --- BANT-T ---
    if _hits(buyer_text, "timeline_urgent"):
        t, ev = 8, "买家有明确且紧急的交货时间（比如指定了具体到货日期），下单意愿急"
        ev_v2 = _find_evidence(buyer_only, "timeline_urgent")
    elif _hits(buyer_text, "timeline_mid"):
        t, ev = 5, "买家提到了大致的时间计划，有一定时间预期但不算紧急"
        ev_v2 = _find_evidence(buyer_only, "timeline_mid")
    else:
        t, ev, ev_v2 = 0, "买家没提任何交货或下单时间，看不出采购紧迫度（信息缺失）", []
    result["items"]["BANT_T"] = {"score": t, "max": 8, "evidence": ev, "evidence_v2": ev_v2}

    # --- Persona-Country ---
    cscore = _country_tier(conv.get("buyer_country"))
    _cc = (conv.get("buyer_country") or "").upper()
    _cn_name = _COUNTRY_CN.get(_cc, _cc or "未知")
    if not _cc:
        _country_ev = "买家所在国家未知，无法判断市场价值"
    elif cscore >= 10:
        _country_ev = f"买家来自{_cn_name}，属于高价值核心市场，加满分"
    elif cscore >= 6:
        _country_ev = f"买家来自{_cn_name}，属于成长型市场，价值中上"
    elif cscore >= 3:
        _country_ev = f"买家来自{_cn_name}，属于新兴市场，有一定潜力"
    else:
        _country_ev = f"买家来自{_cn_name}，市场价值一般"
    result["items"]["Persona_Country"] = {
        "score": cscore, "max": 10,
        "evidence": _country_ev,
        "evidence_v2": [{"tag": "country", "raw_quote": f"买家所在国家：{_cn_name}（{_cc or 'unknown'}）",
                         "msg_time": None, "from": "buyer_profile", "msg_idx": None}],
    }

    # --- Persona-Company ---
    cc = 0
    ev_cc = []
    ev_v2 = []
    if domain_m and not _COMPILED["free_mail"].search(conv.get("buyer_email") or ""):
        cc += 7
        ev_cc.append("用企业邮箱，背后有公司实体，正规采购方可能性高")
        ev_v2.append({"tag": "corporate_email", "raw_quote": f"email domain: {domain_m.group(1)}",
                      "msg_time": None, "from": "buyer_profile", "msg_idx": None})
    elif _hits(buyer_text, "scene"):  # 提及公司/项目
        cc += 4
        ev_cc.append("聊天里提到了自己的公司或项目")
        ev_v2.extend(_find_evidence(buyer_only, "scene", max_quotes=2))
    elif conv.get("buyer_email"):
        cc += 2
        ev_cc.append("只留了免费邮箱（如 Gmail），公司背景较弱")
        ev_v2.append({"tag": "free_email", "raw_quote": "buyer used free-mail domain",
                      "msg_time": None, "from": "buyer_profile", "msg_idx": None})
    result["items"]["Persona_Company"] = {
        "score": cc, "max": 10,
        "evidence": "；".join(ev_cc) if ev_cc else "看不出买家的公司背景（信息缺失）",
        "evidence_v2": ev_v2,
    }

    # --- Persona-Category ---
    # 简化：spec 或 cert 词命中即视为精准品类匹配
    ev_v2 = []
    if _hits(buyer_text, "spec") and _hits(buyer_text, "cert"):
        cat = 10
        ev = "买家既讲了产品规格又问了认证，需求和我们品类高度对口"
        ev_v2.extend(_find_evidence(buyer_only, "spec", max_quotes=1))
        ev_v2.extend(_find_evidence(buyer_only, "cert", max_quotes=1))
    elif _hits(buyer_text, "spec") or _hits(buyer_text, "cert"):
        cat = 6
        ev = "买家提到了规格或认证其中一项，品类基本对口"
        ev_v2.extend(_find_evidence(buyer_only, "spec", max_quotes=1) or
                     _find_evidence(buyer_only, "cert", max_quotes=1))
    else:
        cat = 4
        ev = "买家没明确说产品规格或认证，品类匹配度按默认估算（把握不大）"
    result["items"]["Persona_Category"] = {"score": cat, "max": 10, "evidence": ev,
                                            "evidence_v2": ev_v2}

    # --- Engagement-Active ---
    active_n = len(buyer_msgs)
    # 取最早 + 最晚 buyer 消息作为证据
    ev_v2_active = []
    if buyer_only:
        first_b = buyer_only[0]
        ev_v2_active.append({"tag": "first_buyer_msg",
                             "raw_quote": _excerpt(first_b["text"], re.compile(r".+")),
                             "msg_time": _ts_iso(first_b.get("timestamp")),
                             "from": "buyer", "msg_idx": first_b.get("msg_idx")})
        if len(buyer_only) > 1:
            last_b = buyer_only[-1]
            ev_v2_active.append({"tag": "last_buyer_msg",
                                 "raw_quote": _excerpt(last_b["text"], re.compile(r".+")),
                                 "msg_time": _ts_iso(last_b.get("timestamp")),
                                 "from": "buyer", "msg_idx": last_b.get("msg_idx")})
    if active_n >= 5:
        ea, ev = 8, f"买家一共主动发了 {active_n} 条消息，互动很积极"
    elif active_n >= 3:
        ea, ev = 5, f"买家发了 {active_n} 条消息，有来有回，互动尚可"
    elif active_n >= 1:
        ea, ev = 2, f"买家只发了 {active_n} 条消息，互动较少"
    else:
        ea, ev = 0, "买家一条消息都没发，基本没互动"
    result["items"]["Engagement_Active"] = {"score": ea, "max": 8, "evidence": ev,
                                            "evidence_v2": ev_v2_active}

    # --- Engagement-Depth ---
    has_sample = bool(_hits(all_text, "sample"))
    has_pi = bool(_hits(all_text, "pi"))
    ev_v2 = []
    if has_sample:
        ev_v2.extend(_find_evidence(all_msgs, "sample", max_quotes=1))
    if has_pi:
        ev_v2.extend(_find_evidence(all_msgs, "pi", max_quotes=1))
    if has_sample and has_pi:
        ed, ev = 8, "既谈到了打样/样品，又谈到了形式发票(PI)，已经进入实质交易环节"
    elif has_sample or has_pi:
        ed, ev = 5, "谈到了样品或形式发票(PI)其中一项，沟通有一定深度"
    elif "catalog" in all_text.lower():
        ed, ev = 2, "只停留在要目录/报价册阶段，沟通还比较浅"
        catalog_pat = re.compile(r"catalog", re.I)
        for m in all_msgs:
            if catalog_pat.search(m.get("text") or ""):
                ev_v2.append({"tag": "catalog", "raw_quote": _excerpt(m["text"], catalog_pat),
                              "msg_time": _ts_iso(m.get("timestamp")),
                              "from": m.get("role"), "msg_idx": m.get("msg_idx")})
                break
    else:
        ed, ev = 0, "没有任何样品/报价/目录等深入沟通的迹象"
    result["items"]["Engagement_Depth"] = {"score": ed, "max": 8, "evidence": ev,
                                           "evidence_v2": ev_v2}

    # --- Engagement-Channel ---
    ch = len(set(_hits(all_text, "video_meeting"))) if _hits(all_text, "video_meeting") else 0
    ch = min(5, 1 + ch)  # 至少 TM=1
    ev_v2 = [{"tag": "channel_tm", "raw_quote": "TM 旺旺在线沟通（默认渠道）",
              "msg_time": None, "from": "system", "msg_idx": None}]
    ev_v2.extend(_find_evidence(all_msgs, "video_meeting", max_quotes=2))
    if ch >= 3:
        _ch_ev = f"除了在线聊天，双方还约了视频/会议等更深入的沟通方式（渠道数 {ch}）"
    elif ch >= 2:
        _ch_ev = f"在 TM 在线聊天之外还出现了其他沟通渠道（渠道数 {ch}）"
    else:
        _ch_ev = "目前只在 TM 旺旺上聊过，沟通渠道单一"
    result["items"]["Engagement_Channel"] = {
        "score": ch, "max": 5,
        "evidence": _ch_ev,
        "evidence_v2": ev_v2,
    }

    # --- Engagement-Response（简化：假定 48h 内回复率从时间戳估算）---
    resp_rate = _calc_response_rate(conv["messages"])
    ev_v2 = [{"tag": "response_rate",
              "raw_quote": f"买家在 48 小时内的回复率 {resp_rate:.0%}（根据 {len(conv['messages'])} 条消息的时间戳算出）",
              "msg_time": None, "from": "system", "msg_idx": None}]
    if resp_rate >= 0.8:
        er, ev = 4, f"买家回复很及时，48 小时内回复率达 {resp_rate:.0%}"
    elif resp_rate >= 0.5:
        er, ev = 2, f"买家回复一般，48 小时内回复率 {resp_rate:.0%}"
    else:
        er, ev = 0, f"买家回复很慢或基本不回，48 小时内回复率仅 {resp_rate:.0%}"
    result["items"]["Engagement_Response"] = {"score": er, "max": 4, "evidence": ev,
                                              "evidence_v2": ev_v2}

    total = sum(v["score"] for v in result["items"].values())
    result["total"] = total
    result["max"] = 100
    return result


def _calc_response_rate(messages: List[Dict]) -> float:
    """48h 内 seller 是否回复 buyer 的比例"""
    pairs = 0
    on_time = 0
    for i, m in enumerate(messages):
        if m["role"] == "buyer" and i + 1 < len(messages):
            # 找下一条 seller 消息
            for j in range(i + 1, len(messages)):
                if messages[j]["role"] == "seller":
                    pairs += 1
                    gap = messages[j].get("timestamp", 0) - m.get("timestamp", 0)
                    if gap <= 48 * 3600:
                        on_time += 1
                    break
    return on_time / pairs if pairs else 0.0


# ======================================================================
# Health Diagnosis (7+1 signals)
# ======================================================================
def score_health(conv: Dict[str, Any]) -> Dict[str, Any]:
    msgs = conv["messages"]
    if not msgs:
        return {"conversation_id": conv["conversation_id"], "health": 0,
                "signals": [], "status": "no_data"}

    signals = []
    all_text = " ".join(m["text"] for m in msgs)
    buyer_text = " ".join(m["text"] for m in msgs if m["role"] == "buyer")
    seller_msgs = [m for m in msgs if m["role"] == "seller"]

    # Signal 1: 响应超时
    last_buyer_idx = -1
    for i, m in enumerate(msgs):
        if m["role"] == "buyer":
            last_buyer_idx = i
    if last_buyer_idx >= 0 and last_buyer_idx == len(msgs) - 1:
        signals.append({"id": "S1", "name": "响应超时", "severity": "high",
                        "evidence": "买家发的最后一条消息，业务员一直没回，球还在我们这边",
                        "quote": _last_msg_quote(msgs, "buyer")})

    # Signal 2: 单向沟通（最近 5 轮中 seller 连续 >3）
    recent = msgs[-5:]
    seller_streak = 0
    max_streak = 0
    for m in recent:
        if m["role"] == "seller":
            seller_streak += 1
            max_streak = max(max_streak, seller_streak)
        else:
            seller_streak = 0
    if max_streak > 3:
        signals.append({"id": "S2", "name": "单向沟通", "severity": "high",
                        "evidence": f"最近 5 条里业务员连发了 {max_streak} 条，买家不接话，基本是单方面在发",
                        "quote": _last_msg_quote(msgs, "seller")})

    # Signal 3: 价格僵局
    price_count = len(_hits(all_text, "price_talk"))
    has_new_var = bool(_hits(all_text, "new_variable"))
    if price_count >= 2 and not has_new_var:
        signals.append({"id": "S3", "name": "价格僵局", "severity": "medium",
                        "evidence": f"价格反复谈了 {price_count} 次还卡着，没引入新条件（如换规格、调数量）来破局",
                        "quote": _sig_quote(msgs, "price_talk", role_filter="buyer") or _sig_quote(msgs, "price_talk")})

    # Signal 4: 需求误判（buyer 提关键词但 seller 未对应）
    buyer_needs = sum(1 for k in ["spec", "cert", "market", "scene"] if _hits(buyer_text, k))
    seller_resp = sum(1 for k in ["spec", "cert", "market", "scene"]
                      if _hits(" ".join(m["text"] for m in seller_msgs), k))
    if buyer_needs >= 2 and seller_resp < buyer_needs - 1:
        signals.append({"id": "S4", "name": "需求误判", "severity": "high",
                        "evidence": f"买家提了 {buyer_needs} 个需求点，业务员只回应了 {seller_resp} 个，没接住买家真正关心的问题",
                        "quote": next((_sig_quote(msgs, k, role_filter="buyer") for k in ["spec", "cert", "market", "scene"] if _sig_quote(msgs, k, role_filter="buyer")), "")})

    # Signal 5: 信任流失
    if _hits(buyer_text, "doubt") and not _hits(" ".join(m["text"] for m in seller_msgs), "trust_repair"):
        signals.append({"id": "S5", "name": "信任流失", "severity": "high",
                        "evidence": "买家表达了疑虑/不信任，业务员没做任何打消顾虑的动作（如提供证书、案例、担保）",
                        "quote": _sig_quote(msgs, "doubt", role_filter="buyer")})

    # Signal 6: 决策推迟
    if _hits(buyer_text, "think_postpone"):
        # 简化：仅检测词出现
        signals.append({"id": "S6", "name": "决策推迟", "severity": "medium",
                        "evidence": "买家说了'再想想/以后再说'之类的话，下单决策被往后拖了",
                        "quote": _sig_quote(msgs, "think_postpone", role_filter="buyer")})

    # Signal 7: 竞品介入
    if _hits(buyer_text, "competitor") and not _hits(" ".join(m["text"] for m in seller_msgs), "differentiation"):
        signals.append({"id": "S7", "name": "竞品介入", "severity": "high",
                        "evidence": "买家提到了别家供应商/在比价，业务员没讲出我们的差异化优势来抢回主动权",
                        "quote": _sig_quote(msgs, "competitor", role_filter="buyer")})

    # Signal 8: 断联未激活
    if last_buyer_idx >= 0 and last_buyer_idx < len(msgs) - 1:
        # buyer 不是最后说话的人
        gap_msgs = msgs[last_buyer_idx + 1:]
        # 检测之后 seller 的激活是否包含 next_step 或 new_variable
        re_activate_text = " ".join(m["text"] for m in gap_msgs if m["role"] == "seller")
        if not _hits(re_activate_text, "next_step") and not _hits(re_activate_text, "new_variable"):
            _s8_q = ""
            for _m in gap_msgs:
                if _m.get("role") == "seller" and (_m.get("text") or "").strip():
                    _t = _m["text"].strip()
                    _s8_q = _t[:120] + ("…" if len(_t) > 120 else "")
                    break
            signals.append({"id": "S8", "name": "断联未激活", "severity": "high",
                            "evidence": "买家不回了，业务员的跟进消息里没给出下一步动作或新钩子（如新报价、新样品），很难把人重新激活",
                            "quote": _s8_q})

    severe = sum(1 for s in signals if s["severity"] == "high")
    medium = sum(1 for s in signals if s["severity"] == "medium")
    health = max(0, 100 - severe * 20 - medium * 10)
    if health >= 80:
        status = "健康"
    elif health >= 60:
        status = "亚健康"
    elif health >= 40:
        status = "危险"
    else:
        status = "濒临流失"

    return {
        "conversation_id": conv["conversation_id"],
        "health": health,
        "status": status,
        "signals": signals,
        "deductions": {"severe": severe, "medium": medium},
    }


# ======================================================================
# Team / Seller Diagnosis
# ======================================================================
def score_seller(conversations: List[Dict[str, Any]]) -> Dict[str, Any]:
    """聚合多 conversation，输出三维评分。"""
    all_seller_msgs = []
    response_times = []
    seller_streaks = []
    night_responses = 0
    next_step_count = 0

    for conv in conversations:
        msgs = conv["messages"]
        s_msgs = [m for m in msgs if m["role"] == "seller"]
        all_seller_msgs.extend(m["text"] for m in s_msgs)

        # 响应时间
        for i, m in enumerate(msgs):
            if m["role"] == "buyer" and i + 1 < len(msgs):
                for j in range(i + 1, len(msgs)):
                    if msgs[j]["role"] == "seller":
                        gap_h = (msgs[j].get("timestamp", 0) - m.get("timestamp", 0)) / 3600
                        response_times.append(gap_h)
                        # 检测夜间响应（00-07 时）
                        import time as _t
                        tm = _t.gmtime(msgs[j].get("timestamp", 0))
                        if 0 <= tm.tm_hour < 7:
                            night_responses += 1
                        break

        # 主动激活
        streak = 0
        max_s = 0
        for m in msgs:
            if m["role"] == "seller":
                streak += 1
                max_s = max(max_s, streak)
            else:
                streak = 0
        seller_streaks.append(max_s)

    seller_text = " ".join(all_seller_msgs)
    n_msgs = len(all_seller_msgs) or 1

    # === 维度一：态度 ===
    avg_resp = sum(response_times) / len(response_times) if response_times else 999
    a1 = 25 if avg_resp < 2 else (15 if avg_resp < 8 else 5)

    avg_streak = sum(seller_streaks) / len(seller_streaks) if seller_streaks else 0
    # F1 缓解：连续独白 >3 时反向扣分
    if avg_streak > 3:
        a2 = 5  # 虚假主动
    elif avg_streak >= 1:
        a2 = 15
    else:
        a2 = 0

    neg_count = len(_hits(seller_text, "negative_emotion"))
    a3 = 25 if neg_count == 0 else (15 if neg_count <= 2 else 5)

    a4 = 25 if night_responses > 0 else 15

    attitude = a1 + a2 + a3 + a4

    # === 维度二：能力 ===
    spin_total = sum(_density(all_seller_msgs, k)
                     for k in ["spin_situation", "spin_problem", "spin_implication", "spin_need_payoff"])
    b1 = 25 if spin_total >= 0.3 else (15 if spin_total >= 0.15 else (8 if spin_total >= 0.05 else 0))

    fab_d = _density(all_seller_msgs, "fab")
    b2 = 20 if fab_d >= 0.3 else (12 if fab_d >= 0.15 else (6 if fab_d >= 0.05 else 0))

    tier_hits = len(_hits(seller_text, "tiered_quote"))
    b3 = 20 if tier_hits >= 3 else (10 if tier_hits >= 1 else 0)

    lscpa_hits = len(_hits(seller_text, "lscpa"))
    b4 = 20 if lscpa_hits >= 3 else (10 if lscpa_hits >= 1 else 0)

    ns_d = len(_hits(seller_text, "next_step")) / max(1, len(conversations))
    b5 = 15 if ns_d >= 1 else (8 if ns_d >= 0.5 else 0)

    skill = b1 + b2 + b3 + b4 + b5

    # === 维度三：谈判 ===
    c1 = 20 if neg_count == 0 else (12 if neg_count <= 2 else 5)

    why_count = len(re.findall(r"\bwhy\b|may i ask|could you tell", seller_text, re.I))
    c2 = 25 if why_count >= 5 else (15 if why_count >= 2 else (8 if why_count >= 1 else 0))

    nv_d = _density(all_seller_msgs, "new_variable")
    c3 = 30 if nv_d >= 2 else (18 if nv_d >= 1 else (10 if nv_d >= 0.5 else 0))

    oc_hits = len(_hits(seller_text, "objective_criteria"))
    c4 = 25 if oc_hits >= 3 else (12 if oc_hits >= 1 else 0)

    negotiation = c1 + c2 + c3 + c4

    overall = round(attitude * 0.3 + skill * 0.4 + negotiation * 0.3, 1)

    return {
        "attitude": {
            "total": attitude, "A1": a1, "A2": a2, "A3": a3, "A4": a4,
            "evidence": {
                "avg_response_hours": round(avg_resp, 2),
                "avg_seller_streak": round(avg_streak, 2),
                "negative_count": neg_count,
                "night_responses": night_responses,
            }
        },
        "skill": {
            "total": skill, "B1": b1, "B2": b2, "B3": b3, "B4": b4, "B5": b5,
            "evidence": {
                "spin_density": round(spin_total, 3),
                "fab_density": round(fab_d, 3),
                "tiered_quote_hits": tier_hits,
                "lscpa_hits": lscpa_hits,
                "next_step_per_conv": round(ns_d, 2),
            }
        },
        "negotiation": {
            "total": negotiation, "C1": c1, "C2": c2, "C3": c3, "C4": c4,
            "evidence": {
                "why_count": why_count,
                "new_variable_density": round(nv_d, 3),
                "objective_criteria_hits": oc_hits,
            }
        },
        "overall": overall,
        "vs_industry": {
            "attitude": attitude - BENCHMARKS["attitude"]["industry_avg"],
            "skill": skill - BENCHMARKS["skill"]["industry_avg"],
            "negotiation": negotiation - BENCHMARKS["negotiation"]["industry_avg"],
            "overall": overall - BENCHMARKS["team_overall"]["industry_avg"],
        }
    }


# ======================================================================
# Customer Tier Classification
# ======================================================================
def classify_tiers(customer_scores: List[Dict]) -> List[Dict]:
    """根据 threshold_calibration.json 决定用绝对还是相对法分层。"""
    n = len(customer_scores)
    use_relative = n < 30
    sorted_scores = sorted(customer_scores, key=lambda x: -x["total"])

    if use_relative:
        # 相对分布法
        for i, c in enumerate(sorted_scores):
            pct = (i + 1) / n * 100
            if pct <= 10:
                c["tier"] = "S"
            elif pct <= 30:
                c["tier"] = "A"
            elif pct <= 70:
                c["tier"] = "B"
            else:
                c["tier"] = "C"
            c["tier_method"] = "relative"
    else:
        for c in sorted_scores:
            s = c["total"]
            if s >= 80:
                c["tier"] = "S"
            elif s >= 60:
                c["tier"] = "A"
            elif s >= 40:
                c["tier"] = "B"
            else:
                c["tier"] = "C"
            c["tier_method"] = "absolute"

    # 补充绝对参考分
    for c in sorted_scores:
        s = c["total"]
        c["tier_absolute"] = "S" if s >= 80 else ("A" if s >= 60 else ("B" if s >= 40 else "C"))

    return sorted_scores
