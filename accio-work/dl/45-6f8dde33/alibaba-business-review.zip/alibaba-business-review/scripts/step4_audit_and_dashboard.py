#!/usr/bin/env python3
"""Step4 主审核交叉验证 + HTML 看板生成 (v1.2)

v1.2 升级：把旧版 69KB 看板的 7 大可视化模块（雷达 / batch 对比 /
信号热力 / S+A 复盘清单 / 7+1 频次 / 国家分布 / 培训方案）整页搬回
当模板，step4 只负责把 step1/2/3 数据 map 成模板期望的 4 个 const
（scored / diagnoses / team / batches）+ 5 个 KPI placeholder + 注入
evidence_v2 抽屉（v1.1 抽屉以独立 <section> 形式追加在底部）。
"""
import json
import sys
import re
import html as _html
from pathlib import Path
from _guard import require_preheat

SKILL_ROOT = Path(__file__).resolve().parent.parent
TEMPLATE = SKILL_ROOT / "templates/dashboard_template.html"
ECHARTS_JS = SKILL_ROOT / "assets/echarts.min.js"
BENCHMARKS = json.loads((SKILL_ROOT / "references/industry_benchmarks.json").read_text())
RULES = json.loads((SKILL_ROOT / "audit/anti_hallucination_rules.json").read_text())["rules"]


# ============================================================
#  Audit Pass (与 v1.1 同语义)
# ============================================================
def audit(step1, step2, step3) -> dict:
    issues = []

    miss_ev = 0
    for c in step1.get("customers", []):
        for k, v in c.get("items", {}).items():
            if v.get("score", 0) > 0 and not v.get("evidence"):
                miss_ev += 1
    if miss_ev:
        issues.append({"rule": "R1", "severity": "critical",
                       "msg": f"{miss_ev} non-zero scores missing evidence"})

    meta = step1.get("meta", {})
    if meta.get("conversation_count", 0) < 10 or meta.get("message_count", 0) < 50:
        issues.append({"rule": "R4", "severity": "high",
                       "msg": f"sample too small: convs={meta.get('conversation_count')} "
                              f"msgs={meta.get('message_count')}"})

    banned = ["排名", "权重", "算法", "流量分配", "曝光提升"]
    text = json.dumps([step1, step2, step3], ensure_ascii=False)
    for w in banned:
        if w in text:
            issues.append({"rule": "R6", "severity": "high",
                           "msg": f"banned speculation word found: '{w}'"})

    # R9 已于 2026-05-27 由用户裁定废除（内部使用允许真名，外发版本需另做脱敏）
    # 原始检查保留备查：
    # pii_pat = re.compile(r"^(Buyer-\d{2}\s*\([A-Z?]{2}\)|[A-Z]\.[A-Z]\.\s*\([A-Z]{2}\)|Test Buyer )")

    critical = [i for i in issues if i["severity"] == "critical"]
    return {"passed": len(critical) == 0, "issues": issues,
            "rules_checked": [r["id"] for r in RULES]}


# ============================================================
#  数据 mapping：把 step1/2/3 翻译成旧模板期望的 4 个 const
# ============================================================
SIG_TYPES = ['响应超时', '单向沟通', '价格僵局', '需求误判',
             '信任流失', '决策推迟', '竞品介入', '断联未激活']


def buyer_label(c, idx):
    """统一显示名：优先 buyer_name（已脱敏），否则 Buyer-NN"""
    bn = c.get("buyer_name")
    if bn:
        return bn
    return f"Buyer-{idx:02d}"


def map_scored(customers):
    """旧模板 scored 字段需要：
       {total, level, bant, persona, engagement, evidence, msg_count, country, contactName}
    """
    out = []
    for idx, c in enumerate(customers, start=1):
        items = c.get("items", {})
        # 三大维度聚合
        bant_keys = [k for k in items if k.startswith("BANT_")]
        persona_keys = [k for k in items if k.startswith("Persona_")]
        engage_keys = [k for k in items if k.startswith("Engagement_")]
        bant_score = sum(items[k].get("score", 0) for k in bant_keys)
        persona_score = sum(items[k].get("score", 0) for k in persona_keys)
        engage_score = sum(items[k].get("score", 0) for k in engage_keys)

        # 简化 evidence（旧模板只展示 key:score:evidence 一句）
        ev = {}
        for k, v in items.items():
            ev[k] = {
                "score": v.get("score", 0),
                "evidence": v.get("evidence", "") or "（这一项聊天里没有相关信息）",
            }

        out.append({
            "contactName": buyer_label(c, idx),
            "country": c.get("buyer_country") or "??",
            "total": c.get("total", 0),
            "level": c.get("tier", "C"),
            "bant": bant_score,
            "persona": persona_score,
            "engagement": engage_score,
            "msg_count": c.get("msg_count", 0),
            "evidence": ev,
            # 抽屉用 evidence_v2 原文（v1.1 保留）
            "items_v2": {k: {
                "score": items[k].get("score", 0),
                "max": items[k].get("max", "?"),
                "evidence": items[k].get("evidence", ""),
                "evidence_v2": items[k].get("evidence_v2", []),
            } for k in items},
        })
    # 按 total 降序
    out.sort(key=lambda x: -x["total"])
    return out


SEV_MAP = {"high": "高", "medium": "中", "low": "低", "高": "高", "中": "中", "低": "低"}


def map_diagnoses(step2_convs, scored_by_conv):
    """旧模板 diagnoses：
       {contactName, country, health_score, status, signals:[{signal,severity,evidence,quote}]}
    """
    out = []
    for c in step2_convs:
        cid = c.get("conversation_id")
        match = scored_by_conv.get(cid, {})
        signals = []
        for s in c.get("signals", []):
            # step2 schema 用 .name；旧字段兼容
            signals.append({
                "signal": s.get("name") or s.get("type") or s.get("signal") or "?",
                "severity": SEV_MAP.get(s.get("severity"), "中"),
                "evidence": s.get("evidence") or s.get("reason") or "",
                "quote": s.get("quote") or "",
            })
        out.append({
            "contactName": match.get("contactName") or cid,
            "country": match.get("country") or "??",
            "health_score": c.get("health", 0),
            "status": {"no_data": "无对话数据", "": "健康"}.get(c.get("status"), c.get("status") or "健康"),
            "signals": signals,
        })
    return out


def map_team(team):
    """旧模板期望嵌套 schema：team.attitude.A1_responsiveness.score 等。
       step3 中 key 是简化形式（A1/B1/C1），这里桥接成完整嵌套。"""
    a = team.get("attitude", {})
    s = team.get("skill", {})
    n = team.get("negotiation", {})
    return {
        "total": team.get("overall", 0),
        "attitude": {
            "score": a.get("total", 0),
            "A1_responsiveness": {"score": a.get("A1", 0)},
            "A2_initiative":     {"score": a.get("A2", 0)},
            "A3_emotion":        {"score": a.get("A3", 0)},
            "A4_timezone":       {"score": a.get("A4", 0)},
        },
        "skill": {
            "score": s.get("total", 0),
            "B1_SPIN":         {"score": s.get("B1", 0)},
            "B2_FAB":          {"score": s.get("B2", 0)},
            "B3_tiered_quote": {"score": s.get("B3", 0)},
            "B4_LSCPA":        {"score": s.get("B4", 0)},
            "B5_next_step":    {"score": s.get("B5", 0)},
        },
        "negotiation": {
            "score": n.get("total", 0),
            "C1_separate_people":       {"score": n.get("C1", 0)},
            "C2_interest_not_position": {"score": n.get("C2", 0)},
            "C3_mutual_gain_variables": {"score": n.get("C3", 0)},
            "C4_objective_criteria":    {"score": n.get("C4", 0)},
        },
    }


def map_batches(step3):
    """旧模板 batches: {batch1a:{total,attitude:{score},skill:{score},negotiation:{score}}, ...}
       step3 当前 granularity=team 时没有 batch 数据，回填一个单 batch 用 team 数据，
       并在 banner_note 显式标注。
    """
    team = step3.get("team", {})
    individual = step3.get("individual") or {}
    # 旧 echarts 需要 batches[k].sample_size.seller_messages 做 x 轴标签
    meta_msgs = step3.get("meta", {}).get("seller_messages") or step3.get("meta", {}).get("message_count") or 0
    if individual:
        return {
            name: {
                "total": v.get("overall", 0),
                "attitude":    {"score": v.get("attitude", {}).get("total", 0)},
                "skill":       {"score": v.get("skill", {}).get("total", 0)},
                "negotiation": {"score": v.get("negotiation", {}).get("total", 0)},
                "sample_size": {"seller_messages": v.get("meta", {}).get("seller_messages", 0)},
            }
            for name, v in individual.items()
        }
    # 降级：只有 team 数据 → 单 batch（granularity=team 场景）
    return {
        "team_aggregate": {
            "total": team.get("overall", 0),
            "attitude":    {"score": team.get("attitude", {}).get("total", 0)},
            "skill":       {"score": team.get("skill", {}).get("total", 0)},
            "negotiation": {"score": team.get("negotiation", {}).get("total", 0)},
            "sample_size": {"seller_messages": meta_msgs},
        }
    }


def map_benchmark():
    """模板 benchmark：{attitude:{industry_avg}, skill:{industry_avg}, negotiation:{industry_avg}}"""
    return {
        "attitude": {"industry_avg": BENCHMARKS["attitude"]["industry_avg"]},
        "skill": {"industry_avg": BENCHMARKS["skill"]["industry_avg"]},
        "negotiation": {"industry_avg": BENCHMARKS["negotiation"]["industry_avg"]},
    }


# ============================================================
#  抽屉行（v1.1 保留，作为独立 section 追加在底部）
# ============================================================
DIM_LABEL = {
    "BANT_B": "预算(Budget)", "BANT_A": "决策权(Authority)",
    "BANT_N": "需求(Need)", "BANT_T": "时间线(Timeline)",
    "Persona_Country": "客户国家(Country)", "Persona_Company": "公司背景(Company)",
    "Persona_Category": "品类匹配(Category)",
    "Engagement_Active": "主动互动(Active)", "Engagement_Depth": "对话深度(Depth)",
    "Engagement_Channel": "沟通渠道(Channel)", "Engagement_Response": "响应及时(Response)",
}
def _zh_dim(k):
    return DIM_LABEL.get(k, k)
def _zh_ev(s):
    return "信息缺失(information missing)" if str(s).strip() == "information_missing" else s

def render_drawer_section(scored):
    blocks = []
    for idx, s in enumerate(scored):
        sections = [
            ("BANT 客户资质", ["BANT_B", "BANT_A", "BANT_N", "BANT_T"]),
            ("Persona 客户画像", ["Persona_Country", "Persona_Company", "Persona_Category"]),
            ("Engagement 互动深度", ["Engagement_Active", "Engagement_Depth",
                                      "Engagement_Channel", "Engagement_Response"]),
        ]
        rows = []
        items = s.get("items_v2", {})
        for title, keys in sections:
            quotes = []
            for k in keys:
                it = items.get(k, {})
                score = it.get("score", 0)
                max_s = it.get("max", "?")
                label = f"{_zh_dim(k)} {score}/{max_s}"
                ev_v2 = it.get("evidence_v2") or []
                if not ev_v2:
                    quotes.append(
                        f'<div class="quote-row"><span class="tag">{_html.escape(label)}</span>'
                        f'<span class="no-evidence">'
                        f'{_html.escape(_zh_ev(it.get("evidence", "information_missing")))}</span></div>'
                    )
                    continue
                for ev in ev_v2:
                    role = ev.get("from") or "system"
                    role_cls = "role-buyer" if role == "buyer" else ("role-seller" if role == "seller" else "")
                    meta = [
                        f'<span class="tag">{_html.escape(label)}</span>',
                        f'<span class="{role_cls}">{_html.escape(role)}</span>',
                    ]
                    if ev.get("msg_time"):
                        meta.append(_html.escape(str(ev["msg_time"])))
                    if ev.get("msg_idx") is not None:
                        meta.append(f'msg#{ev["msg_idx"]}')
                    quotes.append(
                        f'<div class="quote-row"><div class="qmeta">{" · ".join(meta)}</div>'
                        f'<div class="qbody">{_html.escape(str(ev.get("raw_quote", "")))}</div></div>'
                    )
            rows.append(
                f'<div class="drawer-section"><h5>{_html.escape(title)}</h5>{"".join(quotes)}</div>'
            )
        blocks.append(
            f'<details class="drawer-block"><summary>'
            f'<span class="badge b-{s["level"]}">{s["level"]}</span> '
            f'<b>{_html.escape(s["contactName"])}</b> · {_html.escape(s["country"])} · '
            f'{s["total"]}/100 分</summary>{"".join(rows)}</details>'
        )
    css = """
    <style>
      .drawer-area{margin-top:30px;padding:20px;background:#fff;border-radius:8px;
                   border:1px solid #e0e0e0}
      .drawer-area h2{font-size:18px;margin:0 0 16px;color:#0277bd}
      .drawer-block{margin:6px 0;padding:10px 14px;background:#f9fafb;
                    border-radius:6px;border-left:3px solid #0277bd}
      .drawer-block summary{cursor:pointer;font-size:13px;color:#333}
      .drawer-section{margin-top:12px}
      .drawer-section h5{margin:8px 0 6px;color:#555;font-size:12px}
      .quote-row{padding:6px 10px;margin:4px 0;background:#fff;border-left:2px solid #ddd;
                 font-size:12px;line-height:1.6}
      .qmeta{color:#999;font-size:11px;margin-bottom:3px}
      .qbody{color:#222}
      .role-buyer{color:#0277bd;font-weight:600}
      .role-seller{color:#7b1fa2;font-weight:600}
      .no-evidence{color:#aaa;font-style:italic}
      .tag{display:inline-block;padding:1px 6px;background:#eef;color:#447;
           border-radius:3px;font-size:10px}
      .badge{display:inline-block;padding:2px 8px;border-radius:10px;
             font-size:11px;color:white;font-weight:600}
      .b-S{background:#d32f2f} .b-A{background:#f57c00}
      .b-B{background:#7b1fa2} .b-C{background:#616161}
    </style>"""
    return (
        f'{css}'
        f'<div class="drawer-area"><h2>📂 全量客户评分证据（点击展开 · '
        f'v1.1 evidence_v2 原文回溯）</h2>{"".join(blocks)}</div>'
    )


# ============================================================
#  组装：注入模板
# ============================================================
def build_html(step1, step2, step3, audit_result, step6=None) -> str:
    tpl = TEMPLATE.read_text()

    customers = step1.get("customers", [])
    scored = map_scored(customers)
    # conv_id → scored 项映射，给 step2 关联用
    scored_by_conv = {customers[i].get("conversation_id"): scored[j]
                      for i, c in enumerate(customers)
                      for j, sc in enumerate(scored)
                      if sc["contactName"] == buyer_label(c, i + 1)}
    diagnoses = map_diagnoses(step2.get("conversations", []), scored_by_conv)
    team = map_team(step3.get("team", {}))
    batches = map_batches(step3)
    benchmark = map_benchmark()

    # KPI
    kpi_customers = len(scored)
    industry_avg = BENCHMARKS["team_overall"]["industry_avg"]
    team_total = team["total"]
    t_att = team["attitude"]["score"]
    t_cap = team["skill"]["score"]
    t_neg = team["negotiation"]["score"]
    # 团队平均响应时长（小时）：取自原始 step3 的 attitude.evidence.avg_response_hours
    _resp_h = (step3.get("team", {}).get("attitude", {}).get("evidence", {}) or {}).get("avg_response_hours")
    t_resp_hours = f"{round(float(_resp_h), 1)}" if isinstance(_resp_h, (int, float)) else "—"
    team_gap = round(team_total - industry_avg, 1)
    team_gap_str = f"+{team_gap}" if team_gap >= 0 else str(team_gap)

    # 单向沟通触发率
    oneway = sum(1 for d in diagnoses if any(s["signal"] == "单向沟通" for s in d["signals"]))
    oneway_pct = round(oneway * 100 / max(1, len(diagnoses)))

    # 替换 5 个 const 数据
    json_dump = lambda x: json.dumps(x, ensure_ascii=False)
    echarts_js = ECHARTS_JS.read_text() if ECHARTS_JS.exists() else "/* echarts asset missing */"
    _m = step1.get("meta", {})
    _shop = _m.get("shop") or _m.get("shop_name") or "阿里国际站"
    _tw = _m.get("time_window") or _m.get("window") or ""
    _msg = _m.get("total_messages") or 0
    _cust = _m.get("total_conversations") or len(scored)
    # 主营业务：只用商家自己声明的 meta.biz_scope（或别名），绝不从客户聊天里推断
    # （客户行业 ≠ 卖家主营，混淆会写错主营）。缺失时整段留空，不硬编码任何品类。
    _biz = (_m.get("biz_scope") or _m.get("business_scope") or _m.get("main_category")
            or _m.get("category") or "")
    _biz = str(_biz).strip()
    _biz_seg = f" · 主营{_biz}" if _biz else ""
    import datetime as _dt
    _gen = _dt.datetime.now().strftime("%Y-%m-%d %H:%M")

    # 数据透明度声明 / 采集凭据：按真实 meta 动态生成，绝不硬编码天数/粒度/路径
    _gran = (step3.get("granularity") or "").strip()
    _gran_cn = {"individual": "员工个人级（按子账号归因到每位业务员）",
                "batch": "批次级（未拿到子账号，按批次聚合）",
                "team": "团队整体级（无法归因到个人）"}.get(_gran, "团队整体级")
    # 采样天数：优先 meta.sample_days，否则从 time_window 估算
    _days = _m.get("sample_days")
    if not _days and _tw and "~" in _tw:
        try:
            _a, _b = [p.strip() for p in _tw.split("~")[:2]]
            _da = _dt.datetime.strptime(_a, "%Y-%m-%d")
            _db = _dt.datetime.strptime(_b, "%Y-%m-%d")
            _days = (_db - _da).days + 1
        except Exception:
            _days = None
    _days_txt = f"近 {_days} 天" if _days else "采集时间窗内"
    _disclosure = (
        f"① 本次采样{_days_txt}（{_tw or '时间窗见标题'}）共 {_cust} 个客户 / {_msg} 条消息，"
        f"分层采用<b>相对分布法</b>（Top10%=S, 10-30%=A, 30-70%=B, 70-100%=C）+ 保留绝对参考分；"
        f"② 员工诊断粒度：<b>{_gran_cn}</b>；"
        f"③ 所有评分项均基于<b>原文关键词正则匹配</b>，可在 reports/*.json 中回溯每一分的证据，未做任何 LLM 推测以杜绝幻觉。"
    )
    _src_note = f"data/chats.json（{_shop} · {_tw or '时间窗见标题'} · {_cust} 个客户 / {_msg} 条真实消息）"
    # 业务员真名明细：优先取 step3 顶层 members（individual 粒度），回退 team.members
    _members = step3.get("members") or (team.get("members") if isinstance(team, dict) else []) or []
    def _num(x):
        if isinstance(x, dict):
            return x.get("total", x.get("score", 0))
        return x if x is not None else 0
    _rows = []
    for m in _members:
        nm = (m.get("name") or "").strip()
        if not nm:
            continue
        ov = m.get("overall", 0)
        cc = m.get("conv_count", m.get("conv", 0))
        att = _num(m.get("attitude"))
        sk = _num(m.get("skill"))
        ng = _num(m.get("negotiation"))
        ng_style = ' style="color:#ff5252;font-weight:700"' if (isinstance(ng,(int,float)) and ng < 20) else ''
        _rows.append(
            f'<tr style="border-bottom:1px solid #2a2a30">'
            f'<td style="padding:7px 8px;font-weight:600">{nm}</td>'
            f'<td style="text-align:center;padding:7px 8px">{cc}</td>'
            f'<td style="text-align:center;padding:7px 8px;color:var(--highlight);font-weight:700">{ov}</td>'
            f'<td style="text-align:center;padding:7px 8px">{att}</td>'
            f'<td style="text-align:center;padding:7px 8px">{sk}</td>'
            f'<td style="text-align:center;padding:7px 8px"{ng_style}>{ng}</td>'
            f'</tr>'
        )
    _members_rows = "".join(_rows) or '<tr><td colspan="6" style="padding:10px;color:#888">暂无业务员个体数据</td></tr>'
    _team_n = len([m for m in _members if (m.get("name") or "").strip()]) or (
        len({t.get("name") for t in (team.get("sellers") or team.get("members") or [])}) if isinstance(team, dict) else 0)
    repl = {
        "__TEAM_MEMBERS_ROWS__": _members_rows,
        "__DASHBOARD_TITLE__": f"{_shop} 业务复盘看板 · {_tw}".strip(" ·"),
        "__SHOP_NAME__":       _shop,
        "__TIME_WINDOW__":     _tw,
        "__BIZ_SCOPE__":       _biz_seg,
        "__DATA_DISCLOSURE__": _disclosure,
        "__DATA_SOURCE_NOTE__": _src_note,
        "__MSG_COUNT__":       str(_msg),
        "__CUST_COUNT__":      str(_cust),
        "__TEAM_COUNT__":      str(_team_n),
        "__GEN_TIME__":        _gen,
        "__ECHARTS_INLINE__":  echarts_js,
        "__SCORED_JSON__":     json_dump(scored),
        "__DIAGNOSES_JSON__":  json_dump(diagnoses),
        "__TEAM_JSON__":       json_dump(team),
        "__BATCHES_JSON__":    json_dump(batches),
        "__SELLER_FOCUS_JSON__": json_dump((step6 or {}).get("sellers", [])),
        "__BENCHMARK_JSON__":  json_dump(benchmark),
        "{{KPI_CUSTOMERS}}":   str(kpi_customers),
        "{{TEAM_TOTAL}}":      str(team_total),
        "{{INDUSTRY_AVG}}":    str(industry_avg),
        "{{TEAM_GAP}}":        team_gap_str,
        "{{T_ATT}}":           str(t_att),
        "{{T_CAP}}":           str(t_cap),
        "{{T_NEG}}":           str(t_neg),
        "{{T_RESP_HOURS}}":    str(t_resp_hours),
        "{{ONEWAY_PCT}}":      str(oneway_pct),
    }
    for k, v in repl.items():
        tpl = tpl.replace(k, v)

    # 把 v1.1 抽屉以 section 形式追加在 </body> 前
    drawer_html = render_drawer_section(scored)
    # 同时追加 audit banner（如有）
    audit_banner = ""
    if audit_result["issues"]:
        items = "".join(
            f'<li><b>[{i["rule"]}][{i["severity"]}]</b> {_html.escape(i["msg"])}</li>'
            for i in audit_result["issues"]
        )
        audit_banner = (
            f'<div style="margin:20px 0;padding:14px 18px;background:#fff3cd;'
            f'border-left:4px solid #f0ad4e;border-radius:4px"><h4 style="margin:0 0 8px">'
            f'⚠️ 审计提示</h4><ul style="margin:0;padding-left:20px">{items}</ul></div>'
        )

    # ⚠️ 必须用 rsplit 只替换最后一个 </body>（内联的 echarts.min.js 源码字符串里
    # 含 '</body>' 字面量，普通 replace 会把它也改掉，破坏 echarts，导致白屏）
    head, tail = tpl.rsplit("</body>", 1)
    tpl = f"{head}{audit_banner}{drawer_html}\n</body>{tail}"
    return tpl


# ============================================================
#  Main
# ============================================================
def main():
    require_preheat()

    step1 = json.loads((SKILL_ROOT / "reports/step1_customer_scoring.json").read_text())
    step2 = json.loads((SKILL_ROOT / "reports/step2_health_diagnosis.json").read_text())
    step3 = json.loads((SKILL_ROOT / "reports/step3_team_diagnosis.json").read_text())
    _sf_path = SKILL_ROOT / "reports/step6_seller_focus.json"
    step6 = json.loads(_sf_path.read_text()) if _sf_path.exists() else {"sellers": []}

    audit_result = audit(step1, step2, step3)

    if not audit_result["passed"]:
        print("❌ AUDIT FAILED (critical issues):", file=sys.stderr)
        for i in audit_result["issues"]:
            if i["severity"] == "critical":
                print(f"  - [{i['rule']}] {i['msg']}", file=sys.stderr)
        sys.exit(4)

    html = build_html(step1, step2, step3, audit_result, step6)
    out = SKILL_ROOT / "reports/alibaba_review_dashboard.html"
    out.parent.mkdir(exist_ok=True, parents=True)
    out.write_text(html, encoding="utf-8")

    audit_md = SKILL_ROOT / "reports/audit_report.md"
    audit_md.write_text(json.dumps(audit_result, indent=2, ensure_ascii=False))

    print(f"✅ Dashboard generated: {out}")
    print(f"   Size: {out.stat().st_size:,} bytes")
    print(f"   Audit issues: {len(audit_result['issues'])} "
          f"(critical={sum(1 for i in audit_result['issues'] if i['severity']=='critical')})")


if __name__ == "__main__":
    main()


if __name__ == "__main__":
    main()
