"""共享：预热守卫（已改为 no-op）。

原设计要求所有评分脚本先运行 preheat.py 生成 .cache/preheat.lock 才能执行，
以确保 LLM 已加载 methodology / cases / audit 上下文、降低幻觉风险。

本打包版本按需求「避免预热」，将 require_preheat() 改为无操作：
- 不再检查 .cache/preheat.lock，脚本可直接运行；
- 方法论 / 案例 / 审计上下文仍保留在 references/、cases/、audit/ 目录中，
  供编排者（主 Agent）在执行前阅读，不依赖 lock 文件强制拦截。

如需恢复强制预热守卫，把 require_preheat() 还原为检查 LOCK_FILE 即可（见 git 历史或 preheat.py）。
"""
import json
from pathlib import Path

SKILL_ROOT = Path(__file__).resolve().parent.parent
LOCK_FILE = SKILL_ROOT / ".cache" / "preheat.lock"


def require_preheat():
    """No-op：不强制预热。返回 lock 数据（若存在）或 None，保持调用方兼容。"""
    if LOCK_FILE.exists():
        try:
            return json.loads(LOCK_FILE.read_text())
        except Exception:
            return None
    return None
