#!/usr/bin/env python3
"""Step3 团队三维诊断（态度 30% + 能力 40% + 谈判 30%）"""
import json
import sys
from collections import defaultdict
from pathlib import Path
from _guard import require_preheat
from scorer import score_seller

SKILL_ROOT = Path(__file__).resolve().parent.parent


def main():
    require_preheat()
    inp = sys.argv[1] if len(sys.argv) > 1 else "data/chats.json"
    out = sys.argv[2] if len(sys.argv) > 2 else "reports/step3_team_diagnosis.json"

    data = json.loads((SKILL_ROOT / inp).read_text())
    convs = data["conversations"]
    meta = data.get("meta", {})

    # 团队整体
    team_score = score_seller(convs)

    # 个人级（如有 subaccount_id）
    by_seller = defaultdict(list)
    name_of = {}
    for c in convs:
        sid = c.get("subaccount_id")
        if sid:
            by_seller[sid].append(c)
            if c.get("subaccount_name"):
                name_of[sid] = c.get("subaccount_name")

    individual = {}
    individual_list = []
    granularity = "team"
    if by_seller and len(by_seller) > 1:
        granularity = "individual"
        for sid, sconvs in by_seller.items():
            sc = score_seller(sconvs)
            sname = name_of.get(sid, str(sid))
            sc["name"] = sname
            sc["subaccount_id"] = sid
            sc["conv_count"] = len(sconvs)
            individual[str(sid)] = sc
            individual_list.append(sc)
        individual_list.sort(key=lambda x: -(x.get("overall") or 0))

    out_data = {
        "meta": meta,
        "granularity": granularity,
        "granularity_note": (
            "individual-level by subaccount_id" if granularity == "individual"
            else "batch-level only (subaccount_id missing in collect output - known limitation)"
        ),
        "team": team_score,
        "individual": individual,
        "members": individual_list,
    }

    out_path = SKILL_ROOT / out
    out_path.parent.mkdir(exist_ok=True, parents=True)
    out_path.write_text(json.dumps(out_data, indent=2, ensure_ascii=False))
    print(f"✅ Step3 done: overall={team_score['overall']} "
          f"(attitude={team_score['attitude']['total']}, "
          f"skill={team_score['skill']['total']}, "
          f"negotiation={team_score['negotiation']['total']}) → {out_path}")
    print(f"   Granularity: {granularity}")


if __name__ == "__main__":
    main()
