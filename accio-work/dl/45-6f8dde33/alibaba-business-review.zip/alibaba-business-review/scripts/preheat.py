#!/usr/bin/env python3
"""
强制预热脚本 - 阿里业务复盘 Skill v1.0

执行此脚本会:
1. 加载 references/cases/memory/audit 全部内容到 stdout（注入 Agent 上下文）
2. 在 .cache/preheat.lock 写入指纹与时间戳
3. 验证关键文件完整性

未运行此脚本时，主入口脚本会拒绝执行评分。
"""
import json
import os
import sys
import hashlib
import time
from pathlib import Path

SKILL_ROOT = Path(__file__).resolve().parent.parent
CACHE_DIR = SKILL_ROOT / ".cache"
LOCK_FILE = CACHE_DIR / "preheat.lock"

REQUIRED_FILES = [
    "SKILL.md",
    "references/methodology.md",
    "references/keyword_dictionary.json",
    "references/industry_benchmarks.json",
    "references/threshold_calibration.json",
    "cases/case_01_us_solar_buyer.md",
    "cases/case_02_ph_emerging_market.md",
    "cases/case_03_price_deadlock.md",
    "cases/case_04_silence_followup.md",
    "cases/scoring_examples.json",
    "memory/industry_context.md",
    "memory/alibaba_platform_terms.md",
    "memory/market_tier_mapping.json",
    "audit/anti_hallucination_rules.json",
    "audit/auditor_checklist.md",
    "audit/failure_modes.md",
]


def verify_files() -> dict:
    """验证关键文件存在 + 计算指纹"""
    fingerprints = {}
    missing = []
    for rel in REQUIRED_FILES:
        p = SKILL_ROOT / rel
        if not p.exists():
            missing.append(rel)
        else:
            content = p.read_bytes()
            fingerprints[rel] = hashlib.md5(content).hexdigest()[:12]
    if missing:
        print(f"❌ PREHEAT FAILED: missing files:\n  - " + "\n  - ".join(missing),
              file=sys.stderr)
        sys.exit(1)
    return fingerprints


def inject_context():
    """把核心知识打印到 stdout - 这是 Agent 上下文注入的关键"""
    sections = [
        ("[METHODOLOGY]", "references/methodology.md"),
        ("[KEYWORDS]", "references/keyword_dictionary.json"),
        ("[BENCHMARKS]", "references/industry_benchmarks.json"),
        ("[THRESHOLDS]", "references/threshold_calibration.json"),
        ("[CASE_01_US_HIGH_VALUE]", "cases/case_01_us_solar_buyer.md"),
        ("[CASE_02_PH_EMERGING]", "cases/case_02_ph_emerging_market.md"),
        ("[CASE_03_DEADLOCK]", "cases/case_03_price_deadlock.md"),
        ("[CASE_04_SILENCE]", "cases/case_04_silence_followup.md"),
        ("[SCORING_EXAMPLES]", "cases/scoring_examples.json"),
        ("[MEMORY_INDUSTRY]", "memory/industry_context.md"),
        ("[MEMORY_PLATFORM]", "memory/alibaba_platform_terms.md"),
        ("[MEMORY_MARKETS]", "memory/market_tier_mapping.json"),
        ("[AUDIT_RULES]", "audit/anti_hallucination_rules.json"),
        ("[AUDIT_CHECKLIST]", "audit/auditor_checklist.md"),
        ("[FAILURE_MODES]", "audit/failure_modes.md"),
    ]
    print("=" * 70)
    print("ALIBABA BUSINESS REVIEW SKILL - PREHEAT CONTEXT INJECTION")
    print("=" * 70)
    print()
    print("🛑🛑🛑 主营品类铁律（覆盖以下所有注入内容）🛑🛑🛑")
    print("以下 cases/ examples/ memory/ 全部是【方法论演示数据】，")
    print("其中出现的任何品类（照明 / 跳绳 / 帽子 / 任何产品）都【与当前商家无关】，")
    print("严禁据此推断当前商家主营。当前商家主营【只能】来自：")
    print("  ① data/chats.json 的 meta.biz_scope（商家自报）；")
    print("  ② step1 从 chats.json 里 role=seller 消息的高频产品词自动推断。")
    print("读案例只学【打分逻辑 / 诊断方法 / 话术结构】，绝不学【品类设定】。")
    print("=" * 70)
    print()
    # 标记哪些 section 是"演示数据"，注入时逐块再提醒一次，防止 Agent 当成事实
    DEMO_TAGS = {"[CASE_01_US_HIGH_VALUE]", "[CASE_02_PH_EMERGING]", "[CASE_03_DEADLOCK]",
                 "[CASE_04_SILENCE]", "[SCORING_EXAMPLES]", "[MEMORY_INDUSTRY]"}
    for tag, rel in sections:
        content = (SKILL_ROOT / rel).read_text(encoding="utf-8")
        warn = "  ⚠️ 演示数据·品类与当前商家无关·只学方法不学品类" if tag in DEMO_TAGS else ""
        print(f"\n<<<{tag} src={rel}{warn}>>>")
        print(content)
        print(f"<<<END {tag}>>>\n")


def write_lock(fingerprints: dict):
    CACHE_DIR.mkdir(exist_ok=True)
    lock_data = {
        "version": "1.0.0",
        "preheated_at": int(time.time()),
        "preheated_at_iso": time.strftime("%Y-%m-%dT%H:%M:%S%z"),
        "fingerprints": fingerprints,
        "files_count": len(fingerprints),
    }
    LOCK_FILE.write_text(json.dumps(lock_data, indent=2, ensure_ascii=False))
    print(f"\n✅ PREHEAT LOCK written: {LOCK_FILE}", file=sys.stderr)


def main():
    print("🔥 Starting preheat...", file=sys.stderr)
    fps = verify_files()
    inject_context()
    write_lock(fps)
    print(f"\n✅ PREHEAT DONE. {len(fps)} files loaded. Skill is ready.", file=sys.stderr)
    print(f"   Lock: {LOCK_FILE}", file=sys.stderr)


if __name__ == "__main__":
    main()
