#!/usr/bin/env python3
"""把复盘结论写回 plugin-memory-manager，供后续 skill 联动。"""
import json
import os
import subprocess
import sys
from pathlib import Path

SKILL_ROOT = Path(__file__).resolve().parent.parent


def main():
    step1 = json.loads((SKILL_ROOT / "reports/step1_customer_scoring.json").read_text())
    step3 = json.loads((SKILL_ROOT / "reports/step3_team_diagnosis.json").read_text())

    team = step3["team"]
    dist = step1["distribution"]

    outcome = (
        f"复盘完成: 客户分层 S/A/B/C = {dist.get('S',0)}/{dist.get('A',0)}/"
        f"{dist.get('B',0)}/{dist.get('C',0)}; 团队综合 {team['overall']} "
        f"(态度{team['attitude']['total']}/能力{team['skill']['total']}/谈判{team['negotiation']['total']})"
    )

    # 提取画像信号
    profile_updates = {"merchant_profile": {}, "user_preferences": {}}
    # 团队规模可从 individual diagnosis 数量推断
    if step3.get("granularity") == "individual" and step3.get("individual"):
        profile_updates["merchant_profile"]["team_size_seller"] = len(step3["individual"])

    # 用户偏好（看板形态）
    profile_updates["user_preferences"]["preferred_output_format"] = "interactive_html"
    profile_updates["user_preferences"]["analysis_depth"] = "deep_with_benchmark"

    payload = {
        "outcome": outcome,
        "profile_updates": profile_updates,
    }

    agent_core = os.environ.get("AGENT_CORE") or os.path.expanduser(
        "~/.accio/accounts/1753864137/agents/DID-D464A3-54D464A3U1779799-1480-C717B1/agent-core"
    )
    post_script = Path(agent_core) / "skills/plugin-memory-manager/scripts/post_skill.py"

    if not post_script.exists():
        print(f"⚠️  post_skill.py not found at {post_script}, skipping writeback.",
              file=sys.stderr)
        print(json.dumps(payload, ensure_ascii=False, indent=2))
        return

    result = subprocess.run(
        ["python3", str(post_script), "alibaba-business-review", json.dumps(payload, ensure_ascii=False)],
        capture_output=True, text=True
    )
    print(result.stdout)
    if result.returncode != 0:
        print(result.stderr, file=sys.stderr)


if __name__ == "__main__":
    main()
