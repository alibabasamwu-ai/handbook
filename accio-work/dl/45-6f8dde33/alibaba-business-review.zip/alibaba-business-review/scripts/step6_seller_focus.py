#!/usr/bin/env python3
"""Step6 · 业务员聚焦诊断（以"员工提升落地"为目的）

为每个业务员生成一份独立汇总：
  1. 核心问题（从三维分最低维 + 证据指标定位，一针见血）
  2. 客户共性问题（名下客户出现最多的健康信号 + 占比）
  3. 客户个性问题清单（高价值客户逐个：信号 + 买家原话证据）
  4. 提升路径（针对核心问题的具体动作）
  5. 客户跟进行动（Top客户逐个给下一步）

输出 reports/step6_seller_focus.json，供 step4 看板渲染。
"""
import json
from pathlib import Path
from collections import Counter, defaultdict

SKILL_ROOT = Path(__file__).resolve().parent.parent
REP = SKILL_ROOT / "reports"

TIER_ORDER = {"S": 0, "A": 1, "B": 2, "C": 3, "D": 4}

# 三维子项 → 中文短名（用于核心问题定位）
DIM_CN = {"attitude": "服务态度", "skill": "销售能力", "negotiation": "谈判能力"}

# 健康信号 → 提升动作（共性问题对症）
SIGNAL_FIX = {
    "响应超时": "建立分级 SLA：A/B 档客户 2 小时内首响，下班前清空未回买家。",
    "单向沟通": "停止连发产品图轰炸，改为每条消息只问一个开放问题，把'发'变'问'。",
    "价格僵局": "价格谈不动时引入非价格变量（换规格/调数量/分批发货/账期），不要只让价。",
    "需求误判": "回复前先复述买家的需求点，确认接住了再报方案，避免答非所问。",
    "信任流失": "买家有疑虑时主动甩证据：认证、案例、工厂视频、质保条款。",
    "决策推迟": "买家说'再想想'时锁定具体时间点，给一个限时理由（涨价/排产/库存）推动决策。",
    "竞品介入": "买家比价时，讲清差异化（参数/认证/服务/案例），不要被动降价。",
    "断联未激活": "断联跟进必须带新钩子（新报价/新样品/新案例），不要只发'在吗'。",
}

# 核心问题模板（按最弱维度 + 关键指标）
def diagnose_core(member):
    dims = [("attitude", member["attitude"]["total"]),
            ("skill", member["skill"]["total"]),
            ("negotiation", member["negotiation"]["total"])]
    dims.sort(key=lambda x: x[1])
    weakest, wscore = dims[0]
    sk = member.get("skill", {}).get("evidence", {})
    ne = member.get("negotiation", {}).get("evidence", {})
    at = member.get("attitude", {}).get("evidence", {})
    problems = []
    # 销售能力短板细分
    if member["skill"]["total"] <= 50:
        if sk.get("spin_density", 1) < 0.05:
            problems.append(("不会挖需求", f"SPIN 提问密度仅 {sk.get('spin_density')}（基本不问买家的现状/痛点/影响），只会等买家提要求。"))
        if sk.get("fab_density", 1) < 0.05:
            problems.append(("不会讲价值", f"FAB 话术密度仅 {sk.get('fab_density')}，只发产品图/参数，不讲'这对买家有什么好处'。"))
        if sk.get("next_step_per_conv", 1) < 0.4:
            problems.append(("不推进下一步", f"平均每个会话只有 {sk.get('next_step_per_conv')} 次明确 next step，聊完就断，不主动约下一步。"))
    # 谈判短板
    if member["negotiation"]["total"] <= 50:
        if ne.get("lscpa_hits", 1) == 0 or sk.get("lscpa_hits", 1) == 0:
            problems.append(("不会处理异议", "面对价格/质量异议时只会让价或沉默，不澄清不引导（LSCPA 动作缺失）。"))
        problems.append(("只在价格层博弈", "谈判停留在'你降我买'，不挖买家真实利益点，不创造多赢方案。"))
    # 态度（通常是优势，但也可能有问题）
    if at.get("avg_seller_streak", 0) >= 4:
        problems.append(("单向输出倾向", f"平均连发 {at.get('avg_seller_streak')} 条买家才回一次，主动量高但'有效互动'低。"))
    if not problems:
        problems.append(("整体均衡", f"三维无明显短板（最弱：{DIM_CN[weakest]} {wscore}分），重点维持并提升转化深度。"))
    return {"weakest_dim": DIM_CN[weakest], "weakest_score": wscore, "problems": problems[:4]}


def main():
    s1 = json.loads((REP / "step1_customer_scoring.json").read_text())
    s2 = json.loads((REP / "step2_health_diagnosis.json").read_text())
    s3 = json.loads((REP / "step3_team_diagnosis.json").read_text())
    chats_path = SKILL_ROOT / "data" / "chats.json"
    chats = {c["conversation_id"]: c for c in json.loads(chats_path.read_text())["conversations"]}
    # 可选：客户背调情报（customer_intel.json：buyer_name -> {company,type,match,role,strategy,source}）
    intel_path = REP / "customer_intel.json"
    intel = json.loads(intel_path.read_text()) if intel_path.exists() else {}

    sig_by_conv = {}
    quote_by_conv = {}
    for c in s2.get("conversations", []):
        cid = c["conversation_id"]
        sig_by_conv[cid] = [x["name"] for x in c.get("signals", [])]
        quote_by_conv[cid] = {x["name"]: (x.get("quote") or "") for x in c.get("signals", [])}

    # 客户按业务员归集
    seller_customers = defaultdict(list)
    for c in s1["customers"]:
        cid = c["conversation_id"]
        seller = chats.get(cid, {}).get("seller_name") or "未归属"
        seller_customers[seller].append({
            "cid": cid,
            "name": c.get("buyer_name"),
            "country": c.get("buyer_country"),
            "tier": c.get("tier"),
            "score": c.get("total"),
            "signals": sig_by_conv.get(cid, []),
            "quotes": quote_by_conv.get(cid, {}),
        })

    members = {m["name"]: m for m in s3.get("members", [])}
    out = []
    for seller, custs in seller_customers.items():
        m = members.get(seller)
        custs.sort(key=lambda c: (TIER_ORDER.get(c["tier"], 9), -(c["score"] or 0)))
        n = len(custs)
        # 共性问题：信号出现次数 + 占比
        sig_counter = Counter()
        for c in custs:
            for s in set(c["signals"]):
                sig_counter[s] += 1
        common = []
        for sig, cnt in sig_counter.most_common(4):
            pct = round(cnt * 100 / max(n, 1))
            if pct >= 25:  # 25%以上才算共性
                common.append({"signal": sig, "count": cnt, "pct": pct,
                               "fix": SIGNAL_FIX.get(sig, "")})
        # 个性问题：Top高价值客户逐个（信号+原话）
        individual = []
        for c in custs:
            if c["tier"] in ("S", "A", "B") and c["signals"]:
                ev = ""
                for sig in c["signals"]:
                    q = c["quotes"].get(sig, "")
                    if q:
                        ev = q
                        break
                individual.append({
                    "name": c["name"], "country": c["country"],
                    "tier": c["tier"], "score": c["score"],
                    "signals": c["signals"],
                    "evidence": ev,
                    "action": _next_action(c),
                    "intel": intel.get(c["name"]),  # 背调情报（公司/类型/角色/攻坚策略），无则 None
                })
        individual = individual[:8]  # 每人最多列8个重点客户
        core = diagnose_core(m) if m else {"weakest_dim": "数据不足", "weakest_score": 0, "problems": []}
        # 提升路径 = 核心问题对应动作 + 共性信号 fix
        uplift = []
        for sig in common[:3]:
            if sig["fix"]:
                uplift.append(sig["fix"])
        out.append({
            "seller": seller,
            "customer_count": n,
            "tier_dist": dict(Counter(c["tier"] for c in custs)),
            "scores": {"attitude": m["attitude"]["total"] if m else None,
                       "skill": m["skill"]["total"] if m else None,
                       "negotiation": m["negotiation"]["total"] if m else None} if m else {},
            "core_problems": core,
            "common_problems": common,
            "individual_problems": individual,
            "uplift_path": uplift,
        })
    out.sort(key=lambda x: -x["customer_count"])
    (REP / "step6_seller_focus.json").write_text(json.dumps({"sellers": out}, ensure_ascii=False, indent=2))
    print(f"✅ step6: {len(out)} 个业务员聚焦诊断已生成")
    for s in out[:3]:
        print(f"  {s['seller']}: {s['customer_count']}客户 | 核心短板={s['core_problems']['weakest_dim']} | 共性问题={[c['signal'] for c in s['common_problems']]}")


def _next_action(c):
    """按客户信号给具体跟进动作。"""
    sigs = c["signals"]
    if "断联未激活" in sigs:
        return f"带新钩子重启：给 {c['name']} 发一版新报价/新样品图，附一句行业近况，避免只发'在吗'。"
    if "响应超时" in sigs:
        return f"立即回复 {c['name']} 最后一条消息，先道歉延迟再给方案。"
    if "价格僵局" in sigs:
        return f"对 {c['name']} 引入非价格变量（调数量/换规格/分批），打破僵局。"
    if "决策推迟" in sigs:
        return f"给 {c['name']} 一个限时理由（排产/涨价）推动定下一步时间点。"
    if "竞品介入" in sigs:
        return f"对 {c['name']} 讲清差异化（认证/案例/参数），别被动降价。"
    if "信任流失" in sigs:
        return f"给 {c['name']} 甩信任证据：认证+工厂视频+质保条款。"
    return f"主动跟进 {c['name']}，确认需求并约下一步。"


if __name__ == "__main__":
    main()
