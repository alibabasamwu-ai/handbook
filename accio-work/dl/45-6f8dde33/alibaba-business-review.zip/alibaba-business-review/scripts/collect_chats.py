#!/usr/bin/env python3
"""
聊天数据采集 - 调用 alibaba-chat-insight 的 collect 工具或读取本地 JSON。

v1.1 升级：
  - 默认开启 PII 脱敏：contactName → "Buyer-NN (CC)"，buyer_email → 域哈希
  - 脏数据告警：双空格姓名、邮箱缺 @、国家代码非 ISO、HTML 实体未解码
  - 输出 data/data_quality_warnings.json 供 audit R9 引用
  - 同步生成可逆映射表 data/.anonymization/name_mapping.json（仅本地，不入看板）

用法:
  python3 collect_chats.py --days 7 --output data/chats.json
  python3 collect_chats.py --from-file /path/to/raw.json --output data/chats.json
  python3 collect_chats.py --from-file raw.json --no-anonymize   # 关闭脱敏（不推荐）
"""
import argparse
import hashlib
import html
import json
import re
import sys
from pathlib import Path
from _guard import require_preheat

SKILL_ROOT = Path(__file__).resolve().parent.parent

# ---- PII / 脏数据正则 ----
ISO_CC = re.compile(r"^[A-Z]{2}$")
EMAIL_OK = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")
DOUBLE_SPACE = re.compile(r"\s{2,}")
HTML_ENTITY = re.compile(r"&[a-zA-Z]+;|&#\d+;")
SUSPICIOUS_TYPO = {
    # 常见拼写错误（首字母大写 → 推荐拼写）；编辑距离 = 1
    "Wilon": "Wilson",
    "Jhon": "John",
    "Micheal": "Michael",
    "Anderew": "Andrew",
}


def anonymize_name(idx: int, country: str | None) -> str:
    """生成不可逆代号：Buyer-01 (US)。idx 从 1 开始。"""
    cc = (country or "??").upper()
    return f"Buyer-{idx:02d} ({cc})"


def hash_email_domain(email: str | None) -> str:
    """保留邮箱域结构信息：corp_h<6位hash> / free / invalid。"""
    if not email:
        return "no_email"
    if not EMAIL_OK.match(email.strip()):
        return "invalid"
    domain = email.split("@", 1)[1].lower()
    free_domains = {"gmail.com", "yahoo.com", "hotmail.com", "outlook.com",
                    "qq.com", "163.com", "126.com", "aol.com", "icloud.com"}
    if domain in free_domains:
        return "free"
    return "corp_h" + hashlib.sha1(domain.encode()).hexdigest()[:6]


def detect_quality_issues(raw_name: str | None, raw_email: str | None,
                          raw_country: str | None) -> list:
    issues = []
    if raw_name:
        if DOUBLE_SPACE.search(raw_name):
            issues.append({"field": "contactName", "code": "DOUBLE_SPACE",
                           "raw": raw_name})
        if HTML_ENTITY.search(raw_name):
            issues.append({"field": "contactName", "code": "HTML_ENTITY_NOT_DECODED",
                           "raw": raw_name, "hint": "considered html.unescape"})
        # 拼写检查（按词）
        for token in re.split(r"\s+", raw_name.strip()):
            tk = token.strip(".,;")
            if tk in SUSPICIOUS_TYPO:
                issues.append({"field": "contactName", "code": "POSSIBLE_TYPO",
                               "raw": tk, "suggest": SUSPICIOUS_TYPO[tk]})
        # 全大写姓 (可能是 caps lock 输入)
        words = raw_name.split()
        if len(words) >= 2 and all(w.isupper() and len(w) >= 3 for w in words):
            issues.append({"field": "contactName", "code": "ALL_CAPS",
                           "raw": raw_name})
    if raw_email and not EMAIL_OK.match(raw_email.strip()):
        issues.append({"field": "buyer_email", "code": "MALFORMED_EMAIL",
                       "raw": raw_email})
    if raw_country and not ISO_CC.match(raw_country.strip()):
        issues.append({"field": "buyer_country", "code": "NON_ISO_CC",
                       "raw": raw_country})
    return issues


def normalize(raw: dict, anonymize: bool = True) -> tuple[list, list, dict]:
    """归一化 + 可选脱敏。

    Returns: (conversations, quality_warnings, name_mapping)
    """
    conversations = []
    warnings = []
    mapping = {}  # 原姓名 → 代号；仅本地保留，便于回溯

    convs_raw = raw.get("conversations") or raw.get("data") or []
    for idx, c in enumerate(convs_raw, 1):
        raw_name = c.get("contactName") or c.get("buyer_name") or c.get("name")
        raw_email = c.get("buyer_email") or c.get("email")
        raw_country = c.get("buyer_country") or c.get("country")

        # 收集脏数据告警（用原始字段，不受脱敏影响）
        issues = detect_quality_issues(raw_name, raw_email, raw_country)
        if issues:
            warnings.append({
                "conversation_id": c.get("conversation_id") or c.get("id") or f"conv_{idx}",
                "issues": issues,
            })

        # 脱敏
        if anonymize and raw_name:
            anon_name = anonymize_name(idx, raw_country)
            mapping[raw_name] = anon_name
            display_name = anon_name
            display_email = hash_email_domain(raw_email)
        else:
            display_name = raw_name
            display_email = raw_email

        msgs = []
        for m_idx, m in enumerate(c.get("messages", [])):
            role = m.get("role") or ("buyer" if m.get("sender_type") == "buyer" else "seller")
            msgs.append({
                "role": role,
                "text": m.get("text") or m.get("content") or "",
                "timestamp": m.get("timestamp") or m.get("ts") or 0,
                "message_id": m.get("message_id") or m.get("id"),
                "msg_idx": m_idx,  # v1.1: 稳定索引，供 evidence 回溯
            })
        conversations.append({
            "conversation_id": c.get("conversation_id") or c.get("id") or f"conv_{idx}",
            "buyer_country": raw_country,
            "buyer_email": display_email,
            "buyer_name": display_name,
            "subaccount_id": c.get("subaccount_id"),
            "messages": msgs,
        })
    return conversations, warnings, mapping


def main():
    require_preheat()
    ap = argparse.ArgumentParser()
    ap.add_argument("--days", type=int, default=7)
    ap.add_argument("--from-file", help="从本地原始 JSON 加载，跳过 MCP 调用")
    ap.add_argument("--output", default="data/chats.json")
    # 2026-05-27 默认改为不脱敏（用户裁定 R9 废除，内部使用）。如需脱敏对外发，加 --anonymize
    ap.add_argument("--anonymize", action="store_true",
                    help="强制开启 PII 脱敏（仅外发/分享场景使用）")
    ap.add_argument("--no-anonymize", action="store_true",
                    help="关闭 PII 脱敏（仅本地调试；线上禁用）")
    ap.add_argument("--biz-scope", default="",
                    help="商家主营业务（填商家真实主营品类，不要照抄任何示例词），写入 meta.biz_scope，"
                         "显示在看板副标题。务必填【卖家自己】的主营，不要填客户行业。留空则看板不显示主营。")
    args = ap.parse_args()

    output = SKILL_ROOT / args.output
    output.parent.mkdir(exist_ok=True, parents=True)

    if args.from_file:
        raw = json.loads(Path(args.from_file).read_text())
    else:
        print("⚠️  MCP 调用需在 Agent 上下文中执行。本地直接运行请使用 --from-file",
              file=sys.stderr)
        sys.exit(3)

    # 默认不脱敏；只有显式 --anonymize 才开启（用户裁定 R9 废除，2026-05-27）
    # --no-anonymize 保留兼容（与默认等价）
    anonymize = bool(args.anonymize) and not args.no_anonymize
    conversations, warnings, mapping = normalize(raw, anonymize=anonymize)

    total_msgs = sum(len(c["messages"]) for c in conversations)
    has_subaccount = sum(1 for c in conversations if c.get("subaccount_id"))

    meta = {
        "sample_days": args.days,
        "conversation_count": len(conversations),
        "message_count": total_msgs,
        "subaccount_coverage": f"{has_subaccount}/{len(conversations)}",
        "individual_diagnosis_available": has_subaccount == len(conversations),
        "anonymized": anonymize,
        "anonymization_scheme": "Buyer-NN (CC)" if anonymize else "raw",
        "quality_warning_count": sum(len(w["issues"]) for w in warnings),
        # 商家主营业务（卖家自报，非客户行业）。只在 CLI 显式传入时写入，避免误推断。
        "biz_scope": (args.biz_scope or "").strip(),
    }

    out = {"meta": meta, "conversations": conversations}
    output.write_text(json.dumps(out, indent=2, ensure_ascii=False))
    print(f"✅ Saved {len(conversations)} conversations / {total_msgs} messages → {output}")
    print(f"   subaccount coverage: {meta['subaccount_coverage']}")
    print(f"   PII anonymization: {'ON' if anonymize else 'OFF (UNSAFE)'}")

    # 脏数据告警
    if warnings:
        warn_path = output.parent / "data_quality_warnings.json"
        warn_path.write_text(json.dumps(warnings, indent=2, ensure_ascii=False))
        print(f"⚠️  {meta['quality_warning_count']} data-quality issues across "
              f"{len(warnings)} conversations → {warn_path}", file=sys.stderr)
        # 高频问题摘要
        codes: dict[str, int] = {}
        for w in warnings:
            for iss in w["issues"]:
                codes[iss["code"]] = codes.get(iss["code"], 0) + 1
        for code, n in sorted(codes.items(), key=lambda x: -x[1]):
            print(f"   - {code}: {n}", file=sys.stderr)

    # 映射表（本地审计用，绝不入看板）
    if anonymize and mapping:
        map_dir = output.parent / ".anonymization"
        map_dir.mkdir(exist_ok=True)
        (map_dir / "name_mapping.json").write_text(
            json.dumps(mapping, indent=2, ensure_ascii=False)
        )
        print(f"   name mapping (local only): {map_dir}/name_mapping.json")

    if not meta["individual_diagnosis_available"]:
        print("⚠️  Individual-level team diagnosis NOT available. Will fallback to batch-level.")


if __name__ == "__main__":
    main()
