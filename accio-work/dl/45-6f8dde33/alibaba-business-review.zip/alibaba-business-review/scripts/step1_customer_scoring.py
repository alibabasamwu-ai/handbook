#!/usr/bin/env python3
"""Step1 客户分层评分 (BANT + Persona + Engagement)"""
import json
import sys
from pathlib import Path
from _guard import require_preheat
from scorer import score_customer, classify_tiers

SKILL_ROOT = Path(__file__).resolve().parent.parent

# 主营品类自动推断词表（seller 消息高频产品词 → 中文品类名）
# 仅在商家未显式提供 meta.biz_scope 时作兜底推断，绝不覆盖商家自报值。
_BIZ_KEYWORDS = [
    ("储能系统 / Energy Storage (ESS)", [r"\bess\b", r"\benergy storage\b", r"\bstorage systems?\b",
                                        r"\bbess\b", r"\blifepo4\b", r"\bbattery (pack|cabinet|rack|system)\b",
                                        r"\binverters?\b", r"\bkwh\b", r"\bsolar (battery|storage)\b",
                                        r"\bpower stations?\b", r"\blithium batter"]),
    ("汽车LED照明（尾灯/大灯）", [r"\btail ?lights?\b", r"\bhead ?lights?\b", r"\bfog ?lights?\b",
                                r"\bcar (lights?|lamps?)\b", r"\bauto (lights?|lamps?)\b",
                                r"\bturn signals?\b", r"\bdrl\b", r"\bled tail\b", r"\bbumper\b",
                                r"\bfor toyota\b", r"\bfor suzuki\b", r"\bfor nissan\b", r"\bvios\b"]),
    ("帽子（hat / cap）", [r"\bbucket hats?\b", r"\bbaseball caps?\b", r"\bbeanie", r"\bsnapback",
                          r"\btrucker hat", r"\bcaps?\b", r"\bhats?\b"]),
    ("户外照明 / Solar Light", [r"\bsolar lights?\b", r"\bstreet lights?\b", r"\bflood lights?\b",
                               r"\bgarden lights?\b"]),
    ("跳绳（jump rope）", [r"\bskipping ropes?\b", r"\bjump(ing)? ropes?\b", r"\bspeed ropes?\b",
                          r"\bbeaded ropes?\b", r"\bfitness ropes?\b", r"\bjump rope\b", r"\brope skipping\b"]),
    ("箱包（bag）", [r"\bbackpacks?\b", r"\bhandbags?\b", r"\btote bags?\b"]),
    ("服装（apparel）", [r"\bt-?shirts?\b", r"\bhoodies?\b", r"\bjackets?\b", r"\bgarments?\b"]),
    ("鞋类（footwear）", [r"\bsneakers?\b", r"\bshoes?\b", r"\bboots?\b"]),
    ("首饰（jewelry）", [r"\bjewelr", r"\bnecklaces?\b", r"\bbracelets?\b", r"\bearrings?\b"]),
]


def _infer_biz_scope(convs):
    """从 seller 消息高频产品词推断主营品类。返回中文品类名或空串。
    只看业务员说的话（卖家在卖什么），不看买家行业，避免把客户行业误当主营。"""
    import re as _re
    blob = " ".join(
        (m.get("text") or "").lower()
        for c in convs for m in c.get("messages", [])
        if m.get("role") == "seller"
    )
    if not blob.strip():
        return ""
    best, best_n, second_n = "", 0, 0
    for name, pats in _BIZ_KEYWORDS:
        n = sum(len(_re.findall(p, blob)) for p in pats)
        if n > best_n:
            best, second_n, best_n = name, best_n, n
        elif n > second_n:
            second_n = n
    # 自适应阈值（兼顾大/小样本，仍坚持"宁缺毋错"）：
    #   - 绝对命中 ≥ 3 次，且
    #   - 第一名命中数 ≥ 第二名的 2 倍（避免品类混淆时乱判）
    if best_n >= 3 and best_n >= max(1, second_n) * 2:
        return best
    return ""


def main():
    require_preheat()
    inp = sys.argv[1] if len(sys.argv) > 1 else "data/chats.json"
    out = sys.argv[2] if len(sys.argv) > 2 else "reports/step1_customer_scoring.json"

    data = json.loads((SKILL_ROOT / inp).read_text())
    convs = data["conversations"]
    meta = data.get("meta", {})

    # 主营品类：商家显式 biz_scope 优先；缺失则从 seller 消息自动推断（仍可能为空）
    if not (meta.get("biz_scope") or "").strip():
        inferred = _infer_biz_scope(convs)
        if inferred:
            meta["biz_scope"] = inferred
            meta["biz_scope_inferred"] = True  # 标记为推断值，便于审计/人工复核
            print(f"   ℹ️ 未提供 biz_scope，已从业务员消息推断主营 = {inferred}")

    scores = [score_customer(c) for c in convs]
    # 附加客户基础信息
    for s, c in zip(scores, convs):
        s["buyer_country"] = c.get("buyer_country")
        s["buyer_email"] = c.get("buyer_email")
        s["buyer_name"] = c.get("buyer_name")

    classified = classify_tiers(scores)

    distribution = {"S": 0, "A": 0, "B": 0, "C": 0}
    for c in classified:
        distribution[c["tier"]] += 1

    result = {
        "meta": meta,
        "distribution": distribution,
        "customers": classified,
    }

    out_path = SKILL_ROOT / out
    out_path.parent.mkdir(exist_ok=True, parents=True)
    out_path.write_text(json.dumps(result, indent=2, ensure_ascii=False))
    print(f"✅ Step1 done: S={distribution['S']} A={distribution['A']} "
          f"B={distribution['B']} C={distribution['C']} → {out_path}")


if __name__ == "__main__":
    main()
