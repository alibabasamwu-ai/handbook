# Dictionaries for Alibaba Business Review Localizer

本目录存储了用于将分析报告从中文化（本地化）的映射表和规则。

## 文件说明

- `field-name-map.json`: 评分字段名映射（英文 ID -> 中文+英文括号）。
- `reason-phrase-map.json`: 评分原因短语映射。
- `signal-text-map.json`: 健康度诊断信号文案映射。
- `protected-json-fields.json`: 需要保护、禁止中文化的字段列表（主要为买家原话）。
- `terminology-banner.html`: 报告顶部的术语对照表 HTML 片段。
- `localizer-rules.md`: 中文化执行的技术规则指南。

## 如何引用

Localizer SubAgent 或相关脚本在生成最终报告前，应读取这些 JSON 文件作为配置：
1. 遍历 `field-name-map` 进行键名替换。
2. 对非保护字段的值，遍历 `reason-phrase-map` 和 `signal-text-map` 进行内容替换。

## 如何扩展

- **新增映射**：直接在对应的 JSON 文件中添加键值对。
- **验证**：修改后建议运行 `python -m json.tool <file>.json` 验证语法，并重跑 `audit` 检查。
