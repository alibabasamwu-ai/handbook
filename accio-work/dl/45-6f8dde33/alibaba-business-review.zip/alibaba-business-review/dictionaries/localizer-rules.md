# 中文化执行规则文档 (Localizer Rules)

## 1. 替换顺序
1. **保护现场**：先用占位符 (如 `@@PROTECT_NNNNNN@@`) 保护 `protected-json-fields.json` 中定义的字段值（注意是 value 而非 key）。
2. **字段名转换**：使用 `field-name-map.json` 替换 JSON 键名。必须使用 `\b` 单词边界，避免如 `BANT_BA` 被误匹配成 `BANT_B` + `A`。
3. **原因转换**：使用 `reason-phrase-map.json` 替换评分原因短语。
4. **信号转换**：使用 `signal-text-map.json` 替换健康度诊断文案。
5. **例外处理**：还原 `evidence` 字段内容（如果被保护逻辑误覆盖），因为 `evidence` 是需要展示给用户的中文描述。
6. **还原现场**：将占位符还原回原始文本。

## 2. JS 变量名零误伤规则
严禁替换以下模式，因为它们是数据路径或 JS 代码标识符：
- `.next_step`
- `'next_step'`
- `B5_next_step`
- `team.skill.B5_next_step.score`
- 其他以 `.` 或 `[` 引导的属性路径。

## 3. evidence 字段处理
`evidence` 字段是专门提供给业务员看的中文评分依据，**不属于**保护对象。在处理流程中，应确保其内容被正确本地化，或在全局处理后通过专门逻辑进行二次修正。

## 4. 安全边界 (Regex Safety)
所有正则表达式匹配必须严格遵守：
- 使用 `\b` 单词边界。
- 或使用前后文断言，确保不误伤子字符串（如 `Active` 不应误伤 `Activation`）。

## 5. 验证方式
- 脚本执行完成后，必须运行 `audit/checklist.py` 的 C 类检查（中文化彻底度）。
- 验收标准：在用户可视区域内，裸英文字段名（Raw English Field Names）的出现次数必须为 0。
