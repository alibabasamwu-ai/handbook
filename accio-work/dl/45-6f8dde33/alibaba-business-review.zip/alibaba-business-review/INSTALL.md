# 安装与首次运行（打包版 · 免预热）

> 本打包版已移除强制预热守卫：`scripts/_guard.py` 的 `require_preheat()` 为 no-op，
> 所有评分脚本无需 `.cache/preheat.lock` 即可直接运行。方法论 / 案例 / 审计上下文
> 仍保留在 `references/`、`cases/`、`audit/`，建议编排者（LLM）执行前阅读以保证零幻觉质量。

## 一、解压并放到 agent skills 目录

```bash
# 解压
unzip alibaba-business-review.zip -d /tmp/abr

# 单 agent 安装（${agent_skills} 是你当前 agent 的 skills 目录）
cp -r /tmp/abr/alibaba-business-review ${agent_skills}/

# 或账号级共享（所有 agent 可用）
cp -r /tmp/abr/alibaba-business-review ${account_skills}/
```

注册方式：把目录放进 skills 目录后，Agent 启动会自动扫描 `SKILL.md` 的 frontmatter
（`name: alibaba-business-review`、`trigger_keywords`）完成注册。无需手改 skills.jsonc。

## 二、无需预热（与旧版差异）

旧版必须先跑 `python3 scripts/preheat.py` 写 lock 文件，否则评分脚本拒绝运行。
**本打包版已取消该强制步骤**，直接进入数据准备与评分即可。

如需恢复 lock 校验（例如对外分发要强制注入上下文），把 `scripts/_guard.py` 的
`require_preheat()` 还原为检查 `.cache/preheat.lock` 的版本即可，调用方零改动。

## 三、运行流程（顺序执行）

```bash
cd ${agent_skills}/alibaba-business-review

# 1. 采集真实数据 → data/chats.json
#    ⭐ 推荐：自动遍历全部业务员子账号实时采集（对任意商家通用，自动识别主账号、不写死品类）
python3 scripts/collect_live.py 90          # 采集近 90 天（店名可选 --shop "你的店名"）
#    🚨 千万别只拉主账号！会话按子账号隔离，只拉主账号会漏 90%+ 客户。
#       collect_live.py 已内置 subaccount_query 遍历，无需手动处理。
#    备选：已有 chat-insight 导出文件 → python3 scripts/collect_chats.py --from-file xx.json --output data/chats.json

# 2. 三套评分（step1 会自动从业务员消息推断主营品类，无需手填）
python3 scripts/step1_customer_scoring.py     # 客户分层 BANT+Persona+Engagement
python3 scripts/step2_health_diagnosis.py     # 跟进健康度 7+1 信号（含买家原话）
python3 scripts/step3_team_diagnosis.py        # 团队三维（态度+能力+谈判）

# 3. ⭐业务员聚焦诊断（复盘落地核心：一人一档，核心问题+共性/个性问题+提升路径+客户行动）
python3 scripts/step6_seller_focus.py
#    可选：先把 Top 客户背调结论整理成 reports/customer_intel.json（格式见 customer_intel.example.json），
#    step6 会自动把"公司/采购角色/攻坚策略"接进每个重点客户卡片。

# 4. 主审核 + 生成 HTML 看板（主交付物，会自动渲染上面的业务员聚焦模块）
python3 scripts/step4_audit_and_dashboard.py

# 5. 背调 + 核验表（审计 A9/A10 需要，且产出 Top 客户情报）
python3 scripts/step5_verification_csv.py     # 生成买家核验表 CSV
#    A10 Top客户公网背调：派 browser SubAgent 按 workflow/05-customer-intel.md 做 OSINT
#    建议规模 Top 12~50，整理成 customer_intel.json 后重跑 step6+step4 接入聚焦模块

# 5. （可选）写回 memory 与画像
python3 scripts/post_skill_writeback.py
```

主交付物：`reports/alibaba_review_dashboard.html`（单文件内联 ECharts，离线可开）。
脚本均相对 SKILL_ROOT 读写 `data/`、`reports/`、`logs/`，不要在别的工作目录运行。

## 四、审计三道闸（卡口）

```bash
# 闸 1：内容/反幻觉审计，目标 P0 28/28（PASS）
python3 audit/checklist.py \
  --html reports/alibaba_review_dashboard.html \
  --reports-dir reports/ \
  --chats data/chats.json \
  --out logs/audit.json

# 闸 2：HTML 内嵌 JS 语法检查
bash audit/node-syntax-check.sh reports/alibaba_review_dashboard.html

# 闸 3：（可选）Playwright 端到端渲染校验，无 playwright 自动 SKIP
node audit/browser-test.js reports/alibaba_review_dashboard.html
```

P1 满分非强制：E1 规则可能把买家原话里出现的 "is undefined" 误报为占位符，这是
**真实买家原文**，保留不动。

## 五、Agent 调用流程（SKILL.md 路由内）

```
1. read SKILL.md（阅读方法论/审计契约）
2. 在上下文用 alibaba-chat-insight 采集数据 → 写入 data/chats.json
3. bash: python3 scripts/step1_customer_scoring.py
4. bash: python3 scripts/step2_health_diagnosis.py
5. bash: python3 scripts/step3_team_diagnosis.py
6. bash: python3 scripts/step4_audit_and_dashboard.py
7. bash: 跑审计三道闸（闸1 必过 P0 28/28）
8. emit file link: [看板](file:///绝对路径/reports/alibaba_review_dashboard.html)
9. （可选）bash: python3 scripts/post_skill_writeback.py
```

## 六、最低输入

- `aliId`（店铺账号 ID）
- 时间窗（默认近 30 天）

一句话调用：**「帮我做近 30 天店铺业务复盘」**。
