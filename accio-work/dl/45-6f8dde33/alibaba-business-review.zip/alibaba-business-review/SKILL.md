---
name: alibaba-business-review
version: 2.0.0
description: |
  阿里巴巴国际站跨境电商「店铺级业务复盘」工业化 Skill。融合"阿里国际站营销专家 + 国际谈判专家"双视角，
  通过 8 个专业 SubAgent 协作 + 主 Agent 编排审计，输出客户分层 / 跟进健康度诊断 / 业务员三维能力诊断 /
  核心客户公网背调 / 一份 ≥ 1 MB 的交互式 HTML 看板（含 8 张 ECharts 图表 + 18 条术语对照 banner + 全篇深度中文化）。
  每一分都可回溯到 chats.json 真实证据，每个英文字段都有 dictionaries/ 翻译映射，每次交付都过 audit/ 三道闸。
trigger_keywords:
  - 业务复盘
  - 月度复盘
  - 30天复盘
  - 店铺复盘
  - 客户分层
  - 跟进健康度
  - 团队诊断
  - 业务员能力诊断
  - 谈判能力诊断
  - 阿里复盘
  - 国际站复盘
  - HTML看板
  - 业务诊断看板
runtime: python3
preheat_required: true
preheat_command: python3 scripts/preheat.py
preheat_token_budget: 12000
---

# 阿里巴巴国际站 30 天店铺业务复盘 · v2.0 多 SubAgent 工业化版

> v2.0 升级核心：**单线串行 Python → 8 个 SubAgent 并行编排**，每个环节有独立去幻觉契约，最后 SA-8 跑三道闸强制审计。
> 黄金参考样：[examples/reference-aliId2500000991014/](examples/reference-aliId2500000991014/README.md)（1.08 MB，8 canvas，全篇中文，已脱敏）
> 🛑 仅参考其**排版 / 章节结构 / 中文话术风格**；其中的**品类、客户名、数字全是演示数据，与当前商家无关**，严禁照抄品类设定。

---

## ⚡ 3 分钟上手（用户调用方式）

用户只需说一句：

> 「帮我做近 30 天的店铺业务复盘」

主 Agent 自动执行 Phase 0 互动 3 问 → 8 SubAgent 编排 → 交付 1 份交互式 HTML + 1 张客户核验 CSV + 1 份 Top10 客户背调 MD。

**最低输入**：aliId（默认从已登录店铺读）+ 时间窗（默认近 30 天）。其它一切自动。

---

## 一、定位与价值

### 与其他 Skill 的边界

| Skill | 定位 | 单次粒度 |
|------|------|---------|
| **alibaba-business-review**（本 Skill） | 店铺级 30 天复盘 | 1 店铺 × N 客户 × N 业务员 |
| alibaba-customer-deepdive-dashboard | 单买家深度背调 | 1 客户 |
| alibaba-analysis-brief | 经营数据周报摘要 | 1 店铺 × KPI |

本 Skill 的输出是「面向店铺主管 / 老板」的一份**可发邮件、可投屏会议、可自检审计**的完整复盘交付物。

### 三大不可替代价值

1. **数据真实性**：所有评分均回溯到 `data/chats.json` 真实消息（evidence 字段必填，SA-8 抽检 3 条做子串校验）
2. **方法论严谨**：BANT / SPIN / FAB / LSCPA / Harvard PON / ASK Model 六大模型驱动评分，不是"AI 自由发挥"
3. **工业化质量**：8 SubAgent 各自有去幻觉契约 + SA-8 三道闸（Python checklist + Node 语法 + Playwright 浏览器实测）

---

## 二、为什么必须多 SubAgent（v2.0 的根本动机）

| 痛点（v1.x 单线串行） | v2.0 解决方案 |
|---|---|
| **数据幻觉**：单 Agent 同时跑评分 + 渲染，HTML 后段开始编客户名 | 数据采集 / 评分 / 渲染 / 审计四阶段隔离，每个 SubAgent 单一职责 |
| **采集偏科**：核心客户背调和评分串行，背调占满 context 后评分质量下降 | 评分（SA-2）与背调（SA-5）并行，互不抢 context |
| **风格漂移**：长 HTML 后 60% 部分配色和字段名开始混乱 | SA-6 只渲染（CSS 锁死）、SA-7 只翻译（dictionaries 锁死），各自孤立 session |
| **后段偷懒**：单 Agent 跑到最后只输出"前 5 个客户全量、其余 ... 省略 N 行"被截断 | SA-6 分块 write + 多次 edit 注入数据，每块 ≤ 12 KB |
| **审计失灵**：自己审自己 → 看不出问题；用户审 → 不专业 | SA-8 独立 session 跑 audit/checklist.py 三道闸，pass/fail 退出码定生死 |

---

## 三、SubAgent 团队架构

```
                    ┌─────────────────────────────────────────────┐
                    │  主 Agent（编排 + 业务诊断 + 用户互动）        │
                    │  · 不直接采数据  · 不直接渲染  · 不自审          │
                    └────────┬────────────────────────┬───────────┘
                             │                        │
              Phase 1 串行   ▼                        │
                    ┌────────────────────┐            │
                    │ SA-1 数据采集（bash） │            │
                    │ scripts/collect_chats │           │
                    │ → data/chats.json    │            │
                    └────────┬────────────┘            │
                             │                        │
              Phase 2 ⚡4 路并行                       │
                ┌────────────┼────────────┬───────────┘
                ▼            ▼            ▼            ▼
         ┌─────────┐  ┌─────────┐  ┌──────────┐  ┌────────────┐
         │ SA-2    │  │ SA-3    │  │ SA-4     │  │ SA-5       │
         │ 评分    │  │ 健康度  │  │ 团队三维 │  │ 核心客户   │
         │ (bash)  │  │ (bash)  │  │ (bash)   │  │ 背调       │
         │ step1   │  │ step2   │  │ step3    │  │ (browser × │
         │         │  │ 7+1信号 │  │ 三维评分 │  │ 4路并行)   │
         └────┬────┘  └────┬────┘  └────┬─────┘  └─────┬──────┘
              │            │            │              │
              └────────────┴────┬───────┴──────────────┘
                                ▼
              Phase 3 主 Agent 一轮审计 + 合成 diagnosis.json
                                │
              Phase 4 串行       ▼
                       ┌────────────────────┐
                       │ SA-6 HTML 渲染师    │
                       │ (general)           │
                       │ → 英文版 HTML       │
                       └─────────┬──────────┘
                                 ▼
                       ┌────────────────────┐
                       │ SA-7 中文化专员      │
                       │ (bash)              │
                       │ dictionaries/ 锁死  │
                       │ → 中文版 HTML       │
                       └─────────┬──────────┘
                                 ▼
                       ┌────────────────────┐
                       │ SA-8 独立审计员      │
                       │ (bash)              │
                       │ 三道闸：             │
                       │  ① Python checklist │
                       │  ② Node 语法        │
                       │  ③ Playwright 浏览器 │
                       └─────────┬──────────┘
                                 │
                Phase 5 通过 → 交付 + post_skill.py 上报
                       不通过 → 退回 SA-6 修复（≤ 2 轮）
```

每个 SubAgent 的详细 prompt 见 [workflow/](workflow/) 目录的 9 份 markdown。

---

## 四、Phase 0 · 用户互动 3 问（主 Agent 执行，必须先问）

主 Agent 收到触发 query 后，**第一件事**是 ask_user：

```
ask_user(mode="form", questions=[
  {
    "header": "店铺",
    "question": "复盘哪个店铺？",
    "options": [
      {"label": "当前已登录店铺", "description": "默认从 cookie 读 aliId"},
      {"label": "手动指定 aliId", "description": "我会再问一次具体 aliId"}
    ],
    "recommended": 0
  },
  {
    "header": "时间窗",
    "question": "数据采样窗口？",
    "options": [
      {"label": "近 30 天（推荐）", "description": "样本足够，趋势明确"},
      {"label": "近 7 天", "description": "样本偏少，仅看应急"},
      {"label": "近 90 天", "description": "深度趋势，但执行偏慢"}
    ],
    "recommended": 0
  },
  {
    "header": "视觉档",
    "question": "看板视觉风格？",
    "options": [
      {"label": "D 档高饱和（推荐）", "description": "Hypebeast / DTC 潮品风格 #FF6B35 #FFE600 #0a0a0a"},
      {"label": "A 档商务稳重", "description": "蓝灰主调，适合 OEM 大客户"}
    ],
    "recommended": 0
  }
])
```

> 第 4 问可选：「是否包含 Top 10-15 个 B/A 档客户的公网背调？（默认包含，会让交付时间从 ~3 分钟延长到 ~6 分钟）」

---

## 五、Phase 1：SA-1 数据采集（必须串行第一步）

唯一目标：把近 N 天 IM 数据落地到 `data/chats.json`，结构必须包含 `selfAliId / subAccount / messageId / sendTime / senderId / content`。

> 🚨🚨🚨 **会话按【子账号】隔离铁律（漏了它整份复盘作废）：**
> 阿里国际站 `query_recent_conversation` **只返回你指定 selfAliId 那一个账号名下的会话**。
> 1. **第一步必须先 `subaccount_query`** 拿到店铺**全部**业务员子账号（含主账号）。
> 2. **遍历每一个子账号的 selfAliId** 分别调 `query_recent_conversation` 拉会话，再去重。
>    ❌ 只拉主账号 = 严重漏单。实测某店只拉主账号=9 会话，遍历 7 个子账号=403 会话（**漏了 97.8%**）。
> 3. 会话的 owner = 拉到它的那个子账号 = **天然的业务员归因**（写入 `seller_name`/`subaccount_id`）。
> 4. 拉单会话消息用 `query_conversation_msg`，`forward=true` 从最早翻到最新拉全；该接口**仅支持最近 30 天**消息。
> 5. **推荐直接用 `scripts/collect_live.py <天数>`**（已封装好上述全部逻辑，对任意商家通用，自动识别子账号、不写死任何 aliId/品类）。
>    例：`python3 scripts/collect_live.py 90`（采集近 90 天；店名可选 `--shop "店名"`）。

> 🛑 **主营品类铁律（最高优先级，违反即误判）：**
> 1. **唯一可信来源**：商家主营只能来自 ① 数据采集时显式传入的 `meta.biz_scope`；② `step1` 从 `data/chats.json` 里**业务员(seller)消息**统计高频产品词的自动推断结果。
> 2. **绝对禁止的来源**：❌ 严禁从 `cases/`、`examples/`、`memory/industry_context.md` 或本 skill 任何**样例/案例/预热知识库**推断主营——那些是演示数据，**不是当前商家的事实**。❌ 严禁从买家行业推断（客户是健身品牌来买帽子，主营是"帽子"不是"健身"）。
> 3. **缺省行为**：`meta.biz_scope` 缺失时 step1 会自动推断；推断不出则**留空**，看板不显示主营段落——**宁可不显示，绝不写错品类，绝不硬编码**。
>
> 历史教训：曾因 `industry_context.md`/`case_01` 写死"户外照明=用户主营"，把一家**定制刺绣帽厂**连续误标成"户外照明""跳绳"。根因就是信了样例文件。**任何"某品类是主营"的断言只认真实 seller 消息。**

完整任务规范见 [workflow/01-data-collector.md](workflow/01-data-collector.md)。

派单代码：

```python
sessions_spawn(
  agent_id="bash",
  task="<workflow/01-data-collector.md 的完整内容，并附 aliId={aliId} 时间窗={start_date}~{end_date}>",
  label="SA-1 拉 30 天聊天数据"
)
```

去幻觉契约：每条消息必有 messageId+sendTime+senderId+subAccount；缺一字段直接抛错；不同子账号必须用各自 selfAliId。

---

## 六、Phase 2：SA-2/3/4/5 并行（4 路同时跑）

主 Agent 必须**在同一个 response 里发出 4 个 sessions_spawn**，让它们并行执行：

```python
# 并行批 4 路
[
  sessions_spawn(agent_id="bash",    task="<workflow/02-scorer.md>",            label="SA-2 客户评分"),
  sessions_spawn(agent_id="bash",    task="<workflow/03-health-diagnoser.md>",  label="SA-3 健康度信号"),
  sessions_spawn(agent_id="bash",    task="<workflow/04-team-diagnoser.md>",    label="SA-4 团队三维诊断"),
  sessions_spawn(agent_id="browser", task="<workflow/05-customer-intel.md>",    label="SA-5 核心客户背调"),
]
```

SA-5 内部自己再 spawn 4 个 browser sub-agent（每 2-3 个客户一路），所以总并发可达 8。

收齐 4 路结果后，主 Agent 自己做**一轮审计**：

| 审计项 | 通过标准 |
|---|---|
| step1_customer_scoring.json 客户数 = chats.json 唯一 buyerId 数 | 必须相等（误差 ≤ 1） |
| step2 每个信号触发的客户数 ≥ 1 | 否则信号失效 |
| step3 三个业务员评分均有 evidence | 不能任何一项为空 |
| SA-5 Top 10 客户每个 ≥ 2 项 found=true | 否则标"未核实" |

四项全过 → 合成 `reports/diagnosis.json` → 进入 Phase 3.5。

---

## 六点五、Phase 3.5：step6 业务员聚焦诊断（⭐ 复盘落地核心）

> **目的**：把散落在"客户维度"的数据，重组为"**业务员维度**"——每位业务员一份独立档案，让主管能对每个员工**一针见血 + 有证据 + 有行动路径**地做提升。这是复盘能否落地的关键模块。

运行：
```bash
python3 scripts/step6_seller_focus.py   # 读 step1/2/3 + chats.json (+可选 customer_intel.json)
```

为每位业务员自动生成（输出 `reports/step6_seller_focus.json`，由 step4 渲染成看板"🎯 业务员聚焦诊断"折叠卡）：
1. **核心问题**：从三维分最弱维 + 证据指标（SPIN/FAB 密度、next_step、LSCPA）定位，带具体数字，如"不会挖需求(SPIN密度0.017)"。
2. **客户共性问题**：名下客户出现 ≥25% 的健康信号 + 占比 + 对症提升建议（团队培训重点）。
3. **客户个性问题清单**：A/B 档重点客户逐个列——信号 + **买家原话证据** + 具体跟进动作。
4. **提升路径**：针对共性问题的可执行动作。

> 🔗 **背调情报接入（可选增强）**：若 `reports/customer_intel.json` 存在（buyer_name → {company,type,match,role,strategy,source}），step6 会把每个高价值客户的背调结论（公司/类型/采购角色/攻坚策略）合并进个性问题卡片，实现"内部沟通问题 + 外部客户背景 + 攻坚策略 + 跟进动作"四合一闭环。格式见 `reports/customer_intel.example.json`。背调结论由 SA-5（browser OSINT）产出后整理而成。

---

## 七、Phase 4：SA-6 → SA-7 → SA-8（必须串行）

### 7.1 SA-6 HTML 渲染师（[workflow/06-html-builder.md](workflow/06-html-builder.md)）

| 项 | 锁死值 |
|---|---|
| CSS 设计系统 | 来自 templates/dashboard.html.jinja，禁止改 |
| 8 个 canvas id | chart-layer / chart-health / chart-team-score / chart-radar / chart-batch / chart-heatmap / chart-signals / chart-country |
| ECharts 来源 | CDN 双备：jsdelivr 主 + cdnjs 备 + 加载失败红色提示条 |
| 写入策略 | write 首块 ≤ 12 KB，然后多次 edit 注入数据，避免 token 截断 |
| 文件命名 | reports/alibaba_review_dashboard_aliid{aliId}_{window}.html |

### 7.2 SA-7 中文化专员（[workflow/07-localizer.md](workflow/07-localizer.md)）

唯一输入：SA-6 产出的英文 HTML + [dictionaries/](dictionaries/) 4 份 JSON 映射表
唯一输出：覆盖写回中文 HTML

**必须严格按 7 步顺序**：
1. 用 `dictionaries/protected-json-fields.json` 的 16 个字段名，把它们的 **value** 用 `@@PROTECT_NNNNNN@@` 占位符保护（保护买家原话 DDP / OEM / MOQ 等英文）
2. 用 `field-name-map.json` 替换字段名（**必须 `\b` 单词边界**，避免 BANT_BA 误伤）
3. 用 `reason-phrase-map.json` 替换评分原因
4. 用 `signal-text-map.json` 替换信号文案
5. 如 evidence 字段被第 1 步误覆盖，还原中文
6. 还原所有 `@@PROTECT_NNNNNN@@` 占位符
7. 在 `<body>` 后第一个 div 前插入 `dictionaries/terminology-banner.html`

JS 变量名零误伤规则：`.next_step` `'next_step'` `B5_next_step` `team.skill.B5_next_step.score` 这类**禁止替换**。

### 7.3 SA-8 独立审计员（[workflow/08-auditor.md](workflow/08-auditor.md)）

独立 session（agent_id=bash），不能改文件、不能上网，只跑三道闸：

```bash
# 闸 1：Python checklist
python3 audit/checklist.py \
  --html reports/alibaba_review_dashboard_*.html \
  --reports-dir reports/ \
  --chats data/chats.json \
  --out audit_report.json

# 闸 2：Node 内联 JS 语法
bash audit/node-syntax-check.sh reports/alibaba_review_dashboard_*.html

# 闸 3：Playwright 浏览器实测（typeof echarts / canvas 数 / console error）
node audit/browser-test.js reports/alibaba_review_dashboard_*.html
```

判定：闸 1 P0 100% + 闸 2 通过 + 闸 3 通过 → 交付；任意 fail → 退回 SA-6 修复（最多 2 轮）。

---

## 八、Phase 5：交付 & 上报

主 Agent 给用户的最终回复必须包含：

1. **3 个文件链接**（必须 emit Markdown 链接，不能只口头说）：
   - `[业务复盘看板](file:///绝对路径/alibaba_review_dashboard_{aliId}_{window}.html)`
   - `[客户核验明细 CSV](file:///绝对路径/buyer_verification_table_{aliId}_{window}.csv)`
   - `[Top 10 客户背调 MD](file:///绝对路径/core10_customer_intel.md)`

2. **关键数据摘要**（≤ 8 行）：
   - 数据窗口、unique 会话数、消息数、业务员数
   - 客户分层结果（S/A/B/C 各几个）
   - 7+1 健康度信号触发 Top 3
   - 业务员综合分 Top 3
   - 核心客户背调发现数

3. **下一步建议**（≤ 3 条可执行）

4. **审计通过证明**（必须）：
   - 闸 1 P0: X/Y, P1: X/Y
   - 闸 2: ✅/❌
   - 闸 3: ✅/⚠️(SKIP 浏览器不可用)

5. **静默上报**（用户看不到）：
   ```bash
   python3 ${agent_core}/skills/plugin-memory-manager/scripts/post_skill.py \
     alibaba-business-review '{"outcome": "...", "profile_updates": {"merchant_profile": {...}}}'
   ```

---

## 九、模板文件与脚本

```
alibaba-business-review/
├── SKILL.md                    ← 本文件，v2.0 多 SubAgent 编排主入口
├── README.md                   ← 用户向简介
├── INSTALL.md                  ← 安装与依赖
├── CHANGELOG.md                ← v1 → v2 升级日志
├── workflow/                   ← ⭐ 9 个 SubAgent prompt
│   ├── 00-orchestrator.md      ← 主 Agent 编排逻辑
│   ├── 01-data-collector.md    ← SA-1 数据采集
│   ├── 02-scorer.md            ← SA-2 客户评分
│   ├── 03-health-diagnoser.md  ← SA-3 健康度信号
│   ├── 04-team-diagnoser.md    ← SA-4 团队三维诊断
│   ├── 05-customer-intel.md    ← SA-5 核心客户背调（≥ 4 路并行）
│   ├── 06-html-builder.md      ← SA-6 HTML 渲染
│   ├── 07-localizer.md         ← SA-7 中文化
│   └── 08-auditor.md           ← SA-8 三道闸独立审计
├── scripts/                    ← v1 沉淀的 Python 评分引擎（v2 复用）
│   ├── preheat.py              ← 强制预热契约
│   ├── collect_chats.py        ← SA-1 调用
│   ├── step1_customer_scoring.py  ← SA-2 调用
│   ├── step2_health_diagnosis.py  ← SA-3 调用
│   ├── step3_team_diagnosis.py    ← SA-4 调用
│   ├── step4_audit_and_dashboard.py
│   ├── step5_verification_csv.py
│   ├── scorer.py
│   └── post_skill_writeback.py
├── dictionaries/               ← ⭐ v2 新增 · 中文化映射表（SA-7 核心资产）
│   ├── field-name-map.json     ← 67 条字段名 → 中文+英文括号
│   ├── reason-phrase-map.json  ← 50 条评分原因短语
│   ├── signal-text-map.json    ← 18 条健康度信号文案
│   ├── protected-json-fields.json  ← 16 个买家原话保护字段
│   ├── terminology-banner.html ← 18 条术语 sticky banner
│   ├── localizer-rules.md      ← 替换顺序 + 边界规则
│   └── README.md               ← 字典使用说明
├── audit/                      ← ⭐ v2 新增 · 三道闸独立审计
│   ├── checklist.py            ← 闸 1 · 35 项 P0/P1 校验
│   ├── node-syntax-check.sh    ← 闸 2 · 内联 JS 语法
│   ├── browser-test.js         ← 闸 3 · Playwright 浏览器实测
│   ├── golden-snapshot.json    ← 黄金参考样基线指标
│   ├── anti_hallucination_rules.json
│   ├── auditor_checklist.md
│   └── failure_modes.md
├── templates/                  ← HTML 模板
│   └── dashboard_template.html ← CSS / 骨架（SA-6 必须遵守）
├── examples/                   ← ⭐ v2 新增 · 黄金参考样
│   └── reference-aliId2500000991014/
│       ├── alibaba_review_dashboard_30d_cn.html  (1.08 MB · 全篇中文 · 黄金)
│       ├── buyer_verification_table_30d.csv
│       ├── core10_customer_intel.md
│       ├── reports/  (5 个 JSON)
│       ├── data/     (chats.json + full_dump_30d.json)
│       └── README.md
├── references/                 ← 方法论 / 行业基准 / 阈值校准
│   ├── methodology.md
│   ├── keyword_dictionary.json
│   ├── industry_benchmarks.json
│   └── threshold_calibration.json
├── cases/                      ← 4 个脱敏案例（预热用）
├── memory/                     ← 追问 / 偏好记忆
├── tests/                      ← 单元测试
└── data/ + reports/            ← 运行时产物（每次执行覆盖）
```

---

## 十、典型反幻觉模式（必须避免）

| 反模式 | v2.0 防护 |
|---|---|
| SA-6 渲染时编客户名（"Customer 1, Customer 2..."） | SA-6 prompt 顶部明令禁止；SA-8 闸 1 抽样客户名必须在 chats.json |
| SA-2 评分时"information_missing 给 60 分" | scorer.py 硬编码：信息缺失必为 information_missing 标记 + 分数 = 0 或 NA |
| SA-7 把 JS 变量名翻译了导致页面崩溃 | dictionaries/localizer-rules.md 明令 `\b` 边界 + JS 变量名零误伤；SA-8 闸 2 跑 node --check |
| SA-7 把买家原话 "DDP" 翻译成"完税交货" | dictionaries/protected-json-fields.json 16 个字段值用占位符保护 |
| SA-6 输出长 HTML 被截断（最后 1/3 是 "..."） | SA-6 强制：write 首块 ≤ 12 KB，多次 edit 注入数据；SA-8 闸 1 校验文件 ≥ 500 KB |
| SA-5 找不到客户官网就编一个 | SA-5 prompt 明令：found=false 必须写"未找到"，禁止"疑似/可能" |

---

## 十一、与商家画像的联动（slot-filling）

执行完成后通过 [post_skill.py](../../../agent-core/skills/plugin-memory-manager/scripts/post_skill.py) 上报：

```json
{
  "outcome": "近 30 天复盘已交付：<N> unique 会话 / <M> 业务员 / <K> B 档客户。8 大模块 + 客户清单 + Top 10 背调。",
  "profile_updates": {
    "merchant_profile": {
      "main_category": "<从真实 seller 消息得出的主营品类，不要照抄此处>",
      "target_markets": "<从真实数据统计的买家国家分布>",
      "team_size_active_sellers": "<实际活跃业务员数>",
      "active_buyer_count_30d": "<实际买家数>",
      "core_b_tier_count": "<实际 B 档客户数>"
    },
    "user_preferences": {
      "slot_defaults": {
        "alibaba-business-review": {
          "default_window": "30d",
          "default_visual_grade": "D",
          "include_intel": true,
          "core_intel_topn": 15
        }
      }
    }
  },
  "memory_query": "近 30 天店铺业务复盘 · aliId 2500000991014"
}
```

下次用户再说"做复盘"时，slot-filling 自动填 30d + D 档 + Top 15，无需追问。

---

## 十二、最后的硬性约束（不可妥协）

1. ❌ **绝不跳过 Phase 0 互动**（哪怕用户消息已含 aliId，也要确认时间窗 + 视觉档）
2. ❌ **绝不让 SA-6 直接产中文 HTML**（必须 SA-6 英文版 → SA-7 中文化，两段隔离）
3. ❌ **绝不让 SA-8 跑在主 Agent context**（必须独立 session，否则等于自审）
4. ❌ **绝不在 Phase 4 跳过任意一道闸**（哪怕 Playwright 不可用，必须记 SKIP 而不是"已通过"）
5. ❌ **绝不在最终回复用"已生成"措辞而不附文件链接**（违反 <delivering_results> 契约）
6. ❌ **绝不让 SA-8 闸 1 输出 fail 时还交付**（必须退回 SA-6 修复，最多 2 轮，第 3 轮失败必须明示用户未通过项）

---

## 附录：v1.4 → v2.0 升级变更

详见 [CHANGELOG.md](CHANGELOG.md) 的 v2.0.0 条目。核心变化：

- **新增** `workflow/` 9 个 SubAgent prompt（原来是主 Agent 顺序跑 step1-5）
- **新增** `dictionaries/` 7 个翻译资产（原来是每次执行临时搞 5942+2457 次字符串替换）
- **新增** `audit/checklist.py` + `browser-test.js` + `node-syntax-check.sh` 三道闸（原来是主 Agent 自审）
- **新增** `examples/reference-aliId2500000991014/` 黄金参考样（原来没有可对标的标准件）
- **保留** `scripts/` 全部 v1.x Python 评分引擎（业务逻辑成熟）
- **保留** `references/ + cases/ + memory/` 方法论资产
