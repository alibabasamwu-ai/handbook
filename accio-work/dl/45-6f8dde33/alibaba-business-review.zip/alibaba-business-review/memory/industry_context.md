# 跨境 B2B 行业上下文（预热加载）

## 阿里国际站 B2B 询盘特征

- **买家画像**：60% 是中小型贸易商或本地零售商，30% 是工程项目方，10% 是工厂/品牌方采购
- **询盘节奏**：首轮回复时效是核心指标。Salesforce 数据显示 <2h 回复的转化率比 >8h 高 4 倍
- **决策周期**：B2B 平均 2-6 周；项目类（municipal / 工厂改造）可达 3-6 个月
- **价格敏感度**：新兴市场（PH/VN/PK/EG）首问价格普遍偏低 30-40%，是议价习惯而非真实预算
- **认证门槛**：欧美市场 CE/UL/FCC/RoHS 是入门标配；中东 SASO；澳洲 SAA

## ⚠️ 商家主营品类（不预设，必须从真实数据判断）

**本 skill 服务所有国际站商家，严禁假设任何固定主营品类。**

- 商家主营**只能**来自两个来源：① 数据采集时显式传入的 `meta.biz_scope`；② 从 `data/chats.json` 里**业务员（seller）消息**统计高频产品词得出。
- **绝不能**从买家行业、样例文件（cases/、examples/）、或本文件的历史示例推断主营——那些是演示数据，不是当前商家的事实。
- 判断主营的快速方法：统计 seller 消息里出现最多的产品名词（如 hat/cap/bag/light/rope…），命中最高的就是主营品类；再看真实商品报价片段（"Item: … Material: … Unit price …"）确认。
- 看板副标题的"主营 XXX"只读 `meta.biz_scope`，缺失则留空——宁可不显示，也不要写错品类。

> 历史教训：曾因本文件写死"户外照明（用户主营）"，导致看板把帽子厂误标成户外照明。任何"某品类是用户主营"的断言都不得写进本通用知识库。

## B2B 谈判跨文化特征

- **美国/英国**：直接、效率导向、合同精确，"by Friday" 是真截止线
- **中东**：关系驱动、议价空间预留 15-20%、礼节性寒暄重要
- **东南亚**：价格敏感、长决策链、需要 sample 验证
- **日本**：详细 spec、质保严格、信任建立期长（3-6 个月）
- **拉美**：私人关系、PayPal/TT 偏好、节假日影响大

## 应当避免的话术陷阱

- ❌ "Hi friend, any update?" - 美国/欧洲买家觉得 spammy
- ❌ "Best price for you my friend" - 中东以外市场看起来不专业
- ❌ "We are the best factory" - 缺乏证据，不如 "5 years exporting to your country"
- ❌ "We can do any color" - 无价值承诺
- ✅ "I noticed you mentioned X. Based on similar projects, may I suggest Y?"
- ✅ "For 500 pcs to Texas, our sea freight cost is $X. Total landed $Y."
- ✅ "Our same product is currently used by [reference] in [country]."
