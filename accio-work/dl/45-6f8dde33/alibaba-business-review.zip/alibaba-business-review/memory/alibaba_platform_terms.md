# 阿里国际站术语速查（预热加载）

## 平台沟通工具
- **TM**：TradeManager，国际站 IM
- **询盘**：Buyer Inquiry，买家发起的产品咨询
- **RFQ**：Request for Quotation，买家发布的招标
- **TM 咨询**：通过 TM 直接咨询，非询盘卡形式

## 客户分级（官方）
- **L0/L1/L2/L3**：买家活跃度等级（L3 最活跃）
- **KA buyer**：Key Account，高价值买家
- **新客 / 老客**：30 天内首次询盘 vs 复购

## 询盘指标
- **首响时长**：First Response Time，首次回复时效（<2h 为优）
- **回复率**：48h 内回复的询盘占比（>95% 为优）
- **TM 转化率**：TM 咨询 → 询盘 → 订单

## 商业指标
- **GMV**：Gross Merchandise Value，成交额
- **MOQ**：Minimum Order Quantity，最小起订量
- **PI**：Proforma Invoice，形式发票
- **TT**：Telegraphic Transfer，电汇
- **LC**：Letter of Credit，信用证
- **FOB / CIF / DDP**：贸易术语（离岸价 / 到岸价 / 完税后交货）

## 子账号体系
- **主账号**：店铺所有者
- **子账号**：业务员账号，每个有独立 ID（subaccount_id）
- **公海客户 / 私海客户**：未分配 vs 已分配给具体业务员

## 平台政策红线（不可推测的内容）
- ❌ 不评估搜索排名算法
- ❌ 不评估流量分配机制
- ❌ 不评估账号权重计算公式
- ✅ 可以评估：可观测的沟通行为、回复时效、内容质量
