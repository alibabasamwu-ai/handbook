#!/bin/bash
# 用 node --check 校验内联 JS 是否能解析（提取 <script> 标签内容到临时文件，再 mock 全局变量）
HTML="$1"
if [ -z "$HTML" ]; then
    echo "Usage: $0 <html_path>"
    exit 1
fi

# 修复 mktemp 在 macOS 下加随机后缀导致 node 不认 .js 的问题：用固定文件名 + trap 清理
TMPDIR_X=$(mktemp -d -t bizreview-syntax.XXXXXX)
TMP="${TMPDIR_X}/inline.js"
trap "rm -rf '$TMPDIR_X'" EXIT

cat > "$TMP" <<'MOCK'
var document={getElementById:()=>({getContext:()=>({}),appendChild:()=>{},style:{}}),addEventListener:()=>{},querySelectorAll:()=>[],createElement:()=>({style:{},appendChild:()=>{}})};
var window={addEventListener:()=>{},innerWidth:1920,innerHeight:1080};
var echarts={init:()=>({setOption:()=>{},resize:()=>{},on:()=>{}})};
var console={log:()=>{},warn:()=>{},error:()=>{}};
MOCK

# 提取所有 <script>...</script> 中间无 src 的块（兼容单行 <script>…</script>）
python3 - "$HTML" >> "$TMP" <<'PY'
import re, sys
html = open(sys.argv[1], encoding='utf-8').read()
for m in re.finditer(r'<script(?![^>]*\bsrc=)[^>]*>(.*?)</script>', html, re.S):
    print(m.group(1))
PY

node --check "$TMP"
RC=$?
if [ $RC -eq 0 ]; then
  echo "✅ JS 语法 OK"
else
  echo "❌ JS 语法错误（rc=$RC）"
  echo "--- 临时文件首 40 行 ---"
  head -40 "$TMP"
  exit 1
fi
