const { chromium } = require('playwright');
const path = require('path');
const fs = require('fs');

(async () => {
    const htmlPath = process.argv[2];
    if (!htmlPath) {
        console.error("Usage: node browser-test.js <html_path>");
        process.exit(1);
    }

    const absolutePath = path.isAbsolute(htmlPath) ? htmlPath : path.resolve(process.cwd(), htmlPath);
    const fileUrl = `file://${absolutePath}`;

    const browser = await chromium.launch();
    const page = await browser.newPage();
    
    const errors = [];
    page.on('pageerror', err => errors.push(err));
    page.on('console', msg => {
        if (msg.type() === 'error') errors.push(msg.text());
    });

    try {
        await page.goto(fileUrl);
        await page.waitForTimeout(2000); // Wait for ECharts

        const metrics = await page.evaluate(() => {
            return {
                echartsDefined: typeof echarts !== "undefined",
                canvasCount: document.querySelectorAll('canvas').length,
                hasTerminology: document.body.innerText.includes('术语对照'),
                bodyTextLength: document.body.innerText.length
            };
        });

        await page.screenshot({ path: 'audit_screenshot.png' });

        const result = {
            success: metrics.echartsDefined && metrics.canvasCount === 8 && errors.length === 0 && metrics.hasTerminology,
            metrics,
            errors
        };

        console.log(JSON.stringify(result, null, 2));
    } catch (e) {
        console.error(e);
        process.exit(1);
    } finally {
        await browser.close();
    }
})();
