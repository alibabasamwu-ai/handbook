# 已知失败模式与缓解策略

## F1 · "勤奋的搬运工"误判
**症状**：seller 发消息很多 → 系统给"主动性 A2"高分 → 实际是单向独白
**缓解**：连续 seller 独白 ≥3 条时 A2 反向扣分（已在 scorer.py 实现）

## F2 · subaccount_id 缺失导致个人评分失真
**症状**：collect.py 未携带账号字段 → 所有 conversation 被归到同一虚拟 seller
**缓解**：检测到缺失时自动降级到 Batch 级 + 在看板透明披露

## F3 · 短周期样本下 BANT 信息天然缺失
**症状**：7 天窗口内 80% 客户的 BANT-T 都缺失 → 都被打到 C 级
**缓解**：threshold_calibration.json 的相对分布法自动启用（Top10% S / 10-30% A）

## F4 · 价格僵局误判为价格异议
**症状**：买家只是问了一次价格被判为"信号 3 触发"
**缓解**：信号 3 要求"价格讨论 ≥2 次"，单次询价不触发

## F5 · 非英语对话漏检关键词
**症状**：买家用西班牙语/俄语 → 关键词词典全部 miss → 给低分
**缓解**：keyword_dictionary.json 暂仅支持英语；遇到非英语时强制 information_missing 并提示"建议人工二次评估"

## F6 · 同行基准过期
**症状**：industry_benchmarks.json 使用 2 年前数据
**缓解**：as_of 字段超 18 个月时灰色显示 + 看板脚注提示

## F7 · 看板渲染依赖 CDN 失败
**症状**：Chart.js / TailwindCSS 通过 CDN 加载，离线打开空白
**缓解**：dashboard_template.html 全部内联（CSS + 极简 SVG 图表，不引用外部 JS 库）

## F8 · LLM 修改了 scorer.py 给出的分数
**症状**：LLM 在 narrative 阶段擅自把 60 分改成 80 分
**缓解**：step4 审计阶段 diff 对比 scorer.py 输出 vs 最终 JSON，不一致直接 fail
