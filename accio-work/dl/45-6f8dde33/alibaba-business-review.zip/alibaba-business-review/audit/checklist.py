#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Alibaba Business Review 30-Day Shop Audit Checklist v2.0
============================================================
P0/P1 validation for alibaba-business-review skill.

Usage:
  python3 checklist.py --html <path> --reports-dir <dir> --chats <json> --out <json>
"""

import argparse
import json
import os
import re
import sys
from pathlib import Path

# -------- Utilities --------

def load_json(path: Path):
    if not path or not path.exists():
        return None
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return None

def grep_count(html: str, pattern: str, flags=0) -> int:
    return len(re.findall(pattern, html, flags))

def make_result(check_id, category, level, ok, reason, evidence=""):
    return {
        "id": check_id,
        "category": category,
        "level": level,
        "pass": bool(ok),
        "reason": reason,
        "evidence": str(evidence)[:400],
    }

# -------- A. Structure P0 (10) --------

def check_structure(html: str, html_path: Path, reports_dir: Path):
    results = []
    
    # A1: Size >= 500KB
    size_kb = html_path.stat().st_size / 1024
    results.append(make_result("A1", "structure", "P0", size_kb >= 500, f"文件大小 {size_kb:.1f}KB (要求 >= 500KB)"))

    # A2: 8 canvas ids
    canvas_ids = ["chart-layer", "chart-health", "chart-team-score", "chart-radar", "chart-batch", "chart-heatmap", "chart-signals", "chart-country"]
    missing = [cid for cid in canvas_ids if f'id="{cid}"' not in html and f"id='{cid}'" not in html]
    results.append(make_result("A2", "structure", "P0", not missing, f"缺失 canvas: {missing}" if missing else "8个 canvas id 全部存在"))

    # A3: Terminology banner sticky
    has_banner = "术语对照" in html and "sticky" in html.lower()
    results.append(make_result("A3", "structure", "P0", has_banner, "术语对照 banner sticky 存在"))

    # A4: ECharts CDN (jsdelivr + cdnjs)
    has_jsdelivr = "cdn.jsdelivr.net" in html.lower() and "echarts" in html.lower()
    has_cdnjs = "cdnjs.cloudflare.com" in html.lower() and "echarts" in html.lower()
    results.append(make_result("A4", "structure", "P0", has_jsdelivr and has_cdnjs, "ECharts 主备 CDN 引入"))

    # A5: ECharts fail hint
    has_fail_hint = any(x in html for x in ["加载失败", "failed to load", "ECharts load error"])
    results.append(make_result("A5", "structure", "P0", has_fail_hint, "ECharts 加载失败提示条存在"))

    # A6: HTML tags closed (basic)
    is_closed = html.strip().endswith("</html>")
    results.append(make_result("A6", "structure", "P0", is_closed, "HTML 标签闭合"))

    # A7: @media responsive
    has_media = "@media" in html
    results.append(make_result("A7", "structure", "P0", has_media, "移动端 @media 存在"))

    # A8: Unreplaced placeholders
    unreplaced = grep_count(html, r"\{\{[a-zA-Z0-9_]+\}\}")
    results.append(make_result("A8", "structure", "P0", unreplaced == 0, f"未替换占位符: {unreplaced}"))

    # A9: buyer_verification_table.csv — 兼容两种布局（与 reports/ 同级 OR 在 reports/ 内）
    csv_candidates = [
        reports_dir / "buyer_verification_table.csv",
        reports_dir.parent / "buyer_verification_table.csv",
    ]
    csv_candidates += list(reports_dir.parent.glob("buyer_verification_table*.csv"))
    csv_exists = any(p.exists() for p in csv_candidates)
    results.append(make_result("A9", "structure", "P0", csv_exists, "buyer_verification_table*.csv 存在"))

    # A10: core10_customer_intel.md — 同样兼容两种布局
    md_candidates = [
        reports_dir / "core10_customer_intel.md",
        reports_dir.parent / "core10_customer_intel.md",
    ]
    md_exists = any(p.exists() for p in md_candidates)
    results.append(make_result("A10", "structure", "P0", md_exists, "core10_customer_intel.md 存在"))

    return results

# -------- B. Data Truth P0 (10) --------

def check_data_truth(html: str, reports_dir: Path, chats_path: Path):
    results = []
    
    # B1: KPI 卡片 — 至少 4 张（黄金样实测 4 张）；若 ≥6 加分但不强制
    kpi_count = grep_count(html, r'class="[^"]*kpi[^"]*"')
    results.append(make_result("B1", "data", "P0", kpi_count >= 4, f"KPI 卡片 {kpi_count} 个 (要求 >= 4)"))

    # B2: Customer segmentation rows
    step1 = load_json(reports_dir / "step1_customer_scoring.json") or []
    expected_rows = len(step1) if isinstance(step1, list) else 0
    seg_table = re.search(r"<table.*?>[\s\S]*?</table>", html)
    table_rows = grep_count(seg_table.group(0) if seg_table else "", r"<tr") - 1
    if expected_rows == 0:
        results.append(make_result("B2", "data", "P0", True, "step1 为空跳过分层表校验"))
    else:
        results.append(make_result("B2", "data", "P0", table_rows >= expected_rows, f"分层表行数 {table_rows} (预期 {expected_rows})"))

    # B3: Health signals in chats.json
    chats = load_json(chats_path) or []
    all_chat_text = ""
    if isinstance(chats, list):
        for c in chats:
            all_chat_text += str(c.get("content", "")) + str(c.get("message", "")) + str(c.get("text", ""))

    signals = re.findall(r'<div class="signal-text">([^<]+)</div>', html)
    sampled = signals[:3]
    if not sampled:
        results.append(make_result("B3", "data", "P0", True, "未找到 .signal-text 节点，跳过抽样校验"))
    else:
        found_count = sum(1 for s in sampled if s.strip()[:10] in all_chat_text)
        results.append(make_result("B3", "data", "P0", found_count == len(sampled), f"健康度信号抽样匹配: {found_count}/{len(sampled)}"))

    # B4: Values from reports
    report_files = list(reports_dir.glob("*.json"))
    has_reports = len(report_files) > 0
    results.append(make_result("B4", "data", "P0", has_reports, f"找到 {len(report_files)} 个 report JSON 文件"))

    # B5: Salesperson names
    step3 = (load_json(reports_dir / "step3_team_diagnosis.json")
             or load_json(reports_dir / "step3_sales_performance.json")
             or {})
    sales_names = []
    if isinstance(step3, dict):
        for k in ("team", "sales_persons", "members", "salespersons"):
            if isinstance(step3.get(k), list):
                sales_names = [s.get("name") for s in step3[k] if isinstance(s, dict) and s.get("name")]
                break
    elif isinstance(step3, list):
        sales_names = [s.get("name") for s in step3 if isinstance(s, dict) and s.get("name")]
    if not sales_names:
        sales_names = ["Susie", "Portia", "Jimmy"]
    found_sales = [n for n in sales_names if n in html]
    results.append(make_result("B5", "data", "P0", len(found_sales) > 0, f"业务员名字出现: {found_sales[:5]}"))

    # B6: Customer names
    def _name_of(c):
        if not isinstance(c, dict):
            return None
        return c.get("company") or c.get("name") or c.get("buyer_name") or c.get("buyerName")
    if isinstance(step1, list):
        cust_names = [_name_of(c) for c in step1[:15]]
    elif isinstance(step1, dict) and isinstance(step1.get("customers"), list):
        cust_names = [_name_of(c) for c in step1["customers"][:15]]
    else:
        cust_names = []
    found_cust = [n for n in cust_names if n and n in html]
    if not cust_names:
        results.append(make_result("B6", "data", "P0", True, "step1 无 customer 列表，跳过名字校验"))
    else:
        results.append(make_result("B6", "data", "P0", len(found_cust) > 0, f"客户名字出现: {len(found_cust)} 个"))

    # B7: aliId appears
    has_aliid = "aliId" in html or re.search(r"\d{10,}", html)
    results.append(make_result("B7", "data", "P0", has_aliid, "aliId 标识存在"))

    # B8: 采样窗口声明存在（不写死 30 天，支持任意窗口：30/90天 或日期范围）
    import re as _re8
    has_window = bool(
        "数据周期" in html
        or _re8.search(r"\d+\s*天", html)
        or _re8.search(r"\d+\s*days", html.lower())
        or _re8.search(r"\d{4}-\d{2}-\d{2}\s*[~\-]\s*\d{4}-\d{2}-\d{2}", html)
    )
    results.append(make_result("B8", "data", "P0", has_window, "采样窗口声明存在（数据周期/X天/日期范围）"))
    
    # B9: chats.json existence
    results.append(make_result("B9", "data", "P0", chats_path.exists(), "chats.json 存在"))
    
    # B10: reports dir not empty
    results.append(make_result("B10", "data", "P0", has_reports, "reports 目录不为空"))

    return results

# -------- C. Chinese coverage P0 (8) --------

def check_chinese(html: str):
    results = []
    
    # C1: Scanning English fields in UI
    eng_fields = ["BANT_B", "Persona_Country", "Engagement_Active", "information_missing", "48h response rate"]
    found_fields = []
    # Simplified check: check if these appear outside script/style tags
    body_content = re.sub(r"<(script|style)[\s\S]*?</\1>", "", html)
    for f in eng_fields:
        if f in body_content:
            found_fields.append(f)
    results.append(make_result("C1", "chinese", "P0", len(found_fields) == 0, f"UI 发现裸英文字段: {found_fields}"))

    # C2: Terminology banner >= 10 terms
    terms = ["BANT", "SPIN", "FAB", "Persona", "Engagement", "MOQ", "OEM", "DDP", "FOB", "CIF",
             "RFQ", "5min", "48h", "AB3", "RNR", "P0", "P1", "P2", "B档", "断联"]
    found_terms = [t for t in terms if t in html]
    results.append(make_result("C2", "chinese", "P0", len(found_terms) >= 10, f"术语库词汇量: {len(found_terms)}/20"))

    # C3: Health signal Chinese
    has_cn_signal = "业务员跟进" in html and "下一步动作" in html
    results.append(make_result("C3", "chinese", "P0", has_cn_signal, "健康度信号文案已中文化"))
    
    # C4-C8: Additional Chinese checks (splitting the 8 items)
    results.append(make_result("C4", "chinese", "P0",
        any(k in html for k in ["店铺业务复盘", "业务复盘", "经营复盘", "经营看板"]),
        "标题含 '店铺业务复盘/经营复盘/经营看板'"))
    results.append(make_result("C5", "chinese", "P0", "核心指标" in html or "KPI" in html, "含 '核心指标' 或 'KPI'"))
    results.append(make_result("C6", "chinese", "P0", "客户" in html, "含 '客户' 字样"))
    results.append(make_result("C7", "chinese", "P0", "诊断" in html or "建议" in html, "含 '诊断' 或 '建议'"))
    results.append(make_result("C8", "chinese", "P0", "趋势" in html or "分布" in html, "含 '趋势' 或 '分布'"))

    return results

# -------- D. Visual P1 (4) --------

def check_visual(html: str):
    results = []
    
    # D1: Colors
    colors = ["#FF6B35", "#FFE600", "#0a0a0a"]
    found_colors = [c for c in colors if c.lower() in html.lower()]
    results.append(make_result("D1", "visual", "P1", len(found_colors) >= 2, f"品牌色匹配: {found_colors}"))

    # D2: Sticky CSS
    has_sticky = "position:sticky" in html.replace(" ", "").lower() or "position: sticky" in html.lower()
    results.append(make_result("D2", "visual", "P1", has_sticky, "CSS 含 position:sticky"))

    # D3: Red for error
    has_error_red = "#ef4444" in html.lower() or "red" in html.lower()
    results.append(make_result("D3", "visual", "P1", has_error_red, "加载失败提示用红色"))

    # D4: Viewport
    has_viewport = 'name="viewport"' in html
    results.append(make_result("D4", "visual", "P1", has_viewport, "Viewport meta 存在"))

    return results

# -------- E. Anti-hallucination P1 (3) --------

def check_anti_hallucination(html: str):
    results = []
    
    # E1: undefined check
    has_undefined = "is undefined" in html or "undefined" in html.split("<script")[-1] # rough check
    results.append(make_result("E1", "hallucination", "P1", "is undefined" not in html, "未发现 'is undefined' 错误文本"))

    # E2: source_url http
    urls = re.findall(r'source_url["\']:\s*["\']([^"\']+)["\']', html)
    bad_urls = [u for u in urls if not u.startswith("http")]
    results.append(make_result("E2", "hallucination", "P1", len(bad_urls) == 0, f"source_url 格式正确: {len(bad_urls)} 个错误"))

    # E3: Evidence date stamp
    has_date = re.search(r"202[0-9]-[0-9]{2}-[0-9]{2}", html)
    results.append(make_result("E3", "hallucination", "P1", has_date, "证据链含日期戳"))

    return results

# -------- Main --------

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--html", required=True)
    parser.add_argument("--reports-dir", required=True)
    parser.add_argument("--chats", required=True)
    parser.add_argument("--out", required=True)
    args = parser.parse_args()

    html_path = Path(args.html)
    reports_dir = Path(args.reports_dir)
    chats_path = Path(args.chats)

    if not html_path.exists():
        print(f"Error: HTML not found at {html_path}")
        sys.exit(1)

    html = html_path.read_text(encoding="utf-8", errors="ignore")

    all_results = []
    all_results.extend(check_structure(html, html_path, reports_dir))
    all_results.extend(check_data_truth(html, reports_dir, chats_path))
    all_results.extend(check_chinese(html))
    all_results.extend(check_visual(html))
    all_results.extend(check_anti_hallucination(html))

    p0_results = [r for r in all_results if r["level"] == "P0"]
    p1_results = [r for r in all_results if r["level"] == "P1"]
    
    p0_pass = sum(1 for r in p0_results if r["pass"])
    p1_pass = sum(1 for r in p1_results if r["pass"])
    
    verdict = "PASS" if p0_pass == len(p0_results) else "FAIL"

    output = {
        "summary": {
            "p0": f"{p0_pass}/{len(p0_results)}",
            "p1": f"{p1_pass}/{len(p1_results)}",
            "verdict": verdict
        },
        "results": all_results
    }

    with open(args.out, "w", encoding="utf-8") as f:
        json.dump(output, f, ensure_ascii=False, indent=2)

    print(f"P0: {p0_pass}/{len(p0_results)}, P1: {p1_pass}/{len(p1_results)}, Verdict: {verdict}")
    sys.exit(0 if verdict == "PASS" else 1)

if __name__ == "__main__":
    main()
