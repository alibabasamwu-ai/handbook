# 方法论参考（预热必读）

> 本文件在 preheat 时会被完整加载到 Agent 上下文。所有评分必须严格对齐此文件定义的概念，
> **禁止根据自己的理解扩展或修改框架**。

---

## 一、客户分层方法论（BANT + Persona + Engagement，100 分）

### 1.1 BANT（45 分）— 来源：IBM 1960s，现为 Salesforce / HubSpot B2B 标准
| 维度 | 分值 | 评分依据 | 信息缺失时 |
|------|------|----------|------------|
| **B - Budget 预算** | 15 | 高($10K+):15 / 中($1K-$10K):10 / 仅说数量:5 | 标 `information_missing` 给 0 |
| **A - Authority 决策权** | 10 | 企业邮箱+5 / 职位关键词(CEO/Purchasing/Manager)+5 | 仅免费邮箱给 0 |
| **N - Need 需求明确度** | 12 | spec/scene/market/cert 四项，每项 3 分 | 缺失项不给分 |
| **T - Timeline 时间线** | 8 | 紧急(ASAP/within X):8 / 中(Q1/by Month):5 / 模糊提及:2 | 缺失给 0 |

### 1.2 Buyer Persona Fit（30 分）— 来源：LinkedIn Sales Navigator ICP 框架
| 维度 | 分值 | 评分依据 |
|------|------|----------|
| 国家分层 | 10 | EU/US/AU/JP:10 / Mid-East+Gulf+SEA:7 / 新兴市场:5 / 其他:3 / 未知:0 |
| 公司真实性 | 10 | 企业邮箱:7 / 提及公司:4 / 仅免费邮箱:2 |
| 品类匹配 | 10 | 精准品类词:10 / 相关词:6 / 仅询盘卡默认:4 |

### 1.3 Engagement Depth（25 分）— 来源：阿里国际站官方《客户分级运营白皮书》
| 维度 | 分值 | 评分依据 |
|------|------|----------|
| 主动性 | 8 | 买家提问 ≥5:8 / 3-4:5 / 1-2:2 / 0:0 |
| 深度信号 | 8 | sample+PI:8 / 单项:5 / 仅 catalog:2 / 无:0 |
| 多渠道 | 5 | TM+email+WA+video 累加，封顶 5 |
| 时效配合 | 4 | 48h 内回复率 ≥80%:4 / 50-80%:2 / <50%:0 |

### 1.4 分层阈值
- **绝对参考线**：S(≥80) / A(60-79) / B(40-59) / C(<40)
- **相对分布法**（样本 <30 时启用）：Top10%=S / 10-30%=A / 30-70%=B / 70-100%=C
- 看板必须同时展示两套分层结果，供用户对照

---

## 二、跟进健康度诊断（7+1 信号）

### 2.1 健康度计算
`health = max(0, 100 - 严重信号数 × 20 - 中等信号数 × 10)`

状态分级：健康(≥80) / 亚健康(60-79) / 危险(40-59) / 濒临流失(<40)

### 2.2 八大信号定义

| # | 信号 | 严重度 | 触发条件 | 检测关键词/规则 |
|---|------|--------|----------|----------------|
| 1 | 响应超时 | 高 | 买家最后消息距今 >48h 无回复 | 时间戳计算 |
| 2 | 单向沟通 | 高 | 最近 5 轮中 seller 独白 >3 轮 | 角色序列 |
| 3 | 价格僵局 | 中 | 价格讨论 ≥2 次但 seller 未引入新变量 | `price/cost/$/quote` ∧ ¬`moq/payment/free sample/gift` |
| 4 | 需求误判 | 高 | 买家关键诉求 ≥2 项未被正面回应 | spec/cert/warranty/lead time 词典匹配 |
| 5 | 信任流失 | 高 | 买家出现质疑后 seller 未做信任修复 | doubt 词 → cert/audit/video 缺失 |
| 6 | 决策推迟 | 中 | "let me think"后 >7 天无后续 | think 词 + 时间差 |
| 7 | 竞品介入 | 高 | 买家提竞品后 seller 未做差异化应对 | competitor 词 → unique/patent/years 缺失 |
| 8 | 断联未激活 | 高 | 买家 >24h 未回 + seller 之后无主动激活 | 角色序列 + 时间差 |

---

## 三、员工三维能力诊断（态度 30% + 能力 40% + 谈判 30%）

### 3.1 维度一：态度（100 分）— 来源：ASK Model 中 Attitude 维度

| 子项 | 分值 | 评分 |
|------|------|------|
| A1 响应及时性 | 25 | <2h:25 / 2-8h:15 / >8h:5 |
| A2 跟进主动性 | 25 | seller 连发(主动激活) ≥3/会话:25 / 1-3:15 / 0:0 |
| A3 情绪稳定性 | 25 | 0 条负面词:25 / 1-2 条:15 / >2:5 |
| A4 跨时区配合 | 25 | 有夜间响应(00-07时):25 / 客户US/CA无夜间:10 / 默认:15 |

### 3.2 维度二：能力（100 分）— 来源：SPIN Selling (Rackham) + ASK Skill

| 子项 | 分值 | 评分 |
|------|------|------|
| B1 需求挖掘 SPIN | 25 | density ≥0.3:25 / 0.15-0.3:15 / 0.05-0.15:8 / <0.05:0 |
| B2 产品介绍 FAB | 20 | density ≥0.3:20 / 0.15-0.3:12 / 0.05-0.15:6 / <0.05:0 |
| B3 阶梯报价 | 20 | tier_hits ≥3:20 / ≥1:10 / 0:0 |
| B4 异议处理 LSCPA | 20 | hits ≥3:20 / ≥1:10 / 0:0 |
| B5 闭环推进 next step | 15 | density ≥1/会话:15 / 0.5-1:8 / <0.5:0 |

**SPIN 四类问题**：
- **S**ituation：现状（currently use / what now / your market）
- **P**roblem：问题（problem / issue / challenge / pain）
- **I**mplication：暗示（impact / cost you / losing / if continue）
- **N**eed-payoff：需求满足（would help / benefit / solve / improve）

**FAB 三段式**：Feature → Advantage → Benefit（关键连接词：because / so that / allow you / help you / save you）

**LSCPA 五步**：Listen → Share → Clarify → Present → Ask for action（关键词：I understand / I hear you / that concern / valid point / let me clarify）

### 3.3 维度三：谈判技巧（100 分）— 来源：Harvard Negotiation Project《Getting to Yes》

| 子项 | 分值 | 评分 |
|------|------|------|
| C1 对人不对事 | 20 | 0 负面词:20 / 1-2:12 / >2:5 |
| C2 聚焦利益（探询 why） | 25 | why ≥5:25 / 2-4:15 / 1:8 / 0:0 |
| C3 创造多赢（新变量） | 30 | 非价格变量 density ≥2:30 / 1-2:18 / 0.5-1:10 / <0.5:0 |
| C4 客观标准 | 25 | 引用市场/原材料/认证 ≥3:25 / 1-2:12 / 0:0 |

---

## 四、引用来源（看板底部必须展示）

- BANT：IBM Sales Methodology (1960s) · Salesforce Trailhead 当前版本
- SPIN Selling：Neil Rackham, 《SPIN Selling》McGraw-Hill 1988
- FAB：Strong, E.K., 《The Psychology of Selling》(1925) · 现代 HubSpot Sales 教材
- LSCPA：Jeb Blount, 《Objections》Wiley 2018
- Harvard Negotiation Project：Roger Fisher & William Ury, 《Getting to Yes》Penguin 2011 (3rd ed.)
- ASK Model：ATD (Association for Talent Development) Sales Competency Framework
- 阿里国际站《客户分级运营白皮书》《询盘转化诊断手册》（卖家中心公开发布版）
- Salesforce State of Sales Report 2024（公开版）
- HubSpot Pipeline Generation Benchmark 2024
- Harvard PON Cross-Cultural Negotiation Research（公开论文集）
