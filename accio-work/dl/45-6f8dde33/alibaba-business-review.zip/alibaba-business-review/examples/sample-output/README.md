# 样例产物框架 · sample-output

> 本目录提供一份**脱敏后**的交互式 HTML 看板范例，用于展示本 Skill 最终交付物的
> 框架结构、section 顺序、图表布局与浅色专业商务风视觉。**真实买家数据已全部剔除**。

## 文件

| 文件 | 说明 |
|------|------|
| `sample_dashboard_cn.html` | 交互式 HTML 看板范例（全篇中文，内联 ECharts，离线可开） |

## 看板框架（section 顺序）

1. 顶部 KPI 概览条（会话数 / 消息数 / 客户分层计数 / 团队均分）
2. 客户分层分布（chart-layer）+ 国家分布（chart-country）
3. 跟进健康度信号（chart-health / chart-signals）
4. 团队三维能力雷达（chart-radar）+ 业务员战力榜（chart-team-score）
5. 接待批次 / 热力分布（chart-batch / chart-heatmap）
6. 核心客户背调卡片（含对话证据片段 + 业务员归属 + 诊断）
7. 行动建议（Top 行动项）

8 个 canvas chart-id：`chart-batch / chart-country / chart-health / chart-heatmap /
chart-layer / chart-radar / chart-signals / chart-team-score`。

## 用途说明

- **模板参考**：SA-6 HTML builder 可参考本范例的 section 顺序与 ECharts 配置。
- **视觉基准**：浅色专业商务风（`--bg:#f4f5f7 / --panel:#ffffff / --txt:#1d2129 /
  --accent:#E85D2A / --highlight:#C77800`），无暗色块，文字高对比。
- **回归基准**：`audit/golden-snapshot.json` 记录基线指标，`audit/checklist.py` 可对标。

> 注：真实店铺的回归基准数据（reports/、data/）不随包分发，请用你自己运行产出的
> `reports/` 作为实际审计对象（闸 1 应 PASS，P0 28/28）。
