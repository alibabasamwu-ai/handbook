# 阿里巴巴国际站业务复盘 Skill

> 阿里国际站跨境电商商家的月度业务复盘工具。基于真实 IM 数据，输出客户分层、跟进健康度诊断、
> 团队三维能力评估，以及一份单文件交互式 HTML 看板。**所有评分都可回溯到原文证据，反幻觉硬约束。**

## 核心特性

| 特性 | 说明 |
|------|------|
| ⚡ **免预热（本打包版）** | `scripts/_guard.py` 的 `require_preheat()` 已改为 no-op，脚本直接可跑，无需先跑 preheat.py。方法论/案例/审计上下文仍在 references/、cases/、audit/ 供编排者阅读 |
| 📊 **三套评分** | 客户分层（BANT+Persona+Engagement 100 分）/ 健康度（7+1 信号）/ 团队三维（态度+能力+谈判） |
| 🔍 **反幻觉审计** | 8 条审计规则 + 三道闸卡口，每分必有 evidence，缺数据强制「信息缺失」 |
| 📈 **同行对比** | 同行均值数据来自 Salesforce / HubSpot / Harvard PON 公开报告（基准必须可追溯） |
| 🎨 **可视化看板** | 单文件 HTML 内联 ECharts，无外部依赖，离线可打开，浅色专业商务风 |
| 🧠 **可迁移** | 任何 Agent 安装本 skill 后即可获得复盘能力，无需额外训练，无需预热 |

## 快速开始（免预热）

```bash
# 1. 准备数据（任选其一）—— 无需预热，直接进入
# 方式 A：从已有 chat-insight 数据导入
python3 scripts/collect_chats.py --from-file /path/to/chats.json --output data/chats.json
# 方式 B：在 Agent 上下文中通过 MCP 调用 alibaba-chat-insight 后写入 data/chats.json

# 2. 跑评分（顺序执行，无需先 preheat）
python3 scripts/step1_customer_scoring.py
python3 scripts/step2_health_diagnosis.py
python3 scripts/step3_team_diagnosis.py

# 3. 主审核 + 生成 HTML 看板
python3 scripts/step4_audit_and_dashboard.py

# 4. 审计三道闸（卡口）
python3 audit/checklist.py --html reports/alibaba_review_dashboard.html --reports-dir reports/ --chats data/chats.json --out logs/audit.json
bash audit/node-syntax-check.sh reports/alibaba_review_dashboard.html

# 5. （可选）写回 memory 与画像
python3 scripts/post_skill_writeback.py
```

产出物：
- `reports/step1_customer_scoring.json`
- `reports/step2_health_diagnosis.json`
- `reports/step3_team_diagnosis.json`
- `reports/audit_report.md`
- `reports/alibaba_review_dashboard.html`  ← 主交付物

## 适用 / 不适用

✅ **适用**
- 阿里国际站后台 IM 数据复盘
- ≥ 10 客户 + ≥ 50 消息的样本
- 接受 BANT / SPIN / Harvard PON 标准方法论

❌ **不适用**
- 仅 1-2 个客户的微样本
- 不接受标准方法论评估
- 推测搜索排名 / 流量算法（明确拒绝）

## 文件结构

详见 [SKILL.md](SKILL.md)。

## 已知局限

- collect 阶段如果未携带 `subaccount_id`，团队诊断将降级到 Batch 级（看板会透明披露）
- 当前关键词词典仅支持英语沟通，西语/俄语/阿语对话将被标「信息缺失」
- IM API 有 30 天滚动窗口限制（来自 chat-insight）
- 本打包版已移除强制预热守卫；若需恢复 lock 校验，将 `scripts/_guard.py` 的 `require_preheat()` 还原即可

## License

内部使用，禁止外传。
