#!/usr/bin/env python3
"""验收脚本：跑完后应该看到所有 ✓"""
import json
import sys
from pathlib import Path

SKILL_ROOT = Path(__file__).resolve().parent.parent
CHECKS = [
    ("SKILL.md exists", SKILL_ROOT / "SKILL.md"),
    ("README.md exists", SKILL_ROOT / "README.md"),
    ("INSTALL.md exists", SKILL_ROOT / "INSTALL.md"),
    ("preheat.py exists", SKILL_ROOT / "scripts/preheat.py"),
    ("_guard.py exists", SKILL_ROOT / "scripts/_guard.py"),
    ("scorer.py exists", SKILL_ROOT / "scripts/scorer.py"),
    ("collect_chats.py exists", SKILL_ROOT / "scripts/collect_chats.py"),
    ("step1 exists", SKILL_ROOT / "scripts/step1_customer_scoring.py"),
    ("step2 exists", SKILL_ROOT / "scripts/step2_health_diagnosis.py"),
    ("step3 exists", SKILL_ROOT / "scripts/step3_team_diagnosis.py"),
    ("step4 exists", SKILL_ROOT / "scripts/step4_audit_and_dashboard.py"),
    ("methodology.md exists", SKILL_ROOT / "references/methodology.md"),
    ("keyword_dictionary.json valid", SKILL_ROOT / "references/keyword_dictionary.json"),
    ("industry_benchmarks.json valid", SKILL_ROOT / "references/industry_benchmarks.json"),
    ("threshold_calibration.json valid", SKILL_ROOT / "references/threshold_calibration.json"),
    ("anti_hallucination_rules.json valid", SKILL_ROOT / "audit/anti_hallucination_rules.json"),
    ("case_01 exists", SKILL_ROOT / "cases/case_01_us_solar_buyer.md"),
    ("case_02 exists", SKILL_ROOT / "cases/case_02_ph_emerging_market.md"),
    ("case_03 exists", SKILL_ROOT / "cases/case_03_price_deadlock.md"),
    ("case_04 exists", SKILL_ROOT / "cases/case_04_silence_followup.md"),
    ("scoring_examples.json valid", SKILL_ROOT / "cases/scoring_examples.json"),
    ("industry_context.md exists", SKILL_ROOT / "memory/industry_context.md"),
    ("market_tier_mapping.json valid", SKILL_ROOT / "memory/market_tier_mapping.json"),
    ("dashboard_template.html exists", SKILL_ROOT / "templates/dashboard_template.html"),
    ("post_skill_writeback.py exists", SKILL_ROOT / "scripts/post_skill_writeback.py"),
]


def main():
    fail = 0
    for name, path in CHECKS:
        if not path.exists():
            print(f"  ✗ {name}: NOT FOUND ({path})")
            fail += 1
            continue
        # JSON 校验
        if path.suffix == ".json":
            try:
                json.loads(path.read_text())
            except Exception as e:
                print(f"  ✗ {name}: invalid JSON: {e}")
                fail += 1
                continue
        print(f"  ✓ {name}")

    # 关键词词典 regex 编译检查
    try:
        import re
        kws = json.loads((SKILL_ROOT / "references/keyword_dictionary.json").read_text())
        for k, v in kws["patterns"].items():
            re.compile(v["regex"])
        print(f"  ✓ All {len(kws['patterns'])} regex patterns compile")
    except Exception as e:
        print(f"  ✗ regex compile failed: {e}")
        fail += 1

    # scorer.py 导入测试
    try:
        sys.path.insert(0, str(SKILL_ROOT / "scripts"))
        # 先创建 mock lock 让 _guard 通过
        lock_dir = SKILL_ROOT / ".cache"
        lock_dir.mkdir(exist_ok=True)
        lock_file = lock_dir / "preheat.lock"
        lock_existed = lock_file.exists()
        if not lock_existed:
            lock_file.write_text(json.dumps({"version":"1.0.0","files_count":16,"preheated_at":0}))
        import scorer  # noqa
        # 快速 sanity 测试
        sample_conv = {
            "conversation_id": "TEST",
            "buyer_country": "US",
            "buyer_email": "test@company.com",
            "messages": [
                {"role": "buyer", "text": "I need 500 pcs solar light, UL certified", "timestamp": 1000},
                {"role": "seller", "text": "Sure, we have UL listed driver. Lead time 30 days.", "timestamp": 2000},
            ],
        }
        r = scorer.score_customer(sample_conv)
        assert r["total"] > 0, "scorer returned 0"
        print(f"  ✓ scorer.score_customer sanity test passed (total={r['total']}/100)")
        # v1.1: evidence_v2 形状校验
        ev2_items = 0
        for k, it in r["items"].items():
            assert "evidence_v2" in it, f"item {k} missing evidence_v2"
            for ev in it.get("evidence_v2", []):
                assert "tag" in ev and "raw_quote" in ev and "from" in ev, \
                    f"{k} evidence_v2 entry missing required fields: {ev}"
                ev2_items += 1
        assert ev2_items > 0, "scorer produced zero evidence_v2 entries"
        print(f"  ✓ v1.1 evidence_v2 shape passed ({ev2_items} entries with tag/raw_quote/from)")
        h = scorer.score_health(sample_conv)
        print(f"  ✓ scorer.score_health sanity test passed (health={h['health']})")
        if not lock_existed:
            lock_file.unlink()
    except Exception as e:
        print(f"  ✗ scorer import/test failed: {e}")
        fail += 1

    print()
    if fail:
        print(f"❌ {fail} checks failed.")
        sys.exit(1)
    print(f"✅ All {len(CHECKS) + 2} verification checks passed.")


if __name__ == "__main__":
    main()
