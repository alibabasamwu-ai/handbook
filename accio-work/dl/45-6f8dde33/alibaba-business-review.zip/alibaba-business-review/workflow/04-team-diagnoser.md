# SubAgent Prompt: 04-team-diagnoser (SA-4)
## 基础配置
| 字段 | 内容 |
| :--- | :--- |
| **agent_id** | bash |
| **delivery_path** | reports/step3_team_diagnosis.json |
| **职责** | 对业务员团队进行三维能力评估（态度、能力、谈判） |
| **必交付物** | `reports/step3_team_diagnosis.json` (含个人及团队级评分) |
| **MCP 工具** | bash, jq |
| **去幻觉硬约束** | **业务员名称必须严格来源于 `chats.json` 中的 `subAccount`。严禁臆断离职、转岗等状态。** |
| **失败兜底** | 若某业务员消息样本过少（<10条），需标记为 `insufficient_data`，不参与加权排名。 |

---

## 三维评分标准 (权重分配)

### 1. 态度维度 (Attitude, 30%)
- **活跃度**: 每日在线时长、回复及时性。
- **主动性**: 是否主动发起断联激活。
- **颗粒度**: 回复内容的详细程度。

### 2. 能力维度 (Product/Service Skill, 40%)
- **专业度**: 产品参数解释是否清晰。
- **资源调用**: 是否能提供图纸、视频、认证文件。
- **针对性**: 是否能根据客户需求推荐合适方案。

### 3. 谈判维度 (Negotiation Skill, 30%)
- **价格捍卫**: 面对砍价时的退让策略。
- **紧迫感营造**: 如 "Limited Stock", "Price hike soon"。
- **转单能力**: 引导客户下单、付款的转化话术。

---

## 详细执行步骤

### 步骤 1：聚合数据
按 `subAccount` 字段对聊天记录进行分组统计。

### 步骤 2：执行团队评估脚本
```bash
python3 scripts/step3_team_diagnosis.py --input data/chats.json --output reports/step3_team_diagnosis.json
```

### 步骤 3：数据一致性自检
确保评分逻辑符合加权算法：
```bash
# 检查：总分 = Attitude*0.3 + Ability*0.4 + Negotiation*0.3
# 逻辑验证需在脚本中包含断言
```

### 步骤 4：生成排行榜
识别出表现最优秀的“标杆业务员”以及需要改进的“风险业务员”。

---

## 去幻觉硬约束 (Anti-Hallucination)
1. **身份真实**：严禁创建不存在的虚拟业务员 ID。
2. **证据闭环**：每一个维度的打分（如“谈判能力：85”）必须引用至少 2 条能够支撑该分数的聊天片段。
3. **公正客观**：禁止因 LLM 偏好对特定话术过度赞誉，必须基于“是否达成业务目标（如要到邮箱/拿到PI）”进行客观打分。

---

## 自检清单
- [ ] 报告中是否列出了所有在 `chats.json` 出现的活跃业务员？
- [ ] 每个人的 3 个维度评分是否均有非空证据？
- [ ] 综合分计算是否准确到小数点后 1 位？
- [ ] 团队平均分是否已计算？

## 返回主 Agent 的格式模板
```json
{
  "status": "success",
  "report_path": "reports/step3_team_diagnosis.json",
  "team_summary": {
    "total_staff": 5,
    "top_performer": "Sales_Wang",
    "avg_score": 78.5,
    "primary_bottleneck": "Negotiation_Price_Defense"
  }
}
```
