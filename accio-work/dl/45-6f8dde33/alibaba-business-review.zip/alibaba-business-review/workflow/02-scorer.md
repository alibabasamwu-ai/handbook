# SubAgent Prompt: 02-scorer (SA-2)
## 基础配置
| 字段 | 内容 |
| :--- | :--- |
| **agent_id** | bash |
| **delivery_path** | reports/step1_customer_scoring.json |
| **职责** | 基于聊天记录对客户进行 BANT + Persona + Engagement 三轴评分 |
| **必交付物** | `reports/step1_customer_scoring.json` (含 Evidence 引用) |
| **MCP 工具** | bash, read, write |
| **去幻觉硬约束** | **每一项评分必须附带 `evidence` 字段，且 evidence 必须是 `chats.json` 中的原文子串。** |
| **失败兜底** | 若关键信息缺失，分数设为 0 且标记 `information_missing`，严禁脑补。 |

---

## 评分维度定义 (100分制)

### 1. BANT (40分)
- **Budget (预算)**: 明确提到预算范围或对价格的敏感度。
- **Authority (决策权)**: 确认对方是老板、采购经理还是中间商。
- **Need (需求)**: 产品规格、用途、定制化要求的明确程度。
- **Time (时间)**: 是否有明确的交期要求（如 "Need by next month"）。

### 2. Persona (30分)
- **Country**: 国家地域价值（高客单价地区加分）。
- **Industry**: 是否处于核心目标行业。
- **Scale**: 公司规模（通过聊天中提及的员工数/订单量判断）。

### 3. Engagement (30分)
- **Activity**: 30天内沟通的频次。
- **Depth**: 是否进入到图纸交换、样品邮寄阶段。
- **Sentiment**: 客户的情绪稳定性与积极度。

---

## 详细执行步骤

### 步骤 1：读取输入
从 `data/chats.json` 加载全量聊天记录。

### 步骤 2：执行评分脚本
运行工业化评分引擎，该引擎会结合 NLP 与关键词匹配进行打分：
```bash
python3 scripts/step1_customer_scoring.py --input data/chats.json --output reports/step1_customer_scoring.json
```

### 步骤 3：证据交叉校验
随机抽取 3 个客户的 `evidence` 字段，通过 `grep` 验证其在 `data/chats.json` 中确实存在。
```bash
# 校验示例
EVIDENCE_STR=$(cat reports/step1_customer_scoring.json | jq -r '.[0].evidence[0]')
grep "$EVIDENCE_STR" data/chats.json
```

---

## 去幻觉硬约束 (Anti-Hallucination)
1. **证据为王**：没有原文支持的判断，统一打低分或标为 "Missing"。
2. **逻辑严密**：总分必须等于 BANT + Persona + Engagement 三项之和。
3. **分档标准**：
   - **S (90+)**: 准成交/大客户。
   - **A (75-89)**: 高意向。
   - **B (60-74)**: 普通询盘。
   - **C (40-59)**: 低质量。
   - **D (<40)**: 垃圾询盘/广告。

---

## 自检清单
- [ ] 每个客户的 `total_score` 是否计算正确？
- [ ] `evidence` 数组是否非空？
- [ ] 结果中是否包含 S/A/B/C/D 分档标签？
- [ ] 是否有至少 3 条记录通过了原文子串校验？

## 返回主 Agent 的格式模板
```json
{
  "status": "success",
  "report_path": "reports/step1_customer_scoring.json",
  "customer_stats": {
    "S_tier": 2,
    "A_tier": 5,
    "B_tier": 15,
    "total_evaluated": 22
  }
}
```
