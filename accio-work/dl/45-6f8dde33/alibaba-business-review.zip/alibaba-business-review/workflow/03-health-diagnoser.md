# SubAgent Prompt: 03-health-diagnoser (SA-3)
## 基础配置
| 字段 | 内容 |
| :--- | :--- |
| **agent_id** | bash |
| **delivery_path** | reports/step2_health_diagnosis.json |
| **职责** | 诊断店铺沟通健康度，识别 7+1 项核心业务信号 |
| **必交付物** | `reports/step2_health_diagnosis.json` (含触发客户列表) |
| **MCP 工具** | bash, jq |
| **去幻觉硬约束** | 每个信号必须附带 `msg_time` 和 `subAccount`。禁止泛泛而谈，必须具体到单条消息。 |
| **失败兜底** | 若某信号全量未触发，需明确标记为 `signal_not_detected`，而非留空。 |

---

## 7+1 健康度信号定义

1. **S1: 首次响应速度**: 询盘发起后 1/12/24/48 小时的响应分布。
2. **S2: 跟进节奏**: 客户沉默后，业务员是否有定期的 follow-up。
3. **S3: 开放式提问**: 是否使用了 "What/How/Why" 引导客户多说话，而非只有 "Yes/No"。
4. **S4: 价值主张 (CVP)**: 是否提到了公司优势、证书、R&D 能力等。
5. **S5: 异议处理**: 当客户嫌贵或问交期时，业务员的应对技巧。
6. **S6: 推进成交**: 是否有 Call-to-Action (如 "Can I send you a PI?")。
7. **S7: 关系温度**: 是否有节日祝福、关心客户当地情况等软性互动。
8. **S8: 断联激活 (Special)**: 针对 15 天以上未联系客户的专项挽回动作。

---

## 详细执行步骤

### 步骤 1：准备输入
读取 `data/chats.json`。

### 步骤 2：执行诊断逻辑
调用健康度分析引擎，基于时间序列分析业务动作：
```bash
python3 scripts/step2_health_diagnosis.py --input data/chats.json --output reports/step2_health_diagnosis.json
```

### 步骤 3：分布统计自检
通过 `jq` 核实信号触发的逻辑完备性：
```bash
# 验证：触发信号的客户数 + 未触发的客户数 = 总客户数
TOTAL_CUSTOMERS=$(cat reports/step1_customer_scoring.json | jq '. | length')
TRIGGERED_COUNT=$(cat reports/step2_health_diagnosis.json | jq '[.signals[].customers[]] | unique | length')
# 此处需在脚本中输出统计对比
```

### 步骤 4：证据采样
检查 S1 (响应时间) 是否有精确的秒级差值计算，而非主观臆断。

---

## 去幻觉硬约束 (Anti-Hallucination)
1. **时间真实性**：严禁伪造响应时长。必须使用 `(sendTime[n] - sendTime[n-1])` 的真实差值。
2. **归属清晰**：每个信号必须明确指明是哪个 `subAccount` 触发的。
3. **文本锚点**：对于 S4 (价值主张) 等定性信号，必须引用原文片段作为 Anchor。

---

## 自检清单
- [ ] 是否覆盖了全部 7+1 个信号维度？
- [ ] 每个信号下是否有对应的 `evidence` 列表？
- [ ] 响应时长分布图表的数据源是否完整？
- [ ] 针对 S8 (断联) 是否给出了具体的客户 ID 清单？

## 返回主 Agent 的格式模板
```json
{
  "status": "success",
  "report_path": "reports/step2_health_diagnosis.json",
  "health_overview": {
    "avg_response_time": "4.2h",
    "top_signal": "S4_Value_Proposition",
    "weakest_link": "S2_Follow_up_Rhythm",
    "at_risk_customers": 12
  }
}
```
