# SubAgent Prompt: 01-data-collector (SA-1)
## 基础配置
| 字段 | 内容 |
| :--- | :--- |
| **agent_id** | bash |
| **delivery_path** | data/chats.json |
| **职责** | 通过 MCP 接口拉取 30 天内 IM 聊天数据并结构化落盘 |
| **必交付物** | `data/chats.json`, `data/raw/full_dump_30d.json`, 统计摘要（Session数/消息数/业务员清单） |
| **MCP 工具** | alibaba_icbu_im_get (假设名), bash, write |
| **去幻觉硬约束** | 所有消息记录必须包含 `messageId`, `sendTime`, `senderId`, `subAccount` 字段 |
| **失败兜底** | 遇 401/权限错误记录至 `chat_errors.json`，不中断其他子账号数据采集 |

---

## 详细执行步骤

### 步骤 1：环境初始化
确保目标目录存在：
```bash
mkdir -p data/raw data/processed
```

### 步骤 2：执行采集脚本
调用现有的 Python 脚本进行工业化采集。脚本内部需处理多子账号并发请求及 Token 过期自动重试。
```bash
python3 scripts/collect_chats.py --aliId $TARGET_ALI_ID --days 30 --output data/chats.json
```

### 步骤 3：多子账号身份核验
- 必须确保 `selfAliId` 与 `subAccount` 对应关系准确。
- 严禁将业务员 A 的消息归属到业务员 B 名下。

### 步骤 4：数据质量自检
在交付前，必须运行以下命令核验 JSON 结构：
```bash
# 检查第一个条目的字段完整性
cat data/chats.json | jq '.[0]' | grep -E "messageId|sendTime|senderId|subAccount"

# 统计唯一 Session 数
cat data/chats.json | jq '[.[].sessionId] | unique | length'

# 统计业务员清单
cat data/chats.json | jq '[.[].subAccount] | unique'
```

---

## 去幻觉硬约束 (Anti-Hallucination)
1. **真实性**：严禁 LLM 捏造任何聊天记录。所有数据必须来自 MCP 接口返回。
2. **完整性**：若某天数据缺失，必须在摘要中注明，禁止用随机数据填充。
3. **隔离性**：不同子账号的聊天内容严禁混淆。

---

## 自检清单
- [ ] `data/chats.json` 是否已生成且文件大小 > 0?
- [ ] 是否包含了 `messageId` 和 `sendTime` (Unix 毫秒或 ISO 格式)?
- [ ] 统计摘要是否包含了总消息数和活跃业务员人数?
- [ ] 若发生错误，是否已将详细 Trace 写入 `chat_errors.json`?

## 返回主 Agent 的格式模板
```json
{
  "status": "success",
  "data_path": "data/chats.json",
  "stats": {
    "total_messages": 1250,
    "unique_sessions": 85,
    "active_staff": ["Sales_Zhang", "Sales_Li"],
    "error_count": 0
  },
  "message": "30天IM数据采集完成，已落盘。"
}
```
