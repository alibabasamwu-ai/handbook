# SubAgent Prompt: 06-html-builder (SA-6)
## 基础配置
| 字段 | 内容 |
| :--- | :--- |
| **agent_id** | general |
| **delivery_path** | reports/alibaba_review_dashboard.html |
| **职责** | 将诊断结果（JSON）渲染为高交互性的 HTML 可视化仪表盘 |
| **必交付物** | 包含 8 个核心图表的 HTML 文件 |
| **MCP 工具** | read, write, edit |
| **去幻觉硬约束** | **禁止修改 CSS 设计系统、禁止删减预设的 8 个 Chart、禁止截断客户数据。** |
| **失败兜底** | 若单次 `write` 超过 12KB 导致截断，必须分段使用 `edit` 注入数据。 |

---

## 核心输入数据源
- `templates/dashboard.html.jinja`: 基础骨架与 CSS 库。
- `reports/diagnosis.json`: 汇总后的诊断结果（含所有评分维度）。
- `data/chats.json`: 原始聊天片段（用于详情下钻展示）。

---

## 图表 Canvas ID 锁定清单 (必须存在)
1. `chart-layer`: 客户分层漏斗图。
2. `chart-health`: 店铺健康度雷达图。
3. `chart-team-score`: 业务员三维评分对比图。
4. `chart-radar`: 核心客户价值模型图。
5. `chart-batch`: 30天内不同批次询盘质量走势。
6. `chart-heatmap`: 回复时间分布热力图。
7. `chart-signals`: 8大信号触发频次统计。
8. `chart-country`: 全球客源分布地图。

---

## 详细执行步骤

### 步骤 1：读取模板与数据
读取 `dashboard.html.jinja`。识别其中的占位符 `{{ DIAGNOSIS_DATA }}`。

### 步骤 2：数据准备 (Data Hydration)
将 JSON 数据转换为 JavaScript 常量。注意转义特殊字符（如消息中的引号），防止 JS 语法错误。

### 步骤 3：分段写入 HTML
由于仪表盘可能包含大量数据，采用以下策略：
1. 先写入带有基础结构、CSS 和 CDN 脚本的 HTML 头部。
2. 使用 `edit` 工具定位 `// DATA_INJECTION_POINT` 并注入处理好的业务数据。
3. 注入图表配置 (ECharts Option) 代码。

### 步骤 4：CDN 备灾处理
ECharts 脚本必须包含备用地址：
```html
<script src="https://cdn.jsdelivr.net/npm/echarts@5.4.3/dist/echarts.min.js"></script>
<script>window.echarts || document.write('<script src="https://cdnjs.cloudflare.com/ajax/libs/echarts/5.4.3/echarts.min.js"><\/script>')</script>
```

---

## 去幻觉硬约束 (Anti-Hallucination)
1. **数据一致性**：HTML 中显示的平均分必须与 `diagnosis.json` 完全一致，严禁二次计算导致误差。
2. **完整性**：客户表格严禁因为性能原因只显示前 10 条。必须支持分页或全量平铺（CSS 控制）。
3. **文本保护**：确保所有的 `evidence` 文本被正确包裹在 `<pre>` 或 `<code>` 标签中，避免被 HTML 渲染破坏格式。

---

## 自检清单
- [ ] 8 个 Chart ID 是否全部在 HTML 中被初始化？
- [ ] 是否包含了 ECharts 的 CDN 脚本？
- [ ] 聊天记录原文中的 HTML 标签（如 `<br>`）是否被正确转义（或保留）以防 XSS 或渲染崩溃？
- [ ] 页面在无网络环境下是否会显示“CDN 加载失败”的提示？

## 返回主 Agent 的格式模板
```json
{
  "status": "success",
  "html_path": "reports/alibaba_review_dashboard.html",
  "filesize_kb": 156,
  "chart_count": 8
}
```
