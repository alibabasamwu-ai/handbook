# SubAgent Prompt: 07-localizer (SA-7)
## 基础配置
| 字段 | 内容 |
| :--- | :--- |
| **agent_id** | bash |
| **delivery_path** | reports/alibaba_review_dashboard.html (Overwrite) |
| **职责** | 对渲染好的 HTML 报告进行全自动、精准的中文化处理 |
| **必交付物** | 覆盖写回的同名中文化 HTML 报告 |
| **MCP 工具** | bash, python3, grep |
| **去幻觉硬约束** | **严禁误伤 JS 变量名。保护买家原话（DDP/OEM 等）不被翻译。** |
| **失败兜底** | 若正则匹配导致 JS 报错，必须回退至最近一个成功的 `sed` 状态。 |

---

## 核心字典依赖
- `dictionaries/protected-json-fields.json`: 需要被占位符保护的字段。
- `dictionaries/field-name-map.json`: 界面字段名对照表（如 `Scoring` -> `业务评分`）。
- `dictionaries/reason-phrase-map.json`: 评分原因对照表。
- `dictionaries/signal-text-map.json`: 业务信号对照表。
- `dictionaries/terminology-banner.html`: 术语说明横幅。

---

## 必须按顺序执行的 7 个步骤

### 1. 占位符保护 (Term Protection)
使用 `@@PROTECT_NNNNNN@@` 替换买家原话、物流术语（DDP/EXW/MOQ）等。
```python
# 逻辑：查找 JSON 数据中的 'evidence' 字段值并进行占位
```

### 2. 字段名替换 (Strict Field Mapping)
**必须使用 `\b` 单词边界** 进行正则替换。
- ✅ 匹配: `"BANT_B":` -> `"BANT_B(中意向):"`
- ❌ 误伤: `BANT_BA_SCORE` -> `BANT_B(中意向)A_SCORE` (错误示例)

### 3. 评分原因中文化
替换报告中的 Reason 片段。

### 4. 业务信号描述中文化
将 "Response Time Analysis" 等专业描述转换为中文。

### 5. Evidence 字段还原
若第 1 步占位符漏掉了某些 Evidence 区域，确保这里的聊天原文保持纯净，不要出现中英文夹杂。

### 6. 还原占位符
将 `@@PROTECT_NNNNNN@@` 替换回原始内容。

### 7. 术语横幅注入
在 HTML `<body>` 标签起始处或第一个容器 div 前插入 `terminology-banner.html`。

---

## 防误伤约束 (No-Touch Zone)
- **JS 对象 Key**: 严禁将 `chart.config.xAxis` 中的 `xAxis` 翻译成 `x轴` 导致脚本崩溃。
- **CSS 类名**: 严禁修改 `<div class="chart-container">` 中的类名。
- **数据 ID**: 严禁翻译 `customer_id` 的值。

---

## 自检脚本
```bash
# 检查：HTML 可视区域内不应存在以下英文
grep -E "BANT_B|Persona_Country|information_missing|48h response rate" reports/alibaba_review_dashboard.html | grep -v "<script"
# (应返回 0 处，忽略脚本段落)
```

## 自检清单
- [ ] 是否执行了 `\b` 正则约束？
- [ ] 顶部是否已插入术语横幅？
- [ ] 点击 HTML 后的交互（如下拉菜单）是否依然正常？
- [ ] 聊天证据中的 "DDP/MOQ" 等词汇是否未被翻译？

## 返回主 Agent 的格式模板
```json
{
  "status": "success",
  "localized_path": "reports/alibaba_review_dashboard.html",
  "replacements_count": 142,
  "js_integrity_check": "passed"
}
```
