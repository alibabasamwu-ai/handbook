# 案例 04 · 单向沟通 / 断联未激活（团队最常见失败模式）

> 🛑 **演示数据 · 品类无关**：本案例的产品品类（及任何商品名）仅用于演示打分/诊断方法，**与当前被分析商家的主营无关**，严禁据此推断主营。

> 用途：教模型识别"看起来在跟进，实际是 seller 自说自话"。

---

## 典型对话（节选）

```
Day1 Seller: Hi! Welcome to inquire. We are solar light supplier 10 years. Catalog attached.
Day1 Seller: Our hot models are X30W, X60W, X100W. Please check.
Day1 Seller: Also we have OEM service. Welcome to ask.
Day3 Seller: Hi friend, do you receive my catalog?
Day3 Seller: We have promotion this month. 5% off.
Day7 Seller: Hi dear, any update? Looking forward to your reply.
Day14 Seller: Hello, are you still interested in our products?
（买家始终未回复）
```

---

## 标准评分

### 健康度：**0 分（濒临流失）**
- 🚨 信号 2「单向沟通」：连续 7 条 seller 独白 → -20
- 🚨 信号 8「断联未激活」：买家从未回复 → -20
- ⚠️ 信号 6「决策推迟」不触发（买家无 "let me think"）
- 评分 = max(0, 100 - 20 - 20) = 60，但因连续单向 ≥5 条强制降级到「濒临流失」

### 员工评分（反向示例 - 低分）
- **B1 SPIN**：0 个问题 → 0/25
- **B2 FAB**：未连接到 benefit → 6/20
- **B3 阶梯报价**：无 → 0/20
- **B4 LSCPA**：无（买家从未发声，何来 Listen） → 0/20
- **B5 next step**：无具体承诺，"any update" 不算 → 0/15
- **态度 A2 主动性**：表面分高但是无效主动 → 此处需要规则补丁：连续单向 ≥3 条时 A2 反向扣分 → 5/25
- **谈判 C2 聚焦利益**：未问任何 why → 0/25

---

## 模型应学到的判断

✅ "Hi friend, any update?" / "are you still interested?" 不是有效的 next step，不计分
✅ 单向独白超过 3 条时，态度 A2 主动性要反向扣分（虚假主动）
✅ 没有买家回复时，B4 LSCPA 必须为 0（无 Listen 对象）
❌ 不要因为 seller 发了很多消息就判定为"勤奋"
