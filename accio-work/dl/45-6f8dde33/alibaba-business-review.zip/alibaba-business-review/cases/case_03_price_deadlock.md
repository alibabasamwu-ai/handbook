# 案例 03 · 价格僵局 - 正反对照

> 🛑 **演示数据 · 品类无关**：本案例的产品品类（及任何商品名）仅用于演示打分/诊断方法，**与当前被分析商家的主营无关**，严禁据此推断主营。

> 用途：教模型如何识别"破僵局动作"是否成立。

---

## 反例（未破僵局）

```
B: your price $25/pcs is too high. competitor offers $20.
S: $25 is our best price. quality is good.
B: but $20 is also good quality.
S: we cannot do $20. sorry.
```
- ❌ Seller 三次回应都只在价格轴上
- ❌ 未引入：MOQ / payment terms / 质保 / 样品 / 长期合作折扣
- ❌ 未引用客观标准（原材料涨幅、市场价、认证成本）
- 信号 3 触发 / 谈判 C3 = 0 / 谈判 C4 = 0

## 正例（成功破僵局）

```
B: your price $25/pcs is too high. competitor offers $20.
S: I understand the price gap matters. May I ask the quantity and your target market?
B: 200 pcs for retail in Mexico.
S: For retail, our $25 includes 2-year warranty (competitor usually 6 months).
   Alternative: $22.50 if you can accept 6-month warranty (matching competitor scope).
   Or $20.80 if MOQ goes to 500 pcs.
   Which option works better for your retail margin?
```
- ✅ Listen → "I understand the price gap matters"（LSCPA）
- ✅ Why → "May I ask quantity and target market?"（Harvard 聚焦利益）
- ✅ 引入 3 个新变量：warranty scope / quantity / payment 隐含
- ✅ 提供 3 个 option 让买家选（多赢）
- 信号 3 不触发 / 谈判 C3 = 30 / B4 LSCPA = 20 / B3 阶梯报价 = 20

---

## 模型应学到的判断规则

破僵局成立的最低标准（满足任意 2 项）：
1. 引入至少 1 个非价格变量（MOQ / payment / warranty / shipping / sample / future order）
2. 引用至少 1 个客观标准（市场价 / 原材料 / 认证 / 通胀）
3. 提供至少 2 个备选方案（option A vs option B）
4. 主动询问买家的真实约束（quantity / market / margin）
