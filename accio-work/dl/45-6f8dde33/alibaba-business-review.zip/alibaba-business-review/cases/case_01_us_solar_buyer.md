# 案例 01 · 美国户外照明高质量买家（已脱敏）

> 🛑 **演示数据 · 品类无关**：本案例的产品品类（及任何商品名）仅用于演示打分/诊断方法，**与当前被分析商家的主营无关**，严禁据此推断主营。

> 来源：真实复盘案例，姓名/邮箱/产品 ID 已脱敏。
> 用途：教模型"什么样的对话给 S 级 / 健康度多少"。

---

## 原始对话片段（节选 12 轮）

| # | 时间 | 角色 | 消息 |
|---|------|------|------|
| 1 | Day1 09:14 | Buyer | Hi, I'm looking for solar street lights for a municipal project in Texas. Quantity around 500 units. Do you have UL/FCC certification? |
| 2 | Day1 09:21 | Seller | Hello, thank you for reaching us. Yes we have UL and FCC. I will send catalog. |
| 3 | Day1 10:02 | Buyer | Great. Also need IP66 minimum, 60W-100W range. What's the lead time for 500 units? |
| 4 | Day1 10:18 | Seller | 30-35 days production. Shipment 25-30 days by sea to Houston. |
| 5 | Day2 08:30 | Buyer | OK. Send me PI for 500 sets of model X60W. Also can you do video factory tour? |
| 6 | Day2 09:00 | Seller | I will send PI today. Video tour can be arranged Friday 9am Texas time. |
| 7 | Day3 14:20 | Buyer | Received PI. Price seems higher than another supplier ($168 vs your $185). Can you match? |
| 8 | Day3 15:45 | Seller | Our price includes 5-year warranty and UL listed driver. Cheaper ones usually use non-listed driver. Happy to send our certificate package. |
| 9 | Day4 10:00 | Buyer | Send certificates please. |
| 10 | Day4 10:15 | Seller | Sent. Also offering: if you confirm by Friday, free shipping upgrade to LCL door delivery (save ~$1500). |
| 11 | Day5 09:00 | Buyer | Confirmed. Sending TT 30% deposit today. |
| 12 | Day5 11:30 | Seller | Received. Thank you! Production starts Monday. Will send weekly photo updates. |

---

## 标准评分（金标准）

### 客户分层：**S 级（94 分）**

| 维度 | 子项 | 得分 | Evidence |
|------|------|------|----------|
| BANT-B | 500 units 中高预算 | 15/15 | "Quantity around 500 units" + "$185 × 500 = $92.5K" |
| BANT-A | Municipal project + 企业邮箱 | 10/10 | "municipal project in Texas" |
| BANT-N | spec/scene/cert 三项全 | 9/12 | "IP66 / 60W-100W" + "municipal project" + "UL/FCC" |
| BANT-T | "by Friday" 紧急 | 8/8 | "confirm by Friday" |
| Persona-Country | US Tier1 | 10/10 | Texas / Houston |
| Persona-Company | 企业邮箱+提及公司 | 9/10 | "municipal project"（推断政府/承包商） |
| Persona-Category | 精准品类 | 10/10 | "solar street lights" |
| Engagement-Active | 买家提问 6 次 | 8/8 | 消息 1/3/5/7/9 |
| Engagement-Depth | sample+PI+video+TT | 8/8 | 消息 5/6/11 |
| Engagement-Channel | TM+video | 5/5 | 消息 6 |
| Engagement-Response | <2h 100% | 4/4 | 时间戳 |

### 健康度：**100 分（健康）**
- 无任何信号触发
- 价格争议被新变量（warranty + free shipping）化解
- next step 闭环：weekly photo updates

### 该卖家的员工评分（能力维度高分示范）
- **B1 SPIN**：消息 8 反问"cheaper ones usually use non-listed driver"= 隐含 Problem+Implication，density ≥0.3 → 25/25
- **B2 FAB**：消息 8 "includes 5-year warranty and UL listed driver" = Feature+Advantage → 15/20（缺 Benefit 句式）
- **B3 阶梯报价**：未做 tiered → 0/20（扣分项）
- **B4 LSCPA**：消息 8 间接做了 Listen+Share → 10/20
- **B5 next step**：消息 6/10/12 均有 → 15/15

---

## 模型应学到的判断

✅ S 级的特征：BANT 四项齐全 + 高 Engagement + 明确闭环
✅ 100 分健康度的关键：价格争议必须用"非价格变量"化解
✅ 即使 S 级客户，员工能力评分中"阶梯报价缺失"依然要扣分（评分独立性）
❌ 不要因为客户成单就给员工所有维度满分
