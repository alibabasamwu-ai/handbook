# 案例 02 · 菲律宾新兴市场客户（已脱敏）

> 🛑 **演示数据 · 品类无关**：本案例的产品品类（及任何商品名）仅用于演示打分/诊断方法，**与当前被分析商家的主营无关**，严禁据此推断主营。

> 用途：教模型"中等买家 B 级如何评分 + 价格僵局信号识别"。

---

## 原始对话片段（节选 8 轮）

| # | 时间 | 角色 | 消息 |
|---|------|------|------|
| 1 | Day1 11:00 | Buyer | hi i need price for 30W solar light. how much? |
| 2 | Day1 11:25 | Seller | Hello, 30W solar street light $42/pcs FOB. MOQ 100pcs. |
| 3 | Day1 14:00 | Buyer | too expensive. local market only $28. can you do $25? |
| 4 | Day1 14:30 | Seller | Sorry $25 not possible. our cost already $35. |
| 5 | Day2 09:00 | Buyer | ok let me check |
| 6 | Day4 10:00 | Seller | Hi friend, any update? |
| 7 | Day8 (无回复) | - | - |
| 8 | Day12 | Seller | Hello, are you still interested? |

---

## 标准评分

### 客户分层：**B 级（42 分）**

| 维度 | 子项 | 得分 | Evidence |
|------|------|------|----------|
| BANT-B | 仅说"30W"无数量 | 5/15 | 消息 1 |
| BANT-A | 无身份/邮箱信息 | 0/10 | `information_missing` |
| BANT-N | 只有 spec | 3/12 | "30W" 命中 spec |
| BANT-T | 无 | 0/8 | `information_missing` |
| Persona-Country | PH Tier3 | 5/10 | "local market $28"推断本地 |
| Persona-Company | 无信息 | 0/10 | `information_missing` |
| Persona-Category | 精准品类 | 10/10 | "30W solar light" |
| Engagement-Active | 提问 2 次 | 2/8 | 消息 1/3 |
| Engagement-Depth | 无 sample/PI | 0/8 | - |
| Engagement-Channel | 仅 TM | 1/5 | - |
| Engagement-Response | 单次响应慢 | 2/4 | Day2 后断联 |

### 健康度：**40 分（危险）**
触发信号：
- ⚠️ 信号 3「价格僵局」：消息 3-4 仅围绕价格争辩，**seller 未引入任何新变量**（MOQ/payment/sample/gift） → -10
- 🚨 信号 8「断联未激活」：Day2 → Day4 隔了 2 天 + Day8 完全断联 + Day12 二次激活也只用"are you still interested?"无新价值 → -20
- 🚨 信号 1「响应超时」：Day4-Day8 超 48h → -20
- ⚠️ 信号 5 不触发（无质疑词）

---

## 模型应学到的判断

✅ 价格僵局的核心判定：seller 是否引入"非价格变量"
  - 错误处理（本案例）："Sorry $25 not possible"
  - 正确处理：可以提"如果 MOQ 提升到 500 pcs，单价 $32" 或 "$25 可以做但取消 5 年质保"
✅ 新兴市场客户即使预算低，也不应直接放弃，应该探测真实需求量
✅ "Hi friend, any update?" 是无价值激活，不算 next step
❌ 不要给"any update?"加分
