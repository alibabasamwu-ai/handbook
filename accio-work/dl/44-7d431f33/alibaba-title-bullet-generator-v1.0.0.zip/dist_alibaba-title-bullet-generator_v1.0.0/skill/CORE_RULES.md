# CORE_RULES.md — 标题卖点生成 Skill 强约束规则

> ⚠️ **任何会话启动后第一动作必须 read 本文件**，整个执行过程中 R1-R7 不可违反
> ⚠️ 与 alibaba-knowledge-base-builder 的 R1-R7 哲学一致，针对"标题卖点生成"场景做专项收敛

---

## R1. 数据溯源强制（Source Provenance）

每条热词、趋势分、竞品标题、社媒洞察 **必须**带来源标签，否则视为幻觉。

### 来源标签规范

| 标签 | 含义 | 示例 |
|------|------|------|
| `[MCP: <工具名>]` | 来自 MCP 调用 | `[MCP: hot_keyword_query]` |
| `[Google Trends: <URL>]` | Google Trends 抽取 | `[Google Trends: trends.google.com/...?q=solar+light]` |
| `[Social: <平台> <URL>]` | 社媒洞察 | `[Social: YouTube https://youtu.be/xxx]` |
| `[Alibaba SERP: <URL>]` | 国际站搜索结果页 | `[Alibaba SERP: alibaba.com/trade/search?...]` |
| `[商家原文]` | 商家在 ask_user 中亲口说 | 直接来自 MERCHANT_BRIEF.md |
| `[商家上传图]` | 来自商家上传产品图 | 通过 see_image 抽取 |
| `[行业基准]` | 通用 B2B 营销常识 | 标注后允许，但 ≤10% |
| `[降级]` | 主源失败后的替代源 | 必须紧邻原失败源说明 |

### 禁止行为
- ❌ 任何精确数字（搜索量、CPC、CTR、价格）无紧邻来源标签
- ❌ 用 "according to industry data" / "in general" 模糊化数据
- ❌ 凭训练数据写"通用流行词"代替 MCP 真实抽取

---

## R2. 自检块强制（Self-Check Block）

每个 subagent 返回时**必须**在文件末尾追加自检块，主 Agent 据此判断是否驳回：

```markdown
---
## 🔍 SA Self-Check
- [ ] 所有数据点带来源标签：是 / 否，缺源 <n> 处
- [ ] 工具调用真实执行（贴入参原文）：是 / 否
- [ ] 抓取时间戳：<ISO 8601>
- [ ] 任何降级/失败已明确说明：是 / 否 / 无降级
- [ ] 字符数：<n>
```

无自检块 → 主 Agent 直接 REJECT。

---

## R3. 缺源驳回 + 重跑（Reject & Retry）

主 Agent 在 Stage 3 审计 5 项中任一不通过，触发：

1. 第 1 次：sessions_send 给原 SA，附「驳回原因 + 缺源条目清单」，要求补齐
2. 第 2 次：再次 sessions_send + 强化 prompt（贴入第 1 次违规示例）
3. 第 2 次仍 fail → **暂停整个流程**，告知商家："SA<n> 反复无法提供合规数据，需您介入决策是否：A. 跳过该数据维度 B. 改用其他工具 C. 中止"

---

## R4. 关键词使用频次审计（Keyword Coverage Audit）

Stage 5 生成 10 套候选后，主 Agent 必须输出**关键词覆盖矩阵**：

```markdown
| SA1 Top 10 热词 | 出现次数 | 覆盖套号 |
|----------------|---------|---------|
| solar street light | 8 | #1,#2,#3,#5,#6,#7,#8,#10 |
| 200w | 4 | #1,#2,#5,#9 |
| ip66 | 6 | #1,#2,#3,#4,#5,#9 |
| ... | | |
```

合规标准：
- SA1 Top 10 中至少 6 个热词被使用 ≥ 3 套
- 任何热词在 10 套中出现 = 0 → 必须解释原因（如"违禁词"或"与商家定位不符"）
- 任意一套使用 SA1 Top 10 热词数 < 3 → 该套需重写

---

## R5. 标题字符长度合规（Alibaba Title Spec）

国际站标题硬规则：

| 项 | 限制 | 处理 |
|----|------|------|
| 总字符数 | ≤ 128 | 超长直接 REJECT |
| 单词重复 | 同一词最多 2 次 | 超过提示「关键词堆砌风险」 |
| 风控品牌词 | 禁止使用未授权品牌名 | 必须经 alibaba-product-information-optimization 风控接口校验 |
| 全大写 | 禁止全大写标题 | 自动改为 Title Case |
| 特殊字符 | 禁止 emoji、全角符号 | 自动剔除 |

每套输出必带 `字符数：<n>/128 ✅` 或 `❌ 超长 <n>`。

---

## R6. 主 Agent 审计协议（5 项硬拦截）

```python
def audit_subagent_output(sa_name, work_dir):
    # 审计 1: 文件实存
    if not exists(f"{work_dir}/RESEARCH_RAW/{sa_name}.md"):
        return REJECT(f"{sa_name}.md 不存在")

    # 审计 2: 字符数 ≥ 800
    if len(read(f)) < 800:
        return REJECT(f"{sa_name} 字符数 < 800，疑似空壳")

    # 审计 3: 来源标注密度 ≥ 70%
    sections = split_by_heading(content)
    labeled_ratio = sum(1 for s in sections if has_source_tag(s)) / len(sections)
    if labeled_ratio < 0.7:
        return REJECT(f"{sa_name} 来源标注密度 {labeled_ratio:.0%} < 70%")

    # 审计 4: 自检块存在
    if "## 🔍 SA Self-Check" not in content:
        return REJECT(f"{sa_name} 缺自检块（违反 R2）")

    # 审计 5: 红线幻觉扫描
    numbers = grep(r"\b\d{2,}\b", content)  # 找精确数字
    for n in numbers:
        if not has_nearby_source_tag(n, window=80):
            return REJECT(f"{sa_name} 数字 '{n}' 无紧邻来源（违反 R1）")

    return PASS
```

每次审计写入 `$WORK_DIR/AUDIT_LOG.md`：

```markdown
## [<ISO时间>] 审计 SA1 (alibaba_keywords)
- 文件实存：✅
- 字符数：1432 ✅
- 来源标注密度：92% ✅
- 自检块：✅
- 红线扫描：0 处 ✅
**结论：PASS**
```

---

## R7. 商家优势必嵌入校验（Merchant Asset Embedding）

10 套候选中，**每套**必须嵌入 ≥ 2 项 MERCHANT_BRIEF 中的元素：

| 必嵌入维度 | 来源字段 |
|-----------|---------|
| 公司资质 | Q1 Manufacturer/Trading/OEM/ODM |
| 认证 | Q2 CE/FCC/RoHS/ISO 等 |
| 差异化卖点 | Q3 价格/质保/交期/技术等 |
| MOQ/产能 | Q4 |

Stage 5 输出表格中每套必带「嵌入商家优势数：<n>/<total>」字段。
- < 2 项 → REJECT，主 Agent 自己重写该套
- 10 套全部 < 2 项的差异化卖点 → 暂停流程，回 Stage 1.3 追问商家

---

## 🚨 违规升级路径

| 违规 | 后果 |
|------|------|
| 1 次违规 | sub-agent 返工 + AUDIT_LOG 记录 |
| 同一类违规 3 次 | 在本次会话结束时写入 `$WORK_DIR/EVOLUTION_NOTES.md` |
| 累积 5 次违规 | 触发 v1.0.x bump，主 Agent 复盘后调整 prompt 模板 |

---

## 🔧 工具调用速查

| 工具 | 用途 | 调用示例 |
|------|------|---------|
| `accio-mcp-cli keyword <kw>` | 找 MCP 工具 | `accio-mcp-cli keyword "buyer search keyword"` |
| `accio-mcp-cli call <tool>` | 调用 MCP | `accio-mcp-cli call hot_keyword_query --json '{"query":"solar light","country":"US"}'` |
| `web_fetch` | 抓 Google Trends 公开页 | trends.google.com/.../?q=... |
| `sessions_spawn agent_id=browser` | 抓 SERP / 截图 | 4 个 SA 并行 |
| `see_image` | 读商家产品图 | 抽取视觉特征辅助卖点 |
| `ask_user mode=form` | 多选必填卡 | Stage 1 信息采集 |
| `ask_user mode=chat + attachmentSlot` | 接收产品图上传 | Q1 追问 |

---

## 📊 来源占比目标

| 来源类型 | 理想占比 |
|---------|---------|
| `[MCP]` 国际站后台 | ≥ 30% |
| `[Google Trends]` | ≥ 15% |
| `[Social]` YouTube/TikTok/Reddit | ≥ 20% |
| `[Alibaba SERP]` 同行 | ≥ 20% |
| `[商家原文]` + `[商家上传图]` | ≥ 10% |
| `[行业基准]` | ≤ 10% |

总占比 = 100%。某项严重缺失 → 触发 R3 重跑该 SA。
