---
name: 国际站标题卖点生成器
description: |
  跨境B2B电商营销专家工作流：为国际站发品中产品详情页一次性生成 **10 套**「标题 + 3-5 条卖点」候选。
  调研维度覆盖 ① 国际站买家热搜词、② Google Trends、③ 社媒热点（YouTube/TikTok/Reddit）、④ 同行 Top10 标题反推；
  并强制将商家自身公司优势 / 差异化卖点 / 认证 / 营销钩子嵌入产出。
  采用 **6 阶段 Stage Gate** + **R1-R7 反幻觉审计**，4 个 subagent 并行执行，主 Agent 全程审计避免幻觉与偷懒。

  触发场景：
  - "帮我写国际站发品标题和卖点"
  - "给我出 10 套标题方案"
  - "新发的 XX 产品需要标题和卖点"
  - "标题怎么写转化高 / 卖点怎么提炼"
  - "发品文案 / 详情页文案 / listing copy"
  - 任何明确要求"基于热词 + 趋势 + 商家优势"生成发品文案的请求

  禁止使用场景：
  - 已发品商品的标题优化 → 走 alibaba-product-information-optimization
  - 整篇详情页 6 图设计 → 走 alibaba-image-marketing-studio
  - 仅调研热词不出文案 → 走 alibaba-hot-product-insight
enabled: true
version: 1.0.0
---

# 国际站标题卖点生成器（Title & Bullet Generator）

> 一次会话产出 10 套「标题 + 3-5 条卖点」候选，全部基于真实热词 / 趋势 / 商家优势，不编造，不偷懒。

---

## 🛡️ 启动前置（必须执行，不可跳过）

**第一动作：read 本目录下的 [CORE_RULES.md](CORE_RULES.md)**，将 R1-R7 装入工作记忆。本次会话的整个执行过程中，R1-R7 不可违反；任何 subagent 返回缺源 / 编造数据 / 内容空壳，主 Agent 必须按 R6 硬拦截重跑。

---

## 📐 6 阶段 Stage Gate 流程总览

```
Stage 1  商家信息采集（ask_user form 必填卡片）       ← Gate 1: 必填项齐全
   ↓
Stage 2  4 个 subagent 并行调研                       ← Gate 2: 4 份原始数据交付
   ↓
Stage 3  主 Agent 数据溯源审计（R1/R3/R6）             ← Gate 3: 缺源驳回重跑
   ↓
Stage 4  营销钩子融合 + 卖点要素拆解                   ← Gate 4: 商家优势嵌入校验
   ↓
Stage 5  生成 10 套标题 + 卖点（含元数据）             ← Gate 5: 字符 / 关键词 / 风格合规
   ↓
Stage 6  商家选择 + 微调 + 落盘                        ← Gate 6: 交付清单 + AUDIT_LOG
```

每过一个 Gate，主 Agent 必须**显式输出该 Gate 的检查结论**（参见各阶段末尾的「Stage Gate 输出模板」），否则不得进入下一阶段。

---

## Stage 1 — 商家信息采集（Gate 1）

### 1.1 工作目录初始化

```bash
WORK_DIR="./title-bullet-{timestamp}-{产品短名}"
mkdir -p "$WORK_DIR"
```

后续所有产物写入 `$WORK_DIR`：`MERCHANT_BRIEF.md` / `RESEARCH_RAW/` / `AUDIT_LOG.md` / `FINAL_10_OPTIONS.md`。

### 1.2 必填卡片（ask_user form，1 张卡 4 个问题）

调用 ask_user `mode:"form"`，4 个 question 一次问完：

| Q | header | question | 选项设计 | allowSkip |
|---|--------|----------|---------|-----------|
| 1 | 产品基础 | 您要写文案的产品是什么？请提供**产品名 + 核心关键词**（英文为佳） | chat 模式追问（见下） | false |
| 2 | 目标市场 | 主要目标市场？ | 美国 / 欧洲（具体国） / 中东 / 东南亚 / 非洲 / 拉美 / 全球通投 | false |
| 3 | 客户类型 | 主要客户类型？ | 经销商批发 / 工程项目（EPC/政府）/ 品牌商 OEM/ODM / 中小零售 / 终端用户 | false |
| 4 | 产品图 | 是否有产品图可上传（用于视觉特征辅助卖点提炼） | 现在上传 / 稍后再传 / 没有 | true |

> Q1 用 form 选项不够灵活，**Q1 必须用单独的 ask_user `mode:"chat"` 后续追问**，并 attachmentSlot 接受 `image/*`。

### 1.3 商家优势补全（第二张卡，结构化必填）

第一张卡回完后，**立刻**发第二张 form 卡，覆盖营销钩子素材：

| Q | header | question | 选项 |
|---|--------|----------|------|
| 1 | 公司资质 | 公司核心资质（多选） | Manufacturer 自有工厂 / Trading Company / Gold Supplier / Verified Supplier / OEM/ODM 能力 / 自有品牌 |
| 2 | 认证 | 主要认证（多选） | CE / FCC / RoHS / ISO9001 / ISO14001 / UL / SAA / SASO / FDA / 无 / 其他（自填）|
| 3 | 差异化卖点 | 与同行最大差异（最多 3 项） | 价格优势 / 质保延长 / 交期更快 / 质量更优 / 一站式方案 / 技术专利 / 已服务知名客户 / 其他（自填） |
| 4 | MOQ与产能 | MOQ 与月产能区间 | MOQ ≤ 1 / MOQ 1-10 / MOQ 10-100 / MOQ 100+ ；产能档位让用户填 |

### 1.4 Gate 1 输出模板

```markdown
## ✅ Stage 1 Gate 检查
- 产品名 / 核心关键词：<填> ✅
- 目标市场：<填> ✅
- 客户类型：<填> ✅
- 产品图：<已上传 / 暂无> ✅
- 公司资质：<填> ✅
- 认证清单：<填> ✅
- 差异化卖点（≥1 条）：<填> ✅
- MOQ 与产能：<填> ✅

写入：$WORK_DIR/MERCHANT_BRIEF.md
**进入 Stage 2：派 4 个 subagent 并行调研**
```

如商家在 Q3「差异化卖点」勾选「无」或全部跳过 → **不得进入 Stage 2**，按 R5 强制复述追问；连续两次拒绝才允许带「[商家未提供差异化]」标签进入 Stage 2，并在最终交付汇报中红字提醒。

---

## Stage 2 — 4 个 subagent 并行调研（Gate 2）

> **关键原则**：4 个 subagent 必须**并行 spawn**（同一个回复内完成 4 次 sessions_spawn），不得串行。
> 每个 subagent 都收到 `MERCHANT_BRIEF.md` 摘要 + 自己的专属任务卡（见下方 4 个任务模板）。

### 2.1 SA1 — 国际站买家热搜词（agent_id=general，配 mcp 工具）

**任务模板**（精简，子 Agent 不读 SKILL.md）：
```
你的角色：国际站热搜词调研员。
目标：基于产品名「<填>」+ 目标市场「<填>」，从国际站后台 MCP 工具拉取最近 30/90 天买家搜索热词。

执行步骤：
1. accio-mcp-cli keyword "buyer search keyword" → 找可用 MCP 工具（候选：keyword_recommend / hot_keyword_query / industry_word 等）
2. 调用工具，入参：{"query": "<核心词>", "country": "<目标市场>"}
3. 抽取每个热词的：搜索量、点击率、竞品数、近 30 天 / 90 天趋势
4. 输出 Top 30 热词 → 写入 $WORK_DIR/RESEARCH_RAW/SA1_alibaba_keywords.md

强制返回字段（缺一项主 Agent 会驳回重跑）：
- 每个热词的 [来源 MCP 工具名]
- 工具调用入参原文
- 工具返回时间戳
- 若 MCP 失败：必须返回原始错误信息，不得编造数据

禁止：未跑 MCP 就用通识知识凭空写词。
```

### 2.2 SA2 — Google Trends 调研（agent_id=browser）

```
你的角色：Google Trends 趋势调研员。
目标：核心词「<填>」+ 目标市场「<填>」近 12 个月趋势曲线 + 相关上升查询。

执行步骤：
1. web_fetch 或 browser 打开 https://trends.google.com/trends/explore?geo=<国家代码>&q=<核心词>
2. 截图保存到 $WORK_DIR/RESEARCH_RAW/SA2_gtrends_<keyword>.png
3. 抽取：趋势分（0-100）/ 12 个月走势 / 「相关上升查询」前 10 / 「相关热门查询」前 10

输出 → $WORK_DIR/RESEARCH_RAW/SA2_google_trends.md

强制返回：
- 每张截图文件名 + 实际 Trends URL
- 抽取时间戳
- 若 Trends 限流或加载失败：明确返回错误，不得编造数字

禁止：用记忆中的"通用流行词"代替真实抽取。
```

### 2.3 SA3 — 社媒热点扫描（agent_id=browser）

```
你的角色：社媒 B2B 营销话题调研员。
目标：核心词「<填>」在 YouTube/TikTok/Reddit 上买家或行业内容创作者使用的高频表达、痛点话术、应用场景。

执行步骤：
1. web_search 三个独立查询：
   - "<核心词>" site:youtube.com 近 6 个月 → 抓 top 10 视频标题
   - "<核心词>" site:reddit.com → 抓 top 10 贴标题 + 评论高赞关键词
   - "<核心词> review OR unboxing OR demo" → 跨平台
2. 提炼：高频形容词（如 heavy-duty / waterproof）、买家痛点（如 "always breaking"）、应用场景（如 "for warehouse" / "for off-grid"）

输出 → $WORK_DIR/RESEARCH_RAW/SA3_social_signals.md，包含至少 15 条带 URL 的引用

强制返回：
- 每条洞察必带 [URL] + [视频/帖子标题摘要]
- 抓取时间戳
- 不得编造任何视频或评论原文

禁止：用泛泛的 "社媒上很流行 XX" 代替具体引用。
```

### 2.4 SA4 — 同行 Top10 标题反推（agent_id=browser）

```
你的角色：竞品 listing 反推研究员。
目标：在 alibaba.com 搜索「<核心词>」，抓取自然搜索结果前 10 名（非广告）的商品标题 + 关键卖点。

执行步骤：
1. browser 打开 https://www.alibaba.com/trade/search?SearchText=<核心词>
2. 抓取前 10 个商品的：完整 Title / 价格区间 / MOQ / 公司类型（Manufacturer/Trader）/ Verified 标识
3. 进入前 3 个商品详情页，抓取卖点 bullet（"Highlight" 区域 5 条）

输出 → $WORK_DIR/RESEARCH_RAW/SA4_competitor_titles.md，10 个标题表格 + 3 套竞品卖点

强制返回：
- 每个标题必带商品 URL + 抓取时间戳
- 截图保存：$WORK_DIR/RESEARCH_RAW/SA4_serp.png

禁止：编造竞品标题；如搜索失败必须明确报告。
```

### 2.5 Gate 2 输出模板

主 Agent 等 4 个 subagent **全部返回**后输出：

```markdown
## ✅ Stage 2 Gate 检查（4 个 subagent 交付）
| SA | 任务 | 文件 | 字符数 | 来源标注 | 状态 |
|----|------|------|--------|---------|------|
| SA1 | 国际站热词 | SA1_alibaba_keywords.md | <count> | <带 [MCP] 标签条数> | ✅/⚠️/❌ |
| SA2 | Google Trends | SA2_google_trends.md + png | <count> | <带 URL 条数> | ✅/⚠️/❌ |
| SA3 | 社媒热点 | SA3_social_signals.md | <count> | <带 URL 条数> | ✅/⚠️/❌ |
| SA4 | 同行 Top10 | SA4_competitor_titles.md + png | <count> | <带 URL 条数> | ✅/⚠️/❌ |

任何一项 ❌ → 进入 Stage 3 审计，硬拦截重跑。
```

---

## Stage 3 — 主 Agent 数据溯源审计（Gate 3）

按 [CORE_RULES.md](CORE_RULES.md) 的 R1（数据溯源）、R3（缺源驳回）、R6（审计协议）执行 5 项审计：

```
审计 1: 文件实存性 — 4 个 .md 必须存在
审计 2: 内容非空 — 每个 .md ≥ 800 字符
审计 3: 来源标注密度 — 每个文件 ≥ 70% 章节带 [MCP]/[URL]/[截图] 标签
审计 4: 红线幻觉扫描 — 任何精确数字（搜索量/趋势分/价格）必须紧邻来源
审计 5: 关键词去重 — SA1/SA3 抽取的高频词列出 Top 20 总表
```

任一审计 REJECT → `sessions_send` 让对应 SA 返工，最多重试 2 次；2 次仍 fail → 暂停流程告知商家。

写入审计日志 `$WORK_DIR/AUDIT_LOG.md`，参考 CORE_RULES R6 的格式。

---

## Stage 4 — 营销钩子融合 + 卖点要素拆解（Gate 4）

主 Agent 自己执行（不再 spawn）：基于 4 份原始数据 + MERCHANT_BRIEF，产出**卖点要素池**。

### 4.1 卖点要素六维拆解

读取 [references/marketing-hooks.md](references/marketing-hooks.md) 加载 B2B 营销钩子库（信任 / 稀缺 / 权威 / 价格 / 效率 / 合规），把要素填入下表：

| 维度 | 来源 | 候选要素 |
|------|------|---------|
| 核心功能词 | SA1 Top 10 + SA4 高频 | <列举> |
| 应用场景词 | SA3 提取 | <列举> |
| 趋势上升词 | SA2 相关上升查询 | <列举> |
| 商家硬实力 | MERCHANT_BRIEF Q1+Q2 | <资质 + 认证> |
| 商家差异化 | MERCHANT_BRIEF Q3 | <差异化卖点> |
| B2B 营销钩子 | references/marketing-hooks.md | <信任/稀缺/权威/价格/效率/合规 各 1-2 条> |

写入 `$WORK_DIR/HOOK_POOL.md`。

### 4.2 Gate 4 输出模板

```markdown
## ✅ Stage 4 Gate 检查（卖点要素池）
- 核心功能词：<n> 个
- 应用场景：<n> 个
- 趋势钩子：<n> 个
- 商家资质 + 认证：<n> 项
- 差异化卖点：<n> 条 ✅（≥1 条强制）
- 营销钩子：<n> 条
**进入 Stage 5：组合生成 10 套**
```

如「差异化卖点」< 1 条 → **不得进入 Stage 5**，回到 Stage 1.3 追问。

---

## Stage 5 — 生成 10 套标题 + 卖点（Gate 5）

### 5.1 生成规则

按 [references/title-formula.md](references/title-formula.md) 的 6 类标题公式 + [templates/output-template.md](templates/output-template.md) 的卖点模板，**主 Agent 自己**生成 10 套，每套必带元数据。

10 套必须覆盖 6 种风格（不可全部同质）：

| # | 风格 | 适用场景 |
|---|------|---------|
| 1-2 | 功能型（参数堆叠） | 工程/批发买家精确搜索 |
| 3-4 | 场景型（应用驱动） | 终端用户 / 行业项目 |
| 5-6 | 认证 + 信任型 | 欧美高合规市场 |
| 7 | 价格 + MOQ 型 | 中小零售 / 试单 |
| 8 | 大客户 OEM/ODM 型 | 品牌商 / 工程项目 |
| 9 | 差异化痛点型 | 强调商家独有优势 |
| 10 | 趋势热词型 | 利用 Google Trends 上升词 |

### 5.2 输出表格（必须用此格式）

```markdown
## 🎯 标题 + 卖点 10 套候选

### #1【功能型】
**标题**（126/128 字符）：
> Heavy Duty 200W Solar Street Light IP66 Waterproof Outdoor LED Lamp with Motion Sensor for Highway Manufacturer

**卖点**：
- 200W 高功率，1 灯顶 3 灯【来源：SA1 高频词「200w solar street light」搜索量 12.5K/月】
- IP66 防水 +5 年质保，雷雨地区无忧使用【商家差异化：5 年质保】
- CE/RoHS/SAA 三认证，欧美 / 澳洲清关零障碍【MERCHANT_BRIEF 认证】
- 工厂直发 MOQ=10，30 天交期【MERCHANT_BRIEF MOQ + 产能】
- 已服务尼日利亚 / 巴基斯坦市政路灯项目【商家优势】

**元数据**：
- 字符数：126/128 ✅
- 嵌入热词：solar street light / 200w / IP66 / motion sensor（4/4 SA1 Top 10）
- 嵌入商家优势：5 年质保 / 3 项认证 / MOQ10 / 案例（4/4 必嵌项命中）
- 营销钩子：权威（认证）+ 信任（案例）+ 效率（30 天）
```

10 套全部按此模板输出。

### 5.3 Gate 5 输出模板

```markdown
## ✅ Stage 5 Gate 检查
| # | 风格 | 字符数 | 嵌入热词数 | 嵌入商家优势数 | 营销钩子数 | 状态 |
|---|------|--------|-----------|---------------|-----------|------|
| 1 | 功能型 | 126/128 | 4 | 4 | 3 | ✅ |
| 2 | ... | ... | ... | ... | ... | ✅ |
| ...| | | | | | |
| 10 | 趋势热词 | 121/128 | 5 | 3 | 2 | ✅ |

合规标准：
- 字符数 ≤ 128 ✅
- 每套至少嵌入 SA1 Top10 中的 ≥ 3 个热词
- 每套至少嵌入 ≥ 2 项商家优势/差异化点
- 10 套覆盖 ≥ 5 种不同风格
- 任意一条卖点必带【来源标签】
```

---

## Stage 6 — 商家选择 + 微调 + 落盘（Gate 6）

### 6.1 让商家选择

```markdown
请选择您最满意的方案（可多选，可让我把任意几套混合微调）：
□ #1 功能型  □ #2 功能型  □ #3 场景型  □ #4 场景型
□ #5 认证型  □ #6 认证型  □ #7 价格型  □ #8 大客户型
□ #9 痛点型  □ #10 趋势型

或告诉我：
- "把 #3 的标题 + #5 的第 2 条卖点合并"
- "#7 的价格部分换成 EXW USD"
- "全部加上一条 about company 的卖点"
```

### 6.2 落盘交付

最终落盘文件：
- `$WORK_DIR/MERCHANT_BRIEF.md` — 商家信息
- `$WORK_DIR/RESEARCH_RAW/` — 4 份原始调研 + 截图
- `$WORK_DIR/HOOK_POOL.md` — 卖点要素池
- `$WORK_DIR/FINAL_10_OPTIONS.md` — 10 套候选
- `$WORK_DIR/SELECTED_FINAL.md` — 商家选定的最终版（如 ≥1 套被选）
- `$WORK_DIR/AUDIT_LOG.md` — 6 个 Gate 的全程审计日志

### 6.3 Gate 6 输出模板

```markdown
## 🎉 交付完成

### 选定方案
<列出商家选择的标题 + 卖点>

### 一键应用建议
- 国际站发品页 → 标题字段填入「<选定标题>」
- 详情页「Product Details」→ 5 条卖点直接粘贴
- 后续若想批量优化已发品 → 调用 alibaba-product-information-optimization Skill

### 数据透明
- 调研覆盖：国际站 MCP 热词 ✅ / Google Trends ✅ / 社媒 3 平台 ✅ / 同行 Top 10 ✅
- 审计：6 Gate 全部通过，0 处幻觉，详见 AUDIT_LOG.md

### 文件清单
- $WORK_DIR/SELECTED_FINAL.md  ← 直接拿走用
- $WORK_DIR/FINAL_10_OPTIONS.md ← 完整 10 套备查
- $WORK_DIR/RESEARCH_RAW/       ← 全部原始数据
```

---

## 🚦 异常处理速查

| 场景 | 处理 |
|------|------|
| 商家拒绝填差异化卖点 | R5 强制复述 2 次后允许标 [商家未提供]，但红字提醒最终方案竞争力受影响 |
| MCP 不可用 | SA1 子任务降级为 web_search 公开热词工具（如 keywords.io），并明确标注 [降级] |
| Google Trends 限流 | SA2 改用 Glimpse / Exploding Topics 等替代，必须标注 |
| Subagent 第 2 次仍返回缺源 | 暂停流程，告知商家：「调研工具反复出错，需您介入决策是否继续」 |
| 商家想要 > 10 套 | 在 Stage 5 完成后追加，但要求商家说明追加方向（如「再来 5 套主打中东市场」） |
| 商家产品涉及风控品牌词 | 在 Stage 5 生成前调用 alibaba-product-information-optimization 的风控品牌词查询逻辑，剔除违禁词 |

---

## 📚 配套文件

- [CORE_RULES.md](CORE_RULES.md) — R1-R7 反幻觉规则（启动必读）
- [references/marketing-hooks.md](references/marketing-hooks.md) — B2B 营销钩子库
- [references/title-formula.md](references/title-formula.md) — 国际站标题公式 + 字符规则
- [references/data-sources.md](references/data-sources.md) — MCP/web 数据源清单
- [templates/output-template.md](templates/output-template.md) — 10 套输出模板范例
- [templates/subagent-prompts.md](templates/subagent-prompts.md) — 4 个 subagent 完整 prompt 模板
