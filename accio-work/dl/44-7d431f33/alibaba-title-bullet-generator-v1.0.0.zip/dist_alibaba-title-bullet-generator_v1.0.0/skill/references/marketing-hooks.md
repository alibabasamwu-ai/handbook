# B2B 营销钩子库（Marketing Hooks for B2B）

> 跨境 B2B 买家决策心理与跨境零售有本质差异：决策周期长、风险厌恶、合规优先、需要信任背书。
> 本库提供 6 类钩子 + 触发场景 + 标题/卖点话术示例，供 Stage 4 卖点要素融合使用。

---

## 钩子 1：信任（Trust）

**心理机制**：跨境采购金额大、退换货困难，买家对供应商风险厌恶极强。
**触发场景**：首次询盘 / 大额订单 / 品牌商尽调 / 政府工程

| 信任要素 | 标题/卖点话术 |
|---------|-------------|
| Verified Supplier | "Verified Manufacturer with 10+ Years of Export Experience" |
| Gold Supplier 年限 | "Alibaba Gold Supplier for 8 Years, On-Site Verified" |
| 工厂规模/员工数 | "30000m² Factory, 200+ Workers, 5 Production Lines" |
| 已服务客户 | "Trusted by 500+ Distributors in 60 Countries" |
| 知名客户案例 | "Supplier for Walmart / Carrefour Project" |
| 第三方审计 | "BSCI / SEDEX / TUV-Audited Factory" |

---

## 钩子 2：稀缺（Scarcity）

**心理机制**：制造紧迫感，推动买家从"再看看"转向"立即询盘"。
**触发场景**：节日促销 / 新品发布 / 限量定制 / 库存有限

| 稀缺要素 | 话术 |
|---------|------|
| 限时折扣 | "Limited Time: 15% Off MOQ Orders Before [Date]" |
| 限量库存 | "Ready Stock: Only 500 Units Available, Ship Within 7 Days" |
| 独家代理机会 | "Exclusive Distributor Wanted in [Region]" |
| 新品首发 | "2026 New Arrival, First Batch Now Open for Pre-Order" |
| 季节性供应 | "Peak Season Slot Booking, Limited Production Capacity" |

⚠️ **滥用风险**：稀缺感叠加过多 → 失去可信度。10 套候选中最多 1-2 套用稀缺主调。

---

## 钩子 3：权威（Authority）

**心理机制**：用第三方权威背书降低买家决策风险。
**触发场景**：高合规市场（欧美/澳洲/日本）/ 政府/医疗/食品/儿童类目

| 权威要素 | 话术 |
|---------|------|
| 认证矩阵 | "CE / FCC / RoHS / ETL / SAA Certified" |
| 行业奖项 | "2025 Alibaba Top Supplier Award" |
| 专利 | "5 Patents Granted, Patent No. ZL2023XXXXXX" |
| 实验室报告 | "SGS Tested, Full Test Report Available" |
| 行业标准制定者 | "ISO 9001:2015 + Industry Standard Drafting Member" |
| 媒体报道 | "Featured in [Industry Magazine] 2025 Issue" |

---

## 钩子 4：价格（Price/ROI）

**心理机制**：B2B 买家最关心采购成本 + 毛利空间，但**不要单纯打低价**，要给出 ROI 逻辑。
**触发场景**：经销商批发 / 试单买家 / 价格敏感市场（南亚/非洲）

| 价格要素 | 话术 |
|---------|------|
| 工厂直发 | "Direct Factory Price, No Middleman" |
| 阶梯价 | "Tiered Pricing: $X for 100pcs, $Y for 1000pcs" |
| MOQ 友好 | "Low MOQ 10pcs, Easy Trial Order" |
| 高毛利空间 | "60% Margin for Distributors, Retail Price Reference Available" |
| 包税/包运 | "DDP Service Available, Total Landed Cost Quoted" |
| 长期合同折扣 | "Annual Contract: Up to 12% Discount" |

⚠️ **避坑**：避免"Cheap"/"Low Price"等廉价词，国际站算法会降权且伤害品牌形象。用 "Competitive" / "Factory Price" / "Best Value" 替代。

---

## 钩子 5：效率（Efficiency）

**心理机制**：买家时间成本高，能快速响应/快速交付的供应商优先。
**触发场景**：项目方案急单 / 季节性补货 / 跨境时效要求高

| 效率要素 | 话术 |
|---------|------|
| 快速响应 | "Reply Within 12 Hours, 7 Days a Week" |
| 短交期 | "30-Day Delivery, 7-Day Sample" |
| 一站式方案 | "One-Stop Solution: Design + Production + Logistics + Installation Guide" |
| 库存保障 | "Ready Stock + Custom Production Parallel" |
| 包装标准化 | "Standard Export Packaging, No Repacking Needed" |
| OEM 提速 | "OEM/ODM in 45 Days from Sample Approval" |

---

## 钩子 6：合规（Compliance）

**心理机制**：跨境贸易最大隐性成本是合规问题（清关失败、罚款、退运），合规背书是高合规市场的硬通货。
**触发场景**：欧盟（CE/REACH）/ 美国（FDA/UL/Prop 65）/ 中东（SASO）/ 海运危险品

| 合规要素 | 话术 |
|---------|------|
| 区域认证全 | "EU CE + UK UKCA + US FCC Compliant" |
| 环保合规 | "RoHS / REACH / Prop 65 Compliant" |
| 食品级 | "FDA Approved, Food-Contact Safe" |
| 包装合规 | "Export-Compliant Packaging, MSDS Available" |
| 原产地证 | "Form A / FORM E Certificate of Origin Available" |
| 反倾销豁免 | "Anti-Dumping Compliant, Duty-Free for [Region]" |

---

## 钩子组合策略（Stage 5 用）

10 套候选中各风格的推荐钩子组合：

| 风格 | 主钩子 | 辅钩子 |
|------|-------|-------|
| 功能型 A/B | 信任 + 价格 | 效率 |
| 场景型 A/B | 信任 + 效率 | 权威 |
| 认证信任型 A/B | 权威 + 合规 | 信任 |
| 价格 MOQ 型 | 价格 + 效率 | 信任 |
| 大客户 OEM 型 | 信任 + 权威 | 效率 |
| 差异化痛点型 | 信任 + 差异化 | 权威 |
| 趋势热词型 | 稀缺 + 效率 | 权威 |

---

## 反钩子（要避免的话术）

| 反钩子 | 为什么避免 |
|--------|-----------|
| "Cheapest in China" | 算法降权 + 品牌形象差 |
| "100% Best Quality" | 绝对化用语，部分平台风控 |
| "World's #1" / "No.1" | 无法证伪，国际站标题规则禁止 |
| 大量 emoji 或 ★★★★★ | 国际站标题字段禁止 |
| 全大写 SHOUTING TITLE | 算法识别为低质 |
| "Hot Sale!!! Click Now!!!" | C 端话术，B2B 买家反感 |
| 未授权品牌名 | 风控直接下架 + 罚款 |
