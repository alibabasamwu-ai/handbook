# 数据源清单（Data Sources）

> 4 个 subagent 调用的数据源、降级路径、字段对照表

---

## SA1 数据源 — 国际站后台 MCP

### 候选 MCP 工具（按优先级）

```bash
# 第一动作：扫描可用工具
accio-mcp-cli keyword "buyer search keyword"
accio-mcp-cli keyword "hot keyword"
accio-mcp-cli keyword "industry word"
```

| 工具名（候选） | 用途 | 关键入参 | 关键返回 |
|---------------|------|---------|---------|
| `hot_keyword_query` | 热搜词 | query, country, timeRange | keywords[].volume / trend / cpc |
| `keyword_recommend` | 关键词推荐 | productId or keyword | recommend_keywords[] |
| `industry_word` | 行业词包 | leafId / category | industry_keywords[] |
| `icbu_keyword_insight` | 词洞察 | keyword | search_volume, competitor_count |
| `buyer_search_term_report` | 买家搜索词报告 | sellerId, dateRange | terms[].search_count |

### 调用示例

```bash
accio-mcp-cli call hot_keyword_query --json '{"query":"solar street light","country":"US","timeRange":"90d"}'
```

### 降级路径
1. MCP 全部不可用 → web_search 公开热词工具：
   - https://www.semrush.com/analytics/keywordoverview/
   - https://ahrefs.com/keyword-explorer
   - https://app.neilpatel.com/en/seo_analyzer/keyword_suggestions
   - https://keywordtool.io/
2. 仅做参考性引用，必须标 `[降级:<source>]`
3. 商家有亚马逊数据需求 → 可调用 `alibaba-amazon-market-intel` 技能补充亚马逊侧搜索量

---

## SA2 数据源 — Google Trends

### 主源
- URL 模板：`https://trends.google.com/trends/explore?date=today%2012-m&geo={country_code}&q={keyword}`
- 国家代码（常用）：US / GB / DE / FR / ES / SA / AE / IN / SG / MY / NG / ZA

### 抓取要点
- 主曲线整体均值（0-100）
- "Related queries → Rising"（关注 +50% 以上 / "Breakout"）
- "Related queries → Top"
- "Compare" 多词对比（最多 5 词同框）

### 降级路径
1. Google Trends 限流 / IP 被封 → 改用：
   - https://glimpse.com（Trends 增强版，免登录可看部分数据）
   - https://explodingtopics.com（趋势新词发现）
2. 必须标 `[降级:Glimpse]` 或 `[降级:ExplodingTopics]`

---

## SA3 数据源 — 社媒三平台

### YouTube
- 搜索：`site:youtube.com "<keyword>" review OR demo OR unboxing`
- 进入视频后看：标题 / 描述 / Top 评论（按 Top comments 排序）
- 重点抓取近 6 个月发布的视频

### Reddit
- 搜索：`site:reddit.com "<keyword>"`
- 重点 subreddit：r/buildapcsales（科技类）/ r/business（商贸类）/ 行业相关 sub
- 抓贴标题 + 高赞评论原文

### TikTok
- 搜索：`site:tiktok.com "<keyword>"` 或 `"<keyword> tiktok"`
- TikTok 反爬严，主要看视频描述 + hashtag
- 替代方案：https://exolyt.com / https://tokchart.com 看 TikTok 趋势

### 降级
- 任一平台 0 结果 → 至少保 YouTube + Reddit 两源
- 全部失败 → 用 Quora / LinkedIn / Twitter 作补充，明确标记

---

## SA4 数据源 — 国际站 SERP

### 主源
- URL 模板：`https://www.alibaba.com/trade/search?SearchText={keyword}`
- 区分广告位（带 "Ad" 标识）和自然位
- 每个商品的 detail 页 URL 形如 `https://www.alibaba.com/product-detail/...html`

### 抓取要点
- 自然位前 10 名标题
- 商品价格 / MOQ / 公司类型 / Verified 标识
- Top 3 进详情页抓 "Highlight" / 卖点 bullet（通常 5 条）
- 「About this Item」/ 「Product Details」区域

### 降级
- 国际站反爬 → 用 web_search "{keyword} site:alibaba.com" 拼凑
- 详情页打不开 → 至少保 SERP 10 条标题
- 任一标题缺 URL → 主 Agent 在 R3 审计时驳回

---

## 数据交叉验证（主 Agent 在 Stage 4 用）

| 维度 | 检查 |
|------|------|
| SA1 Top 词 vs SA4 Top 10 标题 | 高频共现词 = 强信号 |
| SA2 Rising 词 vs SA1 Top 词 | 共现 = 双源验证的趋势词 |
| SA3 高频形容词 vs SA4 卖点 bullet | 共现 = 买家+卖家共识 |
| SA1 词搜索量 vs SA4 标题字符位置 | 高搜索量词应出现在前 80 字符 |

差异点（如 SA2 显示某词飙升但 SA1 显示低搜索）→ 可能是亚马逊向国际站迁移的"早期信号"，值得专门做趋势型标题（#10）。

---

## 风控品牌词查询

调用 `alibaba-product-information-optimization` 已实现的 MCP：

```
入参：{"catIdList": [<叶子类目 id>]}
返回：model.result.content.brand_names — 风控品牌词列表
```

Stage 5 生成 10 套后，主 Agent 必须把每套标题+卖点中的英文专有名词与该列表做交集校验，命中即剔除/替换。
