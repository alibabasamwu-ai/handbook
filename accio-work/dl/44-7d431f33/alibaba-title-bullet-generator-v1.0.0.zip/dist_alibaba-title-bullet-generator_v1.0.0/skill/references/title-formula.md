# 国际站标题公式与字符规则

> 国际站标题是流量入口，**第一权重 = 关键词匹配 + 长尾覆盖**，第二权重 = 标题质量分。
> 本文档对齐国际站官方发品规则（可能更新，以后台「商品发布」页提示为最终准）。

---

## 硬规则（写入即必须遵守）

| 规则 | 限制 | 违反后果 |
|------|------|---------|
| 总字符数 | ≤ 128（含空格、标点） | 后台保存失败 |
| 单词重复 | 同一非介词单词最多出现 2 次 | 关键词堆砌降权 |
| 全大写 | 禁止全大写整行标题 | 质量分降低 |
| 特殊字符 | 禁止 emoji、★、❤、◆ 等装饰符号 | 后台校验拒绝 |
| 风控品牌词 | 未授权的他方品牌名 | 商品下架 + 处罚 |
| 绝对化用语 | "Best"/"#1"/"World's First" | 平台风控关键词 |
| 行业违禁词 | "FDA Approved" 仅限通过 FDA 的卖家 | 虚假宣传处罚 |
| 数字单位 | 200W ✅ / 200WATT ✅ / 200瓦 ❌（必须英文） | 后台保存失败 |
| 大小写规范 | Title Case（每个实词首字母大写）推荐 | 质量分加分项 |

---

## 6 大标题公式

### 公式 1：参数堆叠型（功能型 A）

```
<规格1> + <规格2> + <核心品类词> + <USP> + <场景> + <Manufacturer>
```

例：`200W IP66 Solar Street Light Outdoor LED Lamp with Motion Sensor for Highway Manufacturer`

适用：工程客户精确搜索（搜索词中含具体参数）

---

### 公式 2：品类驱动型（功能型 B）

```
<品类> + <核心规格> + <认证> + <场景> + <价格暗示>
```

例：`Solar Street Light 200W IP66 CE RoHS Outdoor LED Lamp Factory Price`

适用：批发买家比价场景

---

### 公式 3：场景驱动型（场景型 A）

```
<场景> + <品类> + <核心USP> + <认证> + <Manufacturer>
```

例：`Highway Outdoor Solar Street Light 200W IP66 Waterproof CE Manufacturer`

适用：终端项目方按场景搜索

---

### 公式 4：行业垂直型（场景型 B）

```
<应用行业> + <品类> + <差异化> + <交期>
```

例：`Marine Solar Street Light Anti-Corrosion 200W LED 30-Day Delivery`

适用：行业垂直买家（船舶/医疗/食品/化工等）

---

### 公式 5：信任背书型（认证型 A/B）

```
<Verified Supplier> + <品类> + <认证矩阵> + <质保>
```

例：`Verified Manufacturer Solar Street Light CE FCC RoHS SAA 5-Year Warranty 200W LED`

适用：欧美高合规市场 / 大客户尽调

---

### 公式 6：差异化突围型（差异化痛点型）

```
<痛点反驳> + <品类> + <商家独有优势>
```

例：`No Battery Replacement Solar Street Light 5-Year Lifespan 200W IP66 LED Outdoor Lamp Manufacturer`

适用：竞争激烈红海类目，强调独有优势

---

## 关键词排序权重（重要）

国际站标题算法对**位置**敏感，前 50 字符权重最高：

```
[前 50 字符 — 核心权重]   [中 50 字符 — 长尾覆盖]   [尾 28 字符 — 补充]
↓                          ↓                          ↓
核心品类词 + 高搜索量参数    场景/认证/USP             Manufacturer/Factory/Service
```

### 排序原则
1. **第 1 个词必须是核心品类词或最重要参数**（如 `200W Solar Street Light`，不要 `OEM Solar Street Light`）
2. SA1 Top 1-3 热词必须出现在**前 80 字符内**
3. `Manufacturer` / `Factory` / `Supplier` 等供应商类型词放尾部
4. 长尾场景词放中部（如 `for Highway` / `for Off-Grid`）

---

## Title Case 规范

**实词首字母大写，介词/冠词小写**：

✅ `Heavy Duty 200W Solar Street Light with Motion Sensor for Highway`
❌ `Heavy duty 200w solar street light With motion sensor For highway`
❌ `HEAVY DUTY 200W SOLAR STREET LIGHT WITH MOTION SENSOR FOR HIGHWAY`

例外：参数中的单位保持原样：`IP66`（不写 Ip66）/ `200W`（不写 200w）/ `LED`（全大写缩写）。

---

## 字符数控制技巧

### 缩短技巧
- `Manufacturer` → `Mfg`（仅在确实超长时用）
- `Outdoor` → `Outdr`（**不推荐**，影响搜索匹配）
- 删除冗余介词：`Light with Motion Sensor` → `Light Motion Sensor`（语法可接受）
- 删除重复修饰：`Heavy Duty High Quality` → 二选一

### 拓长技巧（≤ 128 范围内充分使用）
- 加场景：`for Highway` / `for Garden` / `for Marine`
- 加供应商类型：`Manufacturer` / `OEM/ODM Factory`
- 加认证：`CE Certified` / `with FCC RoHS`
- 加 USP：`5-Year Warranty` / `IP66 Waterproof`

---

## 标题质量自检清单（Stage 5 用）

```
□ 字符数 ≤ 128
□ 第 1 个词是核心品类词或核心参数
□ SA1 Top 3 中至少 2 个热词在前 80 字符内
□ 嵌入 ≥ 1 个商家硬实力（资质/认证/质保等）
□ 无重复单词超过 2 次
□ 无 emoji / 全大写 / 风控品牌词 / 绝对化用语
□ Title Case 规范
□ 数字单位为英文（W/V/A/IP/mm 等）
```

---

## 风控品牌词自查（强制）

每生成一套标题前，主 Agent 应：
1. 提取标题中所有可能是品牌的英文专有名词
2. 调用 alibaba-product-information-optimization 的「风控品牌词查询」MCP（catIdList = 商品叶子类目）
3. 对返回的 `brand_names` 列表做交集校验
4. 命中即剔除该词或换同义词

如不便调用 MCP，至少提示商家：「以下词疑似品牌词，请确认是否有授权：<列表>」。
