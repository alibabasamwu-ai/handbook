# Output Template — 10 套标题 + 卖点输出范式

> 主 Agent 在 Stage 5 必须严格按此模板生成 `FINAL_10_OPTIONS.md`

---

## 文件头

```markdown
# 标题 + 卖点 10 套候选 — {{product_name}}

- 生成时间：<ISO>
- 调研覆盖：国际站热词 ✅ / Google Trends ✅ / 社媒 3 平台 ✅ / 同行 Top 10 ✅
- 商家优势嵌入校验：✅
- 字符长度合规：10/10 ✅
```

---

## 单套模板（10 套都用同一格式）

```markdown
### #N【风格标签】

**标题**（{{字符数}}/128 字符）：
> {{Title 英文原文}}

**卖点**（{{n}} 条）：
- {{Bullet 1}}【来源：{{标签}}】
- {{Bullet 2}}【来源：{{标签}}】
- {{Bullet 3}}【来源：{{标签}}】
- {{Bullet 4}}【来源：{{标签}}】
- {{Bullet 5}}【来源：{{标签}}】

**元数据**：
- 字符数：{{n}}/128 ✅
- 嵌入 SA1 Top 10 热词：{{kw1}} / {{kw2}} / {{kw3}} / {{kw4}}（{{命中数}}/4 ✅）
- 嵌入商家优势：{{资质}} / {{认证}} / {{差异化}} / {{MOQ}}（{{命中数}}/4 ✅）
- 嵌入 Google Trends 上升词：{{rising_kw}}（如有）
- 嵌入社媒洞察：{{social_phrase}}（如有）
- 营销钩子：{{hook1}} + {{hook2}} + {{hook3}}
- 适用客户：{{customer_type}}
```

---

## 10 套风格分配（强制覆盖）

| # | 风格 | 公式 | 适用场景 |
|---|------|------|---------|
| 1 | 功能型 A | <参数1> + <参数2> + <品类> + <USP> + <场景> + <Manufacturer> | 工程客户精确搜索 |
| 2 | 功能型 B | <品类> + <核心规格> + <认证> + <场景> + <价格暗示> | 批发买家比价 |
| 3 | 场景型 A | <场景> + <品类> + <核心USP> + <认证> + <Manufacturer> | 终端项目方 |
| 4 | 场景型 B | <应用行业> + <品类> + <差异化> + <交期> | 行业垂直买家 |
| 5 | 认证信任型 A | <认证> + <品类> + <参数> + <质保> + <Manufacturer> | 欧美高合规市场 |
| 6 | 认证信任型 B | <Verified Supplier> + <品类> + <认证矩阵> + <案例暗示> | 大客户尽调 |
| 7 | 价格 MOQ 型 | <品类> + <核心USP> + <Low MOQ X> + <交期> + <Direct Factory> | 中小零售试单 |
| 8 | 大客户 OEM/ODM 型 | <OEM/ODM> + <品类> + <产能> + <认证> + <Custom Service> | 品牌商定制 |
| 9 | 差异化痛点型 | <痛点反驳话术>（如 No XX, No YY） + <品类> + <商家独有优势> | 竞争激烈类目突围 |
| 10 | 趋势热词型 | <Google Trends 上升词> + <品类> + <SA3 社媒高频形容词> + <USP> | 抢占新兴搜索流量 |

---

## 范例（实际输出参考 — solar street light）

### #1【功能型 A】

**标题**（126/128 字符）：
> Heavy Duty 200W Solar Street Light IP66 Waterproof Outdoor LED Lamp with Motion Sensor for Highway Manufacturer

**卖点**（5 条）：
- 200W 高功率 LED + 30000lm 流明，1 灯顶 3 灯效果【来源：SA1 Top1 热词「200w solar street light」搜索量 12.5K/月 [MCP: hot_keyword_query]】
- IP66 整机防水 + 5 年质保，雷雨大风地区零担忧【来源：MERCHANT_BRIEF Q3 差异化卖点「5 年质保」 + SA3 高频痛点「always breaks」[Social: Reddit https://...]】
- CE / RoHS / SAA 三大认证齐全，欧美/澳洲清关零障碍【来源：MERCHANT_BRIEF Q2 认证】
- Manufacturer 直发 MOQ=10，30 天交期，散货客户也能合作【来源：MERCHANT_BRIEF Q1+Q4】
- 已服务尼日利亚 / 巴基斯坦市政路灯项目，工程客户首选【来源：MERCHANT_BRIEF Q3 差异化卖点】

**元数据**：
- 字符数：126/128 ✅
- 嵌入 SA1 Top 10 热词：solar street light / 200w / IP66 / motion sensor（4/4 ✅）
- 嵌入商家优势：Manufacturer / 5 年质保 / 3 项认证 / MOQ10（4/4 ✅）
- 嵌入 Google Trends 上升词：—（本套未使用）
- 嵌入社媒洞察：always breaks 痛点反驳
- 营销钩子：权威（认证）+ 信任（案例）+ 效率（30 天）
- 适用客户：工程项目方（EPC/政府）

---

### #10【趋势热词型】

**标题**（121/128 字符）：
> Smart Solar Street Light with App Control 200W IP66 LED Lamp Motion Sensor for Off-Grid Highway Manufacturer

**卖点**（5 条）：
- App 远程控制 + 智能调光，支持单灯/分组管理【来源：Google Trends 上升词「smart solar light」+185% [Google Trends: trends.google.com/...]】
- Off-Grid 离网设计，无需市电，偏远地区/非洲市场首选【来源：SA3 社媒高频场景「for off-grid」5 次 [Social: ...]】
- 200W LED + IP66 户外标准，5 年质保零烦恼【来源：SA1 + MERCHANT_BRIEF】
- CE/RoHS 双认证，工厂直发 MOQ=10【来源：MERCHANT_BRIEF Q1+Q2+Q4】
- 7 天发样 + 30 天大货，跟得上项目节奏【来源：MERCHANT_BRIEF Q4 产能】

**元数据**：
- 字符数：121/128 ✅
- 嵌入 SA1 Top 10 热词：solar street light / 200w / IP66 / motion sensor（4/4 ✅）
- 嵌入商家优势：Manufacturer / 5 年质保 / 2 项认证 / MOQ10（4/4 ✅）
- 嵌入 Google Trends 上升词：smart solar light（+185%）
- 嵌入社媒洞察：for off-grid 应用场景
- 营销钩子：稀缺（智能新品）+ 效率（远程管控）+ 信任（认证质保）
- 适用客户：经销商批发 + 工程项目方

---

## 关键词覆盖矩阵（必带，对齐 R4 审计）

```markdown
## 🔍 关键词覆盖矩阵

| SA1 Top 10 热词 | 出现次数 | 覆盖套号 |
|----------------|---------|---------|
| solar street light | 10 | 全部 |
| 200w | 7 | #1,#2,#3,#5,#7,#9,#10 |
| ip66 | 8 | #1,#2,#3,#4,#5,#7,#9,#10 |
| motion sensor | 6 | #1,#2,#3,#5,#9,#10 |
| outdoor led | 5 | ... |
| ... | | |

未使用热词及原因：
- "<某词>"：风控品牌词，已剔除
- "<某词>"：与商家定位不符（商家无此 SKU）
```

---

## 商家选择卡（Stage 6 用）

```markdown
请选择您最满意的方案（可多选 / 可让我重新组合）：

□ #1【功能型 A】 □ #2【功能型 B】
□ #3【场景型 A】 □ #4【场景型 B】
□ #5【认证型 A】 □ #6【认证型 B】
□ #7【价格 MOQ】  □ #8【大客户 OEM】
□ #9【痛点突围】  □ #10【趋势热词】

或自然语言告诉我，例如：
- "把 #3 的标题 + #1 的第 2、4 条卖点合并"
- "#7 的价格部分换成 EXW USD 单价"
- "全部加一条 about company 卖点"
- "再来 5 套主打中东/沙特市场"
```
