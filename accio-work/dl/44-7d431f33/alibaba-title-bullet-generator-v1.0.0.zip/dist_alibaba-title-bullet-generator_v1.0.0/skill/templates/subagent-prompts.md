# Subagent Prompts — 4 个并行调研任务完整模板

> 主 Agent 在 Stage 2 必须**同一回复内并行 spawn 4 个 sessions_spawn**，不可串行。
> 每个 task 描述都是自包含的，sub-agent 看不到 SKILL.md。
> 占位符 `{{...}}` 在派发前必须由主 Agent 替换为 MERCHANT_BRIEF 中的实际值。

---

## 🚀 派发协议（主 Agent 执行）

```
4 次 sessions_spawn 必须放在同一个 assistant 回复内：
  - SA1: agent_id=general,  label="国际站热词调研"
  - SA2: agent_id=browser, label="Google Trends 调研"
  - SA3: agent_id=browser, label="社媒热点扫描"
  - SA4: agent_id=browser, label="同行 Top10 反推"
```

每个 task 必须以下面的「公共开头」+ 该 SA 的专属任务体 拼接而成。

### 公共开头（4 个 SA 都包含）

```
【公共上下文】
- 产品名：{{product_name}}
- 核心英文关键词：{{core_keyword}}
- 目标市场：{{target_market}}（country code: {{country_code}}）
- 客户类型：{{customer_type}}
- 工作目录：{{work_dir}}
- 调研时间窗：近 90 天

【公共强约束】
1. 任何精确数字（搜索量/CTR/价格/趋势分）必须紧邻来源标签 [MCP]/[URL]/[截图文件名]
2. 工具调用失败时如实报告错误，不得用训练数据补全
3. 文件末尾必须追加 SA Self-Check 块（格式见下）
4. 抓取/调用全部带 ISO 时间戳

【SA Self-Check 块格式】（追加到产出文件末尾）
---
## 🔍 SA Self-Check
- [ ] 所有数据点带来源标签：是 / 否，缺源 <n> 处
- [ ] 工具调用真实执行（贴入参原文）：是 / 否
- [ ] 抓取时间戳：<ISO 8601>
- [ ] 任何降级/失败已明确说明：是 / 否 / 无降级
- [ ] 字符数：<n>
```

---

## SA1 — 国际站热搜词调研（agent_id=general）

```
{{公共开头}}

【你的角色】国际站买家热搜词调研员。

【目标】基于产品「{{product_name}}」+ 关键词「{{core_keyword}}」+ 市场「{{target_market}}」，
拉取国际站后台买家真实搜索热词 Top 30。

【步骤】
1. 找 MCP 工具：accio-mcp-cli keyword "buyer search keyword"
   候选工具名：keyword_recommend / hot_keyword_query / industry_word / icbu_keyword 等
2. 调用候选工具（按返回字段判断哪个最合适），入参示例：
   accio-mcp-cli call <tool_name> --json '{"query":"{{core_keyword}}","country":"{{country_code}}","timeRange":"90d"}'
3. 抽取每个热词的：搜索量 / 竞品数 / 近 30 天趋势分 / 推荐 CPC（如有）
4. 输出格式（写入 {{work_dir}}/RESEARCH_RAW/SA1_alibaba_keywords.md）：

   # SA1 — 国际站买家热搜词

   ## 调用记录
   - 工具：<tool_name> [MCP]
   - 入参原文：<原文>
   - 调用时间：<ISO>
   - 返回总词数：<n>

   ## Top 30 热词表
   | 排名 | 关键词 | 搜索量/月 | 竞品数 | 90天趋势 | 推荐CPC | 来源 |
   |------|--------|----------|--------|---------|---------|------|
   | 1 | <kw> | <num> | <num> | ↑/↓/平 | $<num> | [MCP: <tool>] |
   | ...|

   ## Top 10 高潜词推荐
   <主 Agent 用得上的精选 10 词，每词附 1 句"为什么推荐">

   ## 风控提示
   <如热词中含品牌名，明确列出>

【降级路径】
- MCP 完全不可用 → 用 web_search "<core_keyword> alibaba search volume" 找公开数据源（如 keywords.io / sembulb），明确标 [降级:<source>]
- 必须保留 ≥ 15 条带来源的词，否则向主 Agent 报告 "数据不足"

【禁止】
- ❌ 用训练数据写"通常 XX 是热词"
- ❌ 编造搜索量数字
- ❌ 跳过 SA Self-Check 块
```

---

## SA2 — Google Trends 调研（agent_id=browser）

```
{{公共开头}}

【你的角色】Google Trends 趋势调研员。

【目标】核心词「{{core_keyword}}」+ 市场「{{target_market}}」近 12 个月趋势 + 上升查询。

【步骤】
1. 构造 URL：https://trends.google.com/trends/explore?date=today%2012-m&geo={{country_code}}&q={{core_keyword_url_encoded}}
2. 用 web_fetch 抓页面（如 fetch 不到完整数据，spawn browser 打开并截图）
3. 截图保存：{{work_dir}}/RESEARCH_RAW/SA2_gtrends_main.png
4. 抽取以下 4 块：
   A. 趋势曲线整体走势分（0-100 平均值）
   B. 12 个月走势文字描述（如"3 月达峰 95，9 月低谷 42"）
   C. 「相关上升查询」前 10（含百分比涨幅）
   D. 「相关热门查询」前 10（含 0-100 分值）
5. 同步抓「Compare」对比：把 {{core_keyword}} 与 SA1 返回的 Top 5 词放进对比，截图保存 SA2_gtrends_compare.png

【输出】写入 {{work_dir}}/RESEARCH_RAW/SA2_google_trends.md

   # SA2 — Google Trends 调研

   ## 主词趋势
   - 关键词：{{core_keyword}}
   - 国家：{{target_market}}
   - 时间窗：past 12 months
   - URL：<完整 URL> [Google Trends: <URL>]
   - 截图：SA2_gtrends_main.png
   - 抓取时间：<ISO>

   ### 走势摘要
   - 均值：<n>/100
   - 峰值：<月份> <值>
   - 谷值：<月份> <值>
   - 趋势判定：上升 / 下降 / 平稳

   ## 相关上升查询 Top 10（Rising）
   | # | 查询 | 涨幅 | 来源 |
   |---|------|------|------|
   | 1 | <q> | +<n>% / Breakout | [Google Trends: <URL>] |

   ## 相关热门查询 Top 10（Top）
   | # | 查询 | 分值 | 来源 |
   ...

   ## 与同类词对比（Compare）
   - 截图：SA2_gtrends_compare.png
   - 排名结论：<XX 词热度高于 YY 词，差距 N 倍>

【降级】
- Trends 限流 / 加载失败 → 改用 https://glimpse.com 或 https://explodingtopics.com 同关键词查询，明确标 [降级:<source>]
- 截图无法获取 → 至少保证文字数据带 URL

【禁止】
- ❌ 编造任何百分比数字
- ❌ 用通识"XX 在欧美很火"代替真实抓取
```

---

## SA3 — 社媒热点扫描（agent_id=browser）

```
{{公共开头}}

【你的角色】B2B 社媒话题调研员。

【目标】核心词「{{core_keyword}}」在 YouTube / TikTok / Reddit 三个平台上：
买家或行业 KOL 使用的高频形容词 + 痛点话术 + 应用场景。

【步骤】
1. 三个独立 web_search 查询：
   A. site:youtube.com "{{core_keyword}}" review OR demo OR unboxing
   B. site:reddit.com "{{core_keyword}}"
   C. site:tiktok.com "{{core_keyword}}" 或 web_search "{{core_keyword}} tiktok viral"
2. 每个平台抓 Top 10 结果（标题 + URL）
3. 进入 ≥ 3 个高互动结果细看（YouTube 看视频简介 + 高赞评论；Reddit 看正文 + Top 5 评论；TikTok 看视频描述）
4. 提炼以下 3 维度：
   - 高频形容词（如 heavy-duty / waterproof / portable / energy-saving）
   - 买家痛点话术（如 "always breaks after 6 months" / "too expensive to install"）
   - 应用场景（如 "for warehouse" / "for off-grid" / "for marine"）

【输出】{{work_dir}}/RESEARCH_RAW/SA3_social_signals.md

   # SA3 — 社媒热点扫描

   ## 抓取摘要
   - 三平台 Top 10 列表（30 条带 URL 引用）
   - 抓取时间：<ISO>

   ## YouTube Top 10
   | # | 标题 | URL | 互动量 | 来源 |
   |---|------|-----|--------|------|
   | 1 | <title> | <URL> | <views/likes> | [Social: YouTube <URL>] |

   ## Reddit Top 10
   <同格式>

   ## TikTok Top 10
   <同格式>

   ## 关键洞察（≥ 15 条带 URL 引用）
   ### 高频形容词（带出现次数）
   - heavy-duty (8 次) [Social: <URL1>, <URL2>, ...]
   - waterproof (6 次) ...

   ### 买家痛点话术（每条带原文 + URL）
   - "always breaks after 6 months" [Social: Reddit <URL>]
   - "installation manual is unclear" [Social: YouTube comments <URL>]

   ### 应用场景词（带出现频次）
   - for warehouse (5 次)
   - for off-grid (4 次)

   ## 营销钩子建议
   <把上述洞察转成 3-5 条可直接用于卖点的话术>

【降级】
- 任一平台搜索 0 结果 → 改用 web_search 通用搜索 + site: 限定，明确标 [降级]
- TikTok 内容难抓 → 至少保留 YouTube + Reddit 两源

【禁止】
- ❌ 编造视频标题或评论
- ❌ "通常社媒上 XX 流行" 这类无 URL 表述
- ❌ 缺 URL 的洞察直接计入主表
```

---

## SA4 — 同行 Top 10 标题反推（agent_id=browser）

```
{{公共开头}}

【你的角色】竞品 listing 反推研究员。

【目标】alibaba.com 自然搜索「{{core_keyword}}」前 10 名（非广告位）的标题 + 卖点反推。

【步骤】
1. browser 打开：https://www.alibaba.com/trade/search?SearchText={{core_keyword_url_encoded}}
2. 截图保存：{{work_dir}}/RESEARCH_RAW/SA4_serp.png
3. 区分广告位（"Ad" 标识）和自然位，只抓**自然位前 10**
4. 每个商品抽取：完整 Title / 价格区间 / MOQ / 公司类型（Manufacturer / Trading）/ Verified 标识 / 商品 URL
5. 选 Top 3 进入详情页，抓取 "Highlight" / 卖点 bullet 区域的 5 条卖点

【输出】{{work_dir}}/RESEARCH_RAW/SA4_competitor_titles.md

   # SA4 — 同行 Top 10 标题反推

   ## SERP 抓取
   - URL：<完整搜索 URL>
   - 抓取时间：<ISO>
   - 截图：SA4_serp.png

   ## Top 10 标题表
   | # | 完整标题 | 字符数 | 价格 | MOQ | 公司类型 | Verified | URL |
   |---|---------|--------|------|-----|---------|----------|-----|
   | 1 | <title> | 124 | $X-Y | 10 | Manufacturer | ✅ | [Alibaba SERP: <URL>] |
   | ...|

   ## 标题结构通用模板（基于 Top 10 总结）
   - <型号/参数> + <核心品类词> + <USP/认证> + <场景/应用> + <公司/产能>
   - 平均字符数：<n>
   - 高频结构片段：<列举>

   ## Top 3 详情页卖点
   ### #1 商品（URL）
   - 卖点 1: <原文>
   - 卖点 2: <原文>
   - ...

   ### #2 商品
   ...

   ### #3 商品
   ...

   ## 同行盲区（值得我方差异化的点）
   <主 Agent 用得上的差异化建议 3-5 条>

【降级】
- 国际站搜索被风控/反爬 → 用 web_search "<core_keyword> site:alibaba.com" 拼凑，明确标 [降级]
- 详情页打不开 → 至少保证 SERP 10 条标题

【禁止】
- ❌ 编造商品 URL 或公司名
- ❌ 把广告位混入自然位统计
- ❌ 抄袭同行卖点原文用于我方（仅做结构参考）
```
