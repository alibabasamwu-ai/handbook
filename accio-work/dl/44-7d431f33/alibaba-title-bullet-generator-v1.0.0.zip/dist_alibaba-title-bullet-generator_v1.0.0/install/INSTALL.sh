#!/usr/bin/env bash
# alibaba-title-bullet-generator · 一键安装脚本（macOS / Linux）
# v1.0.0
set -euo pipefail

SKILL_ID="alibaba-title-bullet-generator"
SKILL_NAME="国际站标题卖点生成器"

# 颜色
GREEN='\033[0;32m'; YELLOW='\033[1;33m'; RED='\033[0;31m'; CYAN='\033[0;36m'; NC='\033[0m'

echo -e "${CYAN}════════════════════════════════════════════════════${NC}"
echo -e "${CYAN}  ${SKILL_NAME} v1.0.0 — 安装向导${NC}"
echo -e "${CYAN}════════════════════════════════════════════════════${NC}"
echo ""

# 1. 定位安装包根目录（脚本上一级）
SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
PKG_ROOT="$( cd "$SCRIPT_DIR/.." && pwd )"
SKILL_SRC="$PKG_ROOT/skill"
SAMPLE_SRC="$PKG_ROOT/sample-case"

if [ ! -d "$SKILL_SRC" ]; then
  echo -e "${RED}✗ 找不到 skill/ 目录，请确认安装包完整: $SKILL_SRC${NC}"
  exit 1
fi
echo -e "${GREEN}✓ 安装包: $PKG_ROOT${NC}"

# 2. 探测 Accio Work Agent 目录
ACCIO_ROOT="$HOME/.accio"
if [ ! -d "$ACCIO_ROOT" ]; then
  echo -e "${RED}✗ 找不到 ~/.accio 目录，请先安装 Accio Work 客户端${NC}"
  exit 1
fi

# 列出所有可选 Agent
echo ""
echo -e "${CYAN}扫描可用 Agent...${NC}"
AGENTS=()
while IFS= read -r line; do AGENTS+=("$line"); done < <(find "$ACCIO_ROOT/accounts" -maxdepth 4 -type d -name "agent-core" 2>/dev/null | sort)

if [ ${#AGENTS[@]} -eq 0 ]; then
  echo -e "${RED}✗ 未发现任何 Agent。请先在 Accio Work 中创建 Agent。${NC}"
  exit 1
fi

# 3. 让用户选 Agent
echo ""
echo -e "${CYAN}请选择安装到哪个 Agent:${NC}"
i=1
for a in "${AGENTS[@]}"; do
  ACC_ID=$(echo "$a" | sed -E 's|.*/accounts/([^/]+)/.*|\1|')
  AGT_ID=$(echo "$a" | sed -E 's|.*/agents/([^/]+)/.*|\1|')
  echo "  [$i] account=$ACC_ID  agent=$AGT_ID"
  i=$((i+1))
done
echo "  [a] 全部安装"
echo ""
read -r -p "输入序号或 a: " CHOICE

TARGETS=()
if [ "$CHOICE" = "a" ] || [ "$CHOICE" = "A" ]; then
  TARGETS=("${AGENTS[@]}")
else
  IDX=$((CHOICE-1))
  if [ "$IDX" -lt 0 ] || [ "$IDX" -ge "${#AGENTS[@]}" ]; then
    echo -e "${RED}✗ 无效选项${NC}"; exit 1
  fi
  TARGETS=("${AGENTS[$IDX]}")
fi

# 4. 询问是否一并复制 sample-case
INSTALL_SAMPLE="n"
if [ -d "$SAMPLE_SRC" ]; then
  echo ""
  read -r -p "是否一并复制太阳能路灯杆参考案例到 ~/Documents/${SKILL_ID}-sample/ ? [Y/n] " ANS
  ANS="${ANS:-Y}"
  if [ "$ANS" = "Y" ] || [ "$ANS" = "y" ]; then INSTALL_SAMPLE="y"; fi
fi

# 5. 执行安装
for AC in "${TARGETS[@]}"; do
  echo ""
  echo -e "${CYAN}── 安装到: $AC${NC}"
  SKILLS_DIR="$AC/skills"
  TARGET_SKILL="$SKILLS_DIR/$SKILL_ID"
  REGISTRY="$SKILLS_DIR/skills.jsonc"

  mkdir -p "$SKILLS_DIR"

  # 5a. 备份已有同名技能
  if [ -d "$TARGET_SKILL" ]; then
    BAK="${TARGET_SKILL}.bak.$(date +%Y%m%d-%H%M%S)"
    mv "$TARGET_SKILL" "$BAK"
    echo -e "${YELLOW}  ⚠ 已有同名技能，备份到: $BAK${NC}"
  fi

  # 5b. 复制
  cp -R "$SKILL_SRC" "$TARGET_SKILL"
  echo -e "${GREEN}  ✓ 技能文件已复制${NC}"

  # 5c. 注册到 skills.jsonc
  if [ ! -f "$REGISTRY" ]; then
    cat > "$REGISTRY" <<EOF
{
  "skills": [
    {
      "id": "$SKILL_ID",
      "name": "$SKILL_NAME",
      "path": "$SKILL_ID/SKILL.md",
      "description": "阿里巴巴国际站标题与卖点 AI 生成 — 6 阶段 Stage Gate 流程，4 SA 并行调研，R1-R7 反幻觉规则。",
      "enabled": true
    }
  ]
}
EOF
    echo -e "${GREEN}  ✓ 创建 skills.jsonc 并注册${NC}"
  else
    if grep -q "\"$SKILL_ID\"" "$REGISTRY"; then
      echo -e "${YELLOW}  ⚠ skills.jsonc 中已存在 $SKILL_ID，跳过注册（请手动检查）${NC}"
    else
      # 在最后一个 ] 之前插入注册项
      python3 - "$REGISTRY" "$SKILL_ID" "$SKILL_NAME" <<'PYEOF'
import json, re, sys, io
path, sid, sname = sys.argv[1], sys.argv[2], sys.argv[3]
with io.open(path, 'r', encoding='utf-8') as f:
    raw = f.read()
# 去除 // 行注释（JSONC → JSON）
stripped = re.sub(r'//[^\n]*', '', raw)
data = json.loads(stripped)
data.setdefault('skills', []).append({
    "id": sid,
    "name": sname,
    "path": f"{sid}/SKILL.md",
    "description": "阿里巴巴国际站标题与卖点 AI 生成 — 6 阶段 Stage Gate 流程，4 SA 并行调研，R1-R7 反幻觉规则。",
    "enabled": True
})
with io.open(path, 'w', encoding='utf-8') as f:
    f.write(json.dumps(data, ensure_ascii=False, indent=2))
PYEOF
      echo -e "${GREEN}  ✓ 已追加到 skills.jsonc${NC}"
    fi
  fi
done

# 6. 复制 sample-case
if [ "$INSTALL_SAMPLE" = "y" ]; then
  DEST="$HOME/Documents/${SKILL_ID}-sample"
  mkdir -p "$DEST"
  cp -R "$SAMPLE_SRC/." "$DEST/"
  echo ""
  echo -e "${GREEN}✓ 案例样板已复制到: $DEST${NC}"
fi

# 7. 完成
echo ""
echo -e "${CYAN}════════════════════════════════════════════════════${NC}"
echo -e "${GREEN}🎉 安装完成！${NC}"
echo -e "${CYAN}════════════════════════════════════════════════════${NC}"
echo ""
echo "下一步:"
echo "  1) 重启 Accio Work 客户端"
echo "  2) 对国际站生意助手说: 写 <商品名> 的标题和卖点"
echo "  3) 验证 Stage 1 是否弹出商家信息采集卡片"
echo ""
