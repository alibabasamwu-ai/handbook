# alibaba-title-bullet-generator · 一键安装脚本（Windows PowerShell）
# v1.0.0
# 用法: powershell -ExecutionPolicy Bypass -File .\INSTALL.ps1

$ErrorActionPreference = "Stop"
$SkillId   = "alibaba-title-bullet-generator"
$SkillName = "国际站标题卖点生成器"
$Desc      = "阿里巴巴国际站标题与卖点 AI 生成 — 6 阶段 Stage Gate 流程，4 SA 并行调研，R1-R7 反幻觉规则。"

Write-Host ""
Write-Host "════════════════════════════════════════════════════" -ForegroundColor Cyan
Write-Host "  $SkillName v1.0.0 — 安装向导" -ForegroundColor Cyan
Write-Host "════════════════════════════════════════════════════" -ForegroundColor Cyan
Write-Host ""

# 1. 定位安装包根目录
$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$PkgRoot   = Resolve-Path (Join-Path $ScriptDir "..")
$SkillSrc  = Join-Path $PkgRoot "skill"
$SampleSrc = Join-Path $PkgRoot "sample-case"

if (-not (Test-Path $SkillSrc)) {
    Write-Host "✗ 找不到 skill/ 目录: $SkillSrc" -ForegroundColor Red
    exit 1
}
Write-Host "✓ 安装包: $PkgRoot" -ForegroundColor Green

# 2. 探测 Accio Work
$AccioRoot = Join-Path $env:USERPROFILE ".accio"
if (-not (Test-Path $AccioRoot)) {
    Write-Host "✗ 找不到 $AccioRoot，请先安装 Accio Work 客户端" -ForegroundColor Red
    exit 1
}

# 3. 扫描 Agent
Write-Host ""
Write-Host "扫描可用 Agent..." -ForegroundColor Cyan
$Agents = Get-ChildItem -Path (Join-Path $AccioRoot "accounts") -Recurse -Directory -Depth 4 |
          Where-Object { $_.Name -eq "agent-core" } | Sort-Object FullName

if ($Agents.Count -eq 0) {
    Write-Host "✗ 未发现任何 Agent" -ForegroundColor Red
    exit 1
}

Write-Host ""
Write-Host "请选择安装到哪个 Agent:" -ForegroundColor Cyan
for ($i = 0; $i -lt $Agents.Count; $i++) {
    $p = $Agents[$i].FullName
    if ($p -match 'accounts[\\/]([^\\/]+)') { $accId = $Matches[1] } else { $accId = "?" }
    if ($p -match 'agents[\\/]([^\\/]+)')   { $agtId = $Matches[1] } else { $agtId = "?" }
    Write-Host ("  [{0}] account={1}  agent={2}" -f ($i+1), $accId, $agtId)
}
Write-Host "  [a] 全部安装"
Write-Host ""
$Choice = Read-Host "输入序号或 a"

if ($Choice -eq "a" -or $Choice -eq "A") {
    $Targets = $Agents
} else {
    $idx = [int]$Choice - 1
    if ($idx -lt 0 -or $idx -ge $Agents.Count) { Write-Host "✗ 无效选项" -ForegroundColor Red; exit 1 }
    $Targets = @($Agents[$idx])
}

# 4. 是否复制案例
$InstallSample = $false
if (Test-Path $SampleSrc) {
    Write-Host ""
    $Ans = Read-Host "是否一并复制太阳能路灯杆参考案例到 ~\Documents\$SkillId-sample\ ? [Y/n]"
    if ([string]::IsNullOrEmpty($Ans) -or $Ans -eq "Y" -or $Ans -eq "y") {
        $InstallSample = $true
    }
}

# 5. 执行安装
foreach ($a in $Targets) {
    Write-Host ""
    Write-Host ("── 安装到: " + $a.FullName) -ForegroundColor Cyan
    $SkillsDir   = Join-Path $a.FullName "skills"
    $TargetSkill = Join-Path $SkillsDir $SkillId
    $Registry    = Join-Path $SkillsDir "skills.jsonc"

    if (-not (Test-Path $SkillsDir)) { New-Item -ItemType Directory -Path $SkillsDir | Out-Null }

    # 5a. 备份
    if (Test-Path $TargetSkill) {
        $bak = "$TargetSkill.bak." + (Get-Date -Format "yyyyMMdd-HHmmss")
        Move-Item -Path $TargetSkill -Destination $bak
        Write-Host "  ⚠ 已有同名技能，备份到: $bak" -ForegroundColor Yellow
    }

    # 5b. 复制
    Copy-Item -Path $SkillSrc -Destination $TargetSkill -Recurse
    Write-Host "  ✓ 技能文件已复制" -ForegroundColor Green

    # 5c. 注册
    if (-not (Test-Path $Registry)) {
        $obj = @{ skills = @( @{ id = $SkillId; name = $SkillName; path = "$SkillId/SKILL.md"; description = $Desc; enabled = $true } ) }
        $obj | ConvertTo-Json -Depth 6 | Set-Content -Path $Registry -Encoding UTF8
        Write-Host "  ✓ 创建 skills.jsonc 并注册" -ForegroundColor Green
    } else {
        $raw = Get-Content $Registry -Raw -Encoding UTF8
        if ($raw -match "`"$SkillId`"") {
            Write-Host "  ⚠ skills.jsonc 中已存在 $SkillId，跳过注册" -ForegroundColor Yellow
        } else {
            # 去掉 // 注释后解析
            $stripped = [regex]::Replace($raw, "//[^`n]*", "")
            $obj = $stripped | ConvertFrom-Json
            if (-not $obj.skills) { $obj | Add-Member -NotePropertyName skills -NotePropertyValue @() }
            $obj.skills += [pscustomobject]@{
                id = $SkillId; name = $SkillName; path = "$SkillId/SKILL.md"; description = $Desc; enabled = $true
            }
            $obj | ConvertTo-Json -Depth 8 | Set-Content -Path $Registry -Encoding UTF8
            Write-Host "  ✓ 已追加到 skills.jsonc" -ForegroundColor Green
        }
    }
}

# 6. 复制 sample
if ($InstallSample) {
    $Dest = Join-Path $env:USERPROFILE "Documents\$SkillId-sample"
    if (-not (Test-Path $Dest)) { New-Item -ItemType Directory -Path $Dest | Out-Null }
    Copy-Item -Path (Join-Path $SampleSrc "*") -Destination $Dest -Recurse -Force
    Write-Host ""
    Write-Host "✓ 案例样板已复制到: $Dest" -ForegroundColor Green
}

# 7. 完成
Write-Host ""
Write-Host "════════════════════════════════════════════════════" -ForegroundColor Cyan
Write-Host "🎉 安装完成！" -ForegroundColor Green
Write-Host "════════════════════════════════════════════════════" -ForegroundColor Cyan
Write-Host ""
Write-Host "下一步:"
Write-Host "  1) 重启 Accio Work 客户端"
Write-Host "  2) 对国际站生意助手说: 写 <商品名> 的标题和卖点"
Write-Host "  3) 验证 Stage 1 是否弹出商家信息采集卡片"
Write-Host ""
