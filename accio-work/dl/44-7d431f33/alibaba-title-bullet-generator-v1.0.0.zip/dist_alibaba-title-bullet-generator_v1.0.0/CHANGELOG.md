# Changelog

## v1.0.0 — 2026-05-08

### 首次发布
- 6 阶段 Stage Gate 主流程（SKILL.md，411 行）
- R1-R7 反幻觉规则（CORE_RULES.md，193 行）
- 4 SA 完整 prompt 模板（templates/subagent-prompts.md）
- 10 套候选输出范式（templates/output-template.md）
- B2B 6 类营销钩子库（references/marketing-hooks.md）
- 国际站标题公式 + ≤128 字符规则（references/title-formula.md）
- 4 SA 数据源 + 降级路径说明（references/data-sources.md）

### 实战验证
- 太阳能路灯杆案例（sample-case/）— 4 SA 全部返回真实数据，10 套候选字符全部 103-116 ≤128
- Stage 3 审计五项检查全部通过（含 SA4 来源标签格式问题的有条件通过决策记录）

### 已知限制
- SA1 依赖 accio-mcp-cli 中的 buyer search keyword 类工具，工具不可用时降级 web_search 公开热词工具，质量下降明显
- SA2 Google Trends 在印尼/越南数据稀疏是真实情况，不是技能 bug
- SA4 抓 alibaba.com SERP 受平台反爬影响，建议浏览器已登录国际站账号
