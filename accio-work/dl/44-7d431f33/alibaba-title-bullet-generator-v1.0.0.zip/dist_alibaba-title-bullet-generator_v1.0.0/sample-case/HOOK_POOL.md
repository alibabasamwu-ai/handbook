# Stage 4 — 卖点要素六维拆解（HOOK_POOL）

> 数据来源：MERCHANT_BRIEF.md + RESEARCH_RAW/SA1-SA4 + references/marketing-hooks.md

## 维度 1：核心品类词（标题前 50 字符必出）

| 优先级 | 关键词 | 来源 | 用法 |
|--------|--------|------|------|
| 主 | solar light pole | [MCP: searchKeywordList] Top1 / [Google Trends: 全球 39] | 所有 10 套必带 |
| 主 | solar street light pole | [MCP] Top23 / 全球 9 | 长尾覆盖 |
| 副 | steel light pole / galvanized lamp pole | [MCP] Top24/25 | 材质强调用 |
| 副 | street light pole 6m / 9m / 10m | [MCP] Top6/9/11 | 参数堆叠用 |
| 蓝海 | smart street light pole | [MCP] Top14 印尼智慧城市 | 趋势热词型用 |
| 蓝海 | octagonal tapered pole | [MCP] Top12 越南 | 差异化型用 |
| 蓝海 | CCTV camera light pole | [MCP] Top17 | 一站式型用 |

## 维度 2：参数规格（嵌入标题中段）

| 参数 | 取值 | 来源 |
|------|------|------|
| 高度 | 3m / 6m / 8m / 9m / 10m / 12m | [MCP] + [Alibaba SERP: SA4 同行 Top10] |
| 材质 | Hot-Dip Galvanized Steel / Q235 / Q355 | [MCP Top3/18] + 商家原文 |
| 形态 | Round / Octagonal / Tapered / Conical / Polygonal / Double Arm | [MCP Top12/13/27/28/29] |
| 厚度 | 3-12mm 钢板（可定制） | 商家原文（MERCHANT_BRIEF） |

## 维度 3：商家硬实力（R7 强制 ≥2 项嵌入每套候选）

| 资质/认证 | 用途 | 来源 |
|----------|------|------|
| Manufacturer 自有工厂 | 信任钩子 | 商家原文 |
| 25-Year Warranty | **核心差异化**（同行 10-15 年）| 商家原文 + [Alibaba SERP: SA4 #10 仅15年] |
| ISO 9001 | 通用合规 | 商家原文 |
| EN40 / AASHTO | **欧美工程标准**（同行盲区）| 商家原文 |
| CE | EU 准入 | 商家原文 |
| Hot-Dip Galvanized | 防腐刚需（沿海市场） | 商家原文 + [Social: corrosion-resistant 4次] |
| One-Stop Solution | 灯杆+灯头+板整套 | 商家原文 |
| MOQ 10-20 pieces | 友好试单 | 商家原文 |
| 30-Day Delivery | 短交期 | 商家原文 |

## 维度 4：场景词（嵌入标题尾部 / 卖点中）

| 场景 | 来源 |
|------|------|
| for Highway | [Social: 3次] + [Alibaba SERP: SA4 #2/#3] |
| for Municipal Project / Urban Lighting | [Social: 5次] [MCP: 越南红绿灯项目] |
| for Parking Lot | [Social: 4次] |
| for Industrial Park | [Social: 2次] |
| for Coastal / Marine Area | [Social: 2次] [MCP: 菲律宾沿海] |
| for Government Project | 商家定位（EPC/Gov） |
| for Rural Village Electrification | [Social: 2次] [MCP: 越南] |

## 维度 5：买家痛点（卖点钩子）

| 痛点（社媒原文） | 我方解法 | 来源 |
|----------------|---------|------|
| "traditional metal poles susceptible to corrosion" | 热浸镀锌 + 25 年质保 | [Social: LinkedIn YUKUO] |
| "concrete anchors threading is jacked" | 加厚高强底座 + 防转膨胀螺栓 | [Social: Reddit DIY] |
| "installation procedure is complicated" | Pre-Wired 一站式发货，30 天到货 | [Social: Reddit solarenergy] + 商家原文 |
| "pole bent in storm / typhoon" | 抗风 ≥160km/h（同行参考）+ EN40 标准 | [Alibaba SERP: SA4 #1] |
| "buried lines safety hazard" | One-Stop Solution 整套预接线 | [Social: Reddit] + 商家原文 |

## 维度 6：差异化与同行盲区

| 我方独有 | 同行普遍 | 差距倍数 |
|---------|---------|---------|
| **25-Year Warranty** | 10-15 年（[Alibaba SERP: SA4 #10 仅15年]） | 1.7-2.5x |
| **EN40 / AASHTO 标准** | 仅 CE / ISO9001 | 欧美工程刚需差异 |
| **One-Stop Solution（杆+灯+板）** | 仅卖单杆 | 客单价 +30-50% |
| **价格优势** | 工厂直发 | 比中间商 -15-25% |

## 6 类风格 → 钩子组合（指导 Stage 5）

| 风格 | 主钩子 | 关键词组合 | 必带商家硬实力 |
|------|-------|-----------|---------------|
| 功能型 A（参数堆叠）| 信任 + 价格 | solar light pole + 高度参数 + 材质 | Manufacturer + Hot-Dip Galvanized |
| 功能型 B（品类驱动）| 信任 + 价格 | solar light pole + 认证 + Factory Price | EN40 + 25Y Warranty |
| 场景型 A（高速公路/市政）| 信任 + 效率 | Highway/Municipal + solar light pole + 抗风 | EN40 + 30-Day Delivery |
| 场景型 B（沿海防腐）| 差异化痛点 + 权威 | Coastal + Hot-Dip Galvanized + Anti-Corrosion | 25Y Warranty + ISO 9001 |
| 认证信任型 A（欧美合规）| 权威 + 合规 | EN40 + AASHTO + ISO + CE | Manufacturer + 25Y |
| 认证信任型 B（25年质保突围）| 权威 + 信任 | 25-Year Warranty + EN40 | Manufacturer + One-Stop |
| 价格 MOQ 型 | 价格 + 效率 | Factory Price + Low MOQ 10pcs + Manufacturer | Hot-Dip Galvanized + 30-Day |
| OEM/ODM 一站式型 | 信任 + 权威 | OEM/ODM + One-Stop + Custom Height | Manufacturer + EN40 |
| 痛点突围型（防腐/抗风）| 差异化 + 权威 | Anti-Corrosion + 25Y + Hot-Dip | EN40 + ISO 9001 |
| 趋势热词型（智慧城市/CCTV 一体化）| 稀缺 + 效率 | Smart Pole / CCTV-Integrated | Manufacturer + One-Stop |
