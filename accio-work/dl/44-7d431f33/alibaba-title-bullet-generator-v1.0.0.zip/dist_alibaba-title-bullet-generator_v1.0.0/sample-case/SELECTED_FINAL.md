# SELECTED_FINAL — 太阳能路灯杆主推文案

> 商家：Manufacturer / 25Y Warranty / EN40·AASHTO·ISO·CE / Hot-Dip Galvanized / One-Stop / MOQ 10-20 / 30-Day
> 目标市场：东南亚 EPC/Government（PH/ID/VN）
> 定稿时间：2026-05-08

---

## 🥇 主推 1 — 候选 #6 · 认证信任型 B（25 年质保突围）

### Title (107 chars)
```
25-Year Warranty Solar Light Pole EN40 Hot-Dip Galvanized 6m 8m 10m Galvanized Steel Lamp Pole Manufacturer
```

### Bullet Points
1. **Industry-Leading 25-Year Warranty** — Written structural warranty vs. typical 10-15 year competitor coverage on Alibaba — backed by manufacturer factory bond.
2. **EN40 Compliant Engineering** — Designed and tested to European EN40 standard for wind load, base bolt pattern, and pole thickness specification.
3. **Hot-Dip Galvanized Heavy-Duty Coating** — Coating thickness ≥85μm tested per ISO 1461; verified for SE Asia tropical climate corrosion resistance.
4. **Manufacturer Direct + Engineer Support** — Factory-employed lighting engineers handle CAD drawings, photometric design, and structural calculation requests.
5. **Quote-Ready in 24 Hours** — Send your project specs (height, arm type, location, quantity) — receive itemized quote with FOB / CIF / DDP options within one working day.

### Strategic Position
- **核心差异化武器**：25 年质保（同行 SA4 #10 仅 15 年，行业平均 10 年）
- **定位**：高合规、高决策标准的 EPC 项目方（菲律宾交通部 / 印尼 PUPR / 越南交通厅采购）
- **预期击中买家**：要求长期可靠性的政府工程 / 重资产分销商

### 发品建议
- **类目**：太阳能路灯杆 / Solar Light Pole 叶子类目
- **关键词覆盖（SA1）**：solar light pole(Top1) / galvanized light poles(Top4) / street light pole 6m(Top6) / 9m(Top11) / hot dip galvanized pole(Top3) — 5 词命中
- **图片建议**：第一张突出"25-Year Warranty"角标 + 工厂全景；细节图突出 ≥85μm 镀锌层显微图；场景图建议高速公路+市政道路实拍

---

## 🥈 主推 2 — 候选 #3 · 场景型 A（高速公路 / 市政）

### Title (107 chars)
```
Highway Municipal Solar Light Pole 6m 8m 10m Hot-Dip Galvanized Street Lamp Pole EN40 Manufacturer One-Stop
```

### Bullet Points
1. **Designed for Public Infrastructure** — Engineered for highway shoulders, urban arterial roads, intersection signal poles per EN40 wind-load specs (≥160 km/h reference).
2. **Government Tender Documentation** — Full submittal pack: EN40 / AASHTO compliance letter, ISO 9001 certificate, mill test report, CAD shop drawings.
3. **Hot-Dip Galvanized Surface** — Coating thickness ≥85μm for 25-year corrosion resistance; suits SE Asia tropical & coastal environments.
4. **One-Stop Project Supply** — Pole + solar panel + LED luminaire + foundation bolt kit shipped as one BOM, reducing project on-site assembly steps.
5. **MOQ 10pcs · 30-Day Delivery** — Friendly trial MOQ for new EPC distributors; serial production lead-time 30 days for 100-1000pc orders.

### Strategic Position
- **场景钩子**：直接对标"高速公路 / 市政道路"采购意图，避开纯 SKU 比价红海
- **定位**：菲律宾 DPWH / 越南市政道路改造 / 印尼地方政府智慧路灯标段
- **One-Stop 卖点**：把竞争从"卖单杆"提升到"项目方案"，避开 SA4 同行的纯杆价格战

### 发品建议
- **类目**：同 #6 一致
- **关键词覆盖（SA1）**：solar light pole(Top1) / street light pole 6m/9m / hot dip galvanized / led street light pole(Top8 隐含) — 4-5 词命中
- **图片建议**：第一张主图建议为政府/市政项目实拍 + 全套 BOM 装箱图；详情页加 EN40/AASHTO 证书页

---

## 📋 共用素材清单（两套通用）

### 资质证书图（详情页 P3-P4）
- ISO 9001:2015 证书扫描件
- EN40 测试报告封面
- AASHTO LTS-6 合规声明
- CE 证书

### 工厂图（详情页 P5-P6）
- 钢板切割车间
- 焊接车间
- 热浸镀锌池实拍（重点：镀锌层厚度量尺）
- 包装出库区

### 项目案例图（详情页 P7-P8）
- 至少 3 个 SE Asia 已交付项目实拍（远景 + 近景）
- 客户感谢信扫描件（如有）

### 价格区间建议（参考用，非定稿）
- 6m HDG 钢杆：FOB Ningbo USD 35-50 / pcs（参考 SA4 #1: USD 38.80-50.50）
- 8m HDG 钢杆：FOB Ningbo USD 50-75 / pcs
- 10m HDG 钢杆：FOB Ningbo USD 75-110 / pcs
- *实际报价请按客户具体规格、镀锌厚度、底盘类型调整*

---

## 🔍 R5 + R7 最终自检

| 候选 | 字符数 | ≤128 | Top1 词位置 | 商家硬实力 | 风控 |
|------|--------|------|-------------|----------|------|
| #6 | 107 | ✅ | char 22 ✅ | 25Y / EN40 / HDG / Manufacturer (4) | ✅ 无品牌词 |
| #3 | 107 | ✅ | char 20 ✅ | EN40 / HDG / One-Stop / MOQ / 30-Day (5) | ✅ 无品牌词 |

## 📌 后续建议

1. **A/B 测试**：建议 30 天后对比两套询盘转化数据，决定谁做主推 SKU
2. **季度迭代**：90 天后基于实际买家搜索词（卖家中心 → 词条分析）补充长尾
3. **配套素材**：建议同步用「**国际站图片素材生成工坊**」生成 6 图详情页位 + EN40 角标主图
4. **竞品监控**：每季度跑一次 SA4，看同行是否跟上 25 年质保（如跟上需重新差异化）

---

✅ Stage 6 完成 — 商品信息可直接进入国际站「商品发布」流程。
