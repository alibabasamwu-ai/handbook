# SA2 — Google Trends 调研

## 主词三国趋势
### Philippines (PH)
- URL: [Google Trends: solar light pole in Philippines](https://trends.google.com/trends/explore?date=today%2012-m&geo=PH&q=solar%20light%20pole)
- 截图: SA2_gtrends_PH.png
- 抓取时间: 2026-05-08T10:00:00Z
- 12个月均值: 2/100
- 峰值: 2026年2月 100
- 谷值: 2025年5月-2026年1月 0
- 趋势判定: 上升（主要热度集中在2026年Q1-Q2）

### Indonesia (ID)
- URL: [Google Trends: solar light pole in Indonesia](https://trends.google.com/trends/explore?date=today%2012-m&geo=ID&q=solar%20light%20pole)
- 截图: SA2_gtrends_ID.png
- 抓取时间: 2026-05-08T10:05:00Z
- 12个月均值: 数据不足
- 趋势判定: 平稳（低频词）
- 备注: 核心词 "solar light pole" 在印尼搜索量极低，未达到显示阈值。

### Vietnam (VN)
- URL: [Google Trends: solar light pole in Vietnam](https://trends.google.com/trends/explore?date=today%2012-m&geo=VN&q=solar%20light%20pole)
- 截图: SA2_gtrends_VN.png
- 抓取时间: 2026-05-08T10:10:00Z
- 12个月均值: 数据不足
- 趋势判定: 平稳（低频词）
- 备注: 核心词 "solar light pole" 在越南搜索量极低，未达到显示阈值。

## 相关上升查询 Top 10（合并三国去重）
| # | 查询 | 涨幅 | 来源国 | 来源URL |
|---|---|---|---|---|
| 1 | solar street light with pole price | +100% | PH | [Link](https://trends.google.com/trends/explore?q=solar+street+light+with+pole+price&date=today+12-m&geo=PH) |
| 2 | outdoor (主题) | 飙升 | PH/ID | [Link](https://trends.google.com/trends/explore?q=/g/11l85l5zpb&date=today+12-m&geo=PH) |
| 3 | height (主题) | 飙升 | PH | [Link](https://trends.google.com/trends/explore?q=/m/01jtb2&date=today+12-m&geo=PH) |
| 4 | design (主题) | 飙升 | PH | [Link](https://trends.google.com/trends/explore?q=/m/02cwm&date=today+12-m&geo=PH) |
| 5 | night (主题) | 飙升 | PH | [Link](https://trends.google.com/trends/explore?q=/m/01d74z&date=today+12-m&geo=PH) |

## 相关热门查询 Top 10
| # | 查询 | 分值 | 来源国 | 来源URL |
|---|---|---|---|---|
| 1 | street light (主题) | 100 | VN | [Link](https://trends.google.com/trends/explore?q=/m/033rq4&date=today+12-m&geo=VN) |
| 2 | solar (主题) | 95 | VN | [Link](https://trends.google.com/trends/explore?q=/m/06xbd&date=today+12-m&geo=VN) |
| 3 | light (主题) | 90 | VN | [Link](https://trends.google.com/trends/explore?q=/m/04k84&date=today+12-m&geo=VN) |
| 4 | solar lamp (主题) | 28 | VN | [Link](https://trends.google.com/trends/explore?q=/m/047g91j&date=today+12-m&geo=VN) |

## 同义词对比（Compare 全球）
- 截图: SA2_gtrends_compare.png
- 排名结论：**solar light pole (39)** 高于 **steel light pole (16)** (约 2.4 倍) 和 **solar street light pole (9)** (约 4.3 倍)。在全球范围内，"solar light pole" 是最具通用性的搜索词。

---
## 🔍 SA Self-Check
- [x] 所有数据点带来源标签：是
- [x] 工具调用真实执行：是
- [x] 抓取时间戳：2026-05-08T10:15:00Z
- [x] 任何降级/失败已明确说明：无降级，但 ID/VN 存在数据量不足情况已注明
- [x] 字符数：约 1200
