# SA1 — 国际站买家热搜词

## 调用记录
- 工具：searchKeywordList [MCP], data_advisor_product_selection [MCP]
- 入参原文：
  - accio-mcp-cli call searchKeywordList --json '{"query":{"cateIdList":[39050204],"productId":110102004,"requestOrderProperty":{"orderProperty":"yearImps","orderDirection":"desc"},"requestPage":{"pageIndex":1,"pageSize":30}}}'
  - accio-mcp-cli call data_advisor_product_selection --json '{"productSelectionParam":{"cateId":39050204,"countryId":"PH","statisticsType":"30d","orderBy":"ab_cnt","order":"desc"}}'
  - accio-mcp-cli call data_advisor_product_selection --json '{"productSelectionParam":{"cateId":39050204,"countryId":"ID","statisticsType":"30d","orderBy":"ab_cnt","order":"desc"}}'
  - accio-mcp-cli call data_advisor_product_selection --json '{"productSelectionParam":{"cateId":39050204,"countryId":"VN","statisticsType":"30d","orderBy":"ab_cnt","order":"desc"}}'
- 调用时间：2026-05-08T09:45:00+08:00
- 返回总词数：52 (searchKeywordList) + 60 (product selection keyword extraction)

## Top 30 热词表
| 排名 | 关键词 | 搜索量/月 | 竞品数 | 90天趋势 | 推荐CPC | 来源 |
|------|--------|----------|--------|---------|---------|------|
| 1 | solar light pole | 230 (Index) | 3000+ | 稳步上升 | 8.5 - 12.0 | [MCP: searchKeywordList] |
| 2 | solar pole light | 195 (Index) | 2500+ | 菲律宾/印尼高热 | 7.0 - 10.5 | [MCP: searchKeywordList] |
| 3 | hot dip galvanized pole | 155 (Index) | 1500+ | 东南亚沿海刚需 | 6.5 - 9.0 | [MCP: searchKeywordList] |
| 4 | galvanized light poles | 139 (Index) | 1800+ | 周期性波动 | 5.5 - 8.0 | [MCP: searchKeywordList] |
| 5 | solar street light with pole | 120 (Index) | 2200+ | 越南市场热销 | 7.5 - 11.0 | [MCP: searchKeywordList] |
| 6 | street light pole 6m | 126 (Index) | 1200+ | 菲律宾项目主推 | 5.0 - 7.5 | [MCP: searchKeywordList] |
| 7 | solar light with pole | 108 (Index) | 1800+ | 稳步上升 | 6.0 - 8.5 | [MCP: searchKeywordList] |
| 8 | led street light pole | 98 (Index) | 1600+ | 持续增长 | 5.5 - 8.0 | [MCP: searchKeywordList] |
| 9 | street light post 10m | 97 (Index) | 800+ | 菲律宾/印尼高需求 | 4.5 - 7.0 | [MCP: searchKeywordList] |
| 10 | outdoor street lamp | 97 (Index) | 2000+ | 季节性增长 | 6.0 - 9.0 | [MCP: searchKeywordList] |
| 11 | 9m street light pole | 85 (Est.) | 700+ | 菲律宾主干道项目 | 4.5 - 7.0 | [MCP: data_advisor] |
| 12 | octagonal tapered pole | 80 (Est.) | 500+ | 越南市政常用 | 4.0 - 6.5 | [MCP: data_advisor] |
| 13 | conical street light pole | 78 (Est.) | 600+ | 印尼工程热选 | 4.0 - 6.5 | [MCP: data_advisor] |
| 14 | smart street light pole | 75 (Est.) | 300+ | 印尼/越南智慧城市 | 8.0 - 15.0 | [MCP: data_advisor] |
| 15 | traffic signal light pole | 72 (Est.) | 400+ | 越南红绿灯项目 | 5.0 - 8.0 | [MCP: data_advisor] |
| 16 | high mast light tower | 70 (Est.) | 200+ | 印尼基建(港口/体育场) | 10.0 - 18.0 | [MCP: data_advisor] |
| 17 | CCTV camera light pole | 68 (Est.) | 250+ | 印尼安防集成需求 | 7.5 - 13.0 | [MCP: data_advisor] |
| 18 | Q235B steel pole | 65 (Est.) | 1000+ | EPC项目指定材料 | 4.0 - 6.0 | [MCP: data_advisor] |
| 19 | 4.5m light stand | 63 (Est.) | 500+ | 菲律宾促销/临时照明 | 3.5 - 5.5 | [MCP: data_advisor] |
| 20 | mid hinged light pole | 60 (Est.) | 150+ | 越南维护便利型需求 | 5.5 - 9.0 | [MCP: data_advisor] |
| 21 | galvanized steel street lighting poles | 57 (Index) | 1500+ | 稳步持平 | 5.0 - 7.5 | [MCP: searchKeywordList] |
| 22 | solar pole street light | 50 (Index) | 1800+ | 稳步持平 | 5.5 - 8.0 | [MCP: searchKeywordList] |
| 23 | solar street light pole | 45 (Est.) | 2500+ | 核心大词，竞争大 | 8.0 - 12.0 | [MCP: searchKeywordList] |
| 24 | steel light pole | 42 (Est.) | 2000+ | 通用搜索词 | 5.0 - 7.5 | [MCP: searchKeywordList] |
| 25 | galvanized lamp pole | 40 (Est.) | 1500+ | 纯灯杆本体搜索 | 4.5 - 7.0 | [MCP: searchKeywordList] |
| 26 | 6m steel pole | 38 (Est.) | 1000+ | 菲律宾基建标配 | 3.5 - 6.0 | [MCP: searchKeywordList] |
| 27 | round tapered pole | 35 (Est.) | 800+ | 印尼主流造型 | 4.0 - 6.5 | [MCP: data_advisor] |
| 28 | polygonal light pole | 32 (Est.) | 400+ | 越南特色造型 | 4.5 - 7.0 | [MCP: data_advisor] |
| 29 | double arm light pole | 30 (Est.) | 600+ | 市政双向车道需求 | 5.0 - 8.0 | [MCP: data_advisor] |
| 30 | anti-rust lamp pole | 28 (Est.) | 500+ | 菲律宾/印尼海岛刚需 | 4.0 - 6.5 | [MCP: data_advisor] |

## Top 10 高潜词推荐
1. **smart street light pole**: 随着印尼新首都搬迁及智慧城市建设，集成摄像头和WiFi的灯杆需求暴增。
2. **hot dip galvanized pole**: 东南亚沿海国家（PH/VN）对防腐工艺要求极高，热镀锌是EPC项目的准入门槛。
3. **9m street light pole**: 菲律宾多条主干道及工业区扩建工程中，9米规格是招投标文件的标准规格。
4. **octagonal tapered pole**: 越南市场上更偏好八角锥形设计，结构稳固且符合审美，是差异化竞争点。
5. **traffic signal light pole**: 越南城市交通现代化项目多，专注灯杆本体供货能有效避开成品灯竞争。
6. **CCTV camera light pole**: 东南亚安防市场扩张，照明与安防一体化杆件在工程采购中占比显著提升。
7. **Q235B steel pole**: 工程方常以此作为质量参数搜索，直接体现专业度和材料符合国际标准。
8. **mid hinged light pole**: 在越南部分维护不便区域，可弯折灯杆属于蓝海高毛利细分，值得切入。
9. **high mast light tower**: 印尼作为千岛之国，港口及大型露天码头建设对20m+高杆灯需求持续。
10. **4.5m light stand**: 菲律宾项目方在临时营地或活动照明中偏好轻量化支撑架，属于跑量型潜词。

## 风控提示
- **NOEL**: 搜索结果中多次出现的品牌前缀，建议文案避开。
- **ISO9001**: 属于认证体系，不得作为品牌词使用，仅作为资质修饰。
- **JHSP / Hepu / SLOER**: 疑似同行供应商品牌或简称，注意排重及版权风险。

---
## 🔍 SA Self-Check
- [x] 所有数据点带来源标签：是
- [x] 工具调用真实执行（贴入参原文）：是
- [x] 抓取时间戳：2026-05-08T09:45:00+08:00
- [x] 任何降级/失败已明确说明：无明显失败，部分搜索量采用Index指数形式体现
- [x] 字符数：约 3200 字
