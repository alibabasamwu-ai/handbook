# alibaba-title-bullet-generator · v1.0.0

> 阿里巴巴国际站「标题 + 卖点」AI 生成技能 — 6 阶段 Stage Gate · R1-R7 反幻觉规则 · 4 SA 并行调研

## ✨ 这个技能能干什么

输入一个国际站商品（产品名/类目/产品图），输出 **10 套候选标题 + 5 条 bullet 卖点**，覆盖 6 种营销风格（功能/场景/认证/价格 MOQ/OEM/痛点突围/趋势热词），每套标题 ≤128 字符、嵌入 ≥2 项商家硬实力，全部数据点带来源标签可追溯。

适用场景：
- 新品发品的标题/卖点起稿
- 老 SKU 标题诊断与改写
- 同行 Top10 竞品反推 + 我方差异化定位
- EPC/政府工程类 B2B 长决策周期场景

## 📦 安装包结构

```
alibaba-title-bullet-generator-v1.0.0/
├── README.md                       ← 本文件
├── CHANGELOG.md                    ← 版本变更
├── skill/                          ← 技能本体（必装）
│   ├── SKILL.md                    ← 6 阶段 Stage Gate 主流程
│   ├── CORE_RULES.md               ← R1-R7 反幻觉规则
│   ├── templates/
│   │   ├── subagent-prompts.md     ← 4 个 SA 完整 prompt 模板
│   │   └── output-template.md      ← 10 套候选输出范式
│   └── references/
│       ├── marketing-hooks.md      ← B2B 6 类营销钩子库
│       ├── title-formula.md        ← 国际站标题公式 + ≤128 字符规则
│       └── data-sources.md         ← 4 SA 数据源 + 降级路径
├── sample-case/                    ← 完整参考案例（可选，强烈建议保留）
│   ├── MERCHANT_BRIEF.md           ← Stage 1 商家信息
│   ├── RESEARCH_RAW/               ← Stage 2 四 SA 原始调研产出
│   ├── AUDIT_LOG.md                ← Stage 3 审计日志
│   ├── HOOK_POOL.md                ← Stage 4 钩子库
│   ├── CANDIDATES_10.md            ← Stage 5 十套候选
│   └── SELECTED_FINAL.md           ← Stage 6 主推定稿
└── install/                        ← 安装脚本
    ├── INSTALL.sh                  ← macOS / Linux 一键装
    ├── INSTALL.ps1                 ← Windows PowerShell
    └── skill-registry-snippet.jsonc ← 手动注册片段
```

## 🚀 快速安装

### 方式 1：一键脚本（推荐）

**macOS / Linux：**
```bash
cd alibaba-title-bullet-generator-v1.0.0/install
bash INSTALL.sh
```

**Windows：**
```powershell
cd alibaba-title-bullet-generator-v1.0.0\install
powershell -ExecutionPolicy Bypass -File .\INSTALL.ps1
```

> 脚本会自动：
> 1. 把 `skill/` 复制到 `~/.accio/accounts/<accountId>/agents/<agentId>/agent-core/skills/alibaba-title-bullet-generator/`（账号/Agent 由脚本交互式询问或自动探测）
> 2. 把 `alibaba-title-bullet-generator` 注册到该 Agent 的 `skills.jsonc`
> 3. 提示用户重启 Accio Work 客户端

### 方式 2：手动安装

1. 把 `skill/` 整个目录复制到目标 Agent 的 `agent-core/skills/alibaba-title-bullet-generator/` 下
2. 编辑同目录的 `skills.jsonc`，参考 `install/skill-registry-snippet.jsonc` 追加注册项
3. 重启 Accio Work 客户端

## ✅ 安装成功验证

启动 Accio Work，对国际站生意助手说：
```
帮我用 国际站标题卖点生成器 写 <商品名> 的标题和卖点
```

或更简短：
```
写 <商品名> 的标题
```

如果 Agent 进入「Stage 1 商家信息采集」并弹出 ask_user 卡片询问商家资质/认证/差异化 — 安装成功。

## 📚 完整流程示例

参考 [sample-case/](sample-case/) — 太阳能路灯杆的完整 6 阶段产出：

| Stage | 文件 | 说明 |
|-------|------|------|
| 1 | MERCHANT_BRIEF.md | 商家信息采集结果 |
| 2 | RESEARCH_RAW/SA1-SA4 | 4 SA 并行调研原文 + 截图 |
| 3 | AUDIT_LOG.md | 主 Agent 五项审计日志 |
| 4 | HOOK_POOL.md | 6 维卖点要素拆解 |
| 5 | CANDIDATES_10.md | 10 套候选（每套带元数据 + 关键词覆盖矩阵） |
| 6 | SELECTED_FINAL.md | 主推定稿（带发品建议） |

阅读这套案例可以帮你理解：
- 主 Agent 该怎么调用 4 SA、怎么审计、怎么避免幻觉
- 10 套候选不同风格之间的实际差异
- 同行 Top10 反推怎么变成自己的差异化武器

## 🔒 反幻觉规则（R1-R7）

技能内置 7 条硬规则，详见 [skill/CORE_RULES.md](skill/CORE_RULES.md)：

| 规则 | 说明 |
|------|------|
| R1 | 每条精确数字必须紧邻来源标签 `[MCP: ...]` / `[Google Trends: <URL>]` 等 |
| R2 | 每个 SA 文件末尾必须有 Self-Check 块 |
| R3 | 4 SA 必须并行 spawn（同回复内）|
| R4 | 每套候选必须列出 SA1 关键词覆盖矩阵 |
| R5 | 标题 ≤128 字符，禁 emoji / 全大写 / 绝对化用语 / 未授权品牌词 |
| R6 | Stage 3 主 Agent 五项审计：实存 / 字符数 / 来源密度 / 自检块 / 红线扫描 |
| R7 | 每套候选必须嵌入 ≥2 项商家硬实力（资质/认证/差异化/MOQ） |

## 🆘 常见问题

**Q：安装脚本找不到我的 Agent 目录？**
A：脚本默认扫描 `~/.accio/accounts/*/agents/*/agent-core/`。如果你的 Accio Work 安装在非默认路径，手动按「方式 2」安装。

**Q：装完后调用技能没反应？**
A：检查 `agent-core/skills/skills.jsonc` 是否有 `alibaba-title-bullet-generator` 这个 id。不在的话用 `install/skill-registry-snippet.jsonc` 手动追加，重启客户端。

**Q：4 个 SA 必须并行？我能不能只跑 2 个？**
A：技能设计上是 4 SA（国际站 MCP / Google Trends / 社媒 / 同行）。少跑一个，HOOK_POOL 的维度就缺一块、最终候选质量下降。如确实想精简，建议保留 SA1（MCP 热词）+ SA4（同行反推），这两个对发品最关键。

**Q：sample-case 可以删吗？**
A：可以，删掉不影响技能运行。但保留可以帮助技能首次调用时的 Stage 5 输出参考真实样板，质量更稳定。

## 📜 License & 反馈

- License: 内部分发，请勿对外公开
- 反馈：把 bug / 改进建议发到原作者
