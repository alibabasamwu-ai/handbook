# GE-01 知识库标杆骨架（脱敏自太阳能照明类）

## 目录树（必须达到的最小结构）

```
{Brand}_KB_2026/
├── README.md
├── INDEX.md                          # 全库索引（必有）
├── _meta/
│   ├── kb_version.json
│   └── change_log.md
├── KB_PUBLIC/                        # 对外可见（接入 Accio Work 生意助手内部检索）
│   ├── 01_company/                   # 7 篇起
│   │   ├── about_us_EN.md
│   │   ├── about_us_ZH.md
│   │   ├── factory_overview.md
│   │   ├── certifications.md
│   │   ├── team.md
│   │   ├── milestones.md
│   │   └── contact.md
│   ├── 02_products/                  # 每 SKU 1 篇，≥ 20 篇
│   │   ├── _category_index.md
│   │   ├── {sku-1}_EN.md
│   │   └── ...
│   ├── 03_solutions/                 # 行业方案 ≥ 5 篇
│   │   ├── EPC_solar_street_light.md
│   │   ├── government_lighting.md
│   │   └── ...
│   ├── 04_faq/                       # ≥ 30 条
│   │   ├── pre_sales_FAQ.md
│   │   ├── shipping_FAQ.md
│   │   ├── warranty_FAQ.md
│   │   └── after_sales_FAQ.md
│   ├── 05_policies/                  # 售前售后政策 ≥ 8 篇
│   │   ├── moq_policy.md
│   │   ├── price_policy.md
│   │   ├── shipping_policy.md
│   │   ├── warranty_5year.md
│   │   ├── return_policy.md
│   │   └── oem_odm_policy.md
│   ├── 06_marketing/                 # 营销素材 ≥ 12 篇（与 image-marketing-studio 联动）
│   │   ├── catalog_cover.md
│   │   ├── usp_poster.md
│   │   └── ...
│   └── 07_cases/                     # 项目案例 ≥ 6 篇
│       └── ...
└── KB_INTERNAL/                      # 仅商家内部 — 严禁外传
    ├── 01_pricing/                   # 含底价
    ├── 02_supplier/
    ├── 03_competitor/
    └── 04_sop/
        ├── 询盘接待SOP.md
        ├── 三轮报价SOP.md
        └── 拒付申诉SOP.md
```

## 单篇 .md 必备字段（frontmatter）

```yaml
---
lang: EN
category: products
subcategory: solar_street_light
sku: {sku}
last_updated: 2026-05-07
source: MCP_pull / merchant_upload  # 必填
visibility: public                    # public | internal
---
```

## 单篇正文最小结构

1. H1 标题（产品名/政策名）
2. 1 段 100 字以上摘要
3. 至少 1 个表格（参数表/对比表）
4. 至少 1 个列表（卖点/步骤/条款）
5. CTA 段落（针对外销文档）
6. 来源/版本注脚

## 评分预期

- 完整性 18/20
- 真实性 19/20（前提是数据来自 MCP）
- 可检索性 17/20
- 实用性 17/20
- 一致性 17/20
- **总分 ~88/100（合格）**
