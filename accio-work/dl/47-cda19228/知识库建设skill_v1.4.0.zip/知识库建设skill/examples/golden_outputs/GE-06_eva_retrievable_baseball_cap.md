# GE-06 · EVA 可抓取知识库样例（Baseball Cap · 真实问题复现）

> 用途：示范 v1.3.0「100% 可抓取 7 铁律」如何把"EVA 抓不到"的内容改成"必抓到"。
> 复现的真实问题：买家问 `what is the moq of baseball cap`，旧 KB 抓不到。
> 下方每条均可直接上传到 MA 后台对应模块。

---

## ❌ 反例（旧写法 — EVA 抓不到，违反 R-E2 + R-E3）

```markdown
# MOQ
MOQ: 详谈，具体见详情页。
```
违规点：①无产品主体(R-E2) ②占位符"详谈/见详情页"被 EVA 判为空值(R-E3) ③无 Keywords ④无结构化。

---

## ✅ 正例（新写法 — EVA 必抓到）

### 文件 1 — 模块 06_payment（交易付款）/ moq_baseball_cap.md

```markdown
---
title: "What is the MOQ of baseball cap? / 棒球帽最小起订量是多少？"
product_subject: ["Baseball Cap", "鸭舌帽", "sports cap", "trucker cap"]
module: "06_payment"
keywords: [MOQ, minimum order quantity, 最小起订量, baseball cap, cap]
last_updated: 2026-06-02
source: "[商家确认]"
---

## Q: What is the MOQ of baseball cap? (棒球帽的最小起订量是多少？)

**A:** The MOQ for **baseball caps (鸭舌帽 / sports caps / trucker caps)** depends on order type:

| Order Type | MOQ | Notes |
|-----------|-----|-------|
| Ready-to-ship (现货) | 10 pcs | Stock colors only |
| Standard custom (标准定制) | 100 pcs | Your logo + color choice |
| Full custom (全定制) | 500 pcs | Custom fabric & design |

Samples are available before bulk production. (可先打样确认再下大货。)

**Keywords:** MOQ, minimum order quantity, 最小起订量, 最少订多少, baseball cap, cap, 鸭舌帽, trucker cap

➡️ Tell us your target quantity and logo — we'll send a quote within 12 hours.
```

### 文件 2 — 模块 02_product_info（产品信息）/ customization_baseball_cap.md

```markdown
---
title: "Can you customize baseball caps with my logo? / 棒球帽能定制logo吗？"
product_subject: ["Baseball Cap", "鸭舌帽", "custom cap"]
module: "02_product_info"
keywords: [custom logo, embroidery, printing, OEM, 定制, baseball cap]
last_updated: 2026-06-02
source: "[商家确认]"
---

## Q: Can you customize baseball caps with my logo? (棒球帽可以定制我的logo吗？)

**A:** Yes. We customize **baseball caps (鸭舌帽 / custom caps)** in 3 ways:

| Method | Best For | MOQ |
|--------|----------|-----|
| 3D Embroidery (立体绣) | Premium logo, durable | 100 pcs |
| Flat Embroidery (平绣) | Standard logo | 100 pcs |
| Heat-transfer Print (烫印) | Full-color / gradient logo | 100 pcs |

Free digital mockup before production. (生产前免费出效果图。)

**Keywords:** custom logo, OEM, embroidery, printing, 定制, 刺绣, 烫印, baseball cap, cap

➡️ Send your logo file (AI/PNG) and we'll make a free mockup.
```

---

## 上传后自检（商家可照做）
1. 等 5–15 分钟向量化生效。
2. 后台"知识库效果评估"用 `what is the moq of baseball cap` 模拟提问。
3. 若仍抓不到 → 检查是否误传到内部模块 / 是否仍有占位符 / 产品主体名是否与 listing 一致。
