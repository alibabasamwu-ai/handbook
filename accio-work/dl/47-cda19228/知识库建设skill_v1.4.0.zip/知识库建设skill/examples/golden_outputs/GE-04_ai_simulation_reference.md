# GE-04 应答模拟标杆

> Stage 4 必参考此结构。**必须 ≥ 10 条**典型问题，每个回答能定位 KB 文件。

## 模拟问题清单（≥ 10 条，覆盖 5 大类）

### 类目 A — 公司/资质（≥ 2 条）
- Q1: How long has your company been in business?
  - **Answer source**: KB_PUBLIC/01_company/about_us_EN.md L12-15
  - Answer (3-5 句)
- Q2: What certifications do you have?
  - Source: KB_PUBLIC/01_company/certifications.md

### 类目 B — 产品/规格（≥ 3 条）
- Q3: Do you have IP65 outdoor solar lights?
  - Source: KB_PUBLIC/02_products/_category_index.md
- Q4: What's the wattage range you offer?
- Q5: Can you do OEM with our logo?

### 类目 C — 价格/MOQ（≥ 2 条）
- Q6: What's your MOQ?
  - Source: KB_PUBLIC/05_policies/moq_policy.md
- Q7: Can I get a 5% discount for 1000 pcs?
  - Source: KB_INTERNAL/01_pricing/* （内部参考，外答用 PUBLIC moq_policy）

### 类目 D — 物流/交期（≥ 2 条）
- Q8: How long is your lead time?
- Q9: Do you ship to South Africa?

### 类目 E — 售后/质保（≥ 1 条）
- Q10: What's your warranty terms?
  - Source: KB_PUBLIC/05_policies/warranty_5year.md

## 评分硬指标

- 兜底回答（无答案/转人工）≤ 2 条 → 否则回 Stage 3 补内容
- 每条回答必须有 source 字段指向 KB 文件 + 行号
- 回答不超过 5 句（B2B 客户偏好简洁）

## Out-of-Scope 上报模板

如果模拟中发现某类高频问题 KB 完全没覆盖：
```
[KNOWLEDGE_GAP] category=shipping question="customs clearance for Russia" 
priority=P0 suggestion="补 KB_PUBLIC/05_policies/customs_RU.md"
```
