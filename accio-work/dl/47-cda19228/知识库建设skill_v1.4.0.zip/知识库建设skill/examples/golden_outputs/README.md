# Golden Outputs — 标准产出参考库

> **目的**：把 Ray 在 ACW 上反复打磨过的"标准答案"打包进 skill，让任何商家在任何电脑首次安装即可对齐到同一品质水位。
> **使用**：每个 sub-agent 在生成前必须 `read` 对应类型的 golden example，按其结构与深度对齐。

## 案例索引

| ID | 类目 | 适用商家类型 | 文件 |
|----|------|-----------|------|
| GE-01 | 知识库交付包 | 太阳能照明类（XINTONG 脱敏） | [GE-01_solar_kb_skeleton.md](GE-01_solar_kb_skeleton.md) |
| GE-02 | 品牌战略文档 | 海洋/工业类（HATA 脱敏） | [GE-02_brand_strategy_skeleton.md](GE-02_brand_strategy_skeleton.md) |
| GE-03 | Catalog PDF 标杆 | 通用 B2B 制造业 | [GE-03_catalog_pdf_reference.md](GE-03_catalog_pdf_reference.md) |
| GE-04 | 应答模拟标杆 | 通用询盘场景 | [GE-04_ai_simulation_reference.md](GE-04_ai_simulation_reference.md) |
| GE-05 | 评分报告范例 | 全类目通用 | [GE-05_scoring_report_sample.md](GE-05_scoring_report_sample.md) |

## 一致性强制规则

任何 sub-agent 输出前必须自问：
1. 我的目录树结构与对应 GE 相似度 ≥ 80%？
2. 我的字段深度（表格列数 / 列表项数）与 GE 一致？
3. 我的可视化（表格/卡片/分级标签）数量 ≥ GE 的 80%？

3 项任一为否 → 重写。

## 脱敏说明

所有 GE 已剔除真实品牌名、SKU、订单号、姓名；保留结构、字段、深度、表格列定义供模仿。
