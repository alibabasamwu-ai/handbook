#!/bin/bash
# ============================================================================
# 国际站 AI 知识库生成器 — 一键安装脚本（macOS / Linux）
# 版本: v1.2.0
#
# ▼ 推荐用法（终端复制粘贴一行即可，无需 cd / chmod）
#    bash "/path/to/alibaba-knowledge-base-builder/INSTALL.sh"
#
# ▼ 行为
#   1. 自动检测 ACW 安装 + 自动选最近活跃账号
#   2. 自动识别"国际站生意助手"agent（扫描 agent-core/IDENTITY.md / SOUL.md / USER.md
#      含"国际站生意助手"或"Alibaba Business Assistant"关键字），多个匹配全装
#   3. 装到 agent-core/skills/{skillName}/（ACW 真实加载位置）
#   4. 自动注册 skills.jsonc（用内嵌 Python 反序列化更新，保留其他记录 + 备份）
#   5. 自动清理已弃用的 alibaba-prelaunch-kb-builder 记录和文件
#   6. 备份所有受影响文件到 .bak.{时间戳}
# ============================================================================

set -euo pipefail

# ----- 颜色（终端不支持时自动降级）-----
if [ -t 1 ]; then
  RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; BLUE='\033[0;34m'; NC='\033[0m'
else
  RED=''; GREEN=''; YELLOW=''; BLUE=''; NC=''
fi

SKILL_NAME="alibaba-knowledge-base-builder"
SKILL_DISPLAY_NAME="知识库建设"
DEPRECATED_SKILL="alibaba-prelaunch-kb-builder"
SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
TS=$(date +%Y%m%d_%H%M%S)

# 解析旗标
INTERACTIVE=0
INSTALL_ALL=0
for arg in "$@"; do
  case "$arg" in
    --interactive|-i) INTERACTIVE=1 ;;
    --yes|-y) INTERACTIVE=0 ;;
    --all-agents) INSTALL_ALL=1 ;;
    --help|-h)
      grep '^#' "$0" | head -25 | sed 's/^# \{0,1\}//'
      exit 0
      ;;
  esac
done

echo -e "${BLUE}=========================================${NC}"
echo -e "${BLUE} 国际站 AI 知识库生成器 — 安装程序${NC}"
echo -e "${BLUE} 版本: v1.2.0 (Catalog PDF + 装到 agent-core)${NC}"
echo -e "${BLUE}=========================================${NC}"
echo ""

# ============================================================================
# Step 1: 校验 Skill 包完整性
# ============================================================================
echo -e "${BLUE}[1/6] 检查 Skill 包完整性...${NC}"

REQUIRED_FILES=("SKILL.md" "VERSION" "orchestrator" "agents" "templates" "references")
for f in "${REQUIRED_FILES[@]}"; do
  if [ ! -e "$SCRIPT_DIR/$f" ]; then
    echo -e "${RED}❌ 缺失必需文件/目录: $f${NC}"
    echo -e "${RED}   请确认 INSTALL.sh 跟 SKILL.md 在同一个目录里（zip 解压完整）${NC}"
    exit 1
  fi
done

VERSION=$(cat "$SCRIPT_DIR/VERSION" | tr -d '[:space:]')
FILE_COUNT=$(find "$SCRIPT_DIR" -type f | wc -l | tr -d '[:space:]')
echo -e "${GREEN}✅ Skill 包完整 (待装版本 ${VERSION}, ${FILE_COUNT} 个文件)${NC}"
echo ""

# ============================================================================
# Step 2: 检测 Accio Work + Python3
# ============================================================================
echo -e "${BLUE}[2/6] 检测 Accio Work 和依赖...${NC}"

ACCIO_DIR="$HOME/.accio"
if [ ! -d "$ACCIO_DIR" ]; then
  echo -e "${RED}❌ 未找到 Accio Work 目录: $ACCIO_DIR${NC}"
  echo -e "${YELLOW}   请先安装 Accio Work：https://www.accio.com${NC}"
  echo -e "${YELLOW}   安装后启动一次（让它创建配置目录），再跑本脚本。${NC}"
  exit 1
fi

if [ ! -d "$ACCIO_DIR/accounts" ]; then
  echo -e "${RED}❌ 未找到 accounts 目录: $ACCIO_DIR/accounts${NC}"
  echo -e "${YELLOW}   请先打开 Accio Work 至少一次并登录账号。${NC}"
  exit 1
fi

# Python3 — macOS / Linux 都自带
if ! command -v python3 &>/dev/null; then
  echo -e "${RED}❌ 未找到 python3（用于解析 skills.jsonc）${NC}"
  echo -e "${YELLOW}   macOS: 系统应自带；如缺失运行 'xcode-select --install'${NC}"
  echo -e "${YELLOW}   Linux: apt install python3 / yum install python3${NC}"
  exit 1
fi

echo -e "${GREEN}✅ Accio Work 已安装 + python3 可用${NC}"
echo ""

# ============================================================================
# Step 3: 选择账号 ID
# ============================================================================
echo -e "${BLUE}[3/6] 选择目标账号...${NC}"

ACCOUNTS=()
while IFS= read -r line; do
  [ -n "$line" ] && ACCOUNTS+=("$line")
done < <(ls "$ACCIO_DIR/accounts/" 2>/dev/null)

if [ ${#ACCOUNTS[@]} -eq 0 ]; then
  echo -e "${RED}❌ 未找到任何账号。请先在 Accio Work 中登录一个账号。${NC}"
  exit 1
elif [ ${#ACCOUNTS[@]} -eq 1 ]; then
  ACCOUNT_ID="${ACCOUNTS[0]}"
  echo -e "${GREEN}✅ 检测到唯一账号: ${ACCOUNT_ID}${NC}"
else
  if [ "$INTERACTIVE" = "1" ] && [ -t 0 ]; then
    echo "检测到多个账号，请选择要安装到哪一个："
    for i in "${!ACCOUNTS[@]}"; do
      echo "  [$((i+1))] ${ACCOUNTS[$i]}"
    done
    read -p "输入序号 (1-${#ACCOUNTS[@]}): " CHOICE
    if ! [[ "$CHOICE" =~ ^[0-9]+$ ]] || [ "$CHOICE" -lt 1 ] || [ "$CHOICE" -gt ${#ACCOUNTS[@]} ]; then
      echo -e "${RED}❌ 无效选择。退出。${NC}"
      exit 1
    fi
    ACCOUNT_ID="${ACCOUNTS[$((CHOICE-1))]}"
  else
    ACCOUNT_ID=$(ls -t "$ACCIO_DIR/accounts/" | head -1)
    echo -e "${YELLOW}⚠️  检测到多个账号，自动选最近活跃: ${ACCOUNT_ID}${NC}"
    echo -e "${YELLOW}   如想换账号，请用 \`bash INSTALL.sh --interactive\` 重跑${NC}"
  fi
  echo -e "${GREEN}✅ 选定账号: ${ACCOUNT_ID}${NC}"
fi
echo ""

# ============================================================================
# Step 4: 识别 "国际站生意助手" agent（多 agent 场景）
# ============================================================================
echo -e "${BLUE}[4/6] 识别国际站生意助手 agent...${NC}"

AGENTS_DIR="$ACCIO_DIR/accounts/$ACCOUNT_ID/agents"
if [ ! -d "$AGENTS_DIR" ]; then
  echo -e "${RED}❌ 未找到 agents 目录: $AGENTS_DIR${NC}"
  echo -e "${YELLOW}   请先在 Accio Work 中至少打开一次"国际站生意助手"${NC}"
  exit 1
fi

# 扫描 agent-core 下识别 "国际站生意助手" 关键字
TARGET_AGENTS=()
ALL_AGENTS=()
KEYWORDS=("国际站生意助手" "Alibaba Business Assistant" "alibaba-com-seller-assistant")

for agent_path in "$AGENTS_DIR"/*/; do
  [ -d "$agent_path" ] || continue
  agent_id=$(basename "$agent_path")
  ALL_AGENTS+=("$agent_id")

  core_dir="${agent_path}agent-core"
  [ -d "$core_dir" ] || continue

  # 扫描 IDENTITY.md / SOUL.md / USER.md
  matched=0
  for f in IDENTITY.md SOUL.md USER.md MEMORY.md; do
    [ -f "$core_dir/$f" ] || continue
    for kw in "${KEYWORDS[@]}"; do
      if grep -q "$kw" "$core_dir/$f" 2>/dev/null; then
        matched=1
        break 2
      fi
    done
  done

  if [ "$matched" = "1" ]; then
    TARGET_AGENTS+=("$agent_id")
  fi
done

# 决策逻辑
if [ "$INSTALL_ALL" = "1" ]; then
  echo -e "${YELLOW}⚠️  --all-agents 模式：装到全部 ${#ALL_AGENTS[@]} 个 agent${NC}"
  TARGET_AGENTS=("${ALL_AGENTS[@]}")
elif [ ${#TARGET_AGENTS[@]} -eq 0 ]; then
  echo -e "${YELLOW}⚠️  没识别到"国际站生意助手"agent（含关键字: ${KEYWORDS[*]}）${NC}"
  echo -e "${YELLOW}   降级方案：装到全部 ${#ALL_AGENTS[@]} 个 agent${NC}"
  TARGET_AGENTS=("${ALL_AGENTS[@]}")
elif [ ${#TARGET_AGENTS[@]} -eq 1 ]; then
  echo -e "${GREEN}✅ 识别到目标 agent: ${TARGET_AGENTS[0]}${NC}"
else
  echo -e "${GREEN}✅ 识别到 ${#TARGET_AGENTS[@]} 个国际站生意助手 agent，将全部安装：${NC}"
  for a in "${TARGET_AGENTS[@]}"; do
    echo "   - $a"
  done
fi

if [ ${#TARGET_AGENTS[@]} -eq 0 ]; then
  echo -e "${RED}❌ 没找到任何 agent，无法安装${NC}"
  exit 1
fi
echo ""

# ============================================================================
# Step 5: 安装到每个目标 agent
# ============================================================================
echo -e "${BLUE}[5/6] 开始安装到 ${#TARGET_AGENTS[@]} 个 agent...${NC}"
echo ""

INSTALLED_COUNT=0
INSTALLED_PATHS=()

for agent_id in "${TARGET_AGENTS[@]}"; do
  echo -e "${BLUE}--- agent: $agent_id ---${NC}"

  AGENT_CORE="$AGENTS_DIR/$agent_id/agent-core"
  SKILLS_DIR="$AGENT_CORE/skills"
  INSTALL_PATH="$SKILLS_DIR/$SKILL_NAME"
  SKILLS_JSONC="$SKILLS_DIR/skills.jsonc"

  mkdir -p "$SKILLS_DIR"

  # 5.1 备份并安装新版
  if [ -d "$INSTALL_PATH" ]; then
    OLD_VERSION="未知"
    [ -f "$INSTALL_PATH/VERSION" ] && OLD_VERSION=$(cat "$INSTALL_PATH/VERSION" | tr -d '[:space:]')
    BACKUP_PATH="$SKILLS_DIR/.${SKILL_NAME}.bak.$TS"
    echo -e "${YELLOW}  ⚠️  检测到旧版本 ${OLD_VERSION}，备份到: $(basename $BACKUP_PATH)${NC}"
    mv "$INSTALL_PATH" "$BACKUP_PATH"
  fi

  cp -R "$SCRIPT_DIR" "$INSTALL_PATH"
  echo -e "${GREEN}  ✅ 安装到: ${INSTALL_PATH}${NC}"

  # 5.2 清理 deprecated 潜客版（目录 + skills.jsonc 记录）
  DEPRECATED_PATH="$SKILLS_DIR/$DEPRECATED_SKILL"
  if [ -d "$DEPRECATED_PATH" ]; then
    DEPRECATED_BAK="$SKILLS_DIR/.${DEPRECATED_SKILL}.deprecated.$TS"
    echo -e "${YELLOW}  ⚠️  清理已弃用的 ${DEPRECATED_SKILL}${NC}"
    mv "$DEPRECATED_PATH" "$DEPRECATED_BAK"
  fi

  # 5.3 注册到 skills.jsonc（用内嵌 Python）
  python3 - "$SKILLS_JSONC" "$SKILL_NAME" "$SKILL_DISPLAY_NAME" "$VERSION" "$INSTALL_PATH" "$DEPRECATED_SKILL" "$TS" <<'PYEOF'
import json
import os
import re
import shutil
import sys

(jsonc_path, skill_name, display_name, version, install_path,
 deprecated_skill, ts) = sys.argv[1:8]

# 读取或初始化
def strip_jsonc(text):
    """去掉 // 行注释和 /* */ 块注释，保留字符串内的 //"""
    # 块注释
    text = re.sub(r'/\*.*?\*/', '', text, flags=re.DOTALL)
    # 行注释（不在字符串内的）
    out = []
    in_str = False
    esc = False
    i = 0
    while i < len(text):
        c = text[i]
        if esc:
            out.append(c)
            esc = False
            i += 1
            continue
        if c == '\\' and in_str:
            out.append(c)
            esc = True
            i += 1
            continue
        if c == '"':
            in_str = not in_str
            out.append(c)
            i += 1
            continue
        if not in_str and c == '/' and i + 1 < len(text) and text[i+1] == '/':
            # 跳到行尾
            while i < len(text) and text[i] != '\n':
                i += 1
            continue
        out.append(c)
        i += 1
    return ''.join(out)

records = []
wrapper_key = None  # 'skills' 包装结构 / None 纯数组
if os.path.exists(jsonc_path):
    # 备份
    shutil.copy(jsonc_path, jsonc_path + f'.bak.{ts}')
    with open(jsonc_path, 'r', encoding='utf-8') as f:
        raw = f.read()
    try:
        parsed = json.loads(strip_jsonc(raw))
        if isinstance(parsed, list):
            records = parsed
            wrapper_key = None
        elif isinstance(parsed, dict) and isinstance(parsed.get('skills'), list):
            records = parsed['skills']
            wrapper_key = 'skills'
        else:
            print(f"  ⚠️  skills.jsonc 既不是数组也不是 {{skills:[...]}} 格式，保持空", file=sys.stderr)
            records = []
            wrapper_key = 'skills'  # 默认用包装结构（ACW 实际用这个）
    except Exception as e:
        print(f"  ⚠️  skills.jsonc 解析失败 ({e})，保持空（已备份）", file=sys.stderr)
        records = []
        wrapper_key = 'skills'

# 清理：移除指向 .bak. 备份目录的过期记录、移除文件已不存在的记录
def is_stale(r):
    ip = r.get('installPath', '')
    en = r.get('entryName', '')
    if '.bak.' in ip or en.startswith('.') and '.bak.' in en:
        return True
    if ip and not os.path.exists(ip):
        return True
    return False

before = len(records)
records = [r for r in records if not is_stale(r)]
removed = before - len(records)
if removed > 0:
    print(f"  🧹 清理了 {removed} 条无效/过期记录（指向备份或不存在路径）")

# 描述（从 SKILL.md frontmatter 读取）
description = ""
skill_md = os.path.join(install_path, "SKILL.md")
if os.path.exists(skill_md):
    with open(skill_md, 'r', encoding='utf-8') as f:
        in_fm = False
        for line in f:
            if line.strip() == '---':
                if in_fm:
                    break
                in_fm = True
                continue
            if in_fm and line.startswith('description:'):
                description = line[len('description:'):].strip()
                break

# 移除已弃用的潜客版记录
records = [r for r in records if r.get('id') != deprecated_skill and r.get('entryName') != deprecated_skill]

# 增/替换当前 Skill
new_record = {
    "id": skill_name,
    "name": display_name,
    "version": version,
    "enabled": True,
    "kind": "directory",
    "entryName": skill_name,
    "description": description,
    "installPath": install_path,
}

# 移除旧记录（如果已存在）
records = [r for r in records if r.get('id') != skill_name and r.get('entryName') != skill_name]
records.append(new_record)

# 写回（保持原结构：包装 or 纯数组）
output = {wrapper_key: records} if wrapper_key else records
with open(jsonc_path, 'w', encoding='utf-8') as f:
    json.dump(output, f, ensure_ascii=False, indent=2)
    f.write('\n')

print(f"  ✅ skills.jsonc 已注册（共 {len(records)} 条记录，结构: {'wrapped' if wrapper_key else 'array'}）")
PYEOF

  if [ $? -eq 0 ]; then
    INSTALLED_COUNT=$((INSTALLED_COUNT + 1))
    INSTALLED_PATHS+=("$INSTALL_PATH")
  else
    echo -e "${RED}  ❌ skills.jsonc 注册失败${NC}"
  fi

  # 5.4 设置可执行权限
  chmod +x "$INSTALL_PATH"/scripts/*.sh 2>/dev/null || true
  chmod +x "$INSTALL_PATH"/scripts/*.py 2>/dev/null || true
  chmod +x "$INSTALL_PATH/INSTALL.sh" 2>/dev/null || true
  echo ""
done

# ============================================================================
# Step 6: 总结
# ============================================================================
echo -e "${BLUE}[6/6] 安装完成总结${NC}"
echo ""
echo -e "${GREEN}=========================================${NC}"
echo -e "${GREEN} 🎉 安装成功！v${VERSION}${NC}"
echo -e "${GREEN} 装到 ${INSTALLED_COUNT} 个 agent${NC}"
echo -e "${GREEN}=========================================${NC}"
echo ""
echo "已安装路径："
for p in "${INSTALLED_PATHS[@]}"; do
  echo -e "  ${BLUE}•${NC} $p"
done
echo ""
echo -e "下一步操作："
echo -e "  ${BLUE}1.${NC} 完全退出 Accio Work（不是最小化）"
echo -e "  ${BLUE}2.${NC} 重新打开 Accio Work"
echo -e "  ${BLUE}3.${NC} 进入「国际站生意助手」"
echo -e "  ${BLUE}4.${NC} 在对话框输入：${GREEN}生成知识库${NC}"
echo -e "  ${BLUE}5.${NC} 跟随 Stage 0/1/2/3 卡片确认 + 等待自动产出"
echo ""
echo -e "如遇问题，查看 ${YELLOW}HOW_TO_USE.md${NC} 末尾的 FAQ。"
echo ""
