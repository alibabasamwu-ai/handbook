#!/bin/bash
set -euo pipefail

# Usage: ./batch_pandoc.sh <work_dir> [--include-internal sales_training,deal_case_studies]

WORK_DIR=${1:-"."}
INCLUDE_INTERNAL=""

# Parse arguments
shift || true
while [[ $# -gt 0 ]]; do
  case $1 in
    --include-internal)
      INCLUDE_INTERNAL="$2"
      shift 2
      ;;
    *)
      echo "Unknown argument: $1"
      exit 1
      ;;
  esac
done

PUBLIC_DIR="$WORK_DIR/KB_PUBLIC"
INTERNAL_DIR="$WORK_DIR/99_INTERNAL_ONLY"
OUTPUT_DIR="$WORK_DIR/DOCX_EXPORT"

mkdir -p "$OUTPUT_DIR"

echo ">>> Starting Pandoc Batch Conversion in: $WORK_DIR"

# Function to convert files
convert_dir() {
  local src_base=$1
  local target_base=$2
  
  if [ ! -d "$src_base" ]; then
    echo "Warning: Directory $src_base does not exist. Skipping."
    return
  fi

  find "$src_base" -name "*.md" | while read -r md_file; do
    # Calculate relative path
    rel_path=${md_file#"$src_base/"}
    docx_file="$target_base/${rel_path%.md}.docx"
    
    # Create parent directory
    mkdir -p "$(dirname "$docx_file")"
    
    echo "Converting: $rel_path"
    pandoc -f markdown-yaml_metadata_block "$md_file" -o "$docx_file"
  done
}

# 1. Convert Public KB
convert_dir "$PUBLIC_DIR" "$OUTPUT_DIR/PUBLIC"

# 2. Convert Optional Internal Dirs
if [ -n "$INCLUDE_INTERNAL" ]; then
  IFS=',' read -ra ADDR <<< "$INCLUDE_INTERNAL"
  for sub_dir in "${ADDR[@]}"; do
    convert_dir "$INTERNAL_DIR/$sub_dir" "$OUTPUT_DIR/INTERNAL/$sub_dir"
  done
fi

# Summary Report
MD_COUNT=$(find "$PUBLIC_DIR" -name "*.md" | wc -l)
DOCX_COUNT=$(find "$OUTPUT_DIR" -name "*.docx" | wc -l)

echo "------------------------------------"
echo "Report:"
echo "Source (.md) files found: $MD_COUNT"
echo "Exported (.docx) files: $DOCX_COUNT"
echo "------------------------------------"

if [ "$MD_COUNT" -gt "$DOCX_COUNT" ]; then
  echo "Warning: Some files might have failed conversion."
fi
