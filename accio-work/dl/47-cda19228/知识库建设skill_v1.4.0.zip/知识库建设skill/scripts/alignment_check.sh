#!/bin/bash
set -euo pipefail

# Usage: ./alignment_check.sh <work_dir> --primary EN --derived ES,FR

WORK_DIR=${1:-"."}
PRIMARY_LANG="EN"
DERIVED_LANGS=""

# Parse arguments
shift || true
while [[ $# -gt 0 ]]; do
  case $1 in
    --primary)
      PRIMARY_LANG="$2"
      shift 2
      ;;
    --derived)
      DERIVED_LANGS="$2"
      shift 2
      ;;
    *)
      echo "Unknown argument: $1"
      exit 1
      ;;
  esac
done

PUBLIC_DIR="$WORK_DIR/KB_PUBLIC"
PRIMARY_DIR="$PUBLIC_DIR/$PRIMARY_LANG"

if [ ! -d "$PRIMARY_DIR" ]; then
  echo "Error: Primary directory $PRIMARY_DIR not found."
  exit 1
fi

echo ">>> Starting Alignment Check (Primary: $PRIMARY_LANG)"

IFS=',' read -ra DERIVED_LIST <<< "$DERIVED_LANGS"

for lang in "${DERIVED_LIST[@]}"; do
  DERIVED_DIR="$PUBLIC_DIR/$lang"
  echo "--- Checking Language: $lang ---"
  
  if [ ! -d "$DERIVED_DIR" ]; then
    echo "❌ Error: Derived directory $DERIVED_DIR not found."
    continue
  fi

  find "$PRIMARY_DIR" -name "*.md" | while read -r primary_file; do
    rel_path=${primary_file#"$PRIMARY_DIR/"}
    derived_file="$DERIVED_DIR/$rel_path"
    
    if [ ! -f "$derived_file" ]; then
      echo "❌ Missing File: $lang/$rel_path"
      continue
    fi
    
    # 1. Check Header count (##)
    P_HEADERS=$(grep -c "^## " "$primary_file" || true)
    D_HEADERS=$(grep -c "^## " "$derived_file" || true)
    
    # 2. Check Line count
    P_LINES=$(wc -l < "$primary_file")
    D_LINES=$(wc -l < "$derived_file")
    
    # Calculate difference
    LINE_DIFF=$(( P_LINES - D_LINES ))
    LINE_DIFF=${LINE_DIFF#-} # absolute value
    THRESHOLD=$(( P_LINES / 10 )) # 10%
    
    if [ "$P_HEADERS" -ne "$D_HEADERS" ]; then
      echo "⚠️ Header Mismatch: $rel_path ($PRIMARY_LANG: $P_HEADERS, $lang: $D_HEADERS)"
    fi
    
    if [ "$LINE_DIFF" -gt "$THRESHOLD" ]; then
      echo "⚠️ Line Count Drift (>10%): $rel_path ($PRIMARY_LANG: $P_LINES, $lang: $D_LINES)"
    fi
  done
done

echo ">>> Alignment check complete."
