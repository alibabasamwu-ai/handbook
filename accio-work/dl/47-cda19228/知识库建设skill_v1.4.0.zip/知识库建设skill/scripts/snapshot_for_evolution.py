#!/usr/bin/env python3
import os
import sys
import re
import json
from datetime import datetime

# Usage: python snapshot_for_evolution.py <work_dir> <industry> [--anonymize-id seed_case_NNN]

def extract_metadata(work_dir):
    data = {
        "timestamp": datetime.now().isoformat(),
        "industry": "",
        "sub_industry": "N/A",
        "ai_score_initial": 0.0,
        "ai_score_final": 0.0,
        "weak_questions": [],
        "blind_spots": []
    }
    
    spec_path = os.path.join(work_dir, "SPEC_LOCKED.md")
    sim_path = os.path.join(work_dir, "AI_RESPONSE_SIMULATION.md")
    
    # Simple regex extraction
    if os.path.exists(spec_path):
        with open(spec_path, 'r', encoding='utf-8') as f:
            content = f.read()
            ind_match = re.search(r"Industry:\s*(.*)", content)
            if ind_match: data["industry"] = ind_match.group(1).strip()
            
            sub_match = re.search(r"Sub-Industry:\s*(.*)", content)
            if sub_match: data["sub_industry"] = sub_match.group(1).strip()

    if os.path.exists(sim_path):
        with open(sim_path, 'r', encoding='utf-8') as f:
            content = f.read()
            scores = re.findall(r"Score:\s*(\d+\.?\d*)", content)
            if len(scores) >= 1: data["ai_score_initial"] = float(scores[0])
            if len(scores) >= 2: data["ai_score_final"] = float(scores[-1])
            
            # Extract weak points (simple list extraction)
            weak_match = re.search(r"## Weak Questions\n(.*?)\n##", content, re.S)
            if weak_match:
                data["weak_questions"] = [item.strip("- ") for item in weak_match.group(1).strip().split("\n") if item]

    return data

def main():
    if len(sys.argv) < 3:
        print("Usage: python snapshot_for_evolution.py <work_dir> <industry>")
        sys.exit(1)
        
    work_dir = sys.argv[1]
    industry = sys.argv[2]
    
    evolution_dir = os.path.abspath(os.path.join(work_dir, "..", "evolution"))
    os.makedirs(evolution_dir, exist_ok=True)
    jsonl_path = os.path.join(evolution_dir, "industry_insights.jsonl")
    
    metadata = extract_metadata(work_dir)
    metadata["industry"] = industry # Override if provided
    
    # Anonymize ID logic
    case_count = 0
    if os.path.exists(jsonl_path):
        with open(jsonl_path, 'r') as f:
            case_count = sum(1 for _ in f)
    
    metadata["case_id"] = f"seed_case_{case_count + 1:03d}"
    
    with open(jsonl_path, 'a', encoding='utf-8') as f:
        f.write(json.dumps(metadata, ensure_ascii=False) + "\n")
        
    print(f">>> Snapshot saved to {jsonl_path} as {metadata['case_id']}")

if __name__ == "__main__":
    main()
