#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
交付完整性 + 零幻觉审计脚本 · v1.0 (知识库 Skill v1.4.0)

解决问题:
1. 防"只交几篇就说完成"——校验每模块篇数下限
2. 防"内容太薄"——校验字数/结构/表格(深度门禁 D1/D2/D6)
3. 防"EVA 抓不到"——校验 7 铁律(产品主体/提问式标题/Keywords/零占位符)
4. 防"幻觉数字"——扫描未经授权的具体数字(交期天数/样品费金额/质保拆分等)
5. 防"文件夹结构错"——校验中文目录结构完整

用法:
  python3 delivery_audit.py --work-dir <知识库工作目录> [--min-per-module 10] [--lang 英文]
退出码: 0=全过, 1=有FAIL

注意: 幻觉数字扫描是"提示可疑",需人工确认是否商家已授权;脚本只负责把可疑点全列出来。
"""
import argparse, glob, os, re, sys

# 6 模块中文目录名(与 SKILL.md 中文目录约定一致)
MODULES_CN = ["01_公司信息", "02_产品信息", "03_沟通报价", "04_售后保障", "05_物流交付", "06_交易付款"]
# 兼容英文旧目录
MODULES_EN = ["01_company_info","02_product_info","03_communication","04_after_sales","05_logistics","06_payment"]

# 幻觉高危模式: 未经授权常被子代理编造的具体数字
HALLUCINATION_PATTERNS = [
    (r'\b\d+\s*-\s*\d+\s*(working |business )?days?\b', "交期天数(需商家确认真实交期)"),
    (r'\bsample\s+fee[^.\n]*\$\s*\d+', "样品费具体金额(需商家确认)"),
    (r'\$\s*\d+\s*-\s*\$?\s*\d+\s*(per|/)?\s*(sample|transaction)', "样品/手续费金额(需商家确认)"),
    (r'\b\d+\s*(months?|year)\s+warranty\b', "质保期具体拆分(核对是否=商家给的统一质保)"),
    (r'\bunder\s*\$\s*\d{3,}', "金额门槛(需商家确认)"),
    (r'\bexceeding\s*\$\s*\d{3,}', "金额门槛(需商家确认)"),
    (r'\b\d+\s*(days?)\s+in advance', "预约天数(需商家确认)"),
]
# 占位符(EVA 视为空值,绝不能上线)
PLACEHOLDER_PATTERNS = [r'待补充', r'\bTBD\b', r'详谈', r'see detail', r'to be confirmed', r'待定']

def audit(work_dir, min_per_module, lang):
    en_root = os.path.join(work_dir, "知识库_对客", lang) if os.path.isdir(os.path.join(work_dir,"知识库_对客")) else os.path.join(work_dir, "KB_PUBLIC", lang)
    results = []  # (level, msg)  level: PASS/WARN/FAIL
    def add(l,m): results.append((l,m))

    # ---- 审计 A: 文件夹结构 ----
    if not os.path.isdir(en_root):
        add("FAIL", f"找不到知识库根目录: {en_root}")
        return results, en_root
    modules = MODULES_CN if any(os.path.isdir(os.path.join(en_root,m)) for m in MODULES_CN) else MODULES_EN
    for m in modules:
        if not os.path.isdir(os.path.join(en_root, m)):
            add("FAIL", f"缺模块目录: {m}")

    # ---- 审计 B: 每模块篇数(防偷工减料) ----
    total = 0
    for m in modules:
        files = glob.glob(os.path.join(en_root, m, "*.md"))
        total += len(files)
        if len(files) < min_per_module:
            add("FAIL", f"模块 {m} 仅 {len(files)} 篇 < 下限 {min_per_module} 篇(防只交几篇)")
        else:
            add("PASS", f"模块 {m}: {len(files)} 篇 ✓")
    add("PASS" if total >= min_per_module*len(modules) else "FAIL", f"总篇数: {total}")

    # ---- 审计 C/D/E: 逐篇 深度 + 7铁律 + 幻觉 ----
    all_md = glob.glob(os.path.join(en_root, "**", "*.md"), recursive=True)
    thin=[]; no_subject=[]; no_kw=[]; no_table=[]; placeholders=[]; suspect={}
    for f in all_md:
        t = open(f, encoding="utf-8").read()
        body = re.sub(r'^---.*?---', '', t, count=1, flags=re.S)
        wc = len(body.split())
        rel = os.path.relpath(f, en_root)
        if wc < 250: thin.append(f"{rel}({wc}词)")
        if 'product_subject' not in t: no_subject.append(rel)
        if not re.search(r'[Kk]eywords[:：]', t): no_kw.append(rel)
        if '|' not in body: no_table.append(rel)
        for p in PLACEHOLDER_PATTERNS:
            if re.search(p, t, re.I): placeholders.append(rel); break
        for pat, desc in HALLUCINATION_PATTERNS:
            for mt in re.findall(pat, body):
                suspect.setdefault(desc, []).append(rel)
                break

    def report(name, lst, level="FAIL"):
        if lst: add(level, f"{name}: {len(lst)} 篇 → {lst[:5]}{'...' if len(lst)>5 else ''}")
        else: add("PASS", f"{name}: 0 ✓")
    report("深度不足(<250词)", thin)
    report("缺 product_subject", no_subject)
    report("缺 Keywords 行", no_kw)
    report("缺表格", no_table)
    report("含占位符(EVA抓不到)", placeholders)
    # 幻觉是 WARN(需人工确认),不是硬FAIL
    if suspect:
        for desc, files in suspect.items():
            add("WARN", f"⚠️可疑幻觉数字-{desc}: {len(files)}篇 {files[:3]} → 必须核对商家是否提供过")
    else:
        add("PASS", "幻觉数字扫描: 0 可疑 ✓")
    return results, en_root

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--work-dir", required=True)
    ap.add_argument("--min-per-module", type=int, default=10)
    ap.add_argument("--lang", default="英文")
    a = ap.parse_args()
    results, root = audit(a.work_dir, a.min_per_module, a.lang)
    print(f"\n{'='*60}\n  交付审计报告  root={root}\n{'='*60}")
    fails = [m for l,m in results if l=="FAIL"]
    warns = [m for l,m in results if l=="WARN"]
    for l,m in results:
        icon = {"PASS":"✅","WARN":"⚠️","FAIL":"❌"}[l]
        print(f"{icon} {m}")
    print(f"\n{'='*60}")
    print(f"结论: {'❌ 不可交付(有FAIL)' if fails else '✅ 可交付'} | FAIL={len(fails)} WARN={len(warns)}")
    if warns: print("⚠️ WARN(疑似幻觉)必须人工逐条核对商家是否授权该数字,否则视同FAIL")
    sys.exit(1 if fails else 0)

if __name__ == "__main__":
    main()
