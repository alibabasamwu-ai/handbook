#!/bin/bash
set -euo pipefail

# Usage: ./risk_scan.sh <work_dir> [--competitors "name1,name2"]

WORK_DIR=${1:-"."}
COMPETITORS=""

# Parse arguments
shift || true
while [[ $# -gt 0 ]]; do
  case $1 in
    --competitors)
      COMPETITORS="$2"
      shift 2
      ;;
    *)
      echo "Unknown argument: $1"
      exit 1
      ;;
  esac
done

PUBLIC_DIR="$WORK_DIR/KB_PUBLIC"
REPORT_FILE="$WORK_DIR/RISK_SCAN_REPORT.md"

echo "# Risk Scan Report" > "$REPORT_FILE"
echo "Generated on: $(date)" >> "$REPORT_FILE"
echo "" >> "$REPORT_FILE"

HAS_P0=0

# 1. Training Labels Scan (Multi-lingual)
echo "## 1. Training Labels Scan" >> "$REPORT_FILE"
# Regex covers English, Chinese, French, Spanish, etc.
LABELS_REGEX="(Bad Talk|Mauvais Discours|Discurso Malo|不良言论|训练数据|Training Data|Instruction:|AI Model|GPT-|Claude|LLM)"
HITS_LABELS=$(grep -riE "$LABELS_REGEX" "$PUBLIC_DIR" --include="*.md" || true)

if [ -n "$HITS_LABELS" ]; then
  echo "❌ P0: Found training labels or AI artifacts!" >> "$REPORT_FILE"
  echo '```' >> "$REPORT_FILE"
  echo "$HITS_LABELS" >> "$REPORT_FILE"
  echo '```' >> "$REPORT_FILE"
  HAS_P0=1
else
  echo "✅ No training labels found." >> "$REPORT_FILE"
fi

# 2. Competitor Names Scan
echo -e "\n## 2. Competitor Scan" >> "$REPORT_FILE"
if [ -n "$COMPETITORS" ]; then
  IFS=',' read -ra COMPS <<< "$COMPETITORS"
  for comp in "${COMPS[@]}"; do
    HITS_COMP=$(grep -ril "$comp" "$PUBLIC_DIR" --include="*.md" || true)
    if [ -n "$HITS_COMP" ]; then
      echo "⚠️ P1: Competitor '$comp' mentioned in:" >> "$REPORT_FILE"
      echo "$HITS_COMP" >> "$REPORT_FILE"
    fi
  done
else
  echo "No competitors provided for scanning." >> "$REPORT_FILE"
fi

# 3. Internal Link Scan
echo -e "\n## 3. Internal Link Scan" >> "$REPORT_FILE"
HITS_INTERNAL=$(grep -rn "99_INTERNAL_ONLY" "$PUBLIC_DIR" --include="*.md" || true)
if [ -n "$HITS_INTERNAL" ]; then
  echo "❌ P0: Internal links found in public KB!" >> "$REPORT_FILE"
  echo '```' >> "$REPORT_FILE"
  echo "$HITS_INTERNAL" >> "$REPORT_FILE"
  echo '```' >> "$REPORT_FILE"
  HAS_P0=1
else
  echo "✅ No internal links found in public KB." >> "$REPORT_FILE"
fi

echo ">>> Scan finished. Report saved to $REPORT_FILE"

if [ "$HAS_P0" -eq 1 ]; then
  echo ">>> FATAL: P0 Risks detected!"
  exit 1
fi
