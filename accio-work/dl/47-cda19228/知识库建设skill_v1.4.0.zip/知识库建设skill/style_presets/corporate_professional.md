# Style Preset: Corporate Professional

## Identity
- **调色板**:
  - 主色: 深灰/炭黑 #2c3e50
  - 辅助: 纯白 #ffffff
  - 强调: 商务金 #c5a059
- **字体风格**: Bold Sans-serif, authoritative, structured.
- **适用品类**: B2B 服务, SaaS 软件, 咨询服务, 贸易物流, 金融科技.

## Master Prompt Fragment
Corporate professional aesthetic, executive boardroom lighting, sharp clean edges, charcoal grey and white contrast with gold accents, sophisticated and trustworthy, high-end commercial photography.

## Material-Type Prompts

### pain_point_comparison
- **Concept**: Efficiency and ROI comparison.
- **Prompt**: Split screen. Left: Low efficiency {{competitor_class}} with red downward charts. Right: {{store_name}} {{category}} with {{differentiator_1}}, gold upward growth chart, professional business executive smiling in background. Sharp focus, high contrast.

### spec_infographic
- **Concept**: Business metrics and global reach.
- **Prompt**: A sleek digital dashboard or a physical {{category}} on a marble desk. Callouts for {{spec_1}} (Efficiency) and {{spec_2}} (Global Compliance). Golden icons, premium corporate branding.

### scenario
- **Concept**: Business meeting or logistics operation.
- **Prompt**: A professional business setting, high-rise office with glass windows. The {{category}} or service result (e.g., {{scenario_outcome}}) is being presented to a group of international clients. Professional, powerful, successful atmosphere.

### factory_capability
- **Concept**: Precision and global standards.
- **Prompt**: A modern, highly organized logistics hub or a high-end data center. Focus on the scale and professionalism of the operation. Charcoal grey tones with gold accent lighting.

### certification_showcase
- **Concept**: Global trust certificates.
- **Prompt**: A wall of frame certificates in a prestigious corporate hallway. The {{store_name}} logo and {{category}} are positioned centrally. Impressive, authoritative, and trustworthy.

## Negative Prompts
- Low-quality, messy, casual, colorful, neon, bright saturated colors, amateur, cluttered, handheld camera.

## Aspect Ratio 推荐
- pain_point_comparison: 16:9
- spec_infographic: 1:1
- scenario: 16:9
- factory_capability: 4:5
- certification_showcase: 1:1
