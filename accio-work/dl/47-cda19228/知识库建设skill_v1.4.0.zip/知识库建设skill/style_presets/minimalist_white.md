# Style Preset: Minimalist White

## Identity
- **调色板**:
  - 背景: 纯白 #ffffff
  - 阴影: 浅灰 #f0f0f0 / #e0e0e0
  - 强调: 极简灰 #333333
- **字体风格**: Clean Sans-serif, light weight, spacious tracking.
- **适用品类**: 家居用品, 3C 消费电子, 办公用品, 极简家具, 个人护理.

## Master Prompt Fragment
Ultra-minimalist aesthetic, soft natural lighting, pure white background, soft shadows, clean and airy composition, studio product photography, 8k resolution, elegant and simple.

## Material-Type Prompts

### pain_point_comparison
- **Concept**: Comparison of design and efficiency.
- **Prompt**: Two-panel layout. Left side: {{competitor_class}} with cluttered wires and bulky design, messy shadow. Right side: {{store_name}}'s {{category}} with {{differentiator_1}}, cordless and sleek, soft elegant shadow. Minimalist icons for "Old" and "New".

### spec_infographic
- **Concept**: Clean icons for key parameters.
- **Prompt**: The {{category}} isolated on a white background. Floating minimalist icons and thin grey lines pointing to {{spec_1}} and {{spec_2}}. Sans-serif typography, soft lighting, focus on product texture and {{material}}.

### scenario
- **Concept**: Product in a modern, sunlit interior.
- **Prompt**: A {{category}} placed on a light oak desk in a bright, modern minimalist room. Natural sunlight streaming through a window, creating soft shadows. The {{category}} fits perfectly into the lifestyle. Soft focus on background, high-end interior design magazine style.

### factory_capability
- **Concept**: Clean-room manufacturing environment.
- **Prompt**: A modern, white-walled assembly facility. Workers in white lab coats carefully inspecting the {{category}}. Bright, even studio lighting. Focus on precision and cleanliness. Minimalist industrial aesthetic.

### certification_showcase
- **Concept**: Minimalist certification display.
- **Prompt**: A group of certificates (CE, FCC) elegantly framed in thin black frames, leaning against a white wall next to a {{category}}. Soft natural light, shadows of leaves, very clean and professional.

## Negative Prompts
- Dark colors, high contrast, heavy shadows, cluttered, colorful, busy background, neon lights, industrial grit, vintage.

## Aspect Ratio 推荐
- pain_point_comparison: 4:3
- spec_infographic: 1:1
- scenario: 4:5
- factory_capability: 16:9
- certification_showcase: 1:1
