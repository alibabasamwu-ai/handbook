# Style Preset: Warm Lifestyle

## Identity
- **调色板**:
  - 主色: 米白/奶油色 #fdf5e6
  - 辅助: 原木色/浅褐 #d2b48c
  - 强调: 暖金/阳光色 #ffdb58
- **字体风格**: Serif or Soft Sans-serif, elegant, approachable.
- **适用品类**: 潮流服饰, 休闲食品, 母婴用品, 宠物用品, 有机化妆品.

## Master Prompt Fragment
Warm and cozy lifestyle atmosphere, soft golden hour sunlight, natural organic textures, cream and wooden tones, shallow depth of field, high-end lifestyle photography, tender and emotional.

## Material-Type Prompts

### pain_point_comparison
- **Concept**: Emotional or comfort comparison.
- **Prompt**: Comparison between {{competitor_class}} and {{store_name}} {{category}}. Left: Cold, uncomfortable setting, harsh artificial light. Right: Warm, soft bed/living room setting with {{store_name}} {{category}}, glowing with soft warmth, {{differentiator_1}} highlighted. Soft blur between panels.

### spec_infographic
- **Concept**: Natural icons for materials/safety.
- **Prompt**: A {{category}} surrounded by natural elements like cotton or wood. Soft UI tags explaining {{spec_1}} (Eco-friendly) and {{spec_2}} (Safety). Warm beige background, organic shapes, elegant serif typography.

### scenario
- **Concept**: A mother and child or happy user with the product.
- **Prompt**: A cozy living room scene. A {{user_type}} is using the {{category}} with a smile. Warm sunlight, soft fabrics, {{differentiator_2}} in action. Beautiful bokeh, high-end lifestyle magazine aesthetic.

### factory_capability
- **Concept**: Craftsmanship and safe materials.
- **Prompt**: Close-up of hands working with {{material}} in a sun-drenched workshop. The {{category}} is being finished with care. Soft focus on the craftsmanship, warm and trust-inspiring atmosphere.

### certification_showcase
- **Concept**: Trust and safety badges.
- **Prompt**: "Mom's Choice" or "Organic" badges displayed next to the {{category}} on a wooden shelf. Warm ambient light, green plants in the background, soft and safe feel.

## Negative Prompts
- Dark, cold blue, industrial, sharp edges, neon, futuristic, metal, high-tech, aggressive branding.

## Aspect Ratio 推荐
- pain_point_comparison: 1:1
- spec_infographic: 4:5
- scenario: 4:5
- factory_capability: 16:9
- certification_showcase: 1:1
