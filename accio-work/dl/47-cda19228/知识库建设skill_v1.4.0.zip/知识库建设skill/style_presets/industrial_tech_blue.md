# Style Preset: Industrial Tech Blue (XINTONG Style)

## Identity
- **调色板**: 
  - 背景: 深蓝黑 #0a0a1a (Deep Midnight)
  - 强调: 科技蓝 #00d4ff (Electric Cyan)
  - 辅助: 银金属 #cccccc (Metallic Silver)
- **字体风格**: Sans-serif, Bold, futuristic, clean lines.
- **适用品类**: 工业设备, 智能制造, 电子零部件, 安防监控, 电网电力设备.

## Master Prompt Fragment
High-tech industrial aesthetic, cinematic lighting with electric cyan accents, deep midnight blue background, metallic textures, sharp focus, 8k resolution, professional commercial photography, futuristic atmosphere.

## Material-Type Prompts

### pain_point_comparison
- **Concept**: {{store_anchor}} vs {{competitor_class}}. Left side shows the failure of standard products, right side shows the superior stability of {{store_name}}'s {{category}}.
- **Prompt**: Split screen comparison. Left: A rusty, broken {{competitor_class}} in a harsh environment, dim yellow lighting, "FAIL" red mark. Right: {{store_name}} brand {{category}} made of {{material}}, sleek and durable, glowing with {{differentiator_1}} under tech-blue spotlight, "SUCCESS" cyan checkmark. High contrast, sharp details.

### spec_infographic
- **Concept**: Technical specs for {{category}} with icons.
- **Prompt**: A {{category}} centered, surrounded by holographic UI elements and icons showing {{spec_1}}, {{spec_2}}, and {{spec_3}}. Technical blue lines connecting specs to product parts. Silver metallic surface of the {{category}} reflecting cyan light. Clean, informative, tech-blueprint style.

### scenario
- **Concept**: The {{category}} installed in a real-world high-end project.
- **Prompt**: A wide shot of a massive EPC project site (like a smart factory or power station). The {{store_name}} {{category}} is prominently installed in the foreground. Professional engineering photography, dusk lighting, tech-blue accent lights on the equipment, sharp focus, hyper-realistic, {{differentiator_2}} visible.

### factory_capability
- **Concept**: High-precision production line for {{category}}.
- **Prompt**: Inside a high-tech smart factory. Robotic arms assembling {{category}} on a clean, organized production line. Tech-blue ambient lighting, silver metallic machinery, blurred background of a vast workshop. Professional industrial photography, depth of field.

### certification_showcase
- **Concept**: Displaying global standards like {{cert_list}}.
- **Prompt**: A clean, premium glass display case. Inside, a silver-plated {{category}} stands next to formal certificates (CE, RoHS, SASO). Tech-blue glowing edges around the certificates. Soft silver reflections, professional B2B presentation style.

## Negative Prompts
- Cartoon, hand-drawn, low-resolution, warm yellow tones, messy environment, crowded background, blurry, low contrast, vintage, amateur photography.

## Aspect Ratio 推荐
- pain_point_comparison: 16:9
- spec_infographic: 1:1
- scenario: 16:9
- factory_capability: 4:5
- certification_showcase: 1:1
