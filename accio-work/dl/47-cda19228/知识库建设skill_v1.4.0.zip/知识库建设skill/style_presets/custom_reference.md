# Style Preset: Custom Reference

## Identity
- **说明**: 此预设主要用于商家提供了具体参考图的情况。
- **核心逻辑**: 不使用 `image_generate` 从零生成，而是使用 `image_edit` 工具，将 `reference_images` 设置为商家提供的图片 URL。
- **适用品类**: 任何有明确视觉对标（如品牌官网图、竞品详情页图）的类目。

## Workflow Strategy
1. **参考图上传**: 商家通过系统上传 1-3 张参考图。
2. **工具选择**: 调用 `image_edit` 工具。
3. **Task Type**:
   - `simple_generation`: 简单的背景替换或颜色调整。
   - `complex_generation`: 需要改变产品形态、组合多个元素或高度还原参考图意境。

## Master Prompt Fragment
(Based on user input reference image) "Maintain the lighting, composition, and style of the reference image while incorporating the {{store_name}} {{category}} with {{differentiator_1}}."

## Material-Type Prompts

### pain_point_comparison
- **Prompt**: Use `image_edit` with the reference layout. Instructions: "Keep the layout of the reference image, replace the generic product with {{store_name}}'s {{category}}, and add {{differentiator_1}} features."

### spec_infographic
- **Prompt**: "Extract the infographic style from the reference image. Overlay it onto the high-resolution shot of {{store_name}} {{category}}. Ensure the font and color scheme match the reference."

### scenario
- **Prompt**: "Recreate the scenario from the reference image but with our {{category}}. Ensure the {{differentiator_2}} is the focal point. Match the time of day and mood exactly."

### factory_capability
- **Prompt**: "Using the reference factory photo as a base, enhance the visibility of {{tech_keyword}} on the production line. Add {{store_name}} branding to the workers' uniforms."

### certification_showcase
- **Prompt**: "Style the certification display exactly like the reference image. Replace the sample certificates with {{cert_list}}."

## Negative Prompts
- Deviating from reference style, inconsistent lighting, poor blending of product into the reference scene.

## Aspect Ratio 推荐
- 严格遵循参考图比例 (Typically 1:1 or 3:4).
