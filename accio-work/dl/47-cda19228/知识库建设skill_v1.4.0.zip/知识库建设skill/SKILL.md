---
name: alibaba-knowledge-base-builder
version: 1.2.0
last_updated: 2026-05-07
maintainer: Accio Work · 国际站生意助手
description: 为阿里巴巴国际站商家（已开通 / 未开通 / 已开通但 MCP 不可用 三类全覆盖）系统化生成、丰富、完善店铺多语种 AI 知识库（177+ 篇 .md + .docx + 营销素材 + 应答模拟 + 修复迭代）+ 未开通商家附带入驻指引（KB_PUBLIC + KB_INTERNAL + ONBOARDING_GUIDE）。**核心定位**：① 商家自用（员工内部检索/培训/标准化话术）；② 接入 Accio Work 生意助手（让生意助手回答时基于商家自己的知识库）；③ v1.2 新增 PDF Catalog 可发给客户参考。v1.1 起合并 alibaba-prelaunch-kb-builder 并对齐图片技能 v2.0.2 反幻觉机制。
trigger_keywords:
  - 建知识库
  - 建AI知识库
  - 国际站知识库
  - 商家自用 AI 知识库
  - 生意助手知识库
  - 丰富完善知识库
  - 做一套店铺知识库
  - 生成知识库
  - 入驻前知识库
  - 潜客知识库
  - prelaunch 知识库
  - 还没开店做知识库
  - knowledge base
  - AI knowledge base
  - prelaunch knowledge base
---

# 国际站 AI 知识库生成器（v1.1.0）

> ⚠️ **强制约束（v1.1.0 起编码为 Stage Gate，不再是建议）**：
> 本 Skill 分两章 — **第一章（商家视图）7 Stage Gate（含 Stage 5.5）**，每个 Stage 必须产出指定文件名才能进下一步；**第二章（AI 执行约束）R1-R7 七大硬规则 + R1.1 强制可见自检块**，违反任何一条即 Skill 执行失败。
> main agent 在执行任何动作前必须 **依次** 完成：
> 1. `read CORE_RULES.md`（了解 R1-R7）
> 2. `read references/alibaba-retrieval-rules.md`（**阿里 EVA/AI Search 真实抓取规则 + 100% 可抓取 7 铁律**，决定所有 KB 内容能否被 EVA 抓到）
> 3. `read references/content-depth-and-sourcing.md`（**内容深度门禁 D1-D6 + 多源差异化挖掘 DA-Flow + 零幻觉 5 级分级**，决定内容够不够详细、够不够差异化、是否零幻觉）
> 4. `read references/中文目录规范.md`（**所有产出文件夹含子文件夹必须用中文名**，唯一目录事实源）
> 5. `read references/customer-interaction-cards.md`（标准互动卡）
> 6. `read references/audit-templates.md`（诚信审计/静默错误/超时降级三模板）
> 7. `read references/source-acquisition.md`（信息源优先级 + 视觉对齐 + 三层降级）
> 8. 进入第一章 Stage 0
>
> ⚠️ **四大核心交付目标（缺一不可）**：
> 1. **可抓取**：内容服务于 **EVA 自动接待（业务场，RAG 语义检索）**，每条满足可抓取 7 铁律。**不进前台 AI Search（货架场，索引商品 listing）**，严禁承诺"知识库提升前台搜索排名"。详见 [alibaba-retrieval-rules.md](references/alibaba-retrieval-rules.md)。
> 2. **足够详细 + 差异化**：每条满足深度门禁 D1-D6（≥250词/结构化/场景化）；KB 必须融合【国际站内部 A】+【客户提供 B】+【外部检索 C：官网/公域/社媒】三源，正向挖掘并放大商家**差异化优势**。详见 [content-depth-and-sourcing.md](references/content-depth-and-sourcing.md)。
> 3. **零幻觉**：外部信息按 T1-T5 来源分级；5 类红线即使在官网/社媒看到也必须商家确认才写；No Evidence No Claim，所有优势点须有证据文件可反查。**子代理为"显得详细"最易编造交期天数/样品费金额/质保拆分/金额门槛 —— 这些是高危幻觉，必须审计清除**。
> 4. **交付完整（防偷工减料）**：每模块 ≥10 篇（6模块共 ≥60 篇）；中文目录结构齐全；DOCX镜像 + 客户图册PDF + 评分报告 + 上传指引齐全。**交付前必须跑 `scripts/delivery_audit.py` 审计，FAIL=0 且 WARN 全部人工核对后方可交付**。详见 [audit-templates.md](references/audit-templates.md)。
>
> ⚠️ **目录命名铁律**：所有产出文件夹（含子文件夹）**用中文**（如 `知识库_对客/英文/01_公司信息/`），禁止 `KB_PUBLIC/01_company_info`。单篇 .md 文件名可英文小写下划线。详见 [中文目录规范.md](references/中文目录规范.md)。
>
> ⚠️ **本机环境限制（已知）**：本机 Accio Python 的 PIL/lxml/reportlab 有代码签名问题。**所有 DOCX/PDF 生成必须走 office-suite 子代理**，不要在主流程用 python 硬扛。

---

# 📖 第一章 · 商家视图（7 Stage Gate（含 Stage 5.5） · 对外可见）

## 我能为商家做什么

**输入**：商家 path（A 已开通+MCP / B 潜客 / C 已开通无 MCP） + 商家手册 + 13 项决策选择
**输出**：一套完整、可上传、零风险残留的多语种 AI 知识库
- 三语种 Public 知识库（默认 EN + 派生 2 语种 = 177 篇 .md）
- 全部 .docx 镜像（与 .md 一一对应）
- 物理隔离的 INTERNAL 内部资产（价格矩阵/谈判禁忌/竞品情报/销售训练话术/战例）
- 5 风格可选的营销素材包
- AI 应答模拟报告（Top N 问题预演 + 30 分制评分）
- P0/P1/P2 修复迭代日志
- README + UPLOAD_GUIDE + SPEC_LOCKED + VERIFICATION_REPORT
- B 路径专属：ONBOARDING_GUIDE.md（国际站入驻指引）

---

## 🎯 7 Stage Gate（含 Stage 5.5） 总览

| Stage | 名称 | 必产出文件 | 强制门禁 | 商家互动 |
|-------|------|----------|---------|---------|
| **Stage 0** | 商家信息收集 | `VERIFIED_MERCHANT_INFO.md` | Card 0 必答 | 上传手册 / 拒绝 |
| **Stage 0.5** | Path 路由 | （无文件） | Card 2 必选 A/B/C | 选 A/B/C |
| **Stage 1** | 公司+产品逐字段确认 | `CONFIRMED_COMPANY_PRODUCT.md` | Card 1 全部字段确认 | 逐字段 ✅/❌/⚠️ |
| **Stage 2** | 市场调研 | `MARKET_RESEARCH_REPORT.md` | spawn `agents/09_market_researcher.md` | 等待 |
| **Stage 3** | 优势对齐 | `CONFIRMED_ADVANTAGES.md` | Card 3 全部优势项确认 | 逐项 ✅/❌/🌟 |
| **Stage 4** | KB 生成（按 Path 分流） | `KB_PUBLIC/`, `99_INTERNAL_ONLY/`, 营销素材 | 按 path_existing/path_prelaunch/path_hybrid 执行 | 等待 |
| **Stage 5** | 独立评分 + 修复 | `AI_RESPONSE_SIMULATION.md` | spawn 全新独立 `05_ai_simulator` | 等待评分结果 |
| **Stage 5.5** | Catalog PDF 生成（v1.2 新增）| `CATALOG/*.pdf` + `_selection.json` + `CATALOG_BRIEF.md` | spawn `12_catalog_designer`，多语种生成 | Card 4 选品确认 |
| **Stage 6** | 交付 | `VERIFICATION_REPORT.md` + 完整目录 | 必含「⚠️ 您超时未回 N 项」段落 | 接收交付 |

> ⚠️ 任何 Stage 必产出文件不存在 → 禁止进入下一 Stage。main agent 必须用 `list` / `read` 验证文件落盘。

---

## Stage 0 · 商家信息收集

### 0.0 Standard Injector — 加载质量基准（v1.2 新增 · 必跑）

> 解决"装到不同电脑产出标准差异大"的问题：把 Ray 打磨过的标准固化成可机读资产，每台 ACW 安装后首次运行自动生成本次任务的"老师傅基准"。

按 [orchestrator/03_standard_injector.md](orchestrator/03_standard_injector.md) 执行：
1. 检测 `${agent_core}/MEMORY.md` 是否含"知识库建设"历史 → 决定 brief 来源
2. 加载 `quality-gates/L1_checklist.json` + `examples/golden_outputs/` 全套
3. 写入 `<work_dir>/_meta/STANDARD_BRIEF.md`
4. 后续每次 sub-agent spawn **强制 append** 该 brief 到 task

**Gate 检查**：
- [x] STANDARD_BRIEF.md 已写入
- [x] 引用了正确的 GE 编号（GE-01 知识库 / GE-02 品牌 / GE-03 Catalog / GE-04 应答 / GE-05 评分）

### 0.1 主代理前置自检（R1.1 强制可见块）

```markdown
## 🚦 Stage 0 启动 · 前置自检
- [x] 已 read CORE_RULES.md / customer-interaction-cards.md / audit-templates.md / source-acquisition.md
- [x] 已创建商家工作目录 <店铺名>_知识库_<YYYY>Q<N>/
- 下一步：发送 Card 0 商家手册资料收集
```

### 0.2 发送 Card 0

按 [references/customer-interaction-cards.md#card-0](references/customer-interaction-cards.md) 标准 ask_user 调用。

### 0.3 按商家回答执行

| 商家回答 | 动作 |
|---------|------|
| 上传手册 | `read` 提取字段 → 写入 `VERIFIED_MERCHANT_INFO.md`，所有字段标 `source: handbook · {filename}` |
| 选「全靠 MCP+对话」| 跳过手册收集，进 0.4，但记录 `handbook_source: NONE` 用于 Stage 6 风险提示 |
| 选「我去找一下手册再回来」| 暂停 Skill，输出「等您说『手册准备好了』继续」 |
| 5 分钟超时 | 走 R6.1 默认值（按「全靠 MCP+对话」继续），写入 `TIMEOUT_DEFAULTS.md` |

### 0.4 自动信息源补充

按 [references/source-acquisition.md](references/source-acquisition.md) 优先级 P1→P4 拉数据，结果合并到 `VERIFIED_MERCHANT_INFO.md`，每字段标 source。

### 0.5 三方交叉验证（R3）

如同一字段从 ≥2 个来源拿到 → 按 source-acquisition.md 「三方交叉验证规则」生成差异表，差异表写入 `VERIFIED_MERCHANT_INFO.md` 顶部。

### 0.6 Gate 检查

```markdown
## ✅ Stage 0 Gate 检查
- [x] VERIFIED_MERCHANT_INFO.md 已写入（list 验证）
- [x] 所有字段标 source
- [x] 差异表（如有）已列入待裁决
- 下一步：Stage 0.5 Path 路由
```

不通过 → 不能进 Stage 0.5。

---

## Stage 0.5 · Path 路由

### 0.5.1 R1.1 自检

```markdown
## 🚦 Stage 0.5 启动 · 前置自检
- [x] Stage 0 Gate 已通过（VERIFIED_MERCHANT_INFO.md 存在）
- 下一步：发送 Card 2 让商家选 path A/B/C
```

### 0.5.2 发送 Card 2

按 [references/customer-interaction-cards.md#card-2](references/customer-interaction-cards.md) 标准调用。

### 0.5.3 按商家选择 read 对应 orchestrator

按 [orchestrator/00_router.md](orchestrator/00_router.md) 决策表跳转。

### 0.5.4 Gate 检查

```markdown
## ✅ Stage 0.5 Gate 检查
- [x] 商家选定 path = {A/B/C}
- [x] 已 read orchestrator/path_{existing/prelaunch/hybrid}.md
- 下一步：Stage 1 公司+产品逐字段确认
```

---

## Stage 1 · 公司+产品逐字段确认

### 1.1 R1.1 自检

```markdown
## 🚦 Stage 1 启动 · 前置自检
- [x] Stage 0.5 Gate 已通过
- [x] 已读取 VERIFIED_MERCHANT_INFO.md 中所有抓到的字段
- 下一步：分 3 组发送 Card 1（公司基础 / 认证+出口国 / 产品系列）
```

### 1.2 发送 Card 1（3 组 form）

按 [references/customer-interaction-cards.md#card-1](references/customer-interaction-cards.md) 标准调用。**严禁合并到一个 form**。

### 1.3 商家纠错处理

- ❌ 选项 → 二次 ask_user 让商家打字给正确值 → 改写 `VERIFIED_MERCHANT_INFO.md` → **回放确认**「已改为 X，对吗？」
- ⚠️ 选项 → 字段标 `[待商家补充]`，写入 `<工作目录>/PENDING_MERCHANT_INPUT.md`
- 5 分钟超时 → R6.1 全部按 ⚠️ 处理

### 1.4 写入 CONFIRMED_COMPANY_PRODUCT.md

格式：
```markdown
# 公司+产品确认结果

## 已确认字段（KB 可用）
- 公司名: ABC Co. Ltd.   `confirmed_at: ISO timestamp`
- 成立年: 2010   `confirmed_at: ...`
- 认证: ISO9001   `confirmed_at: ...`

## 待商家补充字段（KB 标 [待商家补充]）
- 工厂面积
- CE 认证

## 商家纠错记录
- 公司名 minisite 抓为 "ABC Ltd"，商家修正为 "ABC Co. Ltd."

## 产品系列覆盖范围
- 本次 KB 覆盖：Top 1 系列「Solar Street Light」（共 N 个 SKU）
```

### 1.5 Gate 检查

```markdown
## ✅ Stage 1 Gate 检查
- [x] CONFIRMED_COMPANY_PRODUCT.md 已写入（list 验证）
- [x] 所有 ❌ 字段已商家修正并回放确认
- [x] 所有 ⚠️ 字段已写入 PENDING_MERCHANT_INPUT.md
- [x] 产品系列覆盖范围明确
- 下一步：Stage 2 市场调研
```

---

## Stage 2 · 市场调研

### 2.1 R1.1 自检

```markdown
## 🚦 Stage 2 启动 · 前置自检
- [x] Stage 1 Gate 已通过
- [x] 已 read CONFIRMED_COMPANY_PRODUCT.md 获取调研对象（系列名 + 主销国）
- 下一步：spawn agents/09_market_researcher.md
```

### 2.2 spawn MarketResearcher（两条调研线，缺一不可）

按 [agents/09_market_researcher.md](agents/09_market_researcher.md) 任务包，**同时跑两条线**：

**线 1 · 同行对标**（原有）：
- 抓 8-10 家同行 minisite（每家单独 spawn 一个 browser，避免一个 browser 跑 8 家超时）
- 抓 Google Trends + 行业论坛公开问答，提炼买家高频询盘问题

**线 2 · 商家自身外部差异化取证（来源 C · v1.3.1 新增 · 强制）**：
按 [content-depth-and-sourcing.md → DA-Flow Step 2](references/content-depth-and-sourcing.md)，针对**商家自己的品牌/公司名**检索：
- 官网（自有域名）About / Factory / Cases 页
- 公域：B2B 目录、行业新闻、展会报道、海关/认证机构记录
- 社媒：LinkedIn / Facebook / YouTube / Instagram / TikTok（工厂视频、产能展示、客户评价）
- 客户口碑：review / feedback
- 每条命中**必须存 URL/截图到 `01_external_evidence/`**，写入 `DIFFERENTIATION_CANDIDATES.md`，按 T1-T5 分级标来源
- 5 分钟未返回 → R6.5 静默错误汇报 + 重试 1 次

### 2.3 R5 诚信审计

MarketResearcher 返回后，main agent 必做 [audit-templates.md 模板①](references/audit-templates.md) 诚信审计报告输出给商家。**额外核**：DIFFERENTIATION_CANDIDATES.md 中每个外部优势点是否有 `01_external_evidence/` 对应证据文件（No Evidence No Claim），查无证据的候选项标 `[待商家确认]` 不得直接进 KB。

### 2.4 Gate 检查

```markdown
## ✅ Stage 2 Gate 检查
- [x] MARKET_RESEARCH_REPORT.md 已写入（list 验证）
- [x] DIFFERENTIATION_CANDIDATES.md 已写入（来源 C 差异化候选池，每条带来源标签+证据）
- [x] 01_external_evidence/ 存有外部取证文件（截图/URL 快照）
- [x] 调研覆盖 ≥4 家同行（否则置信度=低，必须明示）
- [x] 已输出 R5 诚信审计报告（含 No Evidence No Claim 核验）
- 下一步：Stage 3 优势对齐
```

---

## Stage 3 · 优势对齐（最关键反幻觉门禁）

### 3.1 R1.1 自检

```markdown
## 🚦 Stage 3 启动 · 前置自检（最关键 Gate · 防 TANAKA_EV 类幻觉）
- [x] Stage 2 Gate 已通过
- [x] 已读取 MARKET_RESEARCH_REPORT.md「同行普遍优势」段
- [x] 已读取 DIFFERENTIATION_CANDIDATES.md（来源 C 外部差异化候选池）
- [x] 准备发送 Card 3 让商家逐项 ✅/❌/🌟
- ⚠️ 严禁批量"我都有"，商家如此回答必须二次拆解
- ⚠️ 外部(C)抓到的优势点必须商家确认才可写入（防止官网/社媒过期或夸大被当事实）
- 下一步：发送 Card 3
```

### 3.2 发送 Card 3

按 [references/customer-interaction-cards.md#card-3](references/customer-interaction-cards.md) 逐项发 form（每张卡最多 4 项，超过分多张）。
**Card 3 必须把 DIFFERENTIATION_CANDIDATES.md 的外部差异化候选点也逐条列入**，让商家裁决 ✅有据可写 / ⚠️有但不授权具名 / ❌没有删除。未确认项一律不写入 KB。

### 3.3 写入 CONFIRMED_ADVANTAGES.md

```markdown
# 商家确认优势清单

## ✅ 强口径（有第三方报告/客户授权）
- IP67 防护 — Tested per IEC 60529 → KB 用 "Certified IP67"
- EPC 客户案例 — 客户 ABC 授权使用名 → KB 用具名

## ✅ 软口径（有但无报告/客户不授权）
- 5 年质保 — 商家自承诺无第三方 → KB 用 "5-Year Warranty (Manufacturer Promise)"
- Top distributor in Saudi — 客户不授权具名 → KB 用 "Top Energy Group in Saudi Arabia"

## ❌ 商家明确没有（绝不写入 KB）
- IP68 防护
- 10 年质保

## 🌟 想加但目前没有（标 [待商家补充]）
- TUV 认证
```

### 3.4 Gate 检查

```markdown
## ✅ Stage 3 Gate 检查
- [x] CONFIRMED_ADVANTAGES.md 已写入
- [x] 所有同行优势项均已商家确认（无遗漏）
- [x] ❌ 优势项已加入「KB 黑名单」（Writer 子代理必须遵守）
- [x] 软口径与强口径分类清晰
- 下一步：Stage 4 KB 生成
```

---

## Stage 4 · KB 生成（按 Path 分流）

### 4.1 R1.1 自检

```markdown
## 🚦 Stage 4 启动 · 前置自检
- [x] Stage 3 Gate 已通过
- [x] 准备 spawn agents/01_writer.md
- [x] Writer 任务包必须含：
      - VERIFIED_MERCHANT_INFO.md（事实底座）
      - CONFIRMED_COMPANY_PRODUCT.md（公司产品白名单）
      - CONFIRMED_ADVANTAGES.md（优势白名单+黑名单，含来源 C 已确认差异化点）
      - PENDING_MERCHANT_INPUT.md（[待商家补充] 字段清单）
      - 01_external_evidence/ 路径（差异化优势的证据文件，供 Writer 引用 + 审计反查）
- [x] Writer 任务包必须强制声明三门禁：
      - 可抓取 7 铁律（alibaba-retrieval-rules.md §3）
      - 深度门禁 D1-D6（content-depth-and-sourcing.md 第一部分）
      - 零幻觉 T1-T5 分级 + No Evidence No Claim（content-depth-and-sourcing.md 第三部分）
- [x] 必须生成差异化汇总条目：01_company_info/why_choose_us.md + differentiators.md
- 当前 path: {A/B/C} → 按 orchestrator/path_{existing/prelaunch/hybrid}.md 主流程
```

### 4.2 按 path 执行

- **A**: read [orchestrator/path_existing.md](orchestrator/path_existing.md)
- **B**: read [orchestrator/path_prelaunch.md](orchestrator/path_prelaunch.md)，先 spawn `agents/10_interviewer.md` 做 2 轮访谈
- **C**: read [orchestrator/path_hybrid.md](orchestrator/path_hybrid.md)

### 4.3 每个 sub-agent 返回必做 R5 诚信审计

按 [audit-templates.md 模板①](references/audit-templates.md) 输出，**严禁简化为「已完成无问题」**。

### 4.4 Gate 检查

```markdown
## ✅ Stage 4 Gate 检查
- [x] KB_PUBLIC/EN/ 含 ≥24 篇 .md（list 验证）
- [x] 每篇通过深度门禁 D1-D6（抽样 read 验证字数/结构/无空话注水）
- [x] 每篇通过可抓取 7 铁律（产品主体/提问式标题/零占位符/Keywords 行）
- [x] why_choose_us.md + differentiators.md 已生成，每个差异化点带来源标签+证据+so-what
- [x] 所有优势点可在 01_external_evidence/ 或 00_handbook/ 反查到证据（No Evidence No Claim）
- [x] 派生语种章节数与 EN 一致（结构对齐）
- [x] 99_INTERNAL_ONLY/ 物理隔离（Public 无任何指向 INTERNAL 的链接）
- [x] 所有 sub-agent 已通过 R5 诚信审计
- 下一步：Stage 5 独立评分
```

---

## Stage 5 · 独立评分 + 修复

### 5.1 R1.1 自检（R7 评分中立强制）

```markdown
## 🚦 Stage 5 启动 · 前置自检
- [x] Stage 4 Gate 已通过
- [x] 即将 spawn 全新独立 sub-agent agents/05_ai_simulator.md
- ⚠️ R7 强制：AISimulator **不得读取 Writer 的中间产物或 system prompt**
- ⚠️ AISimulator 只能读 KB_PUBLIC/ 最终产物 + question_packs/
```

### 5.2 评分 < 25/30 触发 P0 修复

按 [agents/06_repair_engineer.md](agents/06_repair_engineer.md) 修复后**重跑 Stage 5**（再次评分），直到 ≥25/30。

### 5.3 Gate 检查

```markdown
## ✅ Stage 5 Gate 检查
- [x] AI_RESPONSE_SIMULATION.md 已写入
- [x] 评分 ≥25/30
- [x] AISimulator session 是全新独立的（未读 Writer 任何中间产物）
- 下一步：Stage 5.5 Catalog PDF 生成
```

---

## Stage 5.5 · Catalog PDF 生成（v1.2.0 新增）

### 5.5.1 Card 4 选品确认（强制门禁）

按 [references/customer-interaction-cards.md → Card 4](references/customer-interaction-cards.md) 收集 4 题：
- Q1: PDF 模式（company_only / catalog_only / full_brochure）
- Q2: 选品范围（all / top_manual / ai_recommend）
- Q3: 多语种
- Q4: 营销钩子套餐

5 分钟超时 → 默认 `full_brochure / ai_recommend / EN+主销 / 标准钩子`，写入 `TIMEOUT_DEFAULTS.md`。

### 5.5.2 Spawn 12_catalog_designer

```bash
sessions_spawn agent_id=general task="<标准基准 brief> + 按 Card 4 brief 执行
- read agents/12_catalog_designer.md 全文
- read references/catalog-design-spec.md
- read examples/golden_outputs/GE-03_catalog_pdf_reference.md
- 跑 templates/catalog_pdf/generate_catalog.py 多语种生 PDF
- 输出到 <work_dir>/CATALOG/{brand}_catalog_{lang}.pdf"
```

### 5.5.3 必产出文件

- `CATALOG/{brand}_catalog_{lang}.pdf`（每语种 1 份）
- `CATALOG/_selection.json`（最终选品数据）
- `CATALOG/_selection.md`（人类可读版）
- `CATALOG/_generation_log.md`（每步日志）
- `_meta/CATALOG_BRIEF.md`（Card 4 决策记录）

### 5.5.4 质量门禁（quality-gates/L1.G5_5.x）

- G5_5.1: Card 4 必填
- G5_5.2: PDF 大小 ≥ 50KB（小于则可能图片未嵌入 → 触发 L3 重做）
- G5_5.3: About Us 字数 ≥ 100
- G5_5.4: 每产品页含 5 卖点 + MOQ + 价格 + CTA
- G5_5.5: 认证 ≥ 3 项（无证商家允许跳过但需记录）

### 5.5.5 Gate 检查

```markdown
## ✅ Stage 5.5 Gate 检查
- [x] CATALOG_BRIEF.md 已写入（Card 4 决策记录）
- [x] PDF 文件落盘 + 每个 ≥ 50KB
- [x] _generation_log.md 含每语种执行结果
- [x] L1.G5_5.x 全部 P0 通过
- 下一步：Stage 6 交付
```

---

## Stage 6 · 交付

### 6.1 必加段落 — 超时未回汇报

按 [audit-templates.md 模板③](references/audit-templates.md) 套用 R6.1 模板，把整个 Skill 执行过程中所有 ask_user 超时未回的项汇总成「⚠️ 您超时未回 N 项」段落。

### 6.2 必加段落 — 风险/降级提示（path C 专属）

如选 path C（无 MCP）→ 必加「准确度自评：80%」段落（按 [path_hybrid.md](orchestrator/path_hybrid.md) 模板）。

### 6.3 写入 VERIFICATION_REPORT.md

```markdown
# 验收报告

## 路径 + 准确度
- Path: {A/B/C}
- 自评准确度: {95%+ / 推测+访谈 / 80%}

## 文件清单
- KB_PUBLIC: 24 篇 EN + 24 篇 ES + 24 篇 RU = 72 篇
- 99_INTERNAL_ONLY: 5 类资产
- 营销素材: 5 风格各 N 张
- AI 评分: 27.5/30

## ⚠️ 您超时未回 N 项
[模板③ 表格]

## 商家可执行的下一步
- 补充 [待商家补充] 字段（共 K 个）→ 我可重跑 P0 修复
- KB_PUBLIC/ 全部 .md → ① 商家自用员工检索/培训；② 接入 Accio Work 生意助手作为问答数据源；③ v1.2 起可生成 PDF Catalog 发给客户参考
- 99_INTERNAL_ONLY 严禁外传（含买家、AI、客户），仅供员工内部使用
```

### 6.4 Gate 检查

```markdown
## ✅ Stage 6 Gate 检查 + 交付
- [x] VERIFICATION_REPORT.md 已写入
- [x] 「⚠️ 您超时未回」段落已加（即使 N=0 也加，写「无超时项」）
- [x] path C 已加「准确度 80%」段落
- ✅ Skill 执行成功，向商家展示交付摘要
```

---

## 工作目录约定

商家的知识库产出位置：**workspace 根目录下** `<店铺名>_知识库_<YYYY>Q<N>/`，例如 `XINTONG_知识库_2026Q2/`。

```
<店铺名>_知识库_<YYYY>Q<N>/
├── README.md
├── SPEC_LOCKED.md
├── VERIFIED_MERCHANT_INFO.md         (Stage 0 产出 · 事实底座)
├── CONFIRMED_COMPANY_PRODUCT.md      (Stage 1 产出)
├── PENDING_MERCHANT_INPUT.md         (Stage 1 [待商家补充] 字段清单)
├── MARKET_RESEARCH_REPORT.md         (Stage 2 产出)
├── CONFIRMED_ADVANTAGES.md           (Stage 3 产出)
├── TIMEOUT_DEFAULTS.md               (R6.1 中间档存)
├── VERIFICATION_REPORT.md            (Stage 6 产出)
├── AI_RESPONSE_SIMULATION.md         (Stage 5 产出)
├── KB_PUBLIC/
│   ├── EN/  (主语种，必有)
│   └── <派生语种 N>/
├── DOCX_VERSIONS/
├── 99_INTERNAL_ONLY/
│   ├── price_matrix/
│   ├── negotiation_taboos/
│   ├── competitor_intelligence/
│   ├── sales_training/
│   └── deal_case_studies/
├── 04_营销素材/
└── 01_browser_evidence/              (path C 专属 · browser 截图证据)
```

---

# ⚙️ 第二章 · AI 执行约束（对内硬规则 · 不可妥协）

> 这部分商家不会看，但**所有执行 AI 必须 100% 遵守**。任何一条违反都是缺陷。

## 硬规则 R1 — 强制 Stage Gate 不可跳过

| 门禁 | 触发位置 | 违反后果 |
|------|---------|---------|
| Stage 0 Gate | VERIFIED_MERCHANT_INFO.md 必须 list 验证存在 | 后续所有 sub-agent 没有事实底座 → 全面幻觉 |
| Stage 1 Gate | CONFIRMED_COMPANY_PRODUCT.md 必须含商家逐字段 ✅ 记录 | KB 把抓错的公司名/品类写进 177 篇文档 → 商家全删返工 |
| Stage 3 Gate | CONFIRMED_ADVANTAGES.md 必须含 ❌ 黑名单 | KB 把同行宣称的优势当作您家的写 → 虚假宣传投诉拒付 |
| Stage 5 Gate | AISimulator 必须独立 session | 评分虚高（自家评自家），商家上线后买家应答崩塌 |

---

## 硬规则 R1.1 — Stage 切换前置自检（强制可见块）

**这是 v1.1.0 最关键的反"宣称式约束"机制**。

每个 Stage 开始前，main agent **必须**输出一个 `## 🚦 Stage N 启动 · 前置自检` 块（含勾选项 + 下一步说明），格式见第一章每个 Stage 的 R1.1 段落。

| 严禁 | 后果 |
|------|------|
| ❌ 把自检藏在 think 块里不输出 | = 违反 R1.1 |
| ❌ 输出但勾选项造假（自检显示 ✅ 但实际未做）| = 违反 R1.1 |
| ❌ 跳过自检直接 spawn sub-agent | = 违反 R1.1 |

商家可凭此自检块**实时质问**：「你说 read 了 CORE_RULES.md，那 R5 诚信审计的 5 项硬拦截是哪 5 项？」

---

## 硬规则 R2 — 信息源优先级

详见 [references/source-acquisition.md](references/source-acquisition.md)。

P1 商家手册 → P2 MCP → P3 Browser → P4 MarketResearcher（推测）。

| 严禁 | 后果 |
|------|------|
| ❌ 跳过 P1 直接 P2/P3 | TANAKA_EV 类幻觉 |
| ❌ P4 推测当事实写入 KB | 虚假宣传 |

---

## 硬规则 R3 — 三方交叉验证 + 视觉/语义对齐

详见 [references/source-acquisition.md](references/source-acquisition.md) 「三方交叉验证规则」+「A.4.5 原图视觉对齐」。

差异未裁决 → 不能进入 KB 主文。

---

## 硬规则 R4 — 5 类红线反幻觉

详见 [CORE_RULES.md](CORE_RULES.md) R4 段。

5 类红线（MOQ / 认证 / 客户名 / 销量 / 工厂面积）必须经 Card 1/3 商家确认；未确认必标 `[待商家补充]`。

---

## 硬规则 R5 — 主代理诚信审计协议

详见 [references/audit-templates.md 模板①](references/audit-templates.md)。

每个 sub-agent 返回必做诚信审计 5 项硬拦截，**严禁简化为「已完成无问题」一句话**。

| 严禁 | 后果 |
|------|------|
| ❌ 审计发现问题但不向商家报告（隐瞒缺陷）| 比不审计更糟 |
| ❌ 把审计结果藏在 think 块 | = 违反 R5 |
| ❌ 用 mock 数据填充缺失字段后假装通过 | = 违反 R5 + R4 |

---

## 硬规则 R6 — 失败处理

### R6.1 — 超时未回 → 安全默认值 + 最终交付汇报

详见 [references/audit-templates.md 模板③](references/audit-templates.md)。

5 分钟超时 → 不死等 → 走安全默认值 → 写入 `TIMEOUT_DEFAULTS.md` → Stage 6 必加「⚠️ 您超时未回 N 项」段落。

### R6.5 — 静默错误必须用户可见汇报

详见 [references/audit-templates.md 模板②](references/audit-templates.md)。

任何工具错误（bash/spawn/MCP/web_fetch）→ 立即输出 `[⚠️ 工具错误]` 块。

| 严禁 | 后果 |
|------|------|
| ❌ 静默吞错继续往下走 | = 违反 R6.5 |
| ❌ 假装成功用 mock 填位 | = 违反 R6.5 + R4 |

---

## 硬规则 R7 — 评分中立

AISimulator 必须**全新独立 session**，**不得读取**：
- Writer 的 system prompt
- Writer 的中间产物（草稿/修改记录）
- 任何 sub-agent 的内部 think

只能读：
- ✅ KB_PUBLIC/ 最终产物（商家自用 / 接入 Accio Work 生意助手 / 给客户参考的对外可见内容）
- ✅ question_packs/ 模拟问题包

| 严禁 | 后果 |
|------|------|
| ❌ AISimulator 读 Writer 草稿 | 评分虚高，商家上线翻车 |
| ❌ AISimulator 与 Writer 同一 session | 同上 |

---

## 关键约束（不可违反 · 来自 v1.0 沉淀）

1. **物理隔离 99_INTERNAL_ONLY/**：Public 文档绝不能含训练标签（Bad/Good/Pro Talk）、不能直接点名竞品、不能含指向 INTERNAL 的链接
2. **多语种结构对齐**：EN + 派生语种章节数和顺序必须一致
3. **真实数据原则**：不虚构认证、客户证言、市占率、年指标、折扣%、MOQ
4. **修复阈值**：AI 应答模拟评分 < 25/30 必须触发 P0 修复后才能交付
5. **多店铺防错配**：当前对话最近 20 条消息中没有线索表明商家就是 MERCHANT_PROFILE 中的店铺时，整体跳过回填，全部走 Card 0/1 重新收集

---

## 包结构索引

- [README.md](README.md) — 商家视角介绍
- [VERSION](VERSION) — 当前版本号
- [CHANGELOG.md](CHANGELOG.md) — 版本变更日志
- [CORE_RULES.md](CORE_RULES.md) — R1-R7 硬规则原文（v1.0.4 起）
- [orchestrator/](orchestrator/) — 编排层
  - [00_router.md](orchestrator/00_router.md) — Path A/B/C 路由（v1.1.0 新增）
  - [path_existing.md](orchestrator/path_existing.md) — A 路径主流程
  - [path_prelaunch.md](orchestrator/path_prelaunch.md) — B 路径主流程
  - [path_hybrid.md](orchestrator/path_hybrid.md) — C 路径主流程（v1.1.0 新增）
  - [00_intake_form.md](orchestrator/00_intake_form.md) — 13 问问卷
  - [01_spec_lock_template.md](orchestrator/01_spec_lock_template.md) — Spec 锁定模板
  - [00_intake_round1.md](orchestrator/00_intake_round1.md) / [00_intake_round2.md](orchestrator/00_intake_round2.md) — B 路径访谈
- [agents/](agents/) — 11 个 sub-agent prompt 模板
- [references/](references/) — v1.1.0 新增三件套
  - [customer-interaction-cards.md](references/customer-interaction-cards.md) — 4 张标准互动卡
  - [audit-templates.md](references/audit-templates.md) — 3 个审计/汇报模板
  - [source-acquisition.md](references/source-acquisition.md) — 信息源 + 视觉对齐 + 三层降级
- [templates/](templates/) — 文档/报告/骨架模板
- [question_packs/](question_packs/) — 8 行业 AI 模拟问题包
- [style_presets/](style_presets/) — 5 套营销素材生图风格
- [scripts/](scripts/) — 自动化脚本（pandoc 批量、风险扫描、对齐校验）
- [evolution/](evolution/) — 跨商家累积的盲点/规则/失败模式数据池
- [checklists/SUBMISSION_CHECKLIST.md](checklists/SUBMISSION_CHECKLIST.md) — 提交前自检清单
- [HOW_TO_USE.md](HOW_TO_USE.md) — 安装与使用
- [INSTALL.sh](INSTALL.sh) / [INSTALL.bat](INSTALL.bat) / [INSTALL.ps1](INSTALL.ps1) — 安装脚本
