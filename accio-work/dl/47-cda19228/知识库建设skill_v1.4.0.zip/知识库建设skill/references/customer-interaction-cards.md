# 标准商家互动卡片库 · v1.1.0

> 本文件是知识库 Skill v1.1.0 的**对外对话标准化模板**，所有卡片必须用 `ask_user` 工具发送（不要把这些写成普通 markdown 直接 print）。
>
> 设计原则（参考图片技能 v2.0.2 customer-interaction-cards.md）：
> 1. 每张卡片对应一个 Stage Gate，不通过不能进下一步
> 2. 每张卡都给「商家典型回答与应对脚本」，避免不同 main agent 应对方式漂移
> 3. 商家说"按你的来""默认就行""你看着办"时，**仍要把默认值完整复述让商家口头确认**（避免事后扯皮）
> 4. 所有 form 卡片的 question 必须含 `?` 或 `？`（API 强制要求）

---

## Card 0 · 商家手册资料收集（Stage 0 强制门禁）

**触发位置**：Skill 启动后的第一句话，**先于** MCP 调用、**先于**任何抓数据动作。

**目的**：图片技能 R1.2 的同款思路 — 抓数据前先问商家有没有现成手册，避免 MCP/browser 抓回来的不一致数据没东西校准。

### 标准 ask_user 调用

```python
ask_user(
  mode="form",
  questions=[
    {
      "question": "开始建知识库前，您手头是否有以下任一现成资料可以上传？（可多选）",
      "header": "手册资料",
      "multiSelect": True,
      "allowSkip": False,  # ← 强制必答（不允许跳过，否则后面交叉验证没基准）
      "options": [
        {"label": "产品手册/Catalog", "description": "PDF/Word/JPG 都可以，含产品参数、规格、应用场景"},
        {"label": "公司介绍/About Us", "description": "公司简介、工厂照片、团队、资质，PDF/Word/PPT 均可"},
        {"label": "SKU 总表", "description": "Excel/CSV，含 SKU 编号、名称、参数、价格"},
        {"label": "认证扫描件 + 工厂照片", "description": "ISO/CE/RoHS 等证书扫描件，工厂车间照片"}
      ]
    },
    {
      "question": "如果上面都没有，是否同意我直接走\"MCP + 对话补全\"模式？（无手册兜底，幻觉风险更高，AI 会把不确定项标 [待商家补充]）",
      "header": "无手册确认",
      "allowSkip": True,
      "recommended": 0,
      "options": [
        {"label": "同意，全靠 MCP+对话", "description": "我现在没空整理手册，先用 MCP 拉到的数据，缺的让 AI 标 [待商家补充] 我后面补"},
        {"label": "我去找一下手册再回来", "description": "暂停 Skill，我整理好手册后重新触发"}
      ]
    }
  ]
)
```

### 商家典型回答与应对脚本

| 商家回答 | 应对动作 |
|---------|---------|
| 选了「产品手册/Catalog」+ 「认证」| 用 `ask_user(mode="chat", attachmentSlot=...)` 让商家上传文件，然后 `read` 提取关键字段写入 `VERIFIED_MERCHANT_INFO.md` |
| 全部选 + 「同意全靠 MCP+对话」 | 跳过手册收集，**直接进 Stage 0.2 走 MCP**，但在 SPEC 锁定阶段必须 ⚠️ 提醒：「无手册兜底，预计 KB 中 [待商家补充] 占比 15-25%，您后续逐条补全可大幅降低 AI 应答幻觉率」|
| 「我去找一下手册再回来」 | 输出：「好的，我把当前会话的状态保留。您整理好后告诉我『手册准备好了』我们继续。」 → 不要继续推进，等待商家回 |
| 商家直接说话不点选项（[OTHER] 文字回复）| 智能解析文字内容映射到选项，并复述确认：「您说『我们手册都是英文版，主要是 catalog 和 ISO9001 证书』→ 已记录为 [产品手册] + [认证]，对吗？」|
| 5 分钟超时未回 | 走 R6.1 超时降级：默认按「同意全靠 MCP+对话」继续，但在最终交付时专门列出「您超时未回决策」段落，提示后期可补手册 |

---

## Card 1 · 公司+产品逐字段确认（Stage 1 强制门禁）

**触发位置**：Stage 0 的 MCP / browser / 手册抓取完成、写入 `VERIFIED_MERCHANT_INFO.md` 之后，**Stage 2 市场调研之前**。

**目的**：用户拍板的"逐字段确认"粒度 — 6-10 个字段每个都让商家在 ✅正确 / ❌错误 / ⚠️未知 三选一，错误的让商家直接打字改，未知的标 `[待商家补充]`。**这是反幻觉的核心门禁**，TANAKA_EV 当时的"Sport-S 130km 续航等编造"就是因为没有这一关。

### 标准做法

把所有抓到的字段拆成 4 个 form question（每个 question 1-3 个字段，避免单卡超过 4 个 question 上限）。**严禁在一个 question 里把 6 个字段塞成 1 个题**。

### 标准 ask_user 调用 — 第 1 组（公司基础信息）

```python
ask_user(
  mode="form",
  questions=[
    {
      "question": "公司名称我抓到的是 \"{抓到的公司名}\"，对吗？",
      "header": "公司名",
      "allowSkip": False,
      "options": [
        {"label": "✅ 完全正确", "description": "{抓到的公司名}"},
        {"label": "❌ 错误（请下方告诉我正确名）", "description": "我会再问您一次正确写法"},
        {"label": "⚠️ 不太确定", "description": "标 [待商家补充]，先继续，您后面查到了告诉我"}
      ]
    },
    {
      "question": "公司成立年份是 {抓到的年份}，对吗？",
      "header": "成立年份",
      "allowSkip": False,
      "options": [
        {"label": "✅ 正确", "description": "{抓到的年份}"},
        {"label": "❌ 错误", "description": "我会再问正确年份"},
        {"label": "⚠️ 不知道", "description": "标 [待商家补充]"}
      ]
    },
    {
      "question": "工厂面积我看到 \"{抓到的面积} ㎡\"，对吗？",
      "header": "工厂面积",
      "allowSkip": False,
      "options": [
        {"label": "✅ 正确", "description": "{抓到的面积} ㎡"},
        {"label": "❌ 错误", "description": "请告诉我实际面积"},
        {"label": "⚠️ 没量过/不便公开", "description": "标 [待商家补充]，AboutUs 不展示工厂面积"}
      ]
    },
    {
      "question": "员工人数 \"{抓到的人数}\"，对吗？",
      "header": "员工人数",
      "allowSkip": False,
      "options": [
        {"label": "✅ 正确", "description": "{抓到的人数}"},
        {"label": "❌ 错误", "description": "请告诉我实际人数（区间也行，如 50-100）"},
        {"label": "⚠️ 不便公开", "description": "标 [待商家补充]"}
      ]
    }
  ]
)
```

### 标准 ask_user 调用 — 第 2 组（认证 + 出口国）

```python
ask_user(
  mode="form",
  questions=[
    {
      "question": "我从 minisite 抓到的认证有 \"{cert1}, {cert2}, {cert3}\"，是否全部真实在手且仍在有效期内？",
      "header": "认证",
      "allowSkip": False,
      "options": [
        {"label": "✅ 全部真实且有效", "description": "可以直接用于 KB"},
        {"label": "❌ 部分错误", "description": "请告诉我哪几张错（编号 1-N）"},
        {"label": "⚠️ 我得查一下证书", "description": "未确认的认证全部标 [待商家补充]，KB 不会写"}
      ]
    },
    {
      "question": "主要出口国我识别为 \"{country1}, {country2}, {country3}\"，对吗？（基于 minisite + 询盘记录）",
      "header": "出口国",
      "allowSkip": False,
      "options": [
        {"label": "✅ 完全正确", "description": "用此清单做 AboutUs 地图打点"},
        {"label": "❌ 部分错误（含已停止的）", "description": "请告诉我要删/加哪些"},
        {"label": "⚠️ 不知道有没有真订单", "description": "改写为口径 B「曾发样到 X 国」，不打地图点"}
      ]
    }
  ]
)
```

### 标准 ask_user 调用 — 第 3 组（产品系列）

```python
ask_user(
  mode="form",
  questions=[
    {
      "question": "我从后台 + minisite 识别出您共 {N} 个产品系列：{系列名表 + 商品数}。系列划分准确吗？",
      "header": "产品系列",
      "allowSkip": False,
      "multiSelect": False,
      "options": [
        {"label": "✅ 完全准确", "description": "按此 N 个系列建 KB"},
        {"label": "🔀 需要合并/拆分", "description": "请告诉我哪几个要合/拆"},
        {"label": "❌ 系列识别完全错", "description": "请重新告诉我您的真实系列划分"}
      ]
    },
    {
      "question": "本次知识库要覆盖哪些系列？（多选，建议先做询盘量最高的 1-3 个，后续补）",
      "header": "覆盖范围",
      "allowSkip": False,
      "multiSelect": True,
      "options": [
        {"label": "Top 1（询盘最高）", "description": "{系列1名}"},
        {"label": "Top 2", "description": "{系列2名}"},
        {"label": "Top 3", "description": "{系列3名}"},
        {"label": "全部系列", "description": "全 {N} 个系列都做（工作量翻倍，不建议首次）"}
      ]
    }
  ]
)
```

### 商家典型回答与应对脚本

| 商家回答 | 应对动作 |
|---------|---------|
| 全部 ✅ | 写入 `CONFIRMED_COMPANY_PRODUCT.md`，进 Stage 2 |
| 「公司名」选 ❌ → 商家用 `[OTHER] 我们正式名是 XYZ Co. Ltd.」| 改写 `VERIFIED_MERCHANT_INFO.md` 公司名字段，**回放确认**：「已改为 XYZ Co. Ltd.，对吗？」再走一遍 form |
| 「工厂面积」选 ⚠️ | 在 `VERIFIED_MERCHANT_INFO.md` 该字段标 `[待商家补充]`，AboutUs 文档生成时跳过 area 字段 |
| 「认证」选 ⚠️ | **所有未确认的认证全部不进 KB**，并在最终交付报告里专门列「⚠️ 您未确认的认证 N 项，已从 KB 移除，确认后告诉我即可加回」 |
| 「产品系列」选 🔀 → 商家说「Solar Street Light 和 Solar Garden Light 要合并成 Outdoor Solar Light」| 合并系列后**重新生成系列清单**给商家二次确认，二次 ✅ 后才进 Stage 2 |
| 商家直接发整段文字纠错（不点选项）| 智能解析所有错误点 → 按字段一条条复述：「您说的我理解为：① 公司名改成 XYZ ② 成立年改 2008 ③ 认证只有 ISO9001 真实，CE 还在申请。对吗？」 → 再确认一次再写 |
| 5 分钟超时未回 | 走 R6.1：所有未确认字段全部按 ⚠️ 处理（标 [待商家补充] 不写入 KB），继续 Stage 2，最终交付列「您超时未回 N 项」 |
| 商家说「我都已经写在手册里了你自己看」| 复述：「明白，我会以您手册里的 \"{字段=值}\" 为准。但有 K 个字段手册没提到（…），这几个能麻烦您回一下吗？」对手册外字段仍要走 form |

---

## Card 2 · Path A/B/C 路径分流

**触发位置**：Stage 0 手册收集 + 商家信息抓取完成后，**Stage 1 字段确认之前**。判断走哪条主流程。

### 标准 ask_user 调用

```python
ask_user(
  mode="form",
  questions=[
    {
      "question": "您当前的国际站状态是？（决定走哪套主流程）",
      "header": "店铺状态",
      "allowSkip": False,
      "recommended": 0,
      "options": [
        {
          "label": "A. 已开通且授权了 MCP",
          "description": "我们用国际站后台数据 + 您的手册 + 同行调研，最完整。预计耗时 60-90 分钟"
        },
        {
          "label": "B. 还没开通国际站（潜客）",
          "description": "我们走\"同行调研 + 访谈您 + AI 推测\"模式，并附入驻指引。预计耗时 90-120 分钟"
        },
        {
          "label": "C. 已开通但暂时拿不到 MCP 数据",
          "description": "我们用 browser 抓您的 minisite + 手册 + 同行调研。预计耗时 75-100 分钟"
        }
      ]
    }
  ]
)
```

### 商家典型回答与应对脚本

| 商家回答 | 应对动作 |
|---------|---------|
| A | `read orchestrator/path_existing.md` 进 A 路径主流程 |
| B | `read orchestrator/path_prelaunch.md` 进 B 路径，**先 spawn `agents/10_interviewer.md` 做 2 轮访谈** |
| C | `read orchestrator/path_hybrid.md` 进 C 路径，**先 spawn browser 抓 minisite** |
| 商家说「我也不知道 MCP 是什么」| 复述：「简单说就是：您能不能在生意助手里直接看到自己国际站的商品列表？能 → 选 A；不能 → 看您是没开店还是开了但插件没装」 |
| 商家说「我开店但你别用 MCP，直接帮我建」| 走 C 路径，并在最终交付报告里 ⚠️ 提醒：「您选择不用 MCP，本次 KB 中商品规格全部基于 minisite 抓取 + 您手册补充，未做 MCP 校准，准确度 80% 左右，建议补上 MCP 后我们重跑校准」 |

---

## Card 3 · 优势逐项对齐确认（Stage 3 强制门禁）

**触发位置**：Stage 2 市场调研产出 `MARKET_RESEARCH_REPORT.md`（含「同行普遍优势 + 买家关注点 + 您可能的差异化点」三节）之后，**Stage 4 KB 生成之前**。

**目的**：避免 MarketResearcher 抓到的"同行宣称的卖点"被直接当作您的卖点写入 KB（这是 TANAKA_EV 案例里"善意夸大变成虚假宣传"的根因）。**逐项让商家选 ✅有 / ❌无 / 🌟想加上**，而非默认全部接受。

### 标准 ask_user 调用（按优势项逐 question 提问）

每张卡最多 4 个 question，超过 4 项分多张卡。

```python
ask_user(
  mode="form",
  questions=[
    {
      "question": "调研发现同行普遍宣称「{优势1，如 IP67 防护}」。您家产品具备这一优势吗？",
      "header": "优势1: IP67",
      "allowSkip": False,
      "options": [
        {"label": "✅ 有，且有第三方测试报告", "description": "进 KB 并附 \"Tested per IECxx\" 字样"},
        {"label": "✅ 有，但没正式报告", "description": "进 KB 但描述用 \"Designed for IP67-level protection\" 软口径"},
        {"label": "❌ 没这个优势", "description": "不写入 KB，避免虚假宣传"},
        {"label": "🌟 想加上但目前还在做", "description": "标 [待商家补充] 等您拿到报告后补"}
      ]
    },
    {
      "question": "调研发现「{优势2，如 5 年质保}」是这个赛道的强买家关注点。您家敢承诺多少年质保？",
      "header": "优势2: 质保",
      "allowSkip": False,
      "options": [
        {"label": "5 年", "description": "进 KB \"5-Year Warranty\""},
        {"label": "3 年", "description": "进 KB \"3-Year Warranty\"，并加买家询盘话术：\"5-year extended warranty available on request\""},
        {"label": "1 年", "description": "进 KB \"1-Year Warranty\"，并标记 ⚠️ 此项可能影响询盘转化（同行普遍 3-5 年）"},
        {"label": "尚未规定", "description": "标 [待商家补充] 不进 KB"}
      ]
    },
    {
      "question": "调研发现头部同行都在打「{优势3，如 EPC 客户案例}」标签。您家有 EPC/政府/分销项目案例吗？",
      "header": "优势3: 案例",
      "allowSkip": False,
      "options": [
        {"label": "✅ 有，且客户授权使用名称", "description": "进 KB 含客户名"},
        {"label": "✅ 有但客户不允许公开名字", "description": "进 KB 用「Top Energy Group in Saudi Arabia」匿名描述"},
        {"label": "❌ 没有真实案例", "description": "不写入 KB，绝不虚构客户名"},
        {"label": "🌟 有但现在还不便公开", "description": "标 [待商家补充]"}
      ]
    }
  ]
)
```

### 商家典型回答与应对脚本

| 商家回答 | 应对动作 |
|---------|---------|
| 全部 ✅ + 选「有第三方报告」/ 「客户授权」| 写入 `CONFIRMED_ADVANTAGES.md`，KB 用强口径描述（"Tested per…", "Project case: ABC Co."）|
| 选「有但没报告」/「客户不授权」| **必须改用软口径**（"Designed for…", "Top distributor in…"），严禁出现 "Certified" / 客户具名 |
| 选 ❌ | 该项**绝对不写入 KB**，且不能在 KB 任何角落软性暗示（如不能在 USP 列表里放「EPC-grade」字样）|
| 选 🌟「想加上」| 标 [待商家补充]，KB 中相关位置写 `<!-- TODO: 商家说想加但目前没有，等待补充 -->` |
| 商家直接打字「这些我都有」（不逐项选）| ❌ **不可接受批量"都有"**。复述：「为了避免后期被买家质疑虚假宣传，需要您 1 项 1 项告诉我"有/无/有但没报告"。我把上面 3 项整理成一个表，您按格子打 ✅/❌/🌟 给我即可」|
| 5 分钟超时未回 | R6.1：所有项默认按 ❌ 处理（绝不写入 KB），最终交付列出「⚠️ 您超时未回的优势 N 项，全部未写入 KB，您确认后告诉我即可加入」|

---

## Card R6 · 超时未回决策汇报（R6.1 标准模板）

**触发位置**：任何上述卡片商家 5 分钟内未回，main agent 按安全默认值继续推进，并在最终交付报告里**专门列出**这一段。

### 标准模板

```markdown
## ⚠️ 您超时未回的 N 项决策（已按安全默认值执行）

| # | 决策点 | 默认值 | 风险口径 | 如需改 |
|---|-------|-------|---------|-------|
| 1 | Card 0 是否上传手册 | 全靠 MCP+对话 | KB 中 [待商家补充] 占比预计 ↑ | 告诉我"我有手册"，我会让您上传后重跑 Stage 0 |
| 2 | Card 1 工厂面积 | 标 [待商家补充] | AboutUs 不展示 area 字段 | 告诉我数字即可补 |
| 3 | Card 1 认证清单 | 仅写您手册中已扫描的 | minisite 抓到但您未确认的 K 项已移除 | 告诉我"X 认证我有"，我会加回 |
| 4 | Card 3 优势 \"{name}\" | 默认 ❌ 不写入 KB | KB 卖点段相关描述已删除 | 选 ✅ + 补证据，我会加回 |
| ... | | | | |

**总览**：本次 KB 中标 `[待商家补充]` 的字段共 N 个，占总字段的 X%。建议您逐条补充后跑 P0 修复（命令：`/补充 <字段名> <值>`），AI 应答模拟评分预计可从 {当前分} 提升到 {预测分}。
```

### 安全默认值优先级（按风险从低到高）

参考图片技能 R6.1 的同款思路：

| 决策类型 | 安全默认值 | 为什么 |
|---------|----------|--------|
| 资质口径 | B 档（\"已供货 X 国\"，绝不打具体认证名/客户 logo） | 宁可保守，不可失实 |
| 优势写不写 | ❌ 不写入 | 写错 → 虚假宣传 → 投诉拒付；少写 → 信息不全 → 询盘少。前者比后者风险大 |
| 多语言 | 仅英文 | 不主动多语言，避免无效翻译消耗 |
| 系列覆盖 | Top 1 询盘最高的系列 | 工作量最小，价值最高 |
| 数字精度 | 区间或软口径 | 「5-10 年经验」比「8 年」安全；「200+ 工人」比「238 人」安全 |

---

## 通用互动原则（每张卡片都适用）

参考图片技能 v2.0.2 的 5 条原则：

1. **强制门禁不可绕过**：每个 Stage Gate 卡片对应的回答必须落到 `<工作目录>/<对应文件名>.md`，否则禁止进下一 Stage
2. **「按你的来」必须复述确认**：商家说「按你的来」「默认就行」「你看着办」时，仍要把默认值完整列出来让商家口头确认
3. **多商品/多产品系列**：每个系列单独走一次 Card 1+3，禁止合并到一个 form 里
4. **多语言**：商家选了多语言后，所有 form 默认用商家选定的主语言（如选了 ZH+EN，则商家可读中文，KB 内容是英文）
5. **5 分钟超时降级**：所有 form 都内置 5 分钟超时 → 走 R6.1 安全默认值 + 最终交付汇报

---

## 卡片版本

| 版本 | 日期 | 改动 |
|------|------|------|
| v1.1.0 | 2026-05-05 | 初版 — 吸收图片技能 v2.0.2 customer-interaction-cards.md 的双层结构（标准调用 + 典型回答应对）|

后续新增卡片必须按 Card N · 标题 / 触发位置 / 标准 ask_user 调用 / 商家典型回答与应对脚本 四段式格式。


---

## Card 4 · Catalog PDF 选品确认卡（Stage 5.5 强制门禁）

**触发位置**：Stage 5（评分 ≥ 75 通过）之后，Stage 6（交付）之前。
**目的**：让商家明确决定 Catalog PDF 的覆盖范围、模式、多语种和营销钩子，避免 sub-agent 自行假设。

### Form 字段（4 题，符合 ACW form API 上限）

| 题 | 选项 | 默认 |
|----|------|------|
| **Q1: PDF 模式？** | ① company_only（公司介绍 5 页）<br/>② catalog_only（产品手册 N 页）<br/>③ full_brochure（公司+产品完整版） | ③ |
| **Q2: 选品范围？** | ① 全店所有 SKU<br/>② 我手选（用 `_selection_template.md` 上传）<br/>③ AI 推荐（按销量/询盘 Top 10） | ③ |
| **Q3: 多语种？** | ① 仅 EN<br/>② EN + 1 个主销市场语种<br/>③ EN + ES + FR + AR + RU 全套 | ② |
| **Q4: 营销钩子套餐？** | ① 标准（CTA + MOQ + 认证 + 5 大理由）<br/>② 极简（仅产品参数）<br/>③ 强促销（标准 + 限时折扣 + 客户案例） | ① |

### 用户超时未回兜底

> 4 题任一未回 → 用默认值（③ ③ ② ①），并在交付时附说明：
> "您未回 Card 4，已用合理默认（full_brochure / AI 推荐 / EN+主销 / 标准钩子）生成。如需调整请回复'调整 Catalog'。"

### 校验规则

1. Q1=`company_only` 时 Q2 自动失效（不需要选品）
2. Q2=`top_manual` 时必须等待商家上传 `_selection_template.md`，否则不进入 5.5
3. Q3 选项 ② 时必须追问"主销市场是哪国"以决定具体语种
4. Q4=`强促销` 时必须有客户案例（≥ 3 条），否则降级为标准

### 输出落地

商家选择后写入 `<work_dir>/_meta/CATALOG_BRIEF.md`，sub-agent 12_catalog_designer 据此执行。
