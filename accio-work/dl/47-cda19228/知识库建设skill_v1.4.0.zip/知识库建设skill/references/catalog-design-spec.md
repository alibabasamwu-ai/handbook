# PDF Catalog 设计规范（v1.2.0）

> **定位**：把 KB_PUBLIC 的产品资产渲染成专业销售型 PDF 图册，**用途之一是发给重点客户参考、可上传到客户自己的 AI 工具**。

---

## 一、用户场景

商家把这份 PDF 用在哪里：

| 场景 | 用途 |
|------|------|
| 询盘高峰期 | 一键发给重点客户，"先看完 catalog 再聊" |
| 展会/招商会 | 现场扫码下载，比 PPT 更通用 |
| 客户的 AI 工具 | 客户上传到 ChatGPT/Claude 等问"你们家产品有什么差异" |
| 内部培训 | 新销售拿到完整产品图谱，快速上手 |

**核心要求**：客户拿到这份 PDF，**不需要再去问任何问题就能做出判断"要不要进一步聊"**。

---

## 二、覆盖范围（Stage 5.5 Card 4 让商家选）

| 模式 | 适用 | 数量 |
|------|------|------|
| **全店** | 完整产品库交给战略客户 | KB_PUBLIC 全部 SKU |
| **Top 手选** | 主推 SKU 给一般客户 | 商家选 5-10 款 |
| **AI 推荐** | 让助手挑明星款 | AI 按询盘量/转化率/星款标识取 Top 8 |

---

## 三、PDF 结构（v1.2 标准）

### 整体页序

```
[封面]              ← 1 页：品牌主形象 + Slogan + 联系方式
[公司一览]          ← 1 页：About Us（成立年份/工厂规模/认证）
[产品索引]          ← 1 页：所有产品的 thumbnail + 页码导航
[产品页 × N]        ← N 页：每款产品 1 页（详细规格 + 营销钩子）
[认证 & 信任墙]     ← 1 页：BSCI / CE / ISO / 客户 logo 拼接
[5 大购买理由]      ← 1 页：差异化卖点
[行动号召]          ← 1 页：CTA + 多渠道联系方式 + QR
```

总页数：**12 + N 产品**（一般 15-25 页）

### 产品页布局（一产品一页）

```
┌─────────────────────────────────────────────────┐
│  [产品中文名] / [Product English Name]   SKU#   │
│  ─────────────────────────────────────────────  │
│  ┌────────────┐  ┌──────────────────────────┐  │
│  │            │  │ KEY SPECS（关键规格表）   │  │
│  │  主图      │  │  • Model:                │  │
│  │  300×300   │  │  • Material:             │  │
│  │            │  │  • Power:                │  │
│  └────────────┘  │  • Cert: CE/RoHS         │  │
│                  └──────────────────────────┘  │
│  TOP 5 SELLING POINTS                          │
│  ✓ ...                                          │
│  ✓ ...                                          │
│  ─────────────────────────────────────────────  │
│  💰 MOQ: 100 pcs   |   💰 Price: $X.XX/pc      │
│  📞 Reply for free quote within 12h            │
└─────────────────────────────────────────────────┘
```

---

## 四、营销钩子（标准套）

每个产品页必须植入：

| 钩子 | 位置 | 内容 |
|------|------|------|
| **MOQ** | 产品页底部 | "MOQ: X pcs" 信号清晰 |
| **价格区间** | 产品页底部 | "Price: \$X-Y/pc" or "Quote on request" |
| **CTA** | 产品页底部 | "Reply within 12h for free quote" |
| **认证标签** | 规格表 | CE / RoHS / FDA / BSCI 等 |
| **联系方式** | 每页页脚 | WhatsApp / Email |

**封面 + 尾页强化**：
- 封面：品牌 Slogan + Established YYYY + Factory size
- 尾页：5 大购买理由 + QR（公司官网/WhatsApp）

---

## 五、技术栈

**Python + ReportLab**

| 选择理由 |
|---------|
| 纯 Python，macOS / Windows / Linux 全平台 |
| 无外部 binary 依赖（不需要 LaTeX / Chrome / pandoc） |
| 中文字体支持（手动注册 PingFang / 思源黑体 / SimSun） |
| 矢量化输出，文件小、清晰可放大 |
| Skill 运行环境一般已带（Python 3.x） |

依赖安装命令（一次性）：

```bash
pip3 install reportlab Pillow
```

字体文件：内置 `templates/catalog_pdf/fonts/` 目录，自带：
- `NotoSansSC-Regular.otf`（中文正文）
- `NotoSansSC-Bold.otf`（中文粗体）
- `OpenSans-Regular.ttf`（英文正文）
- `OpenSans-Bold.ttf`（英文粗体）

> 字体过大不放进 zip，改用脚本第一次跑时自动从 Google Fonts 下载到 `templates/catalog_pdf/fonts/`。

---

## 六、多语种处理

跟现有 KB 多语种对齐：

| 主语种 | 派生 | 输出文件名 |
|-------|------|----------|
| EN | （主） | `{brand}_catalog_EN.pdf` |
| ES | （派生） | `{brand}_catalog_ES.pdf` |
| FR | （派生） | `{brand}_catalog_FR.pdf` |
| AR | （派生）| `{brand}_catalog_AR.pdf` |
| RU | （派生）| `{brand}_catalog_RU.pdf` |

每个语种独立生成 1 份 PDF（避免一份杂糅多语言导致客户看不下去）。
**翻译数据源**：直接复用 KB_PUBLIC/{lang}/ 已生成的内容，不重复翻译。

---

## 七、输出位置

```
work_dir/
└── CATALOG/                       ← 新增独立目录（不混入 KB_PUBLIC）
    ├── {brand}_catalog_EN.pdf
    ├── {brand}_catalog_ES.pdf
    ├── {brand}_catalog_FR.pdf
    ├── _generation_log.md         ← 生成日志（产品数 / 页数 / 耗时）
    └── _selection.md              ← 商家选的 SKU 清单（审计用）
```

---

## 八、质量阈值（Gate）

PDF 生成完毕后，以下任一不满足即标记 ⚠️：

- [ ] 每个产品页都有主图（无图占位 → 用产品名占位 ❌ 不允许）
- [ ] MOQ + 价格 + CTA 三件套齐全
- [ ] 总页数 ≥ 10 页（少于 10 页不够"图册"质感）
- [ ] 文件大小 ≥ 500KB（太小说明图未嵌入）
- [ ] 多语种版本：每种语言独立检查同上规则
