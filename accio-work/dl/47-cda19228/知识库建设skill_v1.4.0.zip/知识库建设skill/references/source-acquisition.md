# 信息源获取 + 视觉/语义对齐 + 三层降级 · v1.1.0

> 知识库 Skill v1.1.0 起，所有数据获取必须遵循本文件规则。
> 设计参考：图片技能 v2.0.2 source-acquisition.md（PDP slug 规则 / 视觉对齐 / 三层降级）+ CORE_RULES.md R1。

---

## 优先级铁律（不可颠倒）

```
P1. 商家手册 / 公司介绍 / SKU 总表（最高真实性）
   ↓ （手册没有的字段才往下找）
P2. MCP（已授权 → 用 alibaba MCP 工具拉本店商品 / 同行公开数据）
   ↓ （MCP 不可用或字段缺失才往下找）
P3. Browser（spawn browser 抓本店 minisite / 同行 minisite / Google）
   ↓ （browser 抓不到才走最后一档）
P4. MarketResearcher（基于公开行业数据推测，结果必须标 [AI 推测]）
```

**严禁顺序**：
- ❌ 跳过 P1 直接走 P2/P3（违反 R2 商家手册问询）
- ❌ MCP 拿到了还要 browser 重抓一遍（浪费 + 容易引入差异）
- ❌ P4 推测结果当 P1/P2/P3 事实写入 KB（违反 R4 红线反幻觉）

---

## P1 · 商家手册（Stage 0 通过 Card 0 收集）

**触发**：[customer-interaction-cards.md](customer-interaction-cards.md#card-0) Card 0 商家选了任一资料类型。

### 标准动作

1. `ask_user(mode="chat", attachmentSlot={accept:["pdf","docx","xlsx","png","jpg"], maxFiles:10})` 让商家上传
2. 用 `read` 工具提取关键字段（公司名 / 成立年 / 工厂面积 / 员工数 / 认证 / 主营品类 / SKU 列表）
3. 写入 `<工作目录>/00_handbook/` 子目录保留原件
4. 关键字段写入 `VERIFIED_MERCHANT_INFO.md` 并标来源 `source: handbook · {filename}`

### 字段冲突处理

商家上传多份文件且字段冲突（如手册说 2010 成立、catalog 说 2012）→ 不要自动选 → ask_user 让商家裁决。

---

## P2 · MCP（path A 主流程）

### A.1 调用商品查询 MCP

**前提**：商家已选 path A，且 MCP 健康检查通过。

**健康检查**（main agent 在 spawn 任何 MCP 调用前必做）：
```bash
accio-mcp-cli keyword "alibaba product list"
# 看是否能列出 list_products / get_product_detail 等可用工具
# 失败信号：401/403/工具列表为空 → 立即输出 [⚠️ 工具错误] + 切到 path C
```

### A.2 PDP URL 标准构建规则（避免 302 到错页）

国际站商品 PDP URL 必须含 product_id + 含 slug，否则会 302 到推荐页：

```
✅ 正确格式：https://www.alibaba.com/product-detail/{slug-with-dashes}_{product_id}.html
❌ 错误格式：https://www.alibaba.com/product-detail/{product_id}.html  ← 没 slug，会跳转
❌ 错误格式：https://detail.1688.com/...  ← 1688 是国内站，不是国际站
```

**slug 怎么来**：从 MCP `get_product_detail` 返回字段 `subject_url_seo` 取，或者从 `subject` 字段把空格转 `-` 小写化作为兜底。

### A.3 拉商品后必做的字段校验

| 字段 | 必校验 | 失败处理 |
|------|-------|---------|
| product_id | 必须是 19 位数字 | 不是 → 跳过这条 |
| subject (产品名) | 非空 | 空 → 跳过 |
| price | 非空且数字 | 空/0 → 标 [待商家补充] |
| min_order | 非空 | 空 → 标 [待商家补充]，**不要默认填 1** |
| certifications | 数组 | **必须经 Card 1 商家确认** 才能写入 KB |
| main_image | URL 可访问 | 不可访问 → 走 A.4.5 视觉降级 |

### A.4.5 原图视觉对齐强制环节（图片技能同款）

**触发**：MCP 拉到的 `main_image` URL 用 `see_image` 抽样校验。

**校验流程**：
```python
# main agent 必须执行（不是建议）
sample_n = min(3, len(products))   # 抽前 3 个商品
for p in products[:sample_n]:
    see_image([p.main_image])       # 把图加载进上下文
    # 然后由 main agent 自检：图里的产品种类 vs subject 字段是否一致
    # 例：subject = "Solar Street Light 100W"，图里却是「室内灯泡」 → 图源污染
```

**判定不匹配后必做**：
1. 立即输出 `[⚠️ 图源污染]` 块告知商家
2. 不要继续用这批数据写 KB
3. 切到 P3 browser 抓 minisite 重校（如果是 MCP 数据有问题）
4. 或 ask_user 让商家选「这是临时换的图，请用 minisite 上的为准」

---

## P3 · Browser（path C 主流程 / path A 备援）

**触发**：path C 选定 / path A 的 MCP 失败 / A.4.5 视觉校验失败。

### B.1 抓本店 minisite

**spawn browser 子代理任务包模板**（参考图片技能 A.3.5）：

```
任务：抓取阿里巴巴国际站本店 minisite 公开信息

URL：https://{shop_subdomain}.en.alibaba.com/  
（subdomain 从商家 path C 选定后给的店铺名构造，或从用户已授权信息中读取）

抓取目标（按顺序，缺哪个标 NULL）：
1. 公司名（Company Profile 页 → Company Overview）
2. Business Type（Manufacturer / Trading / Both）
3. 主营品类 Main Products（≤5 个）
4. Year Established
5. Total Employees（区间，如 51-100 People）
6. Total Annual Revenue（区间）
7. Main Markets（地图打点的国家清单）
8. Certifications（必须是 Certifications 模块里的图标，**严禁**抓侧边栏推荐位）
9. Top 10 Products（产品列表页前 10 条 → 每条返回 {product_id, subject, main_image_url, price_range, min_order}）

约束：
- 严禁抓「Recommended」/「Sponsored」/「You may also like」等推荐位
- 每张抓到的 main_image 必须用 see_image 自校验图里的品类是否与 subject 一致，不一致返回 visual_mismatch=true
- 截图保存到 <工作目录>/01_browser_evidence/ 作为审计证据
- 返回 JSON：{company_info: {...}, certifications: [...], top_products: [{...}]}
- 5 分钟超时 → 立即返回部分结果 + status=partial
```

### B.2 抓同行 minisite（MarketResearcher 调用 browser）

由 `agents/09_market_researcher.md` 子代理执行，每个同行单独 spawn 一个 browser 任务，不要让一个 browser 跑 8 家（容易超时）。

---

## P4 · MarketResearcher（Stage 2 调研专用）

**触发**：Stage 2 市场调研。

**输入**：商家 confirmed 的产品系列名 + 主销国家
**输出**：`MARKET_RESEARCH_REPORT.md`，含：

```markdown
# 市场调研报告

## 1. 同行普遍优势（基于 N 家公开 minisite）
| 优势项 | N 家中有 X 家宣称 | 是否硬指标 |
|-------|-----------------|----------|
| IP67 防护 | 8/10 | ✅ 有第三方测试报告标准（IEC 60529）|
| 5 年质保 | 6/10 | ⚠️ 商家自宣称，无统一标准 |
| EPC 客户案例 | 4/10 | ⚠️ 部分仅匿名描述 |

## 2. 买家关注点（基于 Google + 行业论坛公开问答 N 条）
- TOP 询盘问题 1: ...
- TOP 询盘问题 2: ...
- TOP 询盘问题 3: ...

## 3. 您可能的差异化点（AI 推测，等 Card 3 商家确认）
- 推测 1: 您家产品参数 X 高于同行均值 → 适合做 USP
- 推测 2: 您家可能有 Y 优势 → 待商家确认

---
**调研覆盖**：{N} 家同行 + {M} 条公开问答 + {K} 条搜索趋势
**调研时间**：{ISO timestamp}
**置信度**：{高/中/低} — 高=N≥8, 中=N=4-7, 低=N<4
```

### 严禁

- ❌ 把"同行宣称的优势"直接写入您家 KB（必须经 Card 3 商家确认）
- ❌ 把 AI 推测的差异化点用确定语气描述
- ❌ 调研覆盖少于 4 家就给出"高置信度"结论

---

## 三层降级策略（任何 P1-P4 失败时）

参考图片技能 A.5：

### L1 — 精准重抓（自动）

- MCP 401 → 重试 1 次 + 检查授权状态
- Browser 404 → 换备选 URL（如 minisite 路径变更）
- see_image 加载失败 → 换主图 / 缩略图 URL

L1 失败 → 进 L2。

### L2 — 引导商家上传

```python
ask_user(
  mode="chat",
  question="MCP 没拉到您家 {产品系列名} 的认证图片，能直接发我几张证书扫描件吗？",
  attachmentSlot={accept:["jpg","png","pdf"], maxFiles:10, required:False}
)
```

商家上传 → 走 P1 处理；商家不上传/超时 → 进 L3。

### L3 — 标 [待商家补充]

- 该字段在 KB 中**严禁编造默认值**
- 必须显式写 `[待商家补充]` 占位
- 必须在最终交付的「⚠️ 您超时未回 N 项」段落里列出
- 严禁用 "Quality assured" / "Industry leading" 等空话填位

---

## 三方交叉验证规则（R3）

当同一字段从 ≥2 个来源拿到时，必须做差异检查：

```markdown
| 字段 | P1 手册 | P2 MCP | P3 Browser | 差异？ | 处置 |
|------|--------|--------|-----------|-------|------|
| 公司成立年 | 2012 | 2010 | 2010 | ✅ 差异 | 走 Card 1 让商家裁决 |
| 工厂面积 | 5000㎡ | NULL | 5000㎡ | ❌ 一致 | 直接写入 |
| 员工人数 | 80 | 51-100 | 50-100 | ✅ 差异（80 vs 区间）| 选区间口径 「51-100」更安全 |
```

差异表必须出现在 `VERIFIED_MERCHANT_INFO.md` 顶部，未裁决的字段不能进入 KB 主文。

---

## 文件版本

| 版本 | 日期 | 改动 |
|------|------|------|
| v1.1.0 | 2026-05-05 | 初版 — 吸收图片技能 v2.0.2 source-acquisition.md 的 PDP slug / 视觉对齐 / 三层降级 / Browser 任务包模板 |
