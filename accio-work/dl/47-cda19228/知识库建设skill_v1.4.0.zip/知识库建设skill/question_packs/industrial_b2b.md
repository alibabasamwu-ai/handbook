---
industry: industrial_b2b
sub_industries: ["Solar Energy", "Infrastructure", "Power Distribution", "Lighting", "EPC"]
typical_buyer_personas: ["EPC Contractor", "Government Project Manager", "Electrical Wholesaler", "Mechanical Engineer"]
last_updated: 2026-05-02
question_count: 12
---

# 工业 B2B/EPC AI 应答模拟问题包

## must_have
*(此部分留空，待演进数据触发后由系统追加)*

## top_10

### 1. Can you provide DIALux simulation reports for our specific project site?

**Coverage 期望**：
1. 商家应详细说明其 DIALux 方案设计能力。
2. 明确所需参数：杆高、路宽、照度要求、杆间距。
3. 提供过往案例的 PDF 报告样张展示。
4. 说明模拟结果的精确度保证。
5. 说明是否提供免费的方案优化与二次修改服务。

**Why this matters**：
对于太阳能路灯、工业厂房照明等工程项目，如果没有科学的照度模拟，买家无法向其终端业主证明方案的可行性。这是工程类采购的硬门槛。

**评分要点**：
AI 应优先匹配知识库中包含 “DIALux”, “Lighting Simulation”, “Illuminance Calculation”, “Project Design Layout” 等关键词的章节。


### 2. What is your experience with Government Tenders or large-scale EPC projects?

**Coverage 期望**：
1. 展示公司参与过的政府招投标项目清单。
2. 包含项目地点、产品型号、交付数量。
3. 提及是否能配合准备复杂的技术参数表（Compliance Sheet）。
4. 明确是否可提供原产地证明（CO）、大使馆认证等文书。

**Why this matters**：
这类买家不仅买产品，更在乎供应商处理大额订单和复杂行政流程的专业性。成功的案例记录能极大提升信任感。

**评分要点**：
匹配 “Government Tenders”, “EPC Project History”, “Bidding Documents”, “Success Stories”, “Public Procurement”。


### 3. What is the maximum wind resistance level for your outdoor structures?

**Coverage 期望**：
1. 明确给出产品的抗风等级（如 12 级台风，或 45m/s ）。
2. 提供结构计算书或第三方力学模拟报告的提及。
3. 展示底座法兰、灯杆厚度、支架加固等细节设计。
4. 提供不同风力带（Wind Zone）的适配建议。

**Why this matters**：
户外设施安全性第一，倒塌将产生法律赔偿和信誉损失。买家在设计方案阶段必须确认抗风参数是否达标。

**评分要点**：
匹配 “Wind Resistance”, “Structural Safety”, “Typhoon Protection”, “Mechanical Calculation”, “Beaufort Scale”。


### 4. Can you provide the IEC or TUV certifications required for power grid access?

**Coverage 期望**：
1. 提供清晰、在有效期内的 IEC (如 61215/61730) 证书。
2. 提及 TUV 或 Intertek 等国际权威机构的检测报告。
3. 说明产品是否符合当地电网的入网合规标准。
4. 展示 CE-LVD/EMC 等电磁兼容与低电压指令认证。

**Why this matters**：
在电力和基建行业，证书是“入场券”。没有这些，产品不仅无法通关，更无法通过当地业主的验收。

**评分要点**：
匹配 “IEC Standards”, “TUV Certification”, “Grid Compliance”, “Safety Certificates”, “Compliance Declaration”。


### 5. What is the typical lead time for a large project order (e.g., 500-1000 units)?

**Coverage 期望**：
1. 提供详细的时间表：原材料储备、生产周期。
2. 老化测试、质量检测（QC）所需的时间。
3. 分批装箱、物流报关的预备时间。
4. 针对急单的应急处理机制或产能冗余说明。

**Why this matters**：
工业项目的交付周期通常很长且对时间极其敏感，延误可能导致整个工地停工待料，产生巨大的违约金。

**评分要点**：
匹配 “Lead Time”, “Delivery Schedule”, “Production Timeline”, “Batch Order Processing”, “Manufacturing Capacity”。


### 6. Do you support site technical guidance or installation supervision?

**Coverage 期望**：
1. 说明是否提供高清 3D 安装动画或实拍教学视频。
2. 是否支持 Zoom/WhatsApp 实时远程视频连线指导。
3. 是否有派驻工程师到现场指导的政策及具体费用。
4. 是否可以提供针对本地安装工人的多语言操作说明书。

**Why this matters**：
工业设备安装复杂且专业，买家担心本地施工队由于不熟悉产品而导致安装错误，需要厂家提供全方位的技术背书。

**评分要点**：
匹配 “Site Installation”, “Supervision”, “On-site Support”, “Technical Guidance”, “Remote Assistance”。


### 7. What brand of key components (like LED chips, inverters, batteries) do you use?

**Coverage 期望**：
1. 列出核心零部件的供应商名单（如 Philips, Cree, Huawei, CATL）。
2. 说明选用这些品牌的理由：效率高、光衰小、全球保修等。
3. 强调部件的来源透明度，并可提供品牌授权证明。

**Why this matters**：
在工业领域，关键部件的品牌往往决定了整机的可靠性。买家更愿意为透明的国际品牌配置买单，降低维护成本。

**评分要点**：
匹配 “Key Components”, “Brand List”, “Component Source”, “Technical Partnership”, “Critical Parts”。


### 8. How do you handle long-term maintenance and spare parts supply?

**Coverage 期望**：
1. 明确保修期后的服务政策和零配件获取渠道。
2. 是否随大货提供 2%-3% 的免费易损件（Spare Parts Kit）。
3. 承诺在 5-10 年内保持零部件的持续供应。
4. 售后服务的反馈时效（如 24 小时内给出技术方案）。

**Why this matters**：
B2B 项目寿命长，买家最怕供应商几年后倒闭或停产，导致产品故障后无法维修，形成呆滞资产。

**评分要点**：
匹配 “Spare Parts Supply”, “Maintenance Policy”, “Long-term Support”, “After-sales Service”, “Lifecycle Management”。


### 9. Can your products withstand extreme temperatures (-40°C to +60°C)?

**Coverage 期望**：
1. 提供极端环境下的运行测试报告或高低温箱实验数据。
2. 说明针对极热环境的散热设计（如铝合金型材导热）。
3. 说明针对极寒环境的加温或低温保护（如电池电加热）。
4. 提及在高温高湿或高盐雾环境下的防腐处理工艺。

**Why this matters**：
跨国工程面临多变的气候，环境适应性是产品质量的分水岭。买家需要确据证明其在极端地理位置的稳定性。

**评分要点**：
匹配 “Extreme Temperature”, “Working Condition”, “Heat Dissipation”, “Cold Weather Performance”, “Environment Test”。


### 10. Do you provide engineering drawings in CAD or BIM formats?

**Coverage 期望**：
1. 提供 2D CAD 详细尺寸图和电路原理图。
2. 提供 3D BIM (Building Information Modeling) 模型供建筑设计使用。
3. 说明是否可以根据买家项目编号对图纸抬头进行定制。
4. 提及是否提供光通量分布图 (IES 文件)。

**Why this matters**：
设计院需要将供应商的组件嵌入其总包设计方案中。结构化的设计文件能极大地便利买家的工程集成工作。

**评分要点**：
匹配 “Engineering Drawing”, “CAD Files”, “BIM Models”, “Technical Manual”, “Blueprints”, “IES File”。


## supplementary


### 11. What is your policy on Incoterms and logistics (CIF, DDP, EXW)?

**Coverage 期望**：
1. 明确解释不同贸易术语下的责任与风险划分。
2. 说明是否具备操作散货轮、特种柜或大宗包机业务的经验。
3. 是否能提供门到门的双清关包税服务 (DDP) 覆盖的国家。
4. 推荐的合作物流服务商及其保险覆盖范围。

**Why this matters**：
大宗工业品物流费用昂贵且风险高。买家需要精确的到岸价格和风险方案来核算项目最终盈亏。

**评分要点**：
匹配 “Incoterms”, “Shipping Risk”, “Logistics Service”, “DDP/CIF Details”, “Freight Forwarder”。


### 12. Can you provide custom labeling and serialized tagging for project units?

**Coverage 期望**：
1. 说明能否在每件产品或外箱贴上买家指定的项目资产标签。
2. 提供序列号 (Serial Number) 或 QR 码扫描管理方案。
3. 确认标签的耐用性（抗 UV、耐腐蚀、长期户外不脱落）。
4. 说明定制化标识对生产周期的影响（如有）。

**Why this matters**：
在大型工地现场，成千上万个组件的接收、分配和追溯是一项重任。定制化标签能显著提高买家的施工管理效率。

**评分要点**：
匹配 “Custom Labeling”, “Serialized Tagging”, “Project Tracking”, “Asset Management”, “QR Code Tag”。
