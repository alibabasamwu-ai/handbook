# ============================================================================
# 国际站 AI 知识库生成器 — 一键安装脚本（Windows / PowerShell）
# 版本: v1.2.0
#
# 推荐用法:
#   powershell -ExecutionPolicy Bypass -File "C:\path\to\alibaba-knowledge-base-builder\INSTALL.ps1"
#
# 行为:
#   1. 自动检测 ACW + 自动选最近活跃账号
#   2. 自动识别"国际站生意助手"agent (扫描 agent-core 关键字)
#   3. 装到 agent-core/skills/{skillName}/ (ACW 真实加载位置)
#   4. 自动注册 skills.jsonc (Python 反序列化)
#   5. 自动清理 alibaba-prelaunch-kb-builder (已弃用)
#   6. 全部备份到 .bak.{时间戳}
# ============================================================================

$ErrorActionPreference = "Stop"

$SKILL_NAME = "alibaba-knowledge-base-builder"
$SKILL_DISPLAY_NAME = "知识库建设"
$DEPRECATED_SKILL = "alibaba-prelaunch-kb-builder"
$SCRIPT_DIR = $PSScriptRoot
$TS = Get-Date -Format "yyyyMMdd_HHmmss"

Write-Host "=========================================" -ForegroundColor Blue
Write-Host " 国际站 AI 知识库生成器 — 安装程序" -ForegroundColor Blue
Write-Host " 版本: v1.2.0 (Catalog PDF + agent-core 安装位置)" -ForegroundColor Blue
Write-Host "=========================================" -ForegroundColor Blue
Write-Host ""

# ============================================================================
# Step 1: 校验包完整性
# ============================================================================
Write-Host "[1/6] 检查 Skill 包完整性..." -ForegroundColor Blue

$REQUIRED = @("SKILL.md", "VERSION", "orchestrator", "agents", "templates", "references")
foreach ($f in $REQUIRED) {
    if (-not (Test-Path "$SCRIPT_DIR\$f")) {
        Write-Host "❌ 缺失必需文件/目录: $f" -ForegroundColor Red
        Write-Host "   请确认 INSTALL.ps1 跟 SKILL.md 在同一个目录里" -ForegroundColor Red
        exit 1
    }
}

$VERSION = (Get-Content "$SCRIPT_DIR\VERSION" -Raw).Trim()
$FILE_COUNT = (Get-ChildItem -Path $SCRIPT_DIR -Recurse -File).Count
Write-Host "✅ Skill 包完整 (v$VERSION, $FILE_COUNT 个文件)" -ForegroundColor Green
Write-Host ""

# ============================================================================
# Step 2: 检测 ACW + Python
# ============================================================================
Write-Host "[2/6] 检测 Accio Work 和依赖..." -ForegroundColor Blue

$ACCIO_DIR = "$env:USERPROFILE\.accio"
if (-not (Test-Path $ACCIO_DIR)) {
    Write-Host "❌ 未找到 Accio Work 目录: $ACCIO_DIR" -ForegroundColor Red
    Write-Host "   请先安装 Accio Work: https://www.accio.com" -ForegroundColor Yellow
    exit 1
}

if (-not (Test-Path "$ACCIO_DIR\accounts")) {
    Write-Host "❌ 未找到 accounts 目录" -ForegroundColor Red
    Write-Host "   请先打开 Accio Work 并登录账号" -ForegroundColor Yellow
    exit 1
}

# Python 检测
$pythonCmd = $null
foreach ($cmd in @("python3", "python", "py")) {
    try {
        $version = & $cmd --version 2>&1
        if ($LASTEXITCODE -eq 0 -and $version -match "Python 3") {
            $pythonCmd = $cmd
            break
        }
    } catch {}
}

if (-not $pythonCmd) {
    Write-Host "❌ 未找到 Python 3 (用于解析 skills.jsonc)" -ForegroundColor Red
    Write-Host "   请安装 Python 3: https://www.python.org/downloads/" -ForegroundColor Yellow
    exit 1
}

Write-Host "✅ Accio Work 已安装 + Python 可用 ($pythonCmd)" -ForegroundColor Green
Write-Host ""

# ============================================================================
# Step 3: 选择账号
# ============================================================================
Write-Host "[3/6] 选择目标账号..." -ForegroundColor Blue

$ACCOUNTS = Get-ChildItem -Path "$ACCIO_DIR\accounts" -Directory | Sort-Object LastWriteTime -Descending

if ($ACCOUNTS.Count -eq 0) {
    Write-Host "❌ 未找到任何账号" -ForegroundColor Red
    exit 1
} elseif ($ACCOUNTS.Count -eq 1) {
    $ACCOUNT_ID = $ACCOUNTS[0].Name
    Write-Host "✅ 检测到唯一账号: $ACCOUNT_ID" -ForegroundColor Green
} else {
    $ACCOUNT_ID = $ACCOUNTS[0].Name
    Write-Host "⚠️  检测到多个账号，自动选最近活跃: $ACCOUNT_ID" -ForegroundColor Yellow
}
Write-Host ""

# ============================================================================
# Step 4: 识别国际站生意助手 agent
# ============================================================================
Write-Host "[4/6] 识别国际站生意助手 agent..." -ForegroundColor Blue

$AGENTS_DIR = "$ACCIO_DIR\accounts\$ACCOUNT_ID\agents"
if (-not (Test-Path $AGENTS_DIR)) {
    Write-Host "❌ 未找到 agents 目录: $AGENTS_DIR" -ForegroundColor Red
    Write-Host "   请先在 Accio Work 中至少打开一次国际站生意助手" -ForegroundColor Yellow
    exit 1
}

$KEYWORDS = @("国际站生意助手", "Alibaba Business Assistant", "alibaba-com-seller-assistant")
$TARGET_AGENTS = @()
$ALL_AGENTS = @()

foreach ($agentDir in (Get-ChildItem -Path $AGENTS_DIR -Directory)) {
    $ALL_AGENTS += $agentDir.Name
    $coreDir = "$($agentDir.FullName)\agent-core"
    if (-not (Test-Path $coreDir)) { continue }

    $matched = $false
    foreach ($f in @("IDENTITY.md", "SOUL.md", "USER.md", "MEMORY.md")) {
        $filePath = "$coreDir\$f"
        if (-not (Test-Path $filePath)) { continue }
        $content = Get-Content $filePath -Raw -ErrorAction SilentlyContinue
        if (-not $content) { continue }
        foreach ($kw in $KEYWORDS) {
            if ($content -match [regex]::Escape($kw)) {
                $matched = $true
                break
            }
        }
        if ($matched) { break }
    }

    if ($matched) {
        $TARGET_AGENTS += $agentDir.Name
    }
}

if ($TARGET_AGENTS.Count -eq 0) {
    Write-Host "⚠️  没识别到国际站生意助手 agent" -ForegroundColor Yellow
    Write-Host "   降级方案：装到全部 $($ALL_AGENTS.Count) 个 agent" -ForegroundColor Yellow
    $TARGET_AGENTS = $ALL_AGENTS
} elseif ($TARGET_AGENTS.Count -eq 1) {
    Write-Host "✅ 识别到目标 agent: $($TARGET_AGENTS[0])" -ForegroundColor Green
} else {
    Write-Host "✅ 识别到 $($TARGET_AGENTS.Count) 个国际站生意助手 agent，将全部安装：" -ForegroundColor Green
    foreach ($a in $TARGET_AGENTS) { Write-Host "   - $a" }
}

if ($TARGET_AGENTS.Count -eq 0) {
    Write-Host "❌ 没找到任何 agent" -ForegroundColor Red
    exit 1
}
Write-Host ""

# ============================================================================
# Step 5: 安装到每个目标 agent
# ============================================================================
Write-Host "[5/6] 开始安装到 $($TARGET_AGENTS.Count) 个 agent..." -ForegroundColor Blue
Write-Host ""

$INSTALLED_COUNT = 0
$INSTALLED_PATHS = @()

# 准备 Python 注册脚本（写到临时文件，跨 PowerShell 引号陷阱）
$pyScript = @'
import json
import os
import re
import shutil
import sys

(jsonc_path, skill_name, display_name, version, install_path,
 deprecated_skill, ts) = sys.argv[1:8]

def strip_jsonc(text):
    text = re.sub(r'/\*.*?\*/', '', text, flags=re.DOTALL)
    out = []
    in_str = False
    esc = False
    i = 0
    while i < len(text):
        c = text[i]
        if esc:
            out.append(c); esc = False; i += 1; continue
        if c == '\\' and in_str:
            out.append(c); esc = True; i += 1; continue
        if c == '"':
            in_str = not in_str; out.append(c); i += 1; continue
        if not in_str and c == '/' and i + 1 < len(text) and text[i+1] == '/':
            while i < len(text) and text[i] != '\n':
                i += 1
            continue
        out.append(c); i += 1
    return ''.join(out)

records = []
wrapper_key = None  # 'skills' / None
if os.path.exists(jsonc_path):
    shutil.copy(jsonc_path, jsonc_path + f'.bak.{ts}')
    with open(jsonc_path, 'r', encoding='utf-8') as f:
        raw = f.read()
    try:
        parsed = json.loads(strip_jsonc(raw))
        if isinstance(parsed, list):
            records = parsed; wrapper_key = None
        elif isinstance(parsed, dict) and isinstance(parsed.get('skills'), list):
            records = parsed['skills']; wrapper_key = 'skills'
        else:
            records = []; wrapper_key = 'skills'
    except Exception as e:
        print(f"  WARN: skills.jsonc 解析失败 ({e})，保持空", file=sys.stderr)
        records = []; wrapper_key = 'skills'

# 清理过期/失效记录
def is_stale(r):
    ip = r.get('installPath', ''); en = r.get('entryName', '')
    if '.bak.' in ip or ('.bak.' in en):
        return True
    if ip and not os.path.exists(ip):
        return True
    return False
records = [r for r in records if not is_stale(r)]

description = ""
skill_md = os.path.join(install_path, "SKILL.md")
if os.path.exists(skill_md):
    with open(skill_md, 'r', encoding='utf-8') as f:
        in_fm = False
        for line in f:
            if line.strip() == '---':
                if in_fm: break
                in_fm = True; continue
            if in_fm and line.startswith('description:'):
                description = line[len('description:'):].strip()
                break

records = [r for r in records if r.get('id') != deprecated_skill and r.get('entryName') != deprecated_skill]
new_record = {
    "id": skill_name,
    "name": display_name,
    "version": version,
    "enabled": True,
    "kind": "directory",
    "entryName": skill_name,
    "description": description,
    "installPath": install_path,
}
records = [r for r in records if r.get('id') != skill_name and r.get('entryName') != skill_name]
records.append(new_record)
output = {wrapper_key: records} if wrapper_key else records
with open(jsonc_path, 'w', encoding='utf-8') as f:
    json.dump(output, f, ensure_ascii=False, indent=2)
    f.write('\n')
print(f"  OK: skills.jsonc 已注册 ({len(records)} 条记录, struct: {'wrapped' if wrapper_key else 'array'})")
'@

$tempPy = "$env:TEMP\register_skill_$TS.py"
$pyScript | Out-File -FilePath $tempPy -Encoding utf8

foreach ($agent_id in $TARGET_AGENTS) {
    Write-Host "--- agent: $agent_id ---" -ForegroundColor Blue
    $AGENT_CORE = "$AGENTS_DIR\$agent_id\agent-core"
    $SKILLS_DIR = "$AGENT_CORE\skills"
    $INSTALL_PATH = "$SKILLS_DIR\$SKILL_NAME"
    $SKILLS_JSONC = "$SKILLS_DIR\skills.jsonc"

    New-Item -ItemType Directory -Force -Path $SKILLS_DIR | Out-Null

    # 备份旧版
    if (Test-Path $INSTALL_PATH) {
        $oldVer = "未知"
        if (Test-Path "$INSTALL_PATH\VERSION") {
            $oldVer = (Get-Content "$INSTALL_PATH\VERSION" -Raw).Trim()
        }
        $bak = "$SKILLS_DIR\.${SKILL_NAME}.bak.$TS"
        Write-Host "  ⚠️  检测到旧版本 $oldVer，备份到: $(Split-Path -Leaf $bak)" -ForegroundColor Yellow
        Move-Item $INSTALL_PATH $bak
    }

    Copy-Item -Recurse -Path $SCRIPT_DIR -Destination $INSTALL_PATH
    Write-Host "  ✅ 安装到: $INSTALL_PATH" -ForegroundColor Green

    # 清理 deprecated
    $depPath = "$SKILLS_DIR\$DEPRECATED_SKILL"
    if (Test-Path $depPath) {
        $depBak = "$SKILLS_DIR\.${DEPRECATED_SKILL}.deprecated.$TS"
        Write-Host "  ⚠️  清理已弃用的 $DEPRECATED_SKILL" -ForegroundColor Yellow
        Move-Item $depPath $depBak
    }

    # 注册 skills.jsonc
    & $pythonCmd $tempPy $SKILLS_JSONC $SKILL_NAME $SKILL_DISPLAY_NAME $VERSION $INSTALL_PATH $DEPRECATED_SKILL $TS
    if ($LASTEXITCODE -eq 0) {
        $INSTALLED_COUNT++
        $INSTALLED_PATHS += $INSTALL_PATH
    } else {
        Write-Host "  ❌ skills.jsonc 注册失败" -ForegroundColor Red
    }
    Write-Host ""
}

Remove-Item $tempPy -ErrorAction SilentlyContinue

# ============================================================================
# Step 6: 总结
# ============================================================================
Write-Host "=========================================" -ForegroundColor Green
Write-Host " 🎉 安装成功！v$VERSION" -ForegroundColor Green
Write-Host " 装到 $INSTALLED_COUNT 个 agent" -ForegroundColor Green
Write-Host "=========================================" -ForegroundColor Green
Write-Host ""
Write-Host "已安装路径："
foreach ($p in $INSTALLED_PATHS) {
    Write-Host "  • $p" -ForegroundColor Blue
}
Write-Host ""
Write-Host "下一步操作："
Write-Host "  1. 完全退出 Accio Work"
Write-Host "  2. 重新打开 Accio Work"
Write-Host "  3. 进入「国际站生意助手」"
Write-Host "  4. 在对话框输入：生成知识库" -ForegroundColor Green
Write-Host ""
