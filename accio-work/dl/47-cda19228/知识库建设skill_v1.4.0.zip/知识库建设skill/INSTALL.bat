@echo off
REM ============================================================================
REM 国际站 AI 知识库生成器 — 安装入口（Windows）
REM 版本: v1.2.0
REM
REM 此 .bat 双击运行会调用 INSTALL.ps1 执行真正的安装。
REM 若 PowerShell 被组策略禁用，请参考 INSTALL_ONELINER.md 用一行命令安装。
REM ============================================================================

setlocal enabledelayedexpansion
chcp 65001 >nul

set "SCRIPT_DIR=%~dp0"
if "%SCRIPT_DIR:~-1%"=="\" set "SCRIPT_DIR=%SCRIPT_DIR:~0,-1%"

set "PS_SCRIPT=%SCRIPT_DIR%\INSTALL.ps1"

if not exist "%PS_SCRIPT%" (
    echo [错误] 未找到 INSTALL.ps1: %PS_SCRIPT%
    echo        请确认 zip 解压完整
    pause
    exit /b 1
)

echo =========================================
echo  正在调用 PowerShell 安装器...
echo  ^(若提示执行策略受限，请用管理员 PowerShell 运行：^)
echo  powershell -ExecutionPolicy Bypass -File "%PS_SCRIPT%"
echo =========================================
echo.

powershell -ExecutionPolicy Bypass -NoProfile -File "%PS_SCRIPT%"
set "PS_EXIT=%ERRORLEVEL%"

if %PS_EXIT% NEQ 0 (
    echo.
    echo [错误] PowerShell 安装失败，退出码: %PS_EXIT%
    echo        请尝试在 PowerShell 终端手动运行：
    echo        powershell -ExecutionPolicy Bypass -File "%PS_SCRIPT%"
    pause
    exit /b %PS_EXIT%
)

echo.
echo 安装完成。按任意键关闭窗口...
pause >nul
