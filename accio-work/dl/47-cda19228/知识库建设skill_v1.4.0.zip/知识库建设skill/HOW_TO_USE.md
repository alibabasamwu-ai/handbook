# 商家上手指引（5 分钟搞定）

> **如果你刚拿到这个 zip 包，先看这一份文档，再看其他任何文件。**
>
> 全程 5 步：装环境 → 放 Skill → 验证 → 触发 → 等成品。

---

## 📦 这是什么？

**国际站 AI 知识库生成器** —— 让你在 Accio Work 对话框里说一句"生成知识库"，30-60 分钟内自动产出：

- 177+ 篇多语种 .md 文档（结构化 Q&A，可直接接入 Accio Work 生意助手作为问答数据源）
- 同数 .docx 镜像（方便编辑和审阅）
- 7 张营销素材图（按你选的风格生成）
- AI 应答模拟报告（30 分制评分，告诉你哪些买家问题答不好）
- 自动修复迭代（把暴露训练话术、竞品名等风险点修干净）
- 上传指引（一步步教你把成品搬到国际站后台）

**适合谁用？**
- 阿里巴巴国际站卖家（任何品类，已内置 8 行业问题包）
- 想让 Accio Work 生意助手回答询盘时基于商家自己的产品/政策/话术（而非通用模板）
- 想给重点客户发一份带营销钩子的专业图文 PDF Catalog（v1.2 起）
- 已有基础店铺资料（产品手册/认证/工厂照片，没有也能跑但效果会弱）

---

## ⚙️ 第 0 步：你需要先有 Accio Work

| 情况 | 怎么办 |
|------|--------|
| 还没装 Accio Work | 通过 [👉 专属邀请链接注册下载](https://www.accio-ai.com/login?sId=FDNjlh%2FMem9Ep139XpkkLg%3D%3D&ic=IC169946055407&tenant=accio_work&src=p_supplier_cn&channel=accio_sales_invite)（注册后即可下载 macOS / Windows 客户端） |
| 已经装好 | 跳到第 1 步 |
| 装了但没用过国际站生意助手 | 打开 Accio Work → 找到"国际站生意助手" agent → 启用 |
| 完全不懂这是什么 | 看 [accio.com/work/doc](https://www.accio.com/work/doc) 入门文档 |

---

## 🚀 第 1 步：把 Skill 包放到指定位置

### 方法 A：一键安装（推荐 ✅）

**👉 看 [INSTALL_ONELINER.md](./INSTALL_ONELINER.md)** — 复制粘贴一行命令，30 秒装好。

核心思路：打开终端 → 输 `bash ` （Mac）或 `powershell -ExecutionPolicy Bypass -File ` （Win）→ **把 INSTALL.sh / INSTALL.ps1 拖进终端窗口** → 回车。

> ❌ **不要双击 INSTALL.sh / INSTALL.bat / INSTALL.ps1** —— 系统可能用错的程序打开它（比如 Xcode、文本编辑器），不会真正运行安装。一定要走"终端 + 拖拽"的方式。

脚本会自动帮你：
- 检测 Accio Work 安装路径
- 找到你的账号 ID（多账号自动选最近活跃）
- **检测旧版 → 备份 .bak.{时间戳} → 覆盖新版**（升级一样这一行）
- 自动清理已弃用的 `alibaba-prelaunch-kb-builder`（v1.1.0 已合并）
- 验证文件完整性 + 设置脚本权限

### 方法 B：手动安装（如果一键脚本失败）

**macOS / Linux：**
```bash
# 1. 找到你的账号 ID（路径中的数字部分）
ls ~/.accio/accounts/

# 2. 把整个 alibaba-knowledge-base-builder 目录拷到 skills/ 下
cp -R ./alibaba-knowledge-base-builder ~/.accio/accounts/<你的账号ID>/skills/
```

**Windows：**
```cmd
# 1. 打开文件管理器，进入 %USERPROFILE%\.accio\accounts\
# 2. 找到你的账号文件夹（一串数字）
# 3. 进入该文件夹下的 skills\（如果没有就新建）
# 4. 把整个 alibaba-knowledge-base-builder 文件夹拖进去
```

### 不知道账号 ID 在哪？

打开 Accio Work → 左下角 ⚙️ 设置 → 账号 → 看 "Account ID" 字段。

---

## ✅ 第 2 步：验证安装成功

1. **完全退出 Accio Work**（不是最小化，是退出，让它重新加载 Skill 列表）
2. **重新打开 Accio Work**
3. **打开"国际站生意助手"agent**
4. **在对话框输入：**
   ```
 x
   ```
5. **预期回复：** 列表里应该能看到 **"国际站 AI 知识库生成器"** 或 **"alibaba-knowledge-base-builder"** 字样。

✅ 看到了 → 装好了，去第 3 步。

❌ 没看到 → 看本文末尾的 [FAQ](#faq) → "装完触发不了怎么办"。

---

## 🎯 第 3 步：触发 Skill

在"国际站生意助手"对话框里，输入以下任一句话即可触发：

- **生成知识库**
- 建知识库
- 建 AI 知识库
- 建国际站知识库
- 商家自用 AI 知识库
- 生意助手知识库
- 丰富完善知识库
- 做一套店铺知识库
- AI knowledge base
- knowledge base

助手识别后会回复："识别到您要为店铺生成 AI 知识库，启动 13 问问卷……"

回复 ✅ 或直接答第一题，就进入流程了。

---

## 📝 第 4 步：准备材料 + 答 13 问

### 必须准备的（5 项基础信息）

| # | 字段 | 示例 |
|---|------|------|
| 1 | 店铺中文/英文名 | XINTONG / Xintong Solar |
| 2 | 主营品类 | 太阳能路灯 + 智慧公路集成 |
| 3 | 战略一句话定位（anchor） | "Solar Lighting + Smart Highway One-Stop EPC Integrator" |
| 4 | 3-5 个差异化卖点 | 5 年质保 / 一站式集成 / EPC 政府项目经验 |
| 5 | 目标市场 | 东南亚（菲律宾/马来西亚）+ 非洲（莫桑比克） |

### 强烈建议准备的（让产出质量提升 50%）

- **现成的产品手册**（PDF 或图片）→ Writer 会基于真实参数写
- **认证扫描件**（CE / RoHS / SASO 等）→ 写认证清单时不会编造
- **工厂照片**（车间/产线/质检）→ 营销素材生图时作为参考
- **3-5 个真实买家询盘**（Top 高价值线索）→ AI 模拟时按这些问题打分

### 可选的（高级玩法）

- **竞品 / 替代品类型描述**（不是具体品牌名）→ 用于 painpoint 对比图
- **去年 GMV / 年增长率** → 写公司实力时有数据支撑
- **核心客户案例**（脱敏版）→ 可放进 INTERNAL 部分

### 答 13 问的预估时长

| 节奏 | 时长 |
|------|------|
| 全部用默认推荐答（最快） | 5 分钟 |
| 详细答 + 上传材料 | 20-30 分钟 |
| 不会答的题，看每题"建议"提示 | 加 5-10 分钟 |

---

## ⏳ 第 5 步：等 30-60 分钟拿成品

答完 13 问 → 助手会先输出一份 **SPEC_LOCKED.md**（执行规格确认书）→ 你 ✅ 后正式开工。

### 执行进度可视化

助手会派 8 个 sub-agent 并行干活，你能实时看到进度：

```
✅ 阶段 1/14: SPEC 锁定
✅ 阶段 2/14: Writer 写主语种 EN ......... 59 文档完成
🔄 阶段 3/14: Translator 翻译 ES + FR ... 进行中 32/118
⏳ 阶段 4/14: FormatConverter pandoc 转换
⏳ ...
```

### 产出位置

全部交付物在你的 Accio Work workspace 目录下，结构大致如下：

```
<workspace>/
├── KB_PUBLIC/                      ← 对外公开版（可上传国际站）
│   ├── EN/
│   │   ├── 01_company_info/
│   │   ├── 02_product_info/
│   │   ├── 03_communication/
│   │   ├── 04_after_sales/
│   │   ├── 05_logistics/
│   │   └── 06_payment/
│   ├── ES/  ← 西班牙语镜像
│   └── FR/  ← 法语镜像（按你选的语种）
├── 99_INTERNAL_ONLY/               ← 内部用（销售训练等，不上传）
├── DOCX_VERSIONS/                  ← 同结构的 .docx 版
├── 04_营销素材/                    ← 7 张图 + USAGE_GUIDE.md
├── SPEC_LOCKED.md                  ← 执行规格
├── AI_RESPONSE_SIMULATION.md       ← 30 分制评分报告
├── RISK_SCAN_REPORT.md             ← 风险扫描报告
├── REPAIR_LOG.md                   ← 修复日志
├── EVOLUTION_LOG.md                ← 你贡献给数据池的内容（脱敏）
└── UPLOAD_GUIDE.md                 ← ⭐ 上传指引，按这个走
```

### 拿到成品后干什么？

打开 **UPLOAD_GUIDE.md**，按里面的步骤把内容搬到国际站后台对应位置。一般 1-2 小时能上完。

---

## 🆘 FAQ

### Q: 装完触发不了怎么办？

按以下顺序排查：
1. **重启 Accio Work**（必须完全退出再开）
2. 检查 Skill 包路径是否正确：`ls ~/.accio/accounts/<你的ID>/skills/alibaba-knowledge-base-builder/SKILL.md` 应该能看到文件
3. 如果路径对但还是触发不了 → 在对话框里直接说："请 read `~/.accio/accounts/<你的ID>/skills/alibaba-knowledge-base-builder/SKILL.md` 然后按里面的指令做"
4. 还不行 → 联系交付方（看 zip 包外的联系方式）

### Q: 多语种翻译不准怎么办？

每篇文档生成后你都可以直接编辑 .md 文件改翻译。改完重新跑一次：
```
请重新转换 docx 并重跑风险扫描
```
助手会按改后的内容重新出 .docx 和报告。

### Q: 生成的内容我想改怎么办？

两种方式：
1. **小改**：直接编辑产出的 .md 文件
2. **大改**：在对话里说"请重写 02_product_info 模块，加上 IoT Smart Pole 的 8 篇文档"，助手会增量补写

### Q: AI 模拟评分太低（<25）怎么办？

低分通常是因为：
- 商家提供的素材不足，Writer 写不出深度内容
- 13 问中"差异化卖点"答得太空泛
- 选了"P0_only"修复深度，跳过了 P1（数据缺口）修复

解决：
- 升级修复深度到 P0_P1（在 SPEC 锁定时改）
- 补提供 3-5 篇真实询盘聊天记录
- 让助手为得分最低的 3 个题专门补写文档

### Q: 演进数据会泄露我的商业机密吗？

不会。EvolutionRecorder 只记录脱敏字段：
- 你的店铺名 → 自动转为 `seed_case_NNN`
- 不记录任何具体内容、客户名、金额、MOQ、年指标
- 只记录：行业 / 品类 / 评分 / 失分题（题目本身，不含你的回答）/ 盲点关键词

如果你完全不想参与演进数据池，在 13 问中第 13 题（"是否启用演进"）选"否"即可。

### Q: 我能改 Skill 包内的模板吗？

可以，但建议先备份原版。所有可定制的位置：
- `templates/kb_module_skeletons/<模块>/README.md` — 改模块覆盖的主题清单
- `style_presets/<风格>.md` — 改营销素材的 prompt 风格
- `question_packs/<行业>.md` — 改你这个行业的 AI 模拟题
- `agents/<角色>.md` — 改 sub-agent 的工作 prompt（不建议改，除非你懂 prompt 工程）

### Q: 这个 Skill 收费吗？

由分发方决定。如果是免费分发，按你拿到的版本无限期使用；如果是付费版，看包内的 `LICENSE.md`（如有）。

### Q: 后续 Skill 升级了怎么办？

把新版 zip 解压后重跑 `INSTALL.sh / INSTALL.bat` 即可，会自动覆盖旧版。建议先备份你修改过的模板文件（如果有改）。

### Q: 装在公司多个员工的电脑上能共用一个执行结果吗？

每个员工电脑独立运行，独立产出。如果想共享，建议：
- 让一位员工跑完后，把 workspace 整个目录共享到团队网盘
- 或者把生成的 .md 直接 commit 到内部 Git 仓库

---

## 📞 联系与反馈

- 遇到 bug / 想要新功能 → 联系本 zip 包的分发方（看你拿到的渠道）
- 想了解 Accio Work 平台问题 → [accio.com/work/doc](https://www.accio.com/work/doc)
- 想了解你交付出去的知识库怎么用得更好 → 阅读包内 [README.md](README.md) 和 [orchestrator/02_workflow.md](orchestrator/02_workflow.md)

---

**祝你早日跑通第一次执行 🚀**

_本指引随 Skill 包升级同步更新，最后版本：v1.0.1 (2026-05-02)_
