# ⚡ 一键安装 / 一键升级（终端复制粘贴版）

> 拿到 zip 后**先看本文件**，30 秒装好。
> 不需要双击、不需要 chmod、不需要 cd，全程**复制粘贴一行**。

---

## 📦 你拿到了什么

一个 zip 包（约 191 KB），解压后是一个叫 `alibaba-knowledge-base-builder` 的文件夹，里面有 SKILL.md / INSTALL.sh / INSTALL.bat / INSTALL.ps1 等文件。

---

## ✅ 第 0 步：解压 zip

把 zip 双击解压到任意位置，比如：

- macOS: `~/Downloads/alibaba-knowledge-base-builder/`
- Windows: `C:\Users\你\Downloads\alibaba-knowledge-base-builder\`

**记住这个解压后的文件夹路径**，下一步要用。

---

## 🍎 macOS 用户 — 三步装好

### 第 1 步：打开"终端"

按 `Cmd + 空格` 搜索 `终端` 或 `Terminal`，回车打开。

### 第 2 步：在终端里输入这一行（先别回车）

```
bash 
```

注意：`bash` 后面有**一个空格**。

### 第 3 步：把 INSTALL.sh **拖到终端窗口里**

- 打开 Finder，进入你解压后的 `alibaba-knowledge-base-builder` 文件夹
- 把里面的 `INSTALL.sh` 文件**用鼠标拖进终端窗口**（不是拖文件夹，是拖那一个 .sh 文件）
- 终端会自动补全完整路径，看起来像这样：
  ```
  bash /Users/你的用户名/Downloads/alibaba-knowledge-base-builder/INSTALL.sh
  ```
- **回车** ✅

> **不想拖？** 也可以右键 `INSTALL.sh` → "拷贝路径"（选项菜单按住 Option 键出现），然后粘到终端里 `bash ` 后面。

---

## 🪟 Windows 用户 — 三步装好

### 第 1 步：打开"PowerShell"

按 `Win + X` → 选 **"Windows PowerShell"** 或 **"终端 (PowerShell)"**。

### 第 2 步：在 PowerShell 里输入这一行（先别回车）

```
powershell -ExecutionPolicy Bypass -File 
```

注意：`-File` 后面有**一个空格**。

### 第 3 步：把 INSTALL.ps1 **拖到 PowerShell 窗口里**

- 打开"文件资源管理器"，进入解压后的 `alibaba-knowledge-base-builder` 文件夹
- 把里面的 `INSTALL.ps1` 文件**用鼠标拖进 PowerShell 窗口**
- PowerShell 会自动补全完整路径，看起来像这样：
  ```
  powershell -ExecutionPolicy Bypass -File "C:\Users\你\Downloads\alibaba-knowledge-base-builder\INSTALL.ps1"
  ```
- **回车** ✅

> **如果 PowerShell 提示无法运行脚本**（很少见），手动运行下面这一句解锁：
> ```
> Set-ExecutionPolicy -Scope CurrentUser -ExecutionPolicy RemoteSigned -Force
> ```
> 然后再重试上面的安装命令。

> **如果你只有 cmd 没有 PowerShell**：用 `INSTALL.bat` 替代 `INSTALL.ps1`，把整行命令换成直接拖 `INSTALL.bat` 进 cmd 窗口回车即可。

---

## 🎬 安装过程会发生什么

脚本会自动做完这些事，全程不用你干预：

1. ✅ 校验 zip 解压完整
2. ✅ 找到你电脑上的 Accio Work 安装路径（`~/.accio/`）
3. ✅ 自动选最近活跃的账号
4. ✅ **如果你之前装过旧版**：自动备份到 `.bak.{时间戳}` → 覆盖新版
5. ✅ **如果你之前装过 `alibaba-prelaunch-kb-builder`**（潜客旧版）：自动备份+移除（v1.1.0 已合并）
6. ✅ 验证文件完整、设置脚本权限
7. ✅ 打印"🎉 安装成功！v1.1.0"

预计耗时：3-10 秒。

---

## 🔁 升级旧版本（一样的命令）

**v1.0.x 升 v1.1.0？** 直接重跑同一行命令。脚本会：

1. 检测到旧版 v1.0.x
2. 自动备份到 `~/.accio/accounts/{你的账号}/skills/alibaba-knowledge-base-builder.bak.20260505_142530/`
3. 装新版到原位置

**完全不会丢数据，旧版还在 .bak 目录里**，需要回滚把 .bak 目录改名回去即可。

---

## ✔️ 装完后下一步

1. **完全退出 Accio Work**（右上角菜单 → 退出，不是关窗口）
2. **重新打开 Accio Work**
3. 进入「国际站生意助手」对话框
4. 输入：**生成知识库**
5. 助手会进入 **Stage 0 商家信息收集** 卡片，跟着答即可

完整使用说明看 [HOW_TO_USE.md](./HOW_TO_USE.md)。

---

## ❓ 出问题了

| 报错 | 怎么办 |
|------|--------|
| `bash: command not found` | 你不在终端里跑（可能在浏览器/编辑器）。重新打开"终端"再粘。 |
| `Permission denied` | 路径里有空格但没加引号；用拖拽方式（终端会自动加引号）。 |
| `未找到 Accio Work 目录` | 你还没装 Accio Work。去 [专属邀请链接](https://www.accio-ai.com/login?sId=FDNjlh%2FMem9Ep139XpkkLg%3D%3D&ic=IC169946055407&tenant=accio_work&src=p_supplier_cn&channel=accio_sales_invite) 注册下载，启动一次再重跑。 |
| `未找到任何账号` | 你装了 Accio Work 但没登录。打开它登录账号后重跑。 |
| 多账号自动选错了 | macOS: `bash <拖INSTALL.sh> --interactive`<br>Windows: `powershell -ExecutionPolicy Bypass -File "<拖路径>" -Interactive`<br>会让你手选账号。 |
| 触发不到 Skill | 完全退出 Accio Work（不是最小化）再重开；进入「国际站生意助手」对话框输 `生成知识库`。 |

更多 FAQ 在 [HOW_TO_USE.md](./HOW_TO_USE.md) 末尾。
