# CORE_RULES.md — 知识库构建 Skill 强约束规则

> ⚠️ **此文件由两个 Skill 共用**：`alibaba-knowledge-base-builder`（存量版）+ `alibaba-prelaunch-kb-builder`（潜客版）
> ⚠️ **任何 Skill 启动后第一动作必须 read 本文件**，且整个执行过程中 7 大规则**不可违反**
> ⚠️ **基于 TANAKA_EV 案例（2026-05-03）暴露的 7 大根因（R1-R7）**，从 v1.0.1 起强制生效

---

## R1. 信息源优先级（MCP 优先 + 手册校验 + 浏览器兜底）

### 强制顺序

```
Step A: ask_user — 问商家是否有产品手册/公司介绍/SKU 表
Step B: 调 MCP（accio-mcp-cli call <seller_info_tool>）拿后台授权数据
Step C: 如商家有手册 → 等上传 → read 手册（PDF / DOCX / 图片）
Step D: 如 MCP 失败 → spawn browser sub-agent 抓 minisite 公开页
Step E: 三方交叉验证 → 输出差异表 → 商家裁决
Step F: 写 VERIFIED_MERCHANT_INFO.md（每字段含来源标签）
```

### 禁止行为

- ❌ 未问商家是否有手册就直接进 MCP
- ❌ 用 browser 优先（除非 MCP 完全不可用）
- ❌ 跳过交叉验证直接进 SPEC 锁定
- ❌ MCP 数据 vs 手册 vs 浏览器有差异时不告知商家

### 来源标签（每条信息必须打）

| 标签 | 含义 |
|------|------|
| `[MCP]` | 来自 MCP 调用，含工具名 |
| `[商家手册]` + 文件名 + 页号 | 来自商家上传的手册 |
| `[商家原文]` | 商家在对话中亲口说 |
| `[访谈]` | Round1/Round2 问出来 |
| `[Browser]` + URL | minisite 公开页抓取 |
| `[公开资料推断]` + URL | MarketResearcher 提供 |
| `[行业基准]` | 通用行业常识 |
| `[待商家补充]` | 完全没数据 |

---

## R2. 商家手册问询（开场必问）

### 触发后第一句话必含

```
您好！开始之前，我先问几个关键问题（可多选）：

❓ 您是否有以下任一资料可上传？（强烈建议有）
  □ 产品手册 / Catalog（PDF/Word）
  □ 公司介绍 / About Us 文档
  □ SKU 总表（Excel/CSV）
  □ 已有的国际站后台账号（我可调 MCP 拉取）
  □ 都没有，全靠对话补全
```

### 处理逻辑

| 商家选择 | 处理 |
|---------|------|
| 有手册 → 等上传 | 优先用手册作为"事实底座"做交叉验证 |
| 有 MCP 授权 | 同时拉 MCP，做手册 ↔ MCP 交叉验证 |
| 都没有 | 进入"对话补全模式"，但**警告商家：缺少手册容易产生信息偏差** |

---

## R3. 交叉验证（Cross-Validation）

### 触发场景

任意两个来源（MCP / 手册 / 商家原文 / Browser）在同一字段上**值不一致**时，立即触发。

### 操作

```markdown
## ⚠️ 信息差异需要您裁决

我从不同渠道获取的信息有出入，请确认以哪个为准：

### 字段：MOQ（起订量）
- [MCP 后台] 50 台
- [商家手册 P12] 100 台
- [商家口述] "我们一般 30 台也接"

请选择：
A. 按 MCP 50 台
B. 按手册 100 台
C. 按口述 30 台
D. 三档分级（小批量/标准/批发）—— 推荐
E. 其他（请说明）
```

### 写入规则

- 商家未裁决前，**该字段一律不写入 KB**，先标 `[待商家裁决]`
- 商家裁决后，VERIFIED_MERCHANT_INFO.md 记录"裁决前 3 个值 + 裁决后 1 个值 + 裁决时间"

---

## R4. 反幻觉（5 类红线 + 行业基准可推断）

### 5 类红线（**未经商家确认绝不写入**）

| 类型 | 例子 | 处理 |
|------|------|------|
| **MOQ / 起订量** | "MOQ 50 台" | `[待商家补充]` |
| **认证号 / 证书号** | "ISO9001 证书号 XXXX" | `[待商家补充]` |
| **客户名 / 项目名** | "已为 XX 项目供货" | `[待商家补充]` |
| **销量数字 / 工厂面积** | "年销 5000 台 / 工厂 8000㎡" | `[待商家补充]` |
| **精确产品参数** | "续航 130km @ 25°C/60kg" | `[待商家补充]`，除非来自手册 |

### 可推断（标 `[行业基准]` 或 `[公开资料推断]+URL`）

- 行业典型 lead time 区间
- 行业典型认证清单（CE / FCC / RoHS）
- 行业典型市场分布
- 同行普遍卖点（来自 MarketResearcher 爬取）

### Sub-agent 如果违反

- main agent 在审计阶段（见 R6）发现 → 立即让 sub-agent 返工
- 反复违反 → 在 prompt 中加入"上轮违规示例"，强化约束

---

## R5. 默认推荐禁止（防止"按 A 一键通过"）

### 禁止场景

商家只回字母 / "好的" / "都可以" / "你看着办" 时：

- ❌ main agent 直接按推荐项写入 SPEC
- ❌ main agent 进入下一阶段
- ❌ "已默认接受所有推断"

### 强制操作

```markdown
我注意到您的回复比较简短。为了避免信息偏差，我把关键决策再复述一遍，请逐项确认：

### 决策 1：战略 anchor
推断：「Taizhou-based Sport & Racing E-Motorcycle Specialist」
来源：[Browser - minisite About Us]

❓ 这句定位是否准确？  □ 准确  □ 需调整：____  □ 不知道（让我推断）

### 决策 2：差异化要点
推断 4 条：
1. 整车自产 [来源: ...]
2. Sport + Racing 双产品矩阵 [来源: ...]
3. Gold Supplier [来源: ...]
4. 台州摩托车产业集群 [来源: 行业基准]

❓ 哪几条您能 100% 站住脚？请勾选：
□ 1  □ 2  □ 3  □ 4
（未勾选的会标 [待补充] 或不写入）
```

### 兜底

商家**连逐项确认都拒绝**时，main agent 必须明确警告：
> "我会按推断写入，但所有未确认项会标 `[待商家补充]`，最终 KB 可能有 30%+ 内容是占位符。建议您后续补充。"

---

## R6. Main Agent 审计协议（硬拦截）

### 每个 sub-agent 返回后，main agent 必须执行 5 项审计

```python
# 伪代码 — main agent 实际行为
def audit_subagent_output(subagent_name, claimed_files, work_dir):
    # 审计 1: 文件实存性
    for f in claimed_files:
        if not exists(f):
            return REJECT(f"{subagent_name} 声称写了 {f}，但文件不存在")

    # 审计 2: 内容非空
    for f in random.sample(claimed_files, min(2, len(claimed_files))):
        content = read(f)
        if len(content) < 200:
            return REJECT(f"{f} 内容不足 200 字符，疑似空壳")

    # 审计 3: 来源标注密度
    for f in claimed_files:
        sections = split_by_heading(read(f))
        labeled = sum(1 for s in sections if has_source_tag(s))
        if labeled / len(sections) < 0.7:
            return REJECT(f"{f} 来源标注密度 < 70%")

    # 审计 4: 红线幻觉扫描
    for f in claimed_files:
        violations = grep(f, RED_LINE_PATTERNS)
        # 如有精确数字但无 [商家原文]/[商家手册]/[MCP] 来源
        if violations and not nearby_has_source(violations):
            return REJECT(f"{f} 检测到 R4 红线幻觉")

    # 审计 5: 待补充比例
    for f in claimed_files:
        pending = grep_count(f, "[待商家补充]")
        total = section_count(f)
        if pending / total > 0.3:
            return WARN(f"{f} 待补充比例 {pending/total:.0%} > 30%")

    return PASS
```

### 审计结果处理

| 结果 | 处理 |
|------|------|
| PASS | 进入下一阶段，简短告知商家 |
| WARN | 进入下一阶段，但在最终交付汇报中标注 |
| **REJECT** | **硬拦截：sessions_send 让 sub-agent 返工，最多重试 2 次** |
| 重试 2 次仍 REJECT | 暂停流程，告知商家"sub-agent 反复出错，需您介入决策" |

### 审计日志

每次审计写入 `<work_dir>/AUDIT_LOG.md`：
```markdown
## [时间] 审计 Writer (01_company_info)
- 文件数声称: 10 / 实存: 10 ✅
- 内容非空抽样: about_company.md (852字), location_info.md (623字) ✅
- 来源标注密度: 平均 85% ✅
- 红线扫描: 0 处违规 ✅
- 待补充比例: 12% ✅
**结论: PASS**
```

---

## R7. 评分中立（AISimulator 不能评自家产物）

### 旧问题

AISimulator sub-agent 评的是 Writer sub-agent 写的内容 → 但**评分逻辑可能受同一份 prompt 影响 → 偏分高**。

### 新约束

- AISimulator 必须用**独立的 prompt**，不读 Writer 的输出原文
- AISimulator 只看商家"模拟询盘 → 模拟 Accio Work 生意助手基于 KB 应答 → 是否能命中"
- 评分时遇到 `[待商家补充]` **视为缺失字段，不能按编造内容打分**

### 推荐升级路径

- 短期：在 AISimulator prompt 中加 "你不知道这是什么 Skill 写的，请客观评估"
- 中期：用 web_search 拉同行公开问答应答做基准对比
- 长期：把 AISimulator 换成 spawn 新独立 sub-agent（agent_id=general，无前序 context）

---

## 🔧 工具调用速查

| 工具 | 用途 | 调用示例 |
|------|------|---------|
| `accio-mcp-cli keyword <关键词>` | 找 MCP 工具 | `accio-mcp-cli keyword seller info` |
| `accio-mcp-cli search` | 浏览 MCP 工具树 | `accio-mcp-cli search alibaba` |
| `accio-mcp-cli call <tool> --json '{...}'` | 调用 MCP 工具 | 拿后台数据 |
| `ask_user` | 问商家 | mode=form 多选 / mode=chat 上传文件 |
| `see_image` | 读手册图/截图 | 处理 PDF 截图、产品图 |
| `web_fetch` / `sessions_spawn browser` | 抓公开页 | minisite / 同行店铺 |

---

## 🚨 违规升级路径

| 违规 | 后果 |
|------|------|
| 1 次违规 | sub-agent 返工 + AUDIT_LOG 记录 |
| 同一类违规 3 次 | 在本次会话结束时写入 `evolution/failure_patterns.md` |
| 累积 5 次违规 | 触发 v1.0.x bump，main agent 复盘后调整 prompt |

---

## 📊 来源占比目标（潜客版 / 存量版差异）

| 来源类型 | 存量版理想占比 | 潜客版理想占比 |
|---------|--------------|--------------|
| `[MCP]` | ≥ 40% | ≥ 0%（潜客无后台）|
| `[商家手册]` | ≥ 20% | ≥ 30% |
| `[商家原文]` + `[访谈]` | ≥ 25% | ≥ 40% |
| `[公开资料推断]` | ≤ 10% | ≤ 20% |
| `[行业基准]` | ≤ 10% | ≤ 15% |
| `[待商家补充]` | ≤ 5% | ≤ 15% |

**总占比 = 100%。某项严重超标 → SPEC 重新对齐。**

---

## 📚 参考案例

- **TANAKA_EV 案例（2026-05-03）**：暴露 R1-R7 全部 7 大根因，是本规则文件的"反面教材"。详见 [evolution/failure_patterns.md](evolution/failure_patterns.md) 的 "TANAKA_EV 案例" 段。
