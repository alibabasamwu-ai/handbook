# Failure Patterns (累积型经验库)

> 本文件由 EvolutionRecorder 自动追加。每条记录对应一种 ≥3 次重复出现的失败模式，含触发条件和推荐前置规避动作。
> 主 agent 在接到新商家执行前应 read 本文件，把相关失败模式注入到对应 sub-agent 的"避坑提醒"中。

---

## Pattern Schema

```yaml
pattern_id: <自增编号>
first_seen: <ISO 时间>
last_seen: <ISO 时间>
hit_count: <累积命中次数>
trigger_industries: [<industry_id>...]
description: <一句话描述失败模式>
root_cause: <根因>
preventive_action: <下次商家执行时的前置规避动作>
related_seed_cases: [<anonymized_id>...]
```

---

## Active Patterns

### pattern_001 — 训练话术外泄（Bad Talk / Good Talk / Pro Talk 在 Public 文档残留）

- **first_seen**: 2026-04-30
- **last_seen**: 2026-04-30
- **hit_count**: 1（待累积到 3 次后正式纳入推荐规则）
- **trigger_industries**: [industrial_b2b]
- **description**: Writer 在 communication 模块写销售话术时，把训练版（含 Bad/Good/Pro Talk 标签）直接写入 KB_PUBLIC，导致接入 Accio Work 生意助手或交付客户时内部话术外泄。
- **root_cause**: Writer prompt 中"sales training material"和"public KB"边界不清晰；商家原始素材中训练话术与对客文档混存。
- **preventive_action**:
  1. Writer 在生成 communication 模块时，把训练话术固化写入 99_INTERNAL_ONLY/sales_training/，文件名加 `_FULL_TRAINING_VERSION` 后缀。
  2. KB_PUBLIC 下只放对客 Q&A 重写版，不含 Bad Talk/Good Talk/Pro Talk 等训练标签。
  3. RiskScanner 必须扫多语种本地化变体：`(Bad Talk|Good Talk|Pro Talk|Mauvais Discours|Bon Discours|Discurso Malo|Discurso Bueno)`。
- **related_seed_cases**: [seed_case_001]

### pattern_002 — Public 文档残留指向 INTERNAL 路径的内链

- **first_seen**: 2026-04-30
- **last_seen**: 2026-04-30
- **hit_count**: 1
- **trigger_industries**: [industrial_b2b]
- **description**: KB_PUBLIC 下的某些 .md 含 `[See sales training](../../99_INTERNAL_ONLY/sales_training/...)` 形式的链接，外部可见。
- **root_cause**: Writer 在跨文件引用时未区分 Public/Internal 边界。
- **preventive_action**:
  1. Writer prompt 中明确"All cross-references in KB_PUBLIC MUST be within KB_PUBLIC tree"。
  2. RiskScanner 扫描 `grep -rln "99_INTERNAL_ONLY" KB_PUBLIC/`，任何命中视为 P0。
  3. RepairExecutor 修复方式：`sed -i '' '/99_INTERNAL_ONLY/d' <file>`（删整行）。
- **related_seed_cases**: [seed_case_001]

---


### pattern_003 — TANAKA_EV 案例（v1.0.1 修复触发）

- **first_seen**: 2026-05-03
- **last_seen**: 2026-05-03
- **hit_count**: 1
- **trigger_industries**: [ev_motorcycle, prelaunch_b2b]
- **description**: 在 TANAKA_EV 测试中，整套 KB 出现严重幻觉与流程跳过，main agent 未审计，AISimulator 自评 26.9 分（虚高）。
- **7 大根因（已 → CORE_RULES.md R1-R7）**:
  1. **R1 用错 Skill** — 商家"还没开店"场景应该用潜客版，但用户实际跑了存量版（存量版无 MarketResearcher）。
  2. **R2 缺 MCP 调用规范** — 直接 spawn browser，跳过 MCP 优先级。
  3. **R3 缺商家手册问询** — 没问"有没有产品手册/Catalog"，第一时间就开始抓数据。
  4. **R4 缺 main agent 审计** — sub-agent 编造产品参数，main agent 当时没发现。
  5. **R5 "默认推荐"按钮太诱人** — 商家只回字母 A，main agent 全按推荐项塞 SPEC，未逐项确认。
  6. **R6 缺幻觉防御** — 编出"Sport-S 续航 130km @ 25°C/60kg/50km/h""Ningbo Port 1.5h""Racing 180 N·m@2500rpm" 等精确数字，无来源。
  7. **R7 AISimulator 评自家产物** — Writer 写完，AISimulator 评 Writer 输出，闭环幻觉，26.9/30 分不可信。
- **root_cause**: 缺少强制规则文件 + main agent 审计协议 + 信息源优先级约束。
- **preventive_action**:
  1. v1.0.1 起两个 Skill 根目录强制 import [CORE_RULES.md](../CORE_RULES.md)，包含 R1-R7。
  2. 两个 SKILL.md 第一行加"⚠️ 强制约束"区块，要求 main agent 启动后第一动作 read CORE_RULES.md。
  3. 加 Step 0 = 商家手册问询 + MCP 优先调取 + 三方交叉验证 + VERIFIED_MERCHANT_INFO.md 信息底座。
  4. **后续 v1.0.1 完整版**（Quick Fix 之外）需要：
     - 新增 `MerchantInfoCollector` sub-agent
     - 升级 Writer / MarketResearcher / Interviewer / AISimulator 4 个 prompt
     - 改 `orchestrator/02_workflow.md` 加审计阶段
     - 把 MarketResearcher 也搬到存量版
- **related_seed_cases**: [TANAKA_EV_2026-05-03]
- **测试结果原文**: `~/Desktop/26年后台工作/3-AI Skill/测试结果/TANAKA_EV_知识库构建_会话记录_2026-05-03.md`
---

## Inactive / Resolved Patterns

（hit_count = 0 或已通过模板默认设计永久规避的失败模式归入此区，仅供回顾。）

---

## 自动化触发规则

- 当某 pattern 的 `hit_count` 达到 3 → 主 agent 应在每次新商家执行前，把 `preventive_action` 注入对应 sub-agent prompt 顶部的 "⚠️ 行业历史教训" 区。
- 当某 pattern 的 `hit_count` 达到 5 → 升级为模板默认行为，把 preventive_action 固化进 `templates/kb_module_skeletons/` 或 `agents/<role>.md` 永久生效。
