# Auto Recommend Rules (基于跨商家累积数据的智能推荐规则)

> 本文件定义"演进数据池累积到何种程度时，触发哪些自动推荐"。EvolutionRecorder 写入新数据后，主 agent 应 read 本文件判断是否触发对应规则。

---

## 触发逻辑总览

```
新商家执行结束 → EvolutionRecorder 追加 industry_insights.jsonl
                ↓
           累积统计扫描
                ↓
    ┌───────────┼───────────┬───────────┐
    ↓           ↓           ↓           ↓
must_have   skeleton    style_default  question
追加         默认覆盖      调整           推荐
```

---

## Rule 1: must_have 题目自动追加

**触发条件**：同一 `sub_industry` 累积 ≥ 3 个商家，在同一题（题目文本去标点后哈希一致）的 `weak_questions` 中失分。

**动作**：
1. 把该题追加到 `question_packs/<industry>.md` 的 `## must_have` 区。
2. must_have 区的题目在新商家执行 AISimulator 时，必须包含（即使商家选 Top 5 也强制注入）。
3. 更新该 .md 的 `last_updated` 字段。

**示例**：
- 若 industrial_b2b 累积 3+ 个商家在 "Can you provide DIALUX simulation files?" 失分 → 该题进入 industrial_b2b.md 的 must_have 区。

---

## Rule 2: skeleton 默认覆盖调整

**触发条件**：同一 `industry` 累积 ≥ 5 次出现某盲点（`blind_spots[]` 中的关键词去重统计）。

**动作**：
1. 在 `templates/kb_module_skeletons/<匹配模块>/README.md` 的"推荐主题清单"中追加针对该盲点的 Q&A 标题。
2. Writer 在新商家执行时会自动看到该追加项，按需生成对应文档。

**模块映射**：
- `dialux_*` / `simulation_*` / `cad_*` → 02_product_info
- `epc_*` / `tender_*` / `government_*` → 03_communication
- `incoterms_*` / `shipping_dispute_*` → 05_logistics
- `chargeback_*` / `credit_*` → 06_payment
- `oem_*` / `customization_*` → 03_communication

---

## Rule 3: style_preset 推荐默认调整

**触发条件**：同一 `industry` 累积 ≥ 5 个商家选择同一 `style_preset`。

**动作**：
1. 在 `orchestrator/00_intake_form.md` 的 Q9（风格选择）问题下方，标注"行业默认推荐：<style>（基于 N 个同行业商家的选择）"。
2. 当新商家选择"按推荐"时，自动套用该 style_preset 而非要求商家逐项选。

**当前推荐**（基于 seed_case_001 + 后续累积）：
- industrial_b2b: industrial_tech_blue（1 票，待累积）
- consumer_goods: minimalist_white（待累积）
- apparel_textile: warm_lifestyle（待累积）
- food_beverage: warm_lifestyle（待累积）
- electronics: minimalist_white（待累积）
- home_furniture: warm_lifestyle 或 minimalist_white（待累积）
- machinery_parts: industrial_tech_blue（待累积）
- services_saas: corporate_professional（待累积）

---

## Rule 4: 评分基线动态校准

**触发条件**：同一 `sub_industry` 累积 ≥ 10 个商家完成执行。

**动作**：
1. 计算该 sub_industry 的 `ai_score_final` 中位数和 P25/P75。
2. 在 AISimulator 报告末尾追加"行业基线对比"区：
   - "本店得分 28.5，行业中位数 27.0，处于前 30%"
3. 主 agent 把基线写入 `evolution/baselines.json` 缓存。

---

## Rule 5: 模块篇幅推荐动态调整

**触发条件**：同一 `industry` 累积 ≥ 5 个商家完成执行。

**动作**：
1. 计算每个模块的 `module_doc_counts` 中位数。
2. 在 SPEC 锁定阶段，主 agent 给商家推荐"行业典型篇幅"。
3. 例：industrial_b2b 推荐 公司 12 / 产品 15 / 沟通 10 / 售后 8 / 物流 8 / 支付 6 = 59 篇。

---

## Rule 6: 失败模式硬编码

**触发条件**：`failure_patterns.md` 中某 pattern `hit_count` ≥ 3。

**动作**：把 `preventive_action` 注入对应 sub-agent prompt 顶部的"⚠️ 行业历史教训"区。

**触发条件**：`hit_count` ≥ 5。

**动作**：把 `preventive_action` 固化进模板/sub-agent prompt 永久生效，并在 `failure_patterns.md` 标记为 "Resolved (hardcoded into template)"。

---

## 当前累积状态

| 指标 | 数值 |
|------|------|
| 总商家数 | 1（seed_case_001） |
| 已覆盖 industry | 1（industrial_b2b） |
| 已覆盖 sub_industry | 1（solar_lighting） |
| 已激活 must_have 题 | 0（待累积到 3 次） |
| 已激活 failure pattern | 0（待累积到 3 次） |

---

## 主 agent 集成点

每次新商家走完 SPEC 锁定阶段，主 agent 应静默执行：
1. `cat evolution/industry_insights.jsonl | jq -r 'select(.industry=="<新商家industry>") | ...'`
2. 应用 Rule 1-6 中已激活的规则。
3. 在执行报告末尾告知商家："本次执行参考了 N 个同行业历史案例的经验。"
