# Changelog

## v1.2.1 — 2026-05-10

### 🎨 PDF Catalog 视觉与营销钩子全面升级

针对 v1.2.0 跑通后实战暴露的 4 类问题（中文方框 / 字体过轻不庄重 / 公司页钩子弱 / Ending 页弱），系统升级 `templates/catalog_pdf/generate_catalog.py`：

#### A. CJK 字体方框修复（v1.2.0 hotfix）
- `.ttc` collection 字体加 `subfontIndex`，优先注册 macOS PingFang/Songti
- 终极降级：reportlab 内置 CID 字体 `UnicodeCIDFont("STSong-Light")`，零文件依赖保证中文不出方框
- alicdn 商品图 URL 升级：`_100x100` → `_640x640`（不能裸去后缀，会 404）

#### B. 字体严肃庄重化（B2B 高端感升级）
- 英文优先注册 **Times New Roman / Times-Bold**（macOS Supplemental + Linux Liberation/DejaVu Serif 全降级链），终极降级 reportlab 内置 PostScript Type1 Times 字体
- 中文用宋体系（Songti.ttc / NotoSerifCJK），保持衬线庄重感
- 配色升级：浅蓝 → **深海军蓝 #0d2858**（主色） + **暗金 #a07d2c**（点缀）+ 米色背景
- 加入 7 种新 ParagraphStyle：`slogan`/`h3`/`body_lead`/`stat_num`/`stat_label`/`small_center` 等

#### C. 封面页升级（品牌主张 + 三大数字）
- `build_cover()` 新增 `brand_slogan` / `year_label` 参数
- 新版式：年度标 → 品牌名 → 金色短分隔线 → **斜体品牌主张 Slogan** → hero 公司形象图（金边框） → **三大数字 Stats Bar**（Years / Factory / Countries） → Contact
- 推荐 Slogan 方向：「Engineering Trust into Every Pole」（工程信任派，适合 EPC/政府/招标场景）

#### D. About Us 页全重写（5 模块 + 营销钩子）
- ① Lead 段公司故事
- ② **4 宫格数字背书**：Years / Factory / R&D Engineers / Monthly Capacity
- ③ **左右双栏**：OUR MISSION（金色斜体）｜ CORE STRENGTHS（4 条核心实力）
- ④ CERTIFICATIONS 米色横条
- ⑤ TRUSTED BY 客户列
- ★ 底部 **Project Consultation 钩子条**（深蓝）：Free Dialux + 24h DDP + Sample

#### E. 产品页营销钩子三件套（每页固定结构）
- 🔴 顶部 **Hot Ribbon**：BEST SELLER / HOT / POPULAR / RECOMMENDED 4 级排名标签
- 🔵 中部 **Trust Bar 蓝条**：自动从 `company` 字段拼装公司背书
- 🟡 底部 **Gift Box 黄盒**：FIRST-ORDER BONUS（Dialux + 5Y warranty + Sample + DDP）
- 💰 保留原 MOQ / Price / CTA 米色钩子条
- 新增 `selection.json` 字段：`company.cover_image_path`、`product.hot_label`

#### F. Ending CTA 页全重写（EPC/政府专属接待钩子）
- 顶部小标 + READY TO PARTNER? 大标 + 金色分隔线
- 金色 Slogan「EPC Contractors · Government Tenders · Distributors」
- ★ **深蓝主钩子卡** ★ EPC & GOVERNMENT PROJECT FAST-TRACK ★（6 项专属服务：72h 评估 / Tender 文档 / Dialux / 优先生产 / 工程师对接 / DDP 报价）
- 黄色副钩子卡 🎁 FIRST-ORDER WELCOME PACKAGE
- 收尾品牌签名 + Brand Slogan 复用

#### G. 数据 Schema 扩展
`build_about()` / `build_cover()` / `build_cta_page()` 新支持的 `company.*` 字段：
- `brand_slogan` / `year_label` / `cover_image_path` / `legal_name`
- `mission` / `core_strengths[]` / `rd_engineers` / `monthly_capacity`

每页结构在 `templates/catalog_pdf/` 内部完整对齐 `references/catalog-design-spec.md`。

#### H. 实战验证
XINTONG 实测（90,000㎡ Yangzhou 太阳能路灯厂家）跑通 6.3 MB / 18 页 catalog，封面 / About / 10 产品页 / Ending 全部钩子到位，AI 生成的工厂鸟瞰图（无文字版）作为 hero。

---

## v1.2.0 — 2026-05-07

### 🎯 P0 修复 + 重大新功能 + 质量统一性方案

#### A. 定位偏差全量修复（P0a · 12 文件 14 处）
将所有"可被 AI Mode 抓取 / 模拟 AI Mode 应答 / 严禁上传 AI Mode"措辞，统一改写为"供商家自用 + 接入 Accio Work 生意助手内部检索 / 模拟 Accio Work 生意助手基于 KB 应答 / 仅供员工内部，禁止外传给买家/客户/AI"。涉及文件：
- `SKILL.md`（frontmatter + Stage 6 + AISimulator 输入说明）
- `README.md` / `HOW_TO_USE.md` / `CORE_RULES.md`
- `agents/05_ai_simulator.md` / `agents/11_onboarding_advisor.md`
- `orchestrator/00_intake_form.md` / `02_workflow.md` / `path_existing.md`
- `evolution/failure_patterns.md` / `checklists/SUBMISSION_CHECKLIST.md`
- `templates/onboarding_skeletons/01_入驻SOP.md` / `03_价格策略.md`

#### B. INSTALL 脚本三平台重写（P0b）
之前装到 `accounts/{id}/skills/`，ACW 不读 → 改装到 `agent-core/skills/` 并自动注册 `skills.jsonc`：
- **`INSTALL.sh`**（macOS/Linux）：6 步流程，扫描 agent-core 自动识别"国际站生意助手"agent，多 agent 自动全装；内嵌 Python 处理 jsonc 注释剥离、备份、移除 deprecated 潜客版记录
- **`INSTALL.ps1`**（Windows）：同上 PowerShell 实现，临时 .py 写到 `$env:TEMP`
- **`INSTALL.bat`**：转发到 PowerShell（不再用纯 batch 处理 jsonc）

#### C. PDF Catalog 新功能（v1.2 旗舰功能）
新增 **Stage 5.5 Catalog PDF 生成**，让知识库可直接产出可发给客户的 PDF 手册：
- **`templates/catalog_pdf/generate_catalog.py`**（469 行 ReportLab 生成器）：
  - 三种 mode：`company_only`（5 页公司介绍）/ `catalog_only`（产品手册）/ `full_brochure`（完整版）
  - 8 节结构：封面 / About / 产品索引 / 产品页 ×N / 认证墙 / 5 大理由 / 客户案例 / CTA
  - 一产品一页，左主图右规格表 + 5 卖点 + MOQ + 价格 + CTA 营销钩子
  - 多语种独立 PDF（EN/ES/FR/AR/RU）
  - 中文字体自动检测系统字体或 NotoSansSC，缺图标 [N/A] 不编造
- **`templates/catalog_pdf/_selection_template.{json,md}`**：商家手选模式模板
- **`templates/catalog_pdf/sample_selection.json`**：完整 schema 示例（已实测跑通）
- **`agents/12_catalog_designer.md`**：sub-agent 定义（5 步任务 + R5 自检）
- **`references/catalog-design-spec.md`**：设计规范
- **`references/customer-interaction-cards.md` Card 4**：4 题选品确认（mode / 范围 / 多语种 / 营销钩子）

#### D. 质量统一性方案（解决"装别人电脑产出标准差异大"）
新增 `quality-gates/` + `examples/` + `orchestrator/03_standard_injector.md` 三件套：
- **`quality-gates/L1_checklist.json`**：每个 Stage Gate 5-10 项硬指标（可机读）
- **`quality-gates/L2_scoring_rubric.md`**：5 维度 100 分制（含新增"一致性"维度）
- **`quality-gates/L3_auto_repair.md`**：不达标自动重写决策表
- **`examples/golden_outputs/`**：5 个标杆案例（GE-01 知识库 / GE-02 品牌 / GE-03 Catalog / GE-04 应答 / GE-05 评分），脱敏自 XINTONG/HATA
- **`orchestrator/03_standard_injector.md`**：Stage 0 加载基准，每次 sub-agent spawn 自动注入 brief

#### E. Stage Gate 升级
6 Stage Gate → **7 Stage Gate（含 Stage 5.5）**

---

## v1.1.0 — 2026-05-05

### Installer — 安装器全面升级（终端一行命令 / 自动覆盖旧版）

- **新增 `INSTALL_ONELINER.md`** — 商家拿到 zip 后的 30 秒安装指南，主推「打开终端 + 输 bash + 拖 INSTALL.sh + 回车」的零打字方式
- **INSTALL.sh / INSTALL.ps1 / INSTALL.bat 三平台同步重写**：
  - 默认**自动覆盖旧版**（备份到 `.bak.{时间戳}`），无需 `read -p` 交互；想交互可加 `--interactive` / `-Interactive` 旗标
  - 多账号场景**自动选最近活跃**（mtime 最新），不再卡住等输入
  - **自动清理已弃用的 `alibaba-prelaunch-kb-builder`**（备份到 `.deprecated.{时间戳}`）
  - 终端不支持颜色码时优雅降级（不输出乱码 ANSI）
  - 完整性校验扩展到 `references/` 目录（v1.1.0 新加的）
- **HOW_TO_USE.md 第 1 步重写**：明确告诉商家「不要双击安装文件，会被关联程序接管」，引导走终端拖拽方式

### Major — 合并 alibaba-prelaunch-kb-builder + 对齐图片技能 v2.0.2 反幻觉机制

**🎯 设计目标**：把"宣称式约束"（CORE_RULES.md 是被动文档）升级为"Stage Gate 编码约束"（每 Stage 必须产出指定文件 + 强制可见自检块 + 标准互动卡 + 诚信审计模板），从机制上封堵 TANAKA_EV 类幻觉。

### Added — 合并潜客版（alibaba-prelaunch-kb-builder v1.0.1 → 本 Skill）

- 合并潜客版 9 个独有文件：
  - `agents/09_market_researcher.md` / `10_interviewer.md` / `11_onboarding_advisor.md`
  - `orchestrator/00_intake_round1.md` / `00_intake_round2.md`
  - `checklists/SUBMISSION_CHECKLIST.md`
  - `templates/onboarding_skeletons/*.md`
  - `INSTALL.ps1`
- `description` 扩展为「已开通 / 未开通 / 已开通但 MCP 不可用 三类全覆盖」
- `trigger_keywords` 新增 4 个潜客触发词（入驻前知识库 / 潜客知识库 / prelaunch 知识库 / 还没开店做知识库）

### Added — 对齐图片技能 v2.0.2 严谨度机制

- **新增 `references/customer-interaction-cards.md`**（363 行 / 4 张标准互动卡）
  - Card 0 商家手册资料收集（Stage 0 强制必答）
  - Card 1 公司+产品逐字段确认（6-10 字段拆 4 个 form，每字段 ✅/❌/⚠️ 三选一）
  - Card 2 Path A/B/C 路径分流
  - Card 3 优势逐项对齐（每项 4 选 1，软口径自动改写）
  - Card R6 超时未回汇报模板
  - 每张卡含「标准 ask_user 调用 + 商家典型回答与应对脚本」双层结构
- **新增 `references/audit-templates.md`**（176 行 / 3 个标准模板）
  - ① R5 诚信审计报告（每个 sub-agent 返回必做，5 项硬拦截+商家三选一）
  - ② R6.5 静默错误汇报（`[⚠️ 工具错误]` 块强制可见）
  - ③ R6.1 超时未回段（最终交付必加，5 列表格+总览）
- **新增 `references/source-acquisition.md`**（234 行）
  - P1-P4 信息源优先级铁律（手册→MCP→Browser→MarketResearcher）
  - PDP URL 含 slug 标准构建规则（避免 302 到错页）
  - A.4.5 原图视觉对齐强制环节（see_image 抽样校验图源污染）
  - L1-L3 三层降级策略（精准重抓 → 引导上传 → 标 [待商家补充]）
  - Browser 子代理任务包标准模板（含截图证据 + 严禁推荐位）
  - 三方交叉验证规则（差异表写入 VERIFIED_MERCHANT_INFO 顶部）
- **新增 `orchestrator/00_router.md`**（Path A/B/C 路由决策表）
- **新增 `orchestrator/path_hybrid.md`**（C 路径 · 已开通无 MCP 主流程，准确度自评 80%）

### Changed — SKILL.md 重写为「商家视图 6-Stage Gate + AI 执行约束 R1-R7」双章结构

- **第一章 商家视图（对外）**：6 Stage Gate
  - Stage 0 商家信息收集 → `VERIFIED_MERCHANT_INFO.md`
  - Stage 0.5 Path 路由
  - Stage 1 公司+产品逐字段确认 → `CONFIRMED_COMPANY_PRODUCT.md`
  - Stage 2 市场调研 → `MARKET_RESEARCH_REPORT.md`
  - Stage 3 优势对齐 → `CONFIRMED_ADVANTAGES.md`（最关键反幻觉门禁）
  - Stage 4 KB 生成（按 Path 分流）→ `KB_PUBLIC/` + `99_INTERNAL_ONLY/`
  - Stage 5 独立评分 + 修复 → `AI_RESPONSE_SIMULATION.md`
  - Stage 6 交付 → `VERIFICATION_REPORT.md`（必加超时未回段+ Path C 准确度提示）
- **第二章 AI 执行约束（对内）**：R1-R7 + R1.1
  - R1 强制 Stage Gate 不可跳过（每条标违反后果）
  - **R1.1 Stage 切换前置自检**（强制可见 `## 🚦 Stage N 启动 · 前置自检` 块，封堵"宣称式约束"）★ 最关键新增
  - R2 信息源优先级（详见 source-acquisition.md）
  - R3 三方交叉验证 + 视觉/语义对齐
  - R4 5 类红线反幻觉（详见 CORE_RULES.md）
  - R5 主代理诚信审计（详见 audit-templates.md 模板①）
  - R6 失败处理（R6.1 超时降级 + R6.5 静默错误汇报）
  - R7 评分中立（AISimulator 全新独立 session，不读 Writer 任何中间产物）

### Deprecated

- `alibaba-prelaunch-kb-builder` 整个 Skill 弃用，所有功能并入本 Skill 的 path B
- 商家从此只需安装一个 Skill 即可覆盖三类场景

### Migration — 升级建议

- 已装 v1.0.x 的商家：删除旧目录后安装 v1.1.0 即可，所有交付目录格式向后兼容
- 已装 alibaba-prelaunch-kb-builder 的商家：必须卸载旧潜客版，改用本 Skill 的 path B

## v1.0.3 — 2026-05-02

### Changed — Accio Work 安装入口替换为专属邀请链接

- **HOW_TO_USE.md**：第 0 步「还没装 Accio Work」的下载链接替换为 Ray 的专属邀请链接（含 sId / ic / src / channel 参数）
- **INSTALL.sh**：检测不到 Accio Work 时的提示信息使用专属邀请链接
- **INSTALL.bat**：同上，注意 Windows cmd 中 `%` 需转义为 `%%`、`&` 需转义为 `^&`
- **保留**：`accio.com/work/doc` 文档站点链接（用于查阅产品文档，非注册入口）
- **影响**：商家通过本 Skill 注册 Accio Work 时，会归属到 Ray 的邀请渠道

## v1.0.2 — 2026-05-02

### Added — 商家分发就绪

- **`HOW_TO_USE.md`**：商家拿到 zip 包后第一份要看的文档。覆盖 5 步上手流程（装 Accio Work → 放 Skill → 验证 → 触发 → 答 13 问 → 等成品）+ 8 题 FAQ。
- **`INSTALL.sh`**：macOS / Linux 一键安装脚本。自动检测 Accio Work 安装、识别账号 ID（多账号时让用户选）、备份旧版后覆盖、设置脚本权限、给出"重启 Accio + 触发词"指引。
- **`INSTALL.bat`**：Windows 同等功能的安装脚本（cmd 双击运行）。
- **影响**：现在商家拿到 zip 包后，可以独立完成"解压 → 双击安装 → 触发使用"全流程，无需任何人工指导。

## v1.0.1 — 2026-05-02

### Patch — 多店铺防错配

- **修复**：SKILL.md Step 1 智能回填增加防错配规则。在多商家服务场景下，若当前对话最近 20 条消息没有任何线索表明商家就是 MERCHANT_PROFILE 中的店铺，**整体跳过回填**，13 问全部以 ❓ 形式问商家。
- **背景**：v1.0.0 触发测试时发现，主 agent 会无条件读 MERCHANT_PROFILE 回填给所有新商家，造成 A 店画像污染 B 店问卷的风险。
- **影响范围**：仅 SKILL.md，1 处 edit。其他文件零变更。

## v1.0.0 — 2026-05-02

### Initial Release

**核心能力**
- 13 阶段编排主流程
- 8 个显式定义的 sub-agent（Writer / Translator / FormatConverter / RiskScanner / AISimulator / RepairExecutor / ImageGenerator / EvolutionRecorder）
- 13 问详尽版商家问卷（智能回填 + 缺失追问）
- 6 模块知识库骨架（公司/产品/沟通/服务/物流/支付）
- 8 行业 AI 模拟问题包（工业 B2B / 消费品 / 服装 / 食品 / 电子 / 家居 / 机械 / 服务）
- 5 风格营销素材生图预设（工业蓝技术 / 简约白底 / 暖色生活 / 商务专业 / 自定义参考）
- 物理隔离 INTERNAL 资产 + 三类风险全库扫描
- AI 应答模拟 30 分制评分 + 自动修复迭代
- 跨商家演进数据池（脱敏）

**种子数据**
- evolution/industry_insights.jsonl 已含 1 条种子（来源：太阳能路灯/智慧公路 EPC 案例，已脱敏为 seed_case_001）

**已知限制（v1 不做，留 v1.1+）**
- schema.org FAQPage JSON-LD 标记（提升抓取识别率）
- 自动同步 1688 / 店铺装修页内容回写
- 拒付/退货/纠纷专题模块（当前需商家自定义）
- 中文版 KB_PUBLIC（当前主语种限定 EN）
- 营销素材的派生语种翻译（当前仅主语种）

## 升级与版本管理

商家可手动升级：
1. 检查 `VERSION` 文件比对当前版本
2. read `CHANGELOG.md` 评估是否需要重跑
3. 重跑时 spec 中可勾选"复用上次产出仅做增量"

## v1.3.0 (2026-06-02) — 抓取规则真相化 + 反幻觉补强（基于完整版 v1.2.1 合入）

### 背景
商家反馈"内容传了但 EVA 自动接待抓不到"（实测 query: what is the moq of baseball cap）。

### 新增
- references/alibaba-retrieval-rules.md：经阿里官方新闻稿(PX002D09Z / PX002D6ER)核实的 EVA/AI Search 真实抓取规则。明确区分「货架场(前台搜索抓 listing)」vs「业务场(EVA 抓 KB)」，杜绝"知识库提升前台搜索排名"幻觉承诺。含「100% 可抓取」7 铁律 + 三大抓不到根因 R-E1/R-E2/R-E3。
- examples/golden_outputs/GE-06_eva_retrievable_baseball_cap.md：反例→正例样例。

### 修改
- agents/01_writer.md：强制 read 抓取规则 + 内嵌 7 铁律硬门禁。
- agents/05_ai_simulator.md：AICitability 改为按 7 铁律评分；命中占位符直接判"抓不到"。
- SKILL.md：前置 read 清单加入 alibaba-retrieval-rules.md + 诚实口径约束。

## v1.3.1 (2026-06-02) — 内容深度 + 多源差异化 + 零幻觉强化

### 背景
商家要求：(1)生成内容足够详细且 EVA 必抓 (2)融合国际站内部+客户提供+外部(官网/公域/社媒)三源，放大差异化优势，但严格零幻觉。

### 新增
- references/content-depth-and-sourcing.md：深度门禁 D1-D6 + 多源差异化挖掘 DA-Flow + 零幻觉 T1-T5 来源分级 + No Evidence No Claim 取证规则。

### 修改
- SKILL.md：前置 read 加入 content-depth-and-sourcing.md；三大交付目标(可抓取/详细差异化/零幻觉)写入头部；Stage 2 新增"商家自身外部差异化取证(来源C)"强制线 + DIFFERENTIATION_CANDIDATES.md + 01_external_evidence/；Stage 3 Card3 纳入外部候选裁决；Stage 4 Writer 任务包加深度门禁+差异化汇总条目，Gate 加 D1-D6/证据反查校验。
- agents/01_writer.md：强制 read 深度文件 + 内嵌 D1-D6 深度门禁 + 多源/零幻觉/差异化条目要求。
- agents/05_ai_simulator.md：Accuracy 改 Sourced(证据反查), 新增 Depth/Differentiation 全局诊断触发修复。
- agents/09_market_researcher.md：新增 Step5 商家自身官网/公域/社媒取证 + DIFFERENTIATION_CANDIDATES.md 产出。

## v1.4.0 (2026-06-02) — 强化审计+中文目录+预热提示词(封装)

### 背景
实跑跃动JUMP暴露:子代理编造交期/样品费幻觉、首版只交4篇、英文目录。本次系统性修复并封装。

### 新增
- scripts/delivery_audit.py:可执行交付审计(模块篇数下限/深度/7铁律/占位符/幻觉数字扫描/中文目录结构),交付前强制跑,FAIL=0才可交付。
- references/中文目录规范.md:所有产出文件夹含子文件夹用中文(知识库_对客/英文/01_公司信息),唯一目录事实源。
- 预热提示词.md:消除冷启动,任何人安装后贴预热词即达一致交付质量;含安装自检清单+触发话术+一致性原理。

### 修改
- SKILL.md:read清单加中文目录规范;三大目标→四大目标(加交付完整防偷工减料);目录命名铁律(中文);本机PIL/lxml限制说明(办公文档走office-suite);零幻觉补充高危编造项(交期/样品费/质保拆分/金额门槛)。

### 实跑验证
- 审计脚本对跃动交付检出3问题(2篇<250词+1篇可疑天数)→修复→复审FAIL=0 WARN=0,闭环有效。
