# Path C 主流程：已开通国际站但 MCP 不可用 · v1.1.0

> 触发条件：[Card 2](../references/customer-interaction-cards.md#card-2--path-abc-路径分流) 商家选 C，或 path A 中途 MCP 失败切换过来。
> 设计原则：**所有数据从 P1 商家手册 + P3 browser 抓 minisite + P4 MarketResearcher 三方拼凑，绝不调用 MCP**。

---

## 与 path_existing 的差异速览

| 阶段 | path_existing (A) | path_hybrid (C) |
|------|------------------|----------------|
| Stage 0 数据源 | 手册 + MCP `list_products` | **手册 + browser 抓 minisite Top 10 商品** |
| Stage 1 字段确认 | 用 MCP 字段做 Card 1 | 用 browser 抓字段做 Card 1，明示「来源=minisite」|
| Stage 2 调研 | 同 | 同（MarketResearcher 不依赖 MCP）|
| Stage 3 优势对齐 | 同 | 同 |
| Stage 4 KB 生成 | Writer 用 MCP 全字段 | Writer 用 minisite + 手册字段，缺字段标 [待商家补充] |
| 准确度自评 | 95%+ | **80% 左右**（必须在最终交付明示）|

---

## Stage 0 → Stage 1 流程（C 路径专用）

### 0.1 收集商家店铺 URL

```python
ask_user(
  mode="chat",
  question="您的国际站店铺 minisite URL 是？（格式：https://xxx.en.alibaba.com/）",
  placeholder="https://xxx.en.alibaba.com/"
)
```

校验：URL 必须以 `.en.alibaba.com/` 结尾或含 `alibaba.com/company` 路径。不符合 → 重问。

### 0.2 spawn browser 抓 minisite

按 [source-acquisition.md B.1](../references/source-acquisition.md#b1-抓本店-minisite) 的标准任务包发 spawn。

**spawn 后 main agent 必做（R1.1 自检）**：

```markdown
## 🚦 Stage 0 browser 抓取 · 前置自检
- [x] 已 spawn browser 子代理，session_key = {key}
- [x] 任务包含 see_image 自校验要求
- [x] 5 分钟超时降级已内置
- 等待返回...
```

### 0.3 browser 返回后必做（R5 诚信审计）

按 [audit-templates.md 模板①](../references/audit-templates.md#模板--r5-诚信审计报告每个-sub-agent-返回必做) 输出诚信审计报告。

- 落盘验证：`<工作目录>/01_browser_evidence/` 必须有截图
- visual_mismatch=true 的商品 → 不进 Stage 1，标 [图源污染待商家修复]
- partial 状态 → ask_user 让商家选「按现有部分继续 / 等我手动补充再继续」

### 0.4 写入 VERIFIED_MERCHANT_INFO.md

每个字段必须标 source：
```markdown
- 公司名: ABC Co. Ltd.   `source: handbook · catalog.pdf p.2`
- 工厂面积: 5000㎡   `source: minisite · /companyprofile.html`
- 认证: ISO9001   `source: minisite · /certifications.html · 待商家 Card 1 确认`
```

---

## Stage 1 字段确认（C 路径专用调整）

走 [Card 1](../references/customer-interaction-cards.md#card-1--公司产品逐字段确认stage-1-强制门禁)，但 question 描述里**必须明示来源**：

```python
"question": "公司名称从您 minisite 抓到的是 \"{抓到的公司名}\"（来源：{shop_url}），对吗？"
```

让商家看到来源，避免商家以为 AI"凭空知道"。

---

## Stage 2 / Stage 3 / Stage 4 与 path_existing 一致

直接 read [path_existing.md](path_existing.md) 的对应章节执行，**唯一差异**：

- Writer 在生成 KB 时遇到「需要 MCP 字段才能填」的位置（如 SKU 详细规格表 / 历史询盘热门词）→ **标 [待商家补充]**，不可编造
- 最终交付报告必加段落：

```markdown
## ⚠️ 本次 KB 准确度自评：80%

原因：本次未调用 MCP，所有数据来自您手册 + minisite + 同行调研。
- minisite 上的商品参数可能不全（部分 SKU 在 minisite 上没列规格）
- 询盘热词、近 30/60/90 天热门询问等数据源缺失
- 已用 [待商家补充] 占位的字段共 N 个

建议：补上 MCP 授权后我可以重跑 KB 校准（保留您本次确认的字段，仅补缺失项），预计 30 分钟内完成。
```

---

## 文件版本

| 版本 | 日期 | 改动 |
|------|------|------|
| v1.1.0 | 2026-05-05 | 初版 — 新增，C 路径不依赖 MCP，用 browser+手册替代 |
