# Path 路由 · v1.1.0

> main agent 在 Stage 0 商家手册收集完成后，**必须 read 本文件**，按 [Card 2](../references/customer-interaction-cards.md#card-2--path-abc-路径分流) 商家选定的 A/B/C 跳转到对应主流程文件。

---

## 决策表

| 商家在 Card 2 选 | 含义 | 接下来 read | 备注 |
|----------------|------|------------|------|
| **A** | 已开通 + MCP 授权可用 | [path_existing.md](path_existing.md) | 完整流程，最高质量 |
| **B** | 还没开通国际站（潜客） | [path_prelaunch.md](path_prelaunch.md) | 前置 spawn `agents/10_interviewer.md` 做 2 轮访谈 |
| **C** | 已开通但 MCP 不可用 | [path_hybrid.md](path_hybrid.md) | 用 browser + 手册替代 MCP |

---

## 进入路径前的强制自检（R1.1）

main agent 在 read 主流程文件之前，**必须**输出以下可见自检块：

```markdown
## 🚦 Path {A/B/C} 路径选定 · 前置自检

- [x] Stage 0 商家手册收集完成（VERIFIED_MERCHANT_INFO.md 已写入）
- [x] Card 2 商家选定 = {A/B/C}
- [x] 已 read orchestrator/path_{existing/prelaunch/hybrid}.md
- 路径预计耗时：{60-90 / 90-120 / 75-100} 分钟
- 下一步：进入 Stage 1（公司+产品逐字段确认）
```

不写 = 违规。商家可凭此质问是否真的按规则走。

---

## 路径切换规则

如果路径执行中途发现选错（比如选了 A 但 MCP 实际拿不到任何数据），**立即停下**：

1. 输出 `[⚠️ 工具错误]` 块（按 [audit-templates.md 模板②](../references/audit-templates.md#模板--r65-静默错误汇报)）
2. ask_user：「检测到 MCP 实际不可用，建议切到 path C 用 browser 替代，您确认吗？」
3. 商家确认 → read path_hybrid.md 重新进 Stage 1（已收集的 VERIFIED_MERCHANT_INFO.md 保留复用）
4. 商家说「先修 MCP」→ 暂停 Skill，等待商家修好后说「继续」

---

## 路径文件版本对应

| 路径 | 文件 | 版本 |
|------|------|------|
| A 已开通+MCP | path_existing.md | v1.1.0（合并自原 v1.0.4 02_workflow.md）|
| B 潜客 | path_prelaunch.md | v1.1.0（合并自原潜客 02_workflow.md）|
| C 已开通无 MCP | path_hybrid.md | v1.1.0（新增）|
