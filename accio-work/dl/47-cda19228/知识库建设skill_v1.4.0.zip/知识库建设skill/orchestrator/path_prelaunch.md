# 14 阶段主流程（潜客版）

> 此文档由生意助手在商家 ✅ Spec 后按顺序执行。
> 与存量版 13 阶段对比：在阶段 2-5 之间插入"公开资料学习 + Round2 追问"，整体编号上移。

---

## 阶段 0 — Skill 识别 ✅

**触发条件**：商家说触发关键词（见 SKILL.md 的 trigger_keywords）
**动作**：read `SKILL.md` → 进入阶段 1

---

## 阶段 1 — 资料档位自动判断（A/B/C）

**目标**：根据商家已提交的资料和对话内容，自动归档位
**动作**：
1. 检查 attachments 数量和类型
2. 检查对话中已透露的信息
3. 按 SKILL.md Step 0 的判定表归档
4. 写入 `<work_dir>/INTAKE_TIER.txt`

**产出**：A/B/C 标签 + 推荐流程深度

---

## 阶段 2 — 资料提交清单分发（按需）

**触发条件**：商家未提交任何素材 OR 档位为 C
**动作**：
1. read [checklists/SUBMISSION_CHECKLIST.md](../checklists/SUBMISSION_CHECKLIST.md)
2. 精简版输出给商家
3. 等商家上传后归档到 `<work_dir>/_submissions/`，写一份 `SUBMISSION_CHECKLIST_FILLED.md`

---

## 阶段 3 — Round 1 访谈（12 题）

**动作**：
1. read [00_intake_round1.md](00_intake_round1.md)
2. 把 12 题问卷展示给商家
3. **等商家回答**

---

## 阶段 4 — 公开资料学习（MarketResearcher）

**动作**：商家答完 Round1 立即 spawn MarketResearcher：
- read [agents/09_market_researcher.md](../agents/09_market_researcher.md)
- 输入：商家品类 / 竞品 / 目标市场 / 档位
- 产出：`<work_dir>/MARKET_RESEARCH_BRIEF.md`

**档位差异**：
- A 档：跳过此阶段（资料已足）或仅做对标补充（spawn 但限制爬取范围）
- B 档：标准爬取（5 家同行 + Google + 行业基准）
- C 档：深度爬取（5 家同行 + 8-10 个 Google 关键词）

---

## 阶段 5 — Round 2 访谈（精准追问）

**动作**：
1. spawn Interviewer：
   - read [agents/10_interviewer.md](../agents/10_interviewer.md)
   - 输入：Round1 答案 + MARKET_RESEARCH_BRIEF.md
   - 生成 8-10 题精准追问
2. 把题抛给商家
3. **等商家回答**
4. Interviewer 整理 `INTERVIEW_LOG.md`

**档位差异**：
- A 档：精简为 6-8 题（缺口少）
- B 档：标准 8-10 题
- C 档：扩展到 10-12 题（覆盖更多缺口推断验证）

---

## 阶段 6 — Spec 锁定

**动作**：
1. read [01_spec_lock_template.md](01_spec_lock_template.md)
2. 合成 Round1 + Round2 + MarketResearchBrief 三方信息
3. write 到 `<work_dir>/SPEC_LOCKED.md`
4. 把 SPEC 简版输出给商家，**等 ✅ 确认**

---

## 阶段 7 — 目录骨架生成（三层目录）

**动作**（一次性 bash）：
```bash
WORK_DIR="<workspace>/<store>_入驻知识库_<YYYY>Q<N>"
mkdir -p "$WORK_DIR"/{KB_PUBLIC,DOCX_VERSIONS,KB_INTERNAL/{price_strategy,competitor_intelligence,sales_training,deal_case_study_template},ONBOARDING_GUIDE,04_营销素材,_submissions}

for lang in $primary_lang $derived_langs; do
  for module in $kb_modules; do
    mkdir -p "$WORK_DIR/KB_PUBLIC/$lang/$module"
    mkdir -p "$WORK_DIR/DOCX_VERSIONS/$lang/$module"
  done
done
```

read [templates/kb_module_skeletons/](../templates/kb_module_skeletons/) 下对应骨架。

---

## 阶段 8 — 批量写作（EN 主语种）

**动作**：
- 按 SPEC 中的 N 个模块，**并行** spawn N 个 Writer
- read [agents/01_writer.md](../agents/01_writer.md)
- ⭐ **潜客版强化**：Writer prompt 中必须额外注入 MARKET_RESEARCH_BRIEF.md 和 INTERVIEW_LOG.md 的内容
- ⭐ Writer 输出每段必须标注来源（[商家原文]/[访谈]/[公开资料推断]+URL/[行业基准]/[待商家补充]）

**产出**：`KB_PUBLIC/EN/<各模块>/*.md`

---

## 阶段 9 — 风险预扫描

**动作**：spawn RiskScanner sub-agent
- read [agents/04_risk_scanner.md](../agents/04_risk_scanner.md)
- 跑 [scripts/risk_scan.sh](../scripts/risk_scan.sh)
- 三类风险：训练标签 / 竞品名 / 内链残留
- ⭐ 潜客版额外检查：是否有"虚构客户名/虚构数字"残留

---

## 阶段 10 — 派生语种翻译

**动作**：
- 按 SPEC 中的派生语种列表，**并行** spawn N 个 Translator
- read [agents/02_translator.md](../agents/02_translator.md)
- 翻译时保留来源标注

---

## 阶段 11 — 营销素材生成

**动作**：spawn ImageGenerator
- read [agents/07_image_generator.md](../agents/07_image_generator.md)
- 按 SPEC 选定的风格 read [style_presets/<style>.md](../style_presets/)
- 产出到 `04_营销素材/`

---

## 阶段 12 — 入驻指引专属文档生成（OnboardingAdvisor）⭐

**动作**：spawn OnboardingAdvisor
- read [agents/11_onboarding_advisor.md](../agents/11_onboarding_advisor.md)
- 输入：SPEC + MARKET_RESEARCH_BRIEF + INTERVIEW_LOG + 已生成的 KB_PUBLIC EN
- 产出：`ONBOARDING_GUIDE/01_入驻SOP.md` / `02_首批SKU选品建议.md` / `03_价格策略.md`（+ 可选 04 / 05）
- 同时写 `KB_INTERNAL/price_strategy/full_price_matrix.md`

---

## 阶段 13 — .docx 镜像 + AI 应答模拟 + 修复

### 13.1 .docx 镜像
- 执行 [scripts/batch_pandoc.sh](../scripts/batch_pandoc.sh)
- 镜像 KB_PUBLIC + 部分 KB_INTERNAL + ONBOARDING_GUIDE 的 .docx
- 校验数量

### 13.2 AI 应答模拟
- spawn AISimulator → read [agents/05_ai_simulator.md](../agents/05_ai_simulator.md)
- 题库来源同存量版（按 SPEC 选 A/B/C/D）
- 输出 `AI_RESPONSE_SIMULATION.md`

### 13.3 修复迭代
判定：
- 总分 ≥ 28 → 跳过修复
- 总分 25-27 → P0 修复
- 总分 < 25 → P0+P1 修复

spawn RepairExecutor → read [agents/06_repair_executor.md](../agents/06_repair_executor.md)
重跑风险扫描 + AI 模拟，确保 ≥ 28（A 级）

---

## 阶段 14 — 交付 + 演进沉淀

**动作**：
1. 生成 README.md / UPLOAD_GUIDE.md / VERIFICATION_REPORT.md
   - **UPLOAD_GUIDE.md 必须含"入驻流程引用 ONBOARDING_GUIDE/01_入驻SOP.md"**
2. 跑 [scripts/alignment_check.sh](../scripts/alignment_check.sh)
3. spawn EvolutionRecorder → read [agents/08_evolution_recorder.md](../agents/08_evolution_recorder.md)
4. 写入演进数据池
5. 向商家输出最终交付汇报：
   - 文件统计（KB_PUBLIC / KB_INTERNAL / ONBOARDING_GUIDE 三类分别多少篇）
   - 风险扫描结果
   - AI 模拟评分
   - 入驻指引摘要（关键 SKU + 价格档位）
   - 后续可选项（先按 ONBOARDING/01 入驻 → 上传 KB_PUBLIC → 训练销售用 KB_INTERNAL）

---

## 异常处理

| 情况 | 处理 |
|------|------|
| MarketResearcher 完全无法访问外网 | 标注"基于行业常识"，跳过对标 |
| 商家在 Round 2 表示"我都不知道你随便编" | 强提示"我不能编关键事实，会标 [待补充]" |
| sub-agent 输出超长被 truncate | RepairExecutor 拆分续写 |
| 翻译 sub-agent 漏译某段 | RiskScanner 检查到三语种行数差 > 10% 报警 |
| 商家中途想改 SPEC | 回到阶段 6 重新锁定 |
| 商家说"先停" | 把当前进度写入 `<work_dir>/EXECUTION_STATE.json`，下次可续 |
