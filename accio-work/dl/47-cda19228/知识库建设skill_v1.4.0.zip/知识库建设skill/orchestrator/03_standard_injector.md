# Standard Injector — 标准注入器

> **目的**：解决"装到别人电脑上没有打磨记忆 → 产出标准差异大"的问题。
> **触发时机**：Stage 0 (Intake 之前) 强制执行；每个 sub-agent spawn 之前注入摘要。

---

## 工作原理

```
┌─────────────────────────────────────────────────────────┐
│  ① skill 启动                                            │
│       ↓                                                  │
│  ② 读 agent-core/MEMORY.md 看是否有"知识库建设"记忆     │
│       ├─ 有：用商家自己的历史案例作为更精准基准 ─┐      │
│       └─ 无：加载 examples/golden_outputs/* ────┤       │
│                                                  ↓      │
│  ③ 生成 STANDARD_BRIEF.md (本次任务的"老师傅基准")      │
│       ↓                                                  │
│  ④ 每个 sub-agent spawn 前自动 append 该 brief 到 task   │
│       ↓                                                  │
│  ⑤ R5 自检阶段对照 brief 评分                            │
└─────────────────────────────────────────────────────────┘
```

---

## 步骤 1 — 检测商家历史记忆

```bash
MEMORY_FILE="${agent_core}/MEMORY.md"
DIARY_DIR="${agent_core}/diary"

# 检测是否有"知识库"相关历史记忆
if grep -l -E "(知识库|kb_builder|knowledge.base)" "$MEMORY_FILE" "$DIARY_DIR"/*.md 2>/dev/null; then
  STANDARD_SOURCE="MEMORY"
else
  STANDARD_SOURCE="GOLDEN_EXAMPLES"
fi
```

## 步骤 2 — 生成 STANDARD_BRIEF.md

写到 `<work_dir>/_meta/STANDARD_BRIEF.md`，作为本次任务的硬基准。

### 模板

```markdown
# 本次任务标准基准（自动生成 by standard_injector）

来源：{MEMORY 或 GOLDEN_EXAMPLES}
生成时间：{timestamp}

## 必须遵循的硬指标
- 见 quality-gates/L1_checklist.json 全部 P0 项
- 总分必须 ≥ 75

## 结构对齐参考
- 知识库骨架：参见 examples/golden_outputs/GE-01_solar_kb_skeleton.md
- 品牌战略：GE-02
- Catalog PDF：GE-03
- 应答模拟：GE-04
- 评分报告：GE-05

## 商家历史偏好（仅当 MEMORY 来源）
{从 MEMORY.md 抽出的关键偏好，如视觉风格、Surgical Mode 等}

## 评分维度（5 维度 100 分制）
见 quality-gates/L2_scoring_rubric.md

## 不达标修复路径
见 quality-gates/L3_auto_repair.md
```

## 步骤 3 — Sub-agent 注入

每次 `sessions_spawn` 时，task 描述末尾**强制 append**：

```
---
【标准基准】请先 read 以下文件再开始工作：
1. <work_dir>/_meta/STANDARD_BRIEF.md
2. quality-gates/L1_checklist.json (本 stage 段)
3. examples/golden_outputs/GE-{对应ID}.md

输出前必须跑 R5 自检（见 L3_auto_repair.md 末尾模板），
P0 全过 + 维度分 ≥ 75 才能交付。
```

## 步骤 4 — 失败兜底

| 异常 | 处理 |
|------|------|
| MEMORY.md 不存在 | 用 GOLDEN_EXAMPLES，不报错 |
| golden_outputs/ 不存在 | 报 R6 silent-error 但继续执行，标记"低质量交付" |
| STANDARD_BRIEF.md 写入失败 | 终止，提示商家手工创建工作目录 |

---

## 一致性验证（交付前必跑）

```bash
# 1. 目录结构相似度（与 GE-01 比对）
diff <(find {work_dir}/KB_PUBLIC -type d | sort) \
     <(grep -E "^├──|^│" examples/golden_outputs/GE-01_solar_kb_skeleton.md | parse_paths)
# 相似度 < 80% → 触发 L3 重做

# 2. 文件数量
test $(find {work_dir} -name "*.md" | wc -l) -ge 60 || FAIL G3.1

# 3. 字段深度抽样（任取 5 个 .md）
for f in $(find {work_dir} -name "*.md" | shuf -n 5); do
  test $(grep -c "^|" "$f") -ge 1 || WARN "$f 无表格"
done
```

---

## 与现有 stage 集成

| Stage | injector 介入点 |
|-------|----------------|
| Stage 0 (Intake) | 步骤 1+2 跑完，生成 BRIEF |
| Stage 2-5 | 每次 spawn sub-agent 步骤 3 自动 append |
| Stage 5 (评分) | 用 GE-05 模板写评分报告 |
| Stage 6 (交付) | 一致性验证脚本必跑 |
