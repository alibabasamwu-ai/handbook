# 13 阶段主流程

> 此文档由生意助手在商家 ✅ Spec 后按顺序执行。每阶段开头先 read 对应 sub-agent 的 prompt 模板。

---

## 阶段 0 — Skill 识别 ✅

**触发条件**：商家说触发关键词（见 SKILL.md 的 trigger_keywords）
**动作**：read `SKILL.md` → 进入阶段 1

---

## 阶段 1 — 智能回填

**目标**：避免商家重复提供已知信息
**动作**：
1. read `${agent_core}/MERCHANT_PROFILE.json`（如存在）
2. memory_search 查 "店铺名 主营 战略 差异化 目标买家"
3. 如商家有店铺装修配置文件或经营数据导出，read 之
4. 把已知字段记入待填问卷的 `[已回填: xxx]` 标签

**产出**：内存中的 `prefilled_answers` 字典

---

## 阶段 2 — 抛出 13 问详尽问卷

**动作**：
1. read [00_intake_form.md](00_intake_form.md)
2. 把 `prefilled_answers` 替换占位符 `{{Q1_PLACEHOLDER}}` 等
3. 输出整张问卷给商家
4. **等商家回答**（这里会停留一轮对话）

---

## 阶段 3 — Spec 锁定

**动作**：
1. read [01_spec_lock_template.md](01_spec_lock_template.md)
2. 把商家回答填入模板所有 `{{...}}` 占位符
3. write 到商家工作目录 `<workspace>/<store>_知识库_<YYYY>Q<N>/SPEC_LOCKED.md`
4. 把 SPEC 内容简版输出给商家，**等 ✅ 确认开工**

---

## 阶段 4 — 目录骨架生成

**动作**（一次性 bash）：
```bash
WORK_DIR="<workspace>/<store>_知识库_<YYYY>Q<N>"
mkdir -p "$WORK_DIR"/{KB_PUBLIC,DOCX_VERSIONS,99_INTERNAL_ONLY/{price_matrix,negotiation_taboos,competitor_intelligence,sales_training,deal_case_studies},04_营销素材}

for lang in $primary_lang $derived_langs; do
  for module in $kb_modules; do
    mkdir -p "$WORK_DIR/KB_PUBLIC/$lang/$module"
    mkdir -p "$WORK_DIR/DOCX_VERSIONS/$lang/$module"
  done
done
```

按 SPEC_LOCKED 中选定的模块创建子目录。read [templates/kb_module_skeletons/](../templates/kb_module_skeletons/) 下对应的目录骨架。

---

## 阶段 5 — 批量写作（EN 主语种）

**动作**：
- 按选定的 N 个模块，**并行** spawn N 个 Writer sub-agent
- 每个 Writer 负责一个模块（如"公司信息"）
- read [agents/01_writer.md](../agents/01_writer.md) 作为 prompt 模板
- 模板中的占位符（{{store_name}}/{{anchor}}/{{module_name}}/...）从 SPEC_LOCKED 注入

**产出**：`KB_PUBLIC/EN/<各模块>/*.md`

---

## 阶段 6 — 风险预扫描

**动作**：spawn RiskScanner sub-agent
- read [agents/04_risk_scanner.md](../agents/04_risk_scanner.md)
- 跑 [scripts/risk_scan.sh](../scripts/risk_scan.sh)
- 三类风险扫描：训练标签 / 竞品名 / 内链
- **若有命中**：先暂停翻译，让 Writer 修正后再继续

---

## 阶段 7 — 派生语种翻译

**动作**：
- 按 SPEC_LOCKED 中的派生语种列表，**并行** spawn N 个 Translator sub-agent
- 每个 Translator 负责一个派生语种
- read [agents/02_translator.md](../agents/02_translator.md)
- 翻译规则：术语保留 / 语气敬称（usted/vous/Sie 等按语种习惯）

**产出**：`KB_PUBLIC/<派生语种>/<各模块>/*.md`

---

## 阶段 8 — 营销素材生成

**动作**：spawn ImageGenerator sub-agent
- read [agents/07_image_generator.md](../agents/07_image_generator.md)
- 按 SPEC 选定的风格 read [style_presets/<style>.md](../style_presets/)
- 按数量和类型组合调用 image_generate
- 产出到 `04_营销素材/`

---

## 阶段 9 — 内部资产建立

**动作**：根据 SPEC 中的"含销售训练话术"等开关，按需建立：
- `99_INTERNAL_ONLY/sales_training/` — 销售训练话术（Bad/Good/Pro Talk）
- `99_INTERNAL_ONLY/price_matrix/` — 价格矩阵（含成本/底价/标价/折扣边界）
- `99_INTERNAL_ONLY/negotiation_taboos/` — 谈判禁忌
- `99_INTERNAL_ONLY/competitor_intelligence/` — 竞品情报（直接点名）
- `99_INTERNAL_ONLY/deal_case_studies/` — 战例（含真实客户名）

read [templates/](../templates/) 下对应的 INTERNAL 模板。

---

## 阶段 10 — .docx 镜像批量生成

**动作**：执行 [scripts/batch_pandoc.sh](../scripts/batch_pandoc.sh)
- 镜像 KB_PUBLIC + 选定的 INTERNAL 内容
- 校验 .md 数 == .docx 数

---

## 阶段 11 — AI 应答模拟

**动作**：spawn AISimulator sub-agent
- read [agents/05_ai_simulator.md](../agents/05_ai_simulator.md)
- 按 SPEC 中的"问题集来源"加载题目：
  - A 智能推荐 → 按品类匹配 question_packs/<industry>.md 取 Top 10
  - B 行业模板 → 直接 read 对应行业包
  - C 自定义勾选 → 商家提供
  - D 三者结合 → 默认 A + 商家补充
- 对每题模拟 Accio Work 生意助手基于 KB 应答 + 30 分制评分
- 输出 `AI_RESPONSE_SIMULATION.md`

---

## 阶段 12 — 修复迭代

**判定规则**（自动）：
- 总分 ≥ 28 → 跳过修复，直接交付
- 总分 25-27 → 触发 P0 修复
- 总分 < 25 → 触发 P0+P1 修复（即使 SPEC 选了 P0 only 也升级）

**动作**：spawn RepairExecutor sub-agent
- read [agents/06_repair_executor.md](../agents/06_repair_executor.md)
- 按 SPEC 中的修复深度和实际触发结果执行
- 重跑风险扫描确认 0 残留
- 重跑 AI 模拟确认评分 ≥ 28（A 级）

---

## 阶段 13 — 交付 + 演进沉淀

**动作**：
1. 生成 README.md / UPLOAD_GUIDE.md / VERIFICATION_REPORT.md（read [templates/](../templates/) 下模板）
2. 跑 [scripts/alignment_check.sh](../scripts/alignment_check.sh) 校验三语种对齐
3. spawn EvolutionRecorder sub-agent → read [agents/08_evolution_recorder.md](../agents/08_evolution_recorder.md)
4. 把本次执行（脱敏）写入 [evolution/industry_insights.jsonl](../evolution/industry_insights.jsonl)
5. 向商家输出最终交付汇报（中文，结构化）：
   - 文件统计
   - 风险扫描结果
   - AI 模拟评分
   - 上传建议
   - 后续可选项（打 ZIP / 培训 PPT / P2 优化 / 暂停）

---

## 异常处理

| 情况 | 处理 |
|------|------|
| sub-agent 输出超长被 truncate | RepairExecutor 拆分续写 |
| 翻译 sub-agent 漏译某段 | RiskScanner 检查到三语种行数差 > 10% 报警 |
| 商家中途想改 SPEC | 回到阶段 3 重新锁定 |
| 商家说"先停" | 把当前进度写入 `<workspace>/<store>_知识库_../EXECUTION_STATE.json`，下次可续 |
