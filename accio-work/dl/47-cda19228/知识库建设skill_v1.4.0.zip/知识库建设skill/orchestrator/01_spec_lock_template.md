# SPEC_LOCKED — `{{store_name}}` 国际站 AI 知识库

> **状态**：🔒 v1.0 LOCKED
> **生成时间**：{{timestamp}}
> **包版本**：alibaba-knowledge-base-builder v{{builder_version}}
> **商家确认**：⏳ 待 ✅ / ✅ 已确认

---

## 一、基础信息

| 字段 | 值 |
|------|-----|
| 店铺名 | `{{store_name}}` |
| 主营品类 | `{{category}}` |
| 战略 anchor | `{{anchor}}` |
| 差异化点 | `{{differentiators}}` |
| 目标买家画像 | `{{buyer_personas}}` |

## 二、语种与覆盖

| 字段 | 值 |
|------|-----|
| 主语种 | `{{primary_language}}` |
| 派生语种 | `{{derived_languages}}` |
| 覆盖模块 | `{{kb_modules}}` |
| 总目标文档数 | `{{target_doc_count}}` 篇 × `{{language_count}}` 语种 = `{{total_md_count}}` 篇 .md |

## 三、内容深度

| 字段 | 值 |
|------|-----|
| AI 模拟问题集来源 | `{{simulation_source}}` |
| Top N 问题数 | `{{top_n}}` |
| 修复迭代深度 | `{{repair_depth}}` |
| 含销售训练话术 | `{{include_training}}` |

## 四、资产与团队

| 字段 | 值 |
|------|-----|
| 营销素材数量 | `{{marketing_count}}` 张 |
| 营销素材风格 | `{{style_preset}}` |
| 营销素材类型组合 | `{{material_types}}` |
| 团队 SOP 纳入 | `{{team_sop}}` |

## 五、隐式默认

| 字段 | 值 |
|------|-----|
| 物理隔离 INTERNAL | ✅ 启用 |
| .docx 镜像 | ✅ 启用 |
| 演进数据回写 | `{{evolution_enabled}}` |

## 六、产出位置

```
<workspace>/{{store_name}}_知识库_{{year}}Q{{quarter}}/
```

## 七、预计工作量

| 阶段 | 步数 | 时长 |
|------|------|------|
| 1-3. Spec + 智能回填 + 问卷 | ~5 步 | 已完成 |
| 4. 目录骨架 | ~3 步 | 短 |
| 5. EN 批量写作（6 模块并行）| ~6 sub-agent | 中 |
| 6. 风险预扫描 | ~2 步 | 短 |
| 7. 派生语种翻译 | ~`{{translator_count}}` sub-agent 并行 | 中 |
| 8. 营销素材生图 | ~`{{marketing_count}}` × 1 步 | 中 |
| 9. 内部资产建立 | ~3 步 | 短 |
| 10. .docx 镜像批量转 | 1 脚本 | 短 |
| 11. AI 应答模拟 | 1 sub-agent | 中 |
| 12. 修复迭代 | 视评分而定 | 视情况 |
| 13. 交付 + 演进沉淀 | ~3 步 | 短 |
| **总计** | **~50 步** | **30-60 分钟** |

---

## ❗ 商家确认

请回复 **✅ 确认开工** 或对任何字段提出修改。
