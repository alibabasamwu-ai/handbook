# Sub-Agent 团队花名册

> 8 个显式定义的角色。生意助手按工作流阶段 spawn 对应 sub-agent，使用 [agents/](../agents/) 下对应 prompt 模板。

| # | 角色 | Prompt 模板 | 触发阶段 | spawn 类型 | 并发数 |
|---|------|-------------|---------|-----------|--------|
| 01 | **Writer**（写作者）| [agents/01_writer.md](../agents/01_writer.md) | 阶段 5 | general | 6（按模块）|
| 02 | **Translator**（翻译者）| [agents/02_translator.md](../agents/02_translator.md) | 阶段 7 | general | 派生语种数（≤ 3）|
| 03 | **FormatConverter**（格式转换者）| [agents/03_format_converter.md](../agents/03_format_converter.md) | 阶段 10 | bash | 1 |
| 04 | **RiskScanner**（风险扫描者）| [agents/04_risk_scanner.md](../agents/04_risk_scanner.md) | 阶段 6, 12 | bash + general | 1 |
| 05 | **AISimulator**（应答模拟者）| [agents/05_ai_simulator.md](../agents/05_ai_simulator.md) | 阶段 11 | general | 1 |
| 06 | **RepairExecutor**（修复执行者）| [agents/06_repair_executor.md](../agents/06_repair_executor.md) | 阶段 12 | general | 1-N（视修复点数）|
| 07 | **ImageGenerator**（营销素材生成）| [agents/07_image_generator.md](../agents/07_image_generator.md) | 阶段 8 | general | 1 |
| 08 | **EvolutionRecorder**（演进沉淀）| [agents/08_evolution_recorder.md](../agents/08_evolution_recorder.md) | 阶段 13 | general | 1 |

## 通用契约（所有 sub-agent 必须遵守）

### 输入契约
每个 sub-agent 必须收到：
- `store_name` — 店铺名
- `work_dir` — 商家工作目录绝对路径
- `spec_path` — SPEC_LOCKED.md 绝对路径
- 任务特定字段（见各 prompt 模板）

### 输出契约
返回 JSON 摘要至少含：
```json
{
  "status": "success|partial|failed",
  "files_created": ["abs/path/1.md", ...],
  "files_modified": ["abs/path/2.md", ...],
  "issues": ["可能的告警"],
  "next_step_recommendation": "..."
}
```

### 失败回退
任一 sub-agent 失败 → 主 agent 决策：
1. 重试同一 sub-agent（最多 1 次，task 描述更精确）
2. 改派另一 sub-agent
3. 升级到 main agent 处理
4. 告诉商家具体失败点，请求人工介入

### 不允许跨 sub-agent 直接通信
所有数据交换通过文件系统（写到 work_dir 下）或 main agent 转发，避免 sub-agent 互相依赖。
