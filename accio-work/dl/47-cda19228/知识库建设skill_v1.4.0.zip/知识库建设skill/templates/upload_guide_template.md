# Alibaba.com KB Upload Guide
# 使用说明：指导商家如何将生成的 Markdown 文件上传到阿里巴巴国际站知识库

## 步骤 1：文件转换 (Conversion)
- 系统已生成 Markdown (.md) 文件。
- 登录 [Alibaba.com 后台](https://seller.alibaba.com/)。
- 导航至：**AI 助手 / 知识库管理 (AI Assistant / Knowledge Base)**。

## 步骤 2：内容检查 (Final Review)
- 打开 `repair_log_template.md` 查看本次修复的重点。
- 确保 frontmatter 已被正确移除或按平台要求填入相应字段。

## 步骤 3：批量导入 (Import)
- 平台目前支持：**手动粘贴内容** 或 **PDF/DOCX 导入**。
- **推荐方案**: 
  1. 使用 Pandoc 或系统自带工具将 .md 转为 .pdf。
  2. 保持层级结构，分模块上传。
  3. 01-02 模块建议设置为“极高频”。

## 步骤 4：验证 (Verification)
- 上传后，在后台使用“模拟对话”功能提问测试。
- 参考 `ai_simulation_template.md` 的案例进行回归测试。

---
**技术支持**: {{support_contact}}
**版本**: {{guide_version}}
