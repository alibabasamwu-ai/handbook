# Risk Scan Checklist (KB Quality)
# ==========================================
# 使用说明 (Instructions):
# 1. 每次知识库生成后，必须按照此清单进行人工或自动化风险扫描。
# 2. 严禁带有 P0 级别风险的文档同步至 Alibaba.com。
# 3. 风险级别定义：
#    - P0 (Critical): 法律/红线问题、核心价格错误、证书伪造或失效。
#    - P1 (High): 关键信息缺失、FAQ 逻辑自相矛盾、重大参数误差。
#    - P2 (Normal): 语言表达、Markdown 格式、低频错词。
# ==========================================

## 1. P0 - 业务红线 (Must Pass)
- [ ] **价格冲突 (Price Conflict)**: 知识库描述的价格范围是否与产品详情页 (PDP) 挂牌价一致？
- [ ] **证书有效性 (Cert Validity)**: CE/ISO/UL/TUV 等关键证书是否过期？证书编号是否可查？
- [ ] **合规禁用词 (Blacklist)**: 是否包含 "Best", "Top 1", "Medical treatment" 等平台违禁词？
- [ ] **联系方式 (Contact Leak)**: 是否包含引导客户脱离平台的私密联系方式（如个人手机号在文本正文中）？

## 2. P1 - 关键体验 (High Priority)
- [ ] **规格对齐 (Spec Alignment)**: 产品 SKU 对应的 Material, Power, Dimension 是否与当前库存一致？
- [ ] **交期逻辑 (Lead Time)**: Bulk order 的交期是否考虑了旺季波动？是否有模糊描述？
- [ ] **工厂背书 (Factory Info)**: 描述的生产线数量、员工规模是否与实地认证 (Verified Supplier) 数据匹配？
- [ ] **术语统一 (Glossary)**: 全文是否对同一专有名词（如 "PV Module" vs "Solar Board"）使用了统一度量？

## 3. P2 - 格式与优化 (Normal Priority)
- [ ] **Markdown 级联**: 是否存在空的二级标题？列表符号是否统一（* 或 -）？
- [ ] **标签覆盖**: 是否每篇文档都带了至少 3 个核心标签以供 AI 向量索引？
- [ ] **翻译润色**: 是否存在明显的机器翻译语法错误（如 "Open a door" 翻译成 "开一扇门" 用于描述开机）？
- [ ] **图片占位符**: 文档中引用的图片链接是否有效？

---
**扫描状态 (Status)**: {{scan_status}} (PASS/FAILED)
**扫描人 (Scanner)**: {{scanner_id}}
**剩余问题 (Issues Remaining)**: {{issues_count}}
