# Module 04: After-Sales Service (售后服务)
# 本模块涵盖质保、退换货、技术支持等售后环节，保障买家长效利益。

## 推荐主题清单 (Recommended Topics)

1. **Warranty Period: What is covered and for how long?**  
   各核心部件的保修时长及非保修范围（如人为损坏）。
2. **RMA (Return Merchandise Authorization) Process**  
   退货/返修的申请步骤、审批流程及所需证据（照片/视频）。
3. **How to request replacement parts (Free or Paid)?**  
   易损件的申领流程及超过保修期后的配件采购价格。
4. **Troubleshooting: Common issues and DIY fixes**  
   高频故障的自查手册及简单修复方案（减少不必要退货）。
5. **Refund policy for quality defects or functional failures**  
   质量问题导致的退款比例、退款周期及操作流程。
6. **Technical Support: Availability and Contact Information**  
   售后技术支持的时间段（24/7 或 8/5）及专属联络人。
7. **How we handle customer feedback and complaints?**  
   投诉处理时效承诺及纠纷升级后的介入机制。
8. **Extended Warranty options and maintenance contracts**  
   延保服务的购买价格及包含的定期维保内容。
9. **Software/Firmware Update procedures and notifications**  
   软件升级的获取方式及升级过程中的安全注意事项。
10. **Shipping cost responsibility for after-sales returns**  
    明确往返运费由哪一方承担（根据不同场景）。
11. **Remote assistance: Video calls and screen sharing support**  
    是否提供远程视频连线指导安装或排障。
12. **Global service centers and partner networks**  
    在海外是否有本地服务网点或合作维修点。
