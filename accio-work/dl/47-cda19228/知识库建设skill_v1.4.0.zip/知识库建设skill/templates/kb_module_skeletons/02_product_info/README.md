# Module 02: Product Information (产品信息)
# 本模块涵盖产品参数、技术规格、应用场景及维护保养，是 AI 回答产品的核心。

## 推荐主题清单 (Recommended Topics)

1. **Product Catalog: Overview of all series**  
   简述产品线分类，引导客户快速定位所需系列。
2. **What is the difference between {{product_a}} and {{product_b}}?**  
   针对相似产品的对比分析（如单晶 vs 多晶，高配 vs 标配）。
3. **Technical Specifications: Material, Durability and Performance**  
   核心参数表：材质构成、耐用年限、性能指标。
4. **How to choose the right model/size for your project?**  
   选型指南，根据客户的应用规模推荐合适规格。
5. **Product Certifications: Detail per product line**  
   针对具体产品型号的测试报告、能效标识。
6. **Application Scenarios: Where can this product be used?**  
   列举真实使用案例（如家庭自用、工程项目、工业环境）。
7. **Installation Guide: Step-by-step instructions**  
   安装前置条件、步骤图示说明及安全注意事项。
8. **Maintenance & Cleaning: How to prolong product life?**  
   日常维护建议、清洁周期及易损件更换说明。
9. **Customization Options: What parts can be customized?**  
   可定制化范围：LOGO 丝印、包装颜色、软件界面等。
10. **Packaging details: Dimensions, Weight, and Protection**  
    单件及整托盘的包装尺寸、毛重，方便买家核算运费。
11. **Safety instructions and Operational precautions**  
    操作禁忌及安全警示。
12. **End-of-life disposal and Environmental impact**  
    报废处理指引及环保回收建议。
