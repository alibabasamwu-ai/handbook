# Module 01: Company Information (公司信息)
# 本模块涵盖公司背景、生产能力、核心团队及认证资质，用于建立买家信任。

## 推荐主题清单 (Recommended Topics)

1. **Who are we? Overview of {{company_name}}**  
   一句话介绍公司历史、主营方向及行业地位。
2. **Where is our factory located and how to visit?**  
   具体的工厂地理位置、交通指引及是否支持视频看厂。
3. **What certifications (ISO/CE/UL) does our company have?**  
   列举持有的体系认证及产品认证，强调合规性。
4. **Our production capacity per month (Units/Volume)**  
   展示产线数量、月产能，证明大单承接能力。
5. **Key team members: Introduction to our engineers and R&D**  
   介绍研发团队背景、工程师资历，体现技术实力。
6. **Factory tour: Key equipment and production lines**  
   关键生产设备（如 SMT, CNC）的清单及其先进程度。
7. **Our R&D capability and customized design (OEM/ODM) support**  
   研发投入、专利数量及如何支持客户从想法到样品。
8. **Main markets and top-tier clients we've served**  
   列举主要出口国家及在该行业内的知名合作客户。
9. **Why choose us over other competitors?**  
   总结公司的核心竞争优势（如自有矿山、24h响应、专利授权等）。
10. **Quality control (QC) process and laboratory equipment**  
    描述从原材料入库到出库的完整 QC 流程。
11. **Our vision, values, and Corporate Social Responsibility (CSR)**  
    可持续发展、员工福利及社会贡献。
12. **Milestones: The development history of our company**  
    公司的重大历史节点，如扩厂、上市、进入新市场。
