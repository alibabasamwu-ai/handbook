# Module 03: Communication & Sales FAQ (沟通技巧)
# 本模块涵盖销售话术、样品政策、交期协商等高频商务 Q&A。

## 推荐主题清单 (Recommended Topics)

1. **FAQ: Dealing with price negotiation and discount requests**  
   针对“价格太高”的标准化专业回复，强调价值而非价格。
2. **Q&A: Why is our MOQ higher/lower than others?**  
   解释起订量的逻辑（如原材料采购门槛或为了测试市场）。
3. **Sample Policy: Cost, Lead time, and Freight**  
   样板费用是否返还、寄样时间及运费承担方。
4. **How to handle urgent orders and peak season delivery?**  
   紧急订单的响应机制及旺季排产规则。
5. **Communication channels: WhatsApp, Email, and Response Time**  
   承诺的响应时效及各环节的对接负责人。
6. **Our process for handling customized (OEM) design requests**  
   从需求确认、初稿设计到样品封样的标准流转时间。
7. **Dealing with out-of-stock or material shortage situations**  
   出现缺货时的替代方案及客户通知流程。
8. **Q&A: Can we provide exclusive distribution rights?**  
   独家代理的申请条件、考核指标及支持政策。
9. **How we protect your customized designs (NDA policy)?**  
   保密协议的签署及知识产权保护措施。
10. **Pre-order consultation checklist for buyers**  
    下单前需要买家提供的清单（如电压要求、插头标准）。
11. **Our experience in handling government tenders/bidding**  
    招投标经验及可提供的文件支持（如审计报告）。
12. **What to do if there is a mistake in the Proforma Invoice (PI)?**  
    单据修改流程及核对指引。
