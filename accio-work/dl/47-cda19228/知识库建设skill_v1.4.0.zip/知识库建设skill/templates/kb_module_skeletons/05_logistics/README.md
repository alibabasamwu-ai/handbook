# Module 05: Logistics & Delivery (物流交付)
# 本模块涵盖运输方式、贸易术语、交期及包装，解决买家的交付焦虑。

## 推荐主题清单 (Recommended Topics)

1. **Shipping modes: Air vs Sea vs Express vs Railway**  
   各运输方式的优缺点对比、预估时效及适用货量。
2. **Incoterms: EXW, FOB, CIF, DDP explained for our products**  
   针对本行业常用的贸易术语进行详细定义，明确责任边界。
3. **Estimated Lead Time for sample vs bulk orders**  
   不同订单规模的预估交货期（从支付到出货）。
4. **Loading ports: Which ports do we usually ship from?**  
   常出港口（如宁波、深圳、青岛）及该港口的运输优势。
5. **Tracking your order: From factory gate to your warehouse**  
   查单系统、提单发送时间及物流单号更新频率。
6. **Customs Clearance: Documentation we provide (C/O, Form E)**  
   列举可协助办理的产地证、发票认证等清关单据。
7. **Shipping Insurance: Who pays and what does it cover?**  
   海运/空运保险的投保建议、费率及理赔流程。
8. **Packaging Strength: How we prevent damage during transit?**  
   包装材质（五层瓦楞、木架、蜂窝板）及防撞测试标准。
9. **Palletization & Container Loading capacity (20GP/40HQ)**  
   整柜装箱量计算参考，帮助买家最大化利用空间。
10. **Drop-shipping services: Capabilities and restrictions**  
    是否支持代发货，及代发货的流程和隐私条款。
11. **What to do if the package arrives damaged?**  
    收货验收指引：当场拒签、拍照留存及联系货代。
12. **Peak season logistics planning and port congestion notices**  
    节假日（如春节、圣诞节）前的出货预案。
