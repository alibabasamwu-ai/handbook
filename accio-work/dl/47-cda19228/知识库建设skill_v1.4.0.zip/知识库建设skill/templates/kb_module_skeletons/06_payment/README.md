# Module 06: Payment & Contract (支付合同)
# 本模块涵盖付款方式、合同条款、信用条款及资金安全，确保交易闭环。

## 推荐主题清单 (Recommended Topics)

1. **Accepted Payment Methods: T/T, L/C, Credit Card, and more**  
   详细列出公司支持的所有收汇渠道及其优缺点。
2. **Payment Terms: Deposit and Balance distribution**  
   标准付款节奏（如 30% Deposit, 70% before shipping）。
3. **Handling Banking Fees and intermediary transfer costs**  
   明确银行手续费由哪一方承担，避免尾款差额纠纷。
4. **Credit Terms (OA/DP): Qualifications for long-term partners**  
   申请信保/账期的条件（如年采购量、合作年限）。
5. **Alibaba Trade Assurance: Benefits and step-by-step process**  
   解释信保交易的安全性、保障范围及买家操作入口。
6. **Our Anti-Fraud Notice for payment transfers**  
   防骗声明：强调不会通过个人邮箱要求修改收款账号。
7. **Proforma Invoice (PI) & Sales Contract (SC) key terms**  
   解释合同中的法律效力、违约责任及仲裁地点。
8. **Handling Chargebacks and refund disputes**  
   拒付处理流程、平台投诉流程及协商调解机制。
9. **Currency Exchange Rate: Which currency do we accept?**  
   支持的币种（USD, EUR, RMB 等）及汇率变动的处理规则。
10. **Taxation & Customs Duties: Responsibilities for buyers**  
    声明买家所在国的进口关税和增值税由买家承担。
11. **Verification of our corporate bank account details**  
    提供银行开户许可证明或通过平台实人认证。
12. **Contract amendments and Force Majeure clauses**  
    合同修改流程及对不可抗力（如天灾、政策变动）的定义。
