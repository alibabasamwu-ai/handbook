#!/usr/bin/env python3
"""
PDF Catalog 生成器 (v1.2.0)

依赖:
  pip3 install reportlab Pillow

用法:
  python3 generate_catalog.py \\
    --work-dir /path/to/work_dir \\
    --lang EN \\
    --brand-name "ACME Lighting" \\
    --contact "WhatsApp: +86-138... | Email: sales@acme.com" \\
    --selection-file /path/to/_selection.json \\
    --output /path/to/output.pdf

selection.json 格式:
  {
    "products": [
      {
        "name": "...",
        "name_en": "...",
        "sku": "...",
        "main_image_path": "...",
        "specs": [["Model", "ABC"], ["Material", "Aluminum"]],
        "selling_points": ["...", "..."],
        "moq": "100 pcs",
        "price_range": "$8-12 / pc",
        "cta": "Reply within 12h for free quote"
      },
      ...
    ],
    "company": {
      "established": 2008,
      "factory_size": "10000 m²",
      "certifications": ["BSCI", "CE", "ISO9001"],
      "about": "...",
      "five_reasons": ["...", "...", "...", "...", "..."]
    }
  }
"""

from __future__ import annotations

import argparse
import json
import os
import sys
from io import BytesIO
from pathlib import Path

try:
    from reportlab.lib import colors
    from reportlab.lib.pagesizes import A4
    from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
    from reportlab.lib.units import mm
    from reportlab.pdfbase import pdfmetrics
    from reportlab.pdfbase.ttfonts import TTFont
    from reportlab.pdfbase.cidfonts import UnicodeCIDFont
    from reportlab.platypus import (
        SimpleDocTemplate, Paragraph, Spacer, Image, Table, TableStyle, PageBreak
    )
    from reportlab.lib.enums import TA_CENTER, TA_LEFT
except ImportError as e:
    print(f"❌ 缺少依赖 reportlab: {e}", file=sys.stderr)
    print("请先运行: pip3 install reportlab", file=sys.stderr)
    sys.exit(1)

# PIL 是可选的（reportlab 自带基础图片渲染）
try:
    from PIL import Image as PILImage  # noqa: F401
    HAS_PIL = True
except ImportError:
    HAS_PIL = False
except Exception:
    # 处理 PIL 二进制签名/Team ID 不匹配等环境问题
    HAS_PIL = False

# ============================================================================
# 字体注册
# ============================================================================

SCRIPT_DIR = Path(__file__).resolve().parent
FONTS_DIR = SCRIPT_DIR / "fonts"

def register_fonts():
    """注册庄重的衬线字体（英文）+ 中文字体；优先 Times/Georgia 等高商务感字体。
    
    设计理念：B2B catalog 要严肃庄重 → 英文用衬线（Times/Georgia/Palatino），
    标题用粗衬线，正文用常规衬线。中文用宋体系（衬线感）。
    """
    fonts_registered = []
    
    # ============ 英文衬线字体（庄重感核心）============
    serif_candidates = [
        # macOS 内置高质量衬线
        ("Times-Roman", Path("/System/Library/Fonts/Supplemental/Times New Roman.ttf"), 0),
        ("Times-Roman", Path("/Library/Fonts/Times New Roman.ttf"), 0),
        ("Times-Roman", Path("/System/Library/Fonts/NewYork.ttf"), 0),
        ("Times-Roman", Path("/System/Library/Fonts/Times.ttc"), 0),
        # Linux
        ("Times-Roman", Path("/usr/share/fonts/truetype/liberation/LiberationSerif-Regular.ttf"), 0),
        ("Times-Roman", Path("/usr/share/fonts/truetype/dejavu/DejaVuSerif.ttf"), 0),
    ]
    serif_bold_candidates = [
        ("Times-Bold", Path("/System/Library/Fonts/Supplemental/Times New Roman Bold.ttf"), 0),
        ("Times-Bold", Path("/Library/Fonts/Times New Roman Bold.ttf"), 0),
        ("Times-Bold", Path("/System/Library/Fonts/Times.ttc"), 1),
        ("Times-Bold", Path("/usr/share/fonts/truetype/liberation/LiberationSerif-Bold.ttf"), 0),
        ("Times-Bold", Path("/usr/share/fonts/truetype/dejavu/DejaVuSerif-Bold.ttf"), 0),
    ]
    
    serif_font = None
    for name, c, idx in serif_candidates:
        if c.exists():
            try:
                if str(c).endswith(".ttc"):
                    pdfmetrics.registerFont(TTFont(name, str(c), subfontIndex=idx))
                else:
                    pdfmetrics.registerFont(TTFont(name, str(c)))
                serif_font = name
                fonts_registered.append(f"Serif: {name} ← {c.name}")
                break
            except Exception:
                continue
    # 降级：reportlab 内置 Times-Roman（标准 PostScript 字体，无文件依赖）
    if not serif_font:
        serif_font = "Times-Roman"  # reportlab 内置
        fonts_registered.append("Serif: builtin Times-Roman (PS Type1)")
    
    serif_bold_font = serif_font
    for name, c, idx in serif_bold_candidates:
        if c.exists():
            try:
                if str(c).endswith(".ttc"):
                    pdfmetrics.registerFont(TTFont(name, str(c), subfontIndex=idx))
                else:
                    pdfmetrics.registerFont(TTFont(name, str(c)))
                serif_bold_font = name
                fonts_registered.append(f"Serif-Bold: {name} ← {c.name}")
                break
            except Exception:
                continue
    if serif_bold_font == serif_font and serif_bold_font == "Times-Roman":
        serif_bold_font = "Times-Bold"  # reportlab 内置
        fonts_registered.append("Serif-Bold: builtin Times-Bold (PS Type1)")
    
    # ============ 中文字体（用宋体系保持衬线庄重感）============
    cjk_candidates = [
        FONTS_DIR / "NotoSerifSC-Regular.otf",
        Path("/System/Library/Fonts/Supplemental/Songti.ttc"),  # macOS 宋体
        Path("/System/Library/Fonts/STHeiti Medium.ttc"),
        Path("/System/Library/Fonts/PingFang.ttc"),
        Path("/usr/share/fonts/opentype/noto/NotoSerifCJK-Regular.ttc"),
    ]
    
    cjk_font = None
    for c in cjk_candidates:
        if c.exists():
            try:
                if str(c).endswith(".ttc"):
                    pdfmetrics.registerFont(TTFont("CJK", str(c), subfontIndex=0))
                else:
                    pdfmetrics.registerFont(TTFont("CJK", str(c)))
                cjk_font = "CJK"
                fonts_registered.append(f"CJK: {c.name}")
                break
            except Exception:
                continue
    # 终极降级：reportlab 内置 STSong-Light
    if not cjk_font:
        try:
            pdfmetrics.registerFont(UnicodeCIDFont("STSong-Light"))
            cjk_font = "STSong-Light"
            fonts_registered.append("CJK: builtin STSong-Light (CID)")
        except Exception:
            pass
    
    return {
        "regular": serif_font,
        "bold": serif_bold_font,
        "cjk": cjk_font or serif_font,
        "registered": fonts_registered,
    }


# ============================================================================
# 主生成函数
# ============================================================================

def build_styles(fonts):
    """庄重衬线风格 — 深海军蓝主色 + 金色点缀，对标顶级 B2B catalog。"""
    base = getSampleStyleSheet()
    NAVY = colors.HexColor("#0d2858")     # 深海军蓝（主色，稳重）
    GOLD = colors.HexColor("#a07d2c")     # 暗金色（高端点缀）
    DARK = colors.HexColor("#1a1a1a")     # 深黑（正文）
    GREY = colors.HexColor("#555555")     # 次要文字
    return {
        "title": ParagraphStyle(
            "title", parent=base["Title"],
            fontName=fonts["bold"], fontSize=32, alignment=TA_CENTER,
            spaceAfter=8, textColor=NAVY, leading=38,
        ),
        "slogan": ParagraphStyle(
            "slogan", parent=base["BodyText"],
            fontName=fonts["regular"], fontSize=13, alignment=TA_CENTER,
            textColor=GOLD, leading=18, spaceAfter=6,
        ),
        "h1": ParagraphStyle(
            "h1", parent=base["Heading1"],
            fontName=fonts["bold"], fontSize=20, spaceAfter=8,
            textColor=NAVY, leading=24,
        ),
        "h2": ParagraphStyle(
            "h2", parent=base["Heading2"],
            fontName=fonts["bold"], fontSize=13, spaceAfter=6,
            textColor=NAVY, leading=17,
        ),
        "h3": ParagraphStyle(
            "h3", parent=base["Heading3"],
            fontName=fonts["bold"], fontSize=11, spaceAfter=4,
            textColor=GOLD, leading=14,
        ),
        "body": ParagraphStyle(
            "body", parent=base["BodyText"],
            fontName=fonts["regular"], fontSize=10.5, leading=15,
            textColor=DARK,
        ),
        "body_lead": ParagraphStyle(
            "body_lead", parent=base["BodyText"],
            fontName=fonts["regular"], fontSize=11.5, leading=17,
            textColor=DARK, alignment=TA_LEFT, spaceAfter=6,
        ),
        "small": ParagraphStyle(
            "small", parent=base["BodyText"],
            fontName=fonts["regular"], fontSize=8.5, textColor=GREY, leading=11,
        ),
        "small_center": ParagraphStyle(
            "small_center", parent=base["BodyText"],
            fontName=fonts["regular"], fontSize=8.5, textColor=GREY,
            alignment=TA_CENTER, leading=11,
        ),
        "cta": ParagraphStyle(
            "cta", parent=base["BodyText"],
            fontName=fonts["bold"], fontSize=11,
            textColor=colors.HexColor("#b71c1c"), alignment=TA_CENTER, leading=14,
        ),
        "stat_num": ParagraphStyle(
            "stat_num", parent=base["BodyText"],
            fontName=fonts["bold"], fontSize=26, alignment=TA_CENTER,
            textColor=NAVY, leading=30,
        ),
        "stat_label": ParagraphStyle(
            "stat_label", parent=base["BodyText"],
            fontName=fonts["regular"], fontSize=8.5, alignment=TA_CENTER,
            textColor=GREY, leading=11,
        ),
        "spec_label": ParagraphStyle(
            "spec_label", parent=base["BodyText"],
            fontName=fonts["bold"], fontSize=9, textColor=GREY,
        ),
        "spec_value": ParagraphStyle(
            "spec_value", parent=base["BodyText"],
            fontName=fonts["regular"], fontSize=9, textColor=DARK,
        ),
    }


def safe_image(path, max_w_mm, max_h_mm):
    """安全加载图片；失败时返回 [N/A] 占位文本而不是 crash。"""
    if not path or not os.path.exists(path):
        return None
    try:
        img = Image(path, width=max_w_mm * mm, height=max_h_mm * mm,
                    kind="proportional")
        return img
    except Exception:
        return None


def _gold_divider(width_mm=60):
    """优雅金色分隔线 — 居中短线，复用于封面/章节"""
    line = Table([[" "]], colWidths=[width_mm * mm], rowHeights=[0.6 * mm])
    line.setStyle(TableStyle([
        ("BACKGROUND", (0,0), (-1,-1), colors.HexColor("#a07d2c")),
        ("LEFTPADDING", (0,0), (-1,-1), 0),
        ("RIGHTPADDING", (0,0), (-1,-1), 0),
        ("TOPPADDING", (0,0), (-1,-1), 0),
        ("BOTTOMPADDING", (0,0), (-1,-1), 0),
    ]))
    # 居中包装
    wrapper = Table([[line]], colWidths=[180 * mm])
    wrapper.setStyle(TableStyle([
        ("ALIGN", (0,0), (-1,-1), "CENTER"),
        ("LEFTPADDING", (0,0), (-1,-1), 0),
        ("RIGHTPADDING", (0,0), (-1,-1), 0),
        ("TOPPADDING", (0,0), (-1,-1), 0),
        ("BOTTOMPADDING", (0,0), (-1,-1), 0),
    ]))
    return wrapper


def build_cover(styles, brand_name, slogan, established, factory_size, contact, hero_image_path=None,
                brand_slogan=None, year_label=None):
    """封面页 — 庄重衬线版（hero 图 + 品牌主张 Slogan + 金色分隔线）"""
    elems = []
    
    # ① 顶部小标 EST. xxxx · CATALOG / YEAR
    top_label = year_label or "PRODUCT CATALOG · 2026"
    elems.append(Spacer(1, 8 * mm))
    elems.append(Paragraph(
        f"<font color='#a07d2c' size=10><b>— {top_label} —</b></font>",
        styles["small_center"]))
    elems.append(Spacer(1, 6 * mm))
    
    # ② 品牌名（大号衬线）
    elems.append(Paragraph(brand_name, styles["title"]))
    elems.append(Spacer(1, 2 * mm))
    elems.append(_gold_divider(width_mm=50))
    elems.append(Spacer(1, 6 * mm))
    
    # ③ 品牌主张 Slogan（最重要的一句话）
    main_slogan = brand_slogan or slogan or "Your Reliable B2B Partner"
    elems.append(Paragraph(f"<i>{main_slogan}</i>", styles["slogan"]))
    elems.append(Spacer(1, 8 * mm))
    
    # ④ Hero 公司形象图（如有）
    hero = safe_image(hero_image_path, max_w_mm=175, max_h_mm=98) if hero_image_path else None
    if hero:
        # 给 hero 图加细边框
        hero_table = Table([[hero]], colWidths=[175 * mm])
        hero_table.setStyle(TableStyle([
            ("BOX", (0,0), (-1,-1), 0.4, colors.HexColor("#a07d2c")),
            ("LEFTPADDING", (0,0), (-1,-1), 0),
            ("RIGHTPADDING", (0,0), (-1,-1), 0),
            ("TOPPADDING", (0,0), (-1,-1), 0),
            ("BOTTOMPADDING", (0,0), (-1,-1), 0),
        ]))
        elems.append(hero_table)
        elems.append(Spacer(1, 10 * mm))
    else:
        elems.append(Spacer(1, 70 * mm))
    
    # ⑤ 三大数字背书条 — Stats Bar（Established / Factory / Countries）
    stats_data = [[
        Paragraph(f"{established or '27 Years'}", styles["stat_num"]),
        Paragraph(f"{(factory_size or '90,000 sqm').upper()}", styles["stat_num"]),
        Paragraph("60+", styles["stat_num"]),
    ], [
        Paragraph("EXPERIENCE", styles["stat_label"]),
        Paragraph("MANUFACTURING SCALE", styles["stat_label"]),
        Paragraph("COUNTRIES SERVED", styles["stat_label"]),
    ]]
    stats = Table(stats_data, colWidths=[58 * mm, 58 * mm, 58 * mm])
    stats.setStyle(TableStyle([
        ("VALIGN", (0,0), (-1,-1), "MIDDLE"),
        ("ALIGN", (0,0), (-1,-1), "CENTER"),
        ("LINEBEFORE", (1,0), (1,-1), 0.4, colors.HexColor("#cccccc")),
        ("LINEBEFORE", (2,0), (2,-1), 0.4, colors.HexColor("#cccccc")),
        ("TOPPADDING", (0,0), (-1,-1), 4),
        ("BOTTOMPADDING", (0,0), (-1,-1), 4),
    ]))
    elems.append(stats)
    elems.append(Spacer(1, 12 * mm))
    
    # ⑥ Contact 优雅居中
    elems.append(_gold_divider(width_mm=30))
    elems.append(Spacer(1, 4 * mm))
    elems.append(Paragraph(
        f"<font color='#0d2858' size=9><b>{contact or '[N/A]'}</b></font>",
        styles["small_center"]))
    
    elems.append(PageBreak())
    return elems


def build_about(styles, company):
    """公司一览页 — 丰富版（章节标题 + 5 个核心模块 + 营销钩子）"""
    elems = []
    
    # ━━━ 章节标题 ━━━
    elems.append(Paragraph("ABOUT US", styles["h1"]))
    elems.append(_gold_divider(width_mm=40))
    elems.append(Spacer(1, 6 * mm))
    
    # ① Lead 段（公司简述，加大字号显主张感）
    about_text = company.get("about") or (
        "A trusted manufacturer with decades of expertise in delivering "
        "world-class infrastructure solutions for global EPC contractors, "
        "government projects, and distributors."
    )
    elems.append(Paragraph(about_text, styles["body_lead"]))
    elems.append(Spacer(1, 6 * mm))
    
    # ② 4 宫格核心实力 Mini-stats —— 数字背书
    established = company.get("established", "27 Years")
    factory = company.get("factory_size", "90,000 sqm")
    rd_count = company.get("rd_engineers", "50+")
    capacity = company.get("monthly_capacity", "10,000+ sets/mo")
    
    mini_stats = Table([[
        Paragraph(f"<b>{established}</b>", styles["stat_num"]),
        Paragraph(f"<b>{factory}</b>", styles["stat_num"]),
        Paragraph(f"<b>{rd_count}</b>", styles["stat_num"]),
        Paragraph(f"<b>{capacity}</b>", styles["stat_num"]),
    ], [
        Paragraph("YEARS IN BUSINESS", styles["stat_label"]),
        Paragraph("FACTORY AREA", styles["stat_label"]),
        Paragraph("R&D ENGINEERS", styles["stat_label"]),
        Paragraph("MONTHLY CAPACITY", styles["stat_label"]),
    ]], colWidths=[44 * mm] * 4)
    mini_stats.setStyle(TableStyle([
        ("VALIGN", (0,0), (-1,-1), "MIDDLE"),
        ("ALIGN", (0,0), (-1,-1), "CENTER"),
        ("BACKGROUND", (0,0), (-1,-1), colors.HexColor("#f5f3ed")),
        ("BOX", (0,0), (-1,-1), 0.4, colors.HexColor("#a07d2c")),
        ("LINEBEFORE", (1,0), (1,-1), 0.3, colors.HexColor("#cccccc")),
        ("LINEBEFORE", (2,0), (2,-1), 0.3, colors.HexColor("#cccccc")),
        ("LINEBEFORE", (3,0), (3,-1), 0.3, colors.HexColor("#cccccc")),
        ("TOPPADDING", (0,0), (-1,-1), 6),
        ("BOTTOMPADDING", (0,0), (-1,-1), 6),
    ]))
    elems.append(mini_stats)
    elems.append(Spacer(1, 8 * mm))
    
    # ③ MISSION + CORE STRENGTHS 双栏
    mission = company.get("mission") or (
        "To engineer trust into every infrastructure project we serve — "
        "delivering safe, durable, and intelligent solutions that perform "
        "for 20+ years in the harshest environments."
    )
    strengths = company.get("core_strengths", [
        "End-to-end manufacturing: design → engineering → fabrication → testing",
        "In-house galvanizing & powder-coating lines (60+ years lifespan)",
        "Customized OEM/ODM with full Dialux lighting simulation support",
        "Strict QC: 5-stage inspection + 3rd-party CCIC pre-shipment",
    ])
    strengths_html = "<br/>".join(f"  ●  {s}" for s in strengths[:4])
    
    two_col = Table([[
        [
            Paragraph("OUR MISSION", styles["h3"]),
            Spacer(1, 2 * mm),
            Paragraph(f"<i>{mission}</i>", styles["body"]),
        ],
        [
            Paragraph("CORE STRENGTHS", styles["h3"]),
            Spacer(1, 2 * mm),
            Paragraph(strengths_html, styles["body"]),
        ],
    ]], colWidths=[88 * mm, 88 * mm])
    two_col.setStyle(TableStyle([
        ("VALIGN", (0,0), (-1,-1), "TOP"),
        ("LINEBEFORE", (1,0), (1,-1), 0.3, colors.HexColor("#a07d2c")),
        ("LEFTPADDING", (1,0), (1,-1), 8),
        ("RIGHTPADDING", (0,0), (0,-1), 8),
        ("TOPPADDING", (0,0), (-1,-1), 6),
        ("BOTTOMPADDING", (0,0), (-1,-1), 6),
    ]))
    elems.append(two_col)
    elems.append(Spacer(1, 8 * mm))
    
    # ④ 认证横排 — 大字号粗衬线
    certs = company.get("certifications", [])
    if certs:
        elems.append(Paragraph("CERTIFICATIONS", styles["h3"]))
        cert_text = "  ●  ".join(f"<b>{c}</b>" for c in certs[:8])
        cert_box = Table([[Paragraph(cert_text, styles["body"])]], colWidths=[180 * mm])
        cert_box.setStyle(TableStyle([
            ("BACKGROUND", (0,0), (-1,-1), colors.HexColor("#f5f3ed")),
            ("ALIGN", (0,0), (-1,-1), "CENTER"),
            ("TOPPADDING", (0,0), (-1,-1), 5),
            ("BOTTOMPADDING", (0,0), (-1,-1), 5),
        ]))
        elems.append(cert_box)
        elems.append(Spacer(1, 6 * mm))
    
    # ⑤ 客户背书
    clients = company.get("client_logos", [])
    if clients:
        elems.append(Paragraph("TRUSTED BY", styles["h3"]))
        elems.append(Paragraph(", ".join(clients[:8]), styles["body"]))
        elems.append(Spacer(1, 6 * mm))
    
    # ★ 底部营销钩子 — Project Consultation 钩子条
    hook_text = (
        "<b><font color='white' size=11>★  COMPLIMENTARY PROJECT CONSULTATION  ★</font></b><br/>"
        "<font color='white' size=9.5>"
        "Free Dialux lighting simulation  ·  Custom drawing service  ·  "
        "DDP quote within 24 hours  ·  Sample available upon request"
        "</font>"
    )
    hook = Table([[Paragraph(hook_text, styles["small_center"])]], colWidths=[180 * mm])
    hook.setStyle(TableStyle([
        ("BACKGROUND", (0,0), (-1,-1), colors.HexColor("#0d2858")),
        ("ALIGN", (0,0), (-1,-1), "CENTER"),
        ("TOPPADDING", (0,0), (-1,-1), 8),
        ("BOTTOMPADDING", (0,0), (-1,-1), 8),
    ]))
    elems.append(hook)
    
    elems.append(PageBreak())
    return elems


def build_product_page(styles, product, page_num, total_pages, contact, trust_bar=None):
    """单个产品页 — 一产品一页 + 营销钩子三件套（Hot Ribbon + Trust Bar + Gift Box）"""
    elems = []
    
    # ★ 钩子①：HOT Ribbon — 顶部红色横条，带 30 天店铺数据背书
    hot_label = product.get("hot_label", "")  # e.g. "⚡ HOT · 255 views in 30 days"
    if hot_label:
        ribbon = Table([[Paragraph(f"<font color='white'><b>{hot_label}</b></font>", styles["body"])]],
                       colWidths=[170 * mm])
        ribbon.setStyle(TableStyle([
            ("BACKGROUND", (0,0), (-1,-1), colors.HexColor("#d32f2f")),
            ("LEFTPADDING", (0,0), (-1,-1), 10),
            ("TOPPADDING", (0,0), (-1,-1), 4),
            ("BOTTOMPADDING", (0,0), (-1,-1), 4),
        ]))
        elems.append(ribbon)
        elems.append(Spacer(1, 3 * mm))
    
    # 标题：产品名 + SKU
    name_line = f"{product.get('name', '[N/A]')} / {product.get('name_en', '[N/A]')}"
    sku = product.get("sku", "[N/A]")
    elems.append(Paragraph(f"<b>{name_line}</b>     SKU: {sku}", styles["h1"]))
    elems.append(Spacer(1, 3 * mm))
    
    # 左图 + 右规格表（用 Table 实现两栏布局）
    img = safe_image(product.get("main_image_path"), max_w_mm=70, max_h_mm=70)
    img_cell = img if img else Paragraph("[NO IMAGE]<br/>请在 KB 补充主图", styles["small"])
    
    specs = product.get("specs", [])
    if specs:
        spec_data = [
            [Paragraph(f"<b>{k}</b>", styles["spec_label"]),
             Paragraph(str(v), styles["spec_value"])]
            for k, v in specs
        ]
        spec_table = Table(spec_data, colWidths=[30 * mm, 50 * mm])
        spec_table.setStyle(TableStyle([
            ("VALIGN", (0, 0), (-1, -1), "TOP"),
            ("FONTSIZE", (0, 0), (-1, -1), 9),
            ("BOTTOMPADDING", (0, 0), (-1, -1), 3),
            ("LINEBELOW", (0, 0), (-1, -2), 0.3, colors.HexColor("#e0e0e0")),
        ]))
    else:
        spec_table = Paragraph("[规格 N/A - 待商家补充]", styles["small"])
    
    main_layout = Table(
        [[img_cell, spec_table]],
        colWidths=[80 * mm, 90 * mm],
    )
    main_layout.setStyle(TableStyle([
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ("LEFTPADDING", (0, 0), (-1, -1), 0),
        ("RIGHTPADDING", (0, 0), (-1, -1), 5),
    ]))
    elems.append(main_layout)
    elems.append(Spacer(1, 5 * mm))
    
    # 卖点
    selling_points = product.get("selling_points", [])
    if selling_points:
        elems.append(Paragraph("TOP SELLING POINTS", styles["h2"]))
        for sp in selling_points[:5]:
            elems.append(Paragraph(f"  ✓  {sp}", styles["body"]))
    elems.append(Spacer(1, 4 * mm))
    
    # ★ 钩子②：Trust Bar — 全局公司背书横条（蓝色）
    if trust_bar:
        trust = Table([[Paragraph(f"<font color='white'>{trust_bar}</font>", styles["small"])]],
                      colWidths=[170 * mm])
        trust.setStyle(TableStyle([
            ("BACKGROUND", (0,0), (-1,-1), colors.HexColor("#1565c0")),
            ("ALIGN", (0,0), (-1,-1), "CENTER"),
            ("LEFTPADDING", (0,0), (-1,-1), 8),
            ("TOPPADDING", (0,0), (-1,-1), 5),
            ("BOTTOMPADDING", (0,0), (-1,-1), 5),
        ]))
        elems.append(trust)
        elems.append(Spacer(1, 4 * mm))
    
    # ★ 钩子③：Gift Box — 黄色高亮促单礼包
    gift_text = (
        "<b>🎁 FIRST-ORDER BONUS</b>  ·  "
        "Free Dialux lighting simulation  ·  "
        "5-Year warranty  ·  "
        "Sample available  ·  "
        "Door-to-Door DDP quote"
    )
    gift = Table([[Paragraph(gift_text, styles["body"])]], colWidths=[170 * mm])
    gift.setStyle(TableStyle([
        ("BACKGROUND", (0,0), (-1,-1), colors.HexColor("#fff8dc")),
        ("BOX", (0,0), (-1,-1), 0.8, colors.HexColor("#f9a825")),
        ("LEFTPADDING", (0,0), (-1,-1), 10),
        ("RIGHTPADDING", (0,0), (-1,-1), 10),
        ("TOPPADDING", (0,0), (-1,-1), 6),
        ("BOTTOMPADDING", (0,0), (-1,-1), 6),
    ]))
    elems.append(gift)
    elems.append(Spacer(1, 4 * mm))
    
    # 营销钩子区块（MOQ + 价格 + CTA）
    moq = product.get("moq", "[N/A]")
    price = product.get("price_range", "[Quote on request]")
    cta = product.get("cta") or "Reply within 12h for free quote"
    
    hook_data = [[
        Paragraph(f"<b>MOQ:</b><br/>{moq}", styles["body"]),
        Paragraph(f"<b>PRICE:</b><br/>{price}", styles["body"]),
        Paragraph(f"<b>NEXT STEP:</b><br/>{cta}", styles["cta"]),
    ]]
    hook_table = Table(hook_data, colWidths=[40 * mm, 50 * mm, 70 * mm])
    hook_table.setStyle(TableStyle([
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ("BACKGROUND", (0, 0), (-1, -1), colors.HexColor("#f8f5e6")),
        ("BOX", (0, 0), (-1, -1), 0.5, colors.HexColor("#cccccc")),
        ("INNERGRID", (0, 0), (-1, -1), 0.3, colors.HexColor("#dddddd")),
        ("LEFTPADDING", (0, 0), (-1, -1), 8),
        ("RIGHTPADDING", (0, 0), (-1, -1), 8),
        ("TOPPADDING", (0, 0), (-1, -1), 8),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 8),
    ]))
    elems.append(hook_table)
    elems.append(Spacer(1, 5 * mm))
    
    # 页脚联系方式
    elems.append(Paragraph(f"📞 {contact}", styles["small"]))
    elems.append(Paragraph(f"Page {page_num} / {total_pages}", styles["small"]))
    elems.append(PageBreak())
    
    return elems


def build_certs_page(styles, company):
    """认证 & 信任墙"""
    elems = [
        Paragraph("CERTIFICATIONS & TRUST", styles["h1"]),
        Spacer(1, 5 * mm),
    ]
    
    certs = company.get("certifications", [])
    if certs:
        cert_text = " · ".join(f"<b>{c}</b>" for c in certs)
        elems.append(Paragraph(cert_text, styles["h2"]))
        elems.append(Spacer(1, 10 * mm))
    
    clients = company.get("client_logos", [])
    if clients:
        elems.append(Paragraph("OUR CLIENTS INCLUDE:", styles["h2"]))
        elems.append(Paragraph(", ".join(clients), styles["body"]))
    
    elems.append(PageBreak())
    return elems


def build_five_reasons(styles, company):
    """5 大购买理由页"""
    elems = [
        Paragraph("5 REASONS TO CHOOSE US", styles["h1"]),
        Spacer(1, 8 * mm),
    ]
    reasons = company.get("five_reasons", [])
    if not reasons:
        reasons = [
            "Reason 1 [N/A - 待商家补充]",
            "Reason 2 [N/A - 待商家补充]",
            "Reason 3 [N/A - 待商家补充]",
            "Reason 4 [N/A - 待商家补充]",
            "Reason 5 [N/A - 待商家补充]",
        ]
    for i, r in enumerate(reasons[:5], 1):
        elems.append(Paragraph(f"<b>{i}.</b>  {r}", styles["body"]))
        elems.append(Spacer(1, 4 * mm))
    
    elems.append(PageBreak())
    return elems


def build_cta_page(styles, brand_name, contact, company=None):
    """CTA 行动号召页（最后一页）— EPC/政府专属接待 钩子版"""
    company = company or {}
    elems = []
    
    # ① 顶部小标
    elems.append(Spacer(1, 12 * mm))
    elems.append(Paragraph(
        "<font color='#a07d2c' size=10><b>— LET'S BUILD YOUR NEXT PROJECT —</b></font>",
        styles["small_center"]))
    elems.append(Spacer(1, 5 * mm))
    
    # ② 主标题
    elems.append(Paragraph("READY TO PARTNER?", styles["title"]))
    elems.append(Spacer(1, 2 * mm))
    elems.append(_gold_divider(width_mm=50))
    elems.append(Spacer(1, 5 * mm))
    
    # ③ 核心钩子 Slogan
    elems.append(Paragraph(
        "<i>EPC Contractors  ·  Government Tenders  ·  Distributors</i>",
        styles["slogan"]))
    elems.append(Spacer(1, 10 * mm))
    
    # ★ 主钩子卡：EPC & GOVERNMENT FAST-TRACK
    main_hook_title = (
        "<font color='white' size=14><b>★  EPC &amp; GOVERNMENT PROJECT FAST-TRACK  ★</b></font>"
    )
    main_hook_body = (
        "<font color='white' size=10.5>"
        "<br/><b>Reserved 1-on-1 senior account manager</b> for projects above USD 50,000.<br/>"
        "<br/>"
        "✓  <b>72-hour project assessment</b> — feasibility + BOM + indicative pricing<br/>"
        "✓  <b>Tender document support</b> — technical specs, datasheets, compliance certificates<br/>"
        "✓  <b>Free Dialux/AGI32 lighting simulation</b> — PDF report within 5 working days<br/>"
        "✓  <b>Priority production slot</b> — guaranteed lead-time commitment<br/>"
        "✓  <b>Engineer-level technical Q&amp;A</b> — direct access, not sales-routed<br/>"
        "✓  <b>DDP / CIF quotation</b> — door-to-door cost transparency"
        "</font>"
    )
    main_hook_card = Table(
        [[Paragraph(main_hook_title, styles["small_center"])],
         [Paragraph(main_hook_body, styles["body"])]],
        colWidths=[175 * mm],
    )
    main_hook_card.setStyle(TableStyle([
        ("BACKGROUND", (0,0), (-1,-1), colors.HexColor("#0d2858")),
        ("ALIGN", (0,0), (-1,-1), "LEFT"),
        ("ALIGN", (0,0), (0,0), "CENTER"),
        ("TOPPADDING", (0,0), (-1,-1), 10),
        ("BOTTOMPADDING", (0,0), (-1,-1), 10),
        ("LEFTPADDING", (0,0), (-1,-1), 14),
        ("RIGHTPADDING", (0,0), (-1,-1), 14),
        ("TEXTCOLOR", (0,0), (-1,-1), colors.white),
    ]))
    elems.append(main_hook_card)
    elems.append(Spacer(1, 8 * mm))
    
    # ★ 副钩子卡（金色限时优惠）
    sub_hook_text = (
        "<b><font color='#0d2858' size=11>🎁  FIRST-ORDER WELCOME PACKAGE</font></b><br/>"
        "<font size=9.5 color='#1a1a1a'>"
        "Free sample (T/T freight only)  ·  5-Year extended warranty  ·  "
        "Free packaging customization  ·  Priority shipment slot"
        "</font>"
    )
    sub_hook = Table([[Paragraph(sub_hook_text, styles["small_center"])]], colWidths=[175 * mm])
    sub_hook.setStyle(TableStyle([
        ("BACKGROUND", (0,0), (-1,-1), colors.HexColor("#fff8dc")),
        ("BOX", (0,0), (-1,-1), 0.8, colors.HexColor("#a07d2c")),
        ("ALIGN", (0,0), (-1,-1), "CENTER"),
        ("TOPPADDING", (0,0), (-1,-1), 8),
        ("BOTTOMPADDING", (0,0), (-1,-1), 8),
    ]))
    elems.append(sub_hook)
    elems.append(Spacer(1, 12 * mm))
    
    # ④ 联系方式 — 大字号居中
    elems.append(Paragraph("CONTACT US TODAY", styles["h2"]))
    elems.append(Spacer(1, 2 * mm))
    elems.append(_gold_divider(width_mm=30))
    elems.append(Spacer(1, 4 * mm))
    elems.append(Paragraph(
        f"<font color='#0d2858' size=10><b>{contact or '[N/A]'}</b></font>",
        styles["small_center"]))
    elems.append(Spacer(1, 3 * mm))
    elems.append(Paragraph(
        "<font color='#555555' size=9><i>Reply within 6 working hours, 7 days a week</i></font>",
        styles["small_center"]))
    elems.append(Spacer(1, 14 * mm))
    
    # ⑤ Brand 收尾签名
    brand_slogan = company.get("brand_slogan") or "Engineering Trust into Every Pole"
    elems.append(_gold_divider(width_mm=80))
    elems.append(Spacer(1, 4 * mm))
    elems.append(Paragraph(brand_name, styles["title"]))
    elems.append(Spacer(1, 2 * mm))
    elems.append(Paragraph(f"<i>{brand_slogan}</i>", styles["slogan"]))
    
    return elems


def generate_pdf(work_dir, lang, brand_name, contact, selection_file, output, mode="catalog_only"):
    """
    mode:
      - company_only:  只出公司介绍 PDF (5页: 封面+About+认证+5理由+CTA, 无产品页)
      - catalog_only:  只出产品手册 (封面+产品页N+CTA)
      - full_brochure: 公司+产品完整版 (默认推荐, 跟原行为一致)
    """
    # 加载选品数据
    with open(selection_file, "r", encoding="utf-8") as f:
        data = json.load(f)
    
    products = data.get("products", [])
    company = data.get("company", {})
    
    # mode 校验
    if mode == "catalog_only" and not products:
        print(f"❌ catalog_only 模式需要 products, selection.json 中无产品", file=sys.stderr)
        return False
    if mode == "company_only" and not company:
        print(f"❌ company_only 模式需要 company 字段, selection.json 中无", file=sys.stderr)
        return False
    if mode == "full_brochure" and not products:
        # full_brochure 缺产品时降级到 company_only
        print(f"  ⚠️  full_brochure 模式但无产品, 降级为 company_only")
        mode = "company_only"
    
    # 注册字体
    fonts = register_fonts()
    if fonts.get("registered"):
        print(f"  字体: {fonts['registered']}")
    else:
        print(f"  ⚠️  未找到 CJK 字体，中文可能显示为方框；将用 Helvetica 渲染")
    
    styles = build_styles(fonts)
    
    # 文档
    doc = SimpleDocTemplate(
        output, pagesize=A4,
        leftMargin=15 * mm, rightMargin=15 * mm,
        topMargin=15 * mm, bottomMargin=15 * mm,
        title=f"{brand_name} Catalog ({lang})",
        author=brand_name,
    )
    
    # 构造内容（按 mode 决定渲染哪些章节）
    elements = []
    show_products = mode in ("catalog_only", "full_brochure")
    show_company = mode in ("company_only", "full_brochure")
    n_product_pages = len(products) if show_products else 0
    # 总页数 = 封面 + (about 仅 company/full) + 产品页 + (认证+5理由 仅 company/full) + CTA
    total_pages = 1 + (1 if show_company else 0) + n_product_pages + (2 if show_company else 0) + 1
    
    # 封面 — 所有 mode 都有 (含 hero 公司形象图 + 品牌 Slogan)
    elements.extend(build_cover(
        styles, brand_name,
        company.get("slogan", ""),
        company.get("established", ""),
        company.get("factory_size", ""),
        contact,
        hero_image_path=company.get("cover_image_path"),
        brand_slogan=company.get("brand_slogan"),
        year_label=company.get("year_label"),
    ))
    
    # About Us — company_only / full_brochure
    if show_company:
        elements.extend(build_about(styles, company))
    
    # 产品页 — catalog_only / full_brochure
    # Trust Bar：从 company 自动拼装公司背书
    trust_bar = company.get("trust_bar") or (
        f"✓ {company.get('established','27 Years')} Manufacturer  ·  "
        f"✓ {company.get('factory_size','90,000 sqm')} Factory  ·  "
        f"✓ {' / '.join(company.get('certifications', ['CE','SASO','UL'])[:4])}  ·  "
        f"✓ Verified Alibaba Gold Supplier  ·  "
        f"✓ 60+ Countries Served"
    )
    if show_products:
        page_offset = 1 + (1 if show_company else 0)
        for i, product in enumerate(products, 1):
            elements.extend(build_product_page(
                styles, product, page_num=page_offset + i,
                total_pages=total_pages, contact=contact,
                trust_bar=trust_bar,
            ))
    
    # 认证墙 + 5 大理由 — company_only / full_brochure
    if show_company:
        elements.extend(build_certs_page(styles, company))
        elements.extend(build_five_reasons(styles, company))
    
    # CTA — 所有 mode 都有 (传 company 用于读取 brand_slogan)
    elements.extend(build_cta_page(styles, brand_name, contact, company=company))
    
    # 渲染
    doc.build(elements)
    
    # 验证
    if os.path.exists(output):
        size_kb = os.path.getsize(output) / 1024
        print(f"  ✅ 生成成功: {output}")
        print(f"     文件大小: {size_kb:.1f} KB")
        print(f"     产品数: {len(products)}")
        print(f"     总页数: ~{total_pages}")
        if size_kb < 500:
            print(f"  ⚠️  文件偏小（< 500KB），可能图片未嵌入")
        return True
    else:
        print(f"  ❌ 生成失败", file=sys.stderr)
        return False


# ============================================================================
# CLI
# ============================================================================

def main():
    p = argparse.ArgumentParser(description="生成 PDF Catalog (v1.2.0)")
    p.add_argument("--work-dir", required=True, help="知识库根路径")
    p.add_argument("--lang", required=True, help="语种 (EN/ES/FR/AR/RU)")
    p.add_argument("--brand-name", required=True, help="品牌名")
    p.add_argument("--contact", required=True, help="联系方式")
    p.add_argument("--selection-file", required=True,
                   help="JSON 文件路径（含 products + company）")
    p.add_argument("--output", required=True, help="输出 PDF 路径")
    p.add_argument("--mode", default="full_brochure",
                   choices=["company_only", "catalog_only", "full_brochure"],
                   help="company_only=只出公司介绍 / catalog_only=只出产品手册 / full_brochure=完整版(默认)")
    
    args = p.parse_args()
    
    # 确保输出目录存在
    os.makedirs(os.path.dirname(args.output), exist_ok=True)
    
    print(f"📑 生成 Catalog: {args.brand_name} ({args.lang}) [mode={args.mode}]")
    success = generate_pdf(
        work_dir=args.work_dir,
        lang=args.lang,
        brand_name=args.brand_name,
        contact=args.contact,
        selection_file=args.selection_file,
        output=args.output,
        mode=args.mode,
    )
    
    sys.exit(0 if success else 1)


if __name__ == "__main__":
    main()
