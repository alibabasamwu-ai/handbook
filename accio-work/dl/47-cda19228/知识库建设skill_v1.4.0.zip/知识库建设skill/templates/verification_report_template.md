# KB Verification & Acceptance Report
# 使用说明：完成所有模块构建后的最终验收报告

## 1. 验收摘要 (Executive Summary)
- **项目名称**: {{project_name}}
- **总文件数**: {{total_files}}
- **核心模块覆盖度**: {{coverage_percentage}}%
- **平均 AI 评分**: {{avg_score}}/30

## 2. 模块验收详情 (Module Acceptance)
| 模块 ID | 名称 (Module Name) | 完备度 | 关键遗漏 (Gap) |
| :--- | :--- | :--- | :--- |
| 01 | Company Info | {{m01_status}} | {{m01_gap}} |
| 02 | Product Info | {{m02_status}} | {{m02_gap}} |
| 03 | Communication | {{m03_status}} | {{m03_gap}} |
| 04 | After Sales | {{m04_status}} | {{m04_gap}} |
| 05 | Logistics | {{m05_status}} | {{m05_gap}} |
| 06 | Payment | {{m06_status}} | {{m06_gap}} |

## 3. 高频测试用例验收 (High-freq Test Cases)
- [ ] **Case 1**: "Are you a manufacturer or a trading company?" -> {{case1_result}}
- [ ] **Case 2**: "What is the lead time for 1000 units?" -> {{case2_result}}
- [ ] **Case 3**: "Do you have CE certification for Europe?" -> {{case3_result}}

## 4. 结论与发布建议
- [ ] **建议发布**: 知识库已达到生产标准。
- [ ] **需补充素材**: 仍需补充 {{missing_material}}。

**签核人**: {{reviewer_name}}
**日期**: {{current_date}}
