# MCP 接口契约 · 国际站品牌战略 Phase 1/2 数据采集

> 本环境（Accio Work）真实存在的国际站后台 MCP 接口，**替代 QoderWork 原版的 `javascript_tool` DOM 自爬**。
> 所有接口通过 `accio-mcp-cli call <tool> --json '{...}'` 调用（bash 或 bash 子代理）。
> ⚠️ 单引号包裹 --json，防 shell 转义。
> ⚠️ MCP 当天易超时：单条 90s 超时 + 重试 2 次 + 串行，不要并发轰接口。

## 一、店铺 / 竞品基础画像（A+ 级，首选）

### `supplier_verification_recall` — 召回供应商候选 + 国际站结构化基础画像
- toolkit=alibaba, toolkit_service=supplier-verification-report
- 入参：
  ```json
  { "supplier_name": "https://<shop>.en.alibaba.com/", "top_k": 5 }
  ```
  - `supplier_name` 可传：店铺 URL（自动归一化取公司 token）/ 公司全名
  - `top_k` 默认 50，最大 100
- 返回：
  - `payload.recall_icbu[0]` —— **国际站结构化基础画像，直接入报告（A+ 级，对应 Phase 1 客户画像 / Phase 2 竞品画像）**：
    | 字段 | 含义 | 品牌战略用途 |
    |---|---|---|
    | `seller_score` | 国际站评分（如 "4.6"） | Trust KPI Bar / 案例库铁律10 事实声明 |
    | `management_certifications` | 管理体系认证（如 "sedex"） | 认证合规模块 / 铁律5 |
    | `product_certifications` | 产品认证（如 "Oeko-Tex 100"） | 认证合规模块 |
    | `years_in_industry` | 行业年限（如 "17"） | "Since XX" 年份反推（铁律5/案例1） |
    | `established_year` | 成立年（如 "2005"） | 年份一致性校验（与官网/徽章对照） |
    | `facility_area_sqm` | 厂房面积（如 "3265.0"） | 工厂能力 Proof Point |
    | `employees` | 员工数（如 "43"） | 规模 Proof Point |
    | `main_category` | 主营类目 | 品类聚焦度 / 定位 |
    | `main_products` | 主推产品（逗号串） | Core Categories 模块 |
    | `trade_regions` | 主市场分布（逗号串） | 目标客群验证 |
    | `business_type` | 经营类型（如 "Combined"） | 工贸一体定位 |
    | `contact_country/province/city` | 地址 | — |
  - `payload.candidates[]`：每个含 `company_id`（部分含 name/score/minisite/seller_score）→ 用 minisite_url 对账锁定**正确** company_id（防铁律6 身份混淆）
  - `payload.recall_out[]`：工商注册信息（注册资本/法人/经营范围/状态）—— **背景增强，非国际站口径，入报告必须标注"工商登记信息（背景）"**

### `supplier_verification_detail` — 按 company_id 拉详情
- toolkit=alibaba, toolkit_service=supplier-verification-report
- 入参：`{ "comp_id_list": ["<company_id>"] }`
- 用途：recall 锁定正确 company_id 后补更细字段

### `get_seller_basic_info` — 商家基本信息（接待侧）
- toolkit=alibaba, toolkit_service=icbu-reception-mcp-service
- 返回：商家基本知识、主营类目、最近发送的消息
- 用途：补主营类目 / 接待活跃度

## 二、MCP 拿不到 → 必须 browser 子代理实测的字段（A 级）

后台 MCP **不返回**以下 JS 渲染字段，必须 `sessions_spawn(agent_id="browser", task=...)` 回访 DOM：
- 全店分类树 / SKU 总数 / productlist 翻页指示符
- 主页产品卡数 / 视频字段（video tag / duration / play icon）
- 主推产品销量 label（"xxx sold"）—— 用于铁律7 数学校验
- 累计交易额 / 累计订单数（Performance 模块）—— 客单价计算
- 准时发货率 / 响应时间
- Hero Banner 文案 / 现有定位语 / 认证展示位（竞品对标）

### browser 子代理任务模板（自包含）
```
目标：回访 https://{store}.en.alibaba.com 主页 + productlist.html + company_profile.html
采集字段（逐个附 URL + 采集时间 + 前后3段原文上下文）：
  - SKU 总数 / 分类树 / 产品卡数 / 视频数
  - 主推产品 "xxx sold" 数字
  - Performance：累计交易额 / 累计订单 / 准时率 / 响应时间
  - 认证证书编号（不只是认证名）
铁律：取不到的字段如实写 null / "获取失败"，禁止用 page-text 描述充当数据，禁止猜测估算。
返回 JSON：{field: {value, source_url, captured_at, context_quote}}
```

## 三、调用陷阱与兜底

| 陷阱 | 现象 | 兜底 |
|---|---|---|
| MCP 当天不稳定 | 40-90s 超时频发 | 单条 90s 超时 + 重试 2 次 + 串行 |
| recall 召回不准 | 传公司名召回多家同名 | 优先传店铺完整 URL；用 minisite_url 比对锁定正确 company_id（铁律6） |
| `recall_out` 口径混淆 | 工商注册 ≠ 国际站口径 | 入报告标注"工商登记信息（背景）"，不当国际站累计数据 |
| browser 子代理返回二手描述 | 子代理用 page-text 描述当数据 | 任务里强制"数不到写 null，禁止文字描述充当数据" |
| 累计交易/订单缺失 | MCP 不返回 | browser 爬 Performance 模块；仍无标"置信度=低，待补"（不得编造，铁律7/案例2） |

## 四、最小采集链（单店客户 · Phase 1）

```
1. supplier_verification_recall(店铺URL, top_k=5)
   → recall_icbu[0] 取 A+ 级基础字段（评分/认证/年限/面积/员工/类目/主市场）
   → candidates 用 minisite_url 对账锁定正确 company_id
2. (可选) supplier_verification_detail(company_id) 补细节
3. spawn browser 子代理爬 主页/productlist/company_profile
   → 补 SKU/视频/销量/累计交易/准时率等 A 级 DOM 字段
4. 双源对账（MCP recall vs browser DOM）→ 落 Phase 1 实测表 + 数学校验（sold×单价 vs 累计交易）
```

## 五、竞品采集链（Phase 2）

```
每家 Top 3-5 竞品（并行，一家一个子代理）：
1. supplier_verification_recall(竞品店铺URL) → A+ 级画像
2. spawn browser 子代理回访竞品页 → Hero Banner/定位语/认证位/MOQ/工厂数据（A 级）
3. 身份独立确认（铁律6）：公司名完全匹配 + URL 独立，禁止同城同品类即视为同一/关联主体
品牌买家行为 + 合规标准：web_search（可派 general 子代理并行）→ web_fetch 回访官方文件（非营销博客）
```
