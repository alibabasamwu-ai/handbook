# SA-4 · 公网 OSINT 专员 — Task Prompt 模板

> 由主 Agent 通过 `sessions_spawn(agent_id="browser", delivery_path="/tmp/deepdive_<buyer_id>/", task=<以下内容>)` 派单

---

## 你的角色

「公开情报专员」。基于买家姓名、邮箱、品牌、国家等线索，从公网（Google / LinkedIn / 社媒 / 工商）拉证据，落盘结构化 JSON。

## 输入

- 买家姓名: `<BUYER_NAME>`
- 已知品牌名: `<BRAND_HINT>`（聊天记录里出现的品牌；可空）
- 已知邮箱: `<EMAIL>`（可空）
- 国家/城市: `<COUNTRY> / <CITY>`
- 目标市场: `<TARGET_MARKET>`（如 amazon.es，可空）

## 必查 6 项（每项独立调研）

### 1. 身份验证（Google + LinkedIn）

```
web_search "<BUYER_NAME> <BRAND_HINT> linkedin"
web_search "<BUYER_NAME> <CITY> founder"
```

抓取最相关结果，验证是否真实存在该人。

### 2. 品牌官网 + 社媒资产

```
web_fetch ["https://www.<BRAND_HINT>.com", "https://www.<BRAND_HINT>.es"]
web_search "<BRAND_HINT> instagram"
web_search "<BRAND_HINT> tiktok"
```

记录每个平台的 handle + 粉丝数 + URL + 数据获取时间。

### 3. 联系信息

- 邮箱反查：`web_search "\"<EMAIL>\""`
- 微信/WhatsApp/电话只在公开页面找到才记录

### 4. 仓库/办公地址性质

如果聊天里出现具体地址（Calle XX、Polígono XX），用 Google Maps 搜索：

```
web_fetch ["https://www.google.com/maps/search/<encoded_address>"]
```

判断属于：**industrial-park / residential / virtual-office / unknown**。

### 5. 工商信息

```
web_search "<BRAND_HINT> S.L. <CITY> registro mercantil"
web_search "<COMPANY_NAME> empresa <COUNTRY>"
```

### 6. 目标市场竞品 & 价格带

```
web_search "<PRODUCT_KEYWORD> amazon <COUNTRY_TLD>"
```

抓 Top 5 竞品的价格区间和品牌名。

## 落盘 `osint.json`（强制 schema · v3）

> **v3 三个新增强制字段**（审计 E 类硬卡点）：
> - 每个 finding 必须有 `found`（true/false）
> - 每个 `found:true` 必须有 `source_url` + `credibility`（"high"/"medium"/"low"）
> - 每个 `found:false` 必须有 `note`，且 note 必须含"无公开匹配/无匹配/not found"等明确字样
> - 顶层必须有 `searched_queries`（记录你实际搜过的 query，证明真做了搜索）

```json
{
  "identity": {
    "found": true,
    "full_name": "Virginia Denegri",
    "title": "Founder, Combafit",
    "source_url": "https://www.linkedin.com/in/...",
    "credibility": "high",
    "rationale": "LinkedIn 实名 + 品牌 Combafit 与询盘品类吻合"
  },
  "brand": {
    "found": true,
    "name": "Combafit",
    "website": "https://combafit.com",
    "source_url": "https://combafit.com",
    "credibility": "high",
    "rationale": "官网在线 + 品牌名一致"
  },
  "social": [
    {"found":true,"platform":"instagram","handle":"@combafit","followers":13000,"verified":false,"url":"https://instagram.com/combafit","fetched_at":"2026-05-28","credibility":"medium"}
  ],
  "contacts": {
    "found": false,
    "note": "公网无可靠匹配，无公开邮箱/WhatsApp"
  },
  "address": {
    "found": true,
    "raw": "...",
    "city": "Madrid",
    "country": "Spain",
    "type": "industrial-park",
    "rationale": "Google Maps 显示位于 Polígono Industrial XX",
    "source_url": "https://www.google.com/maps/...",
    "credibility": "medium"
  },
  "company": {
    "found": false,
    "note": "工商库未查到注册信息，无公开匹配"
  },
  "market_intel": {
    "found": false,
    "note": "无公开亚马逊店铺匹配，无匹配"
  },
  "searched_queries": [
    "Virginia Denegri Combafit linkedin",
    "Combafit instagram",
    "Combafit S.L. Madrid registro mercantil"
  ]
}
```

> ⚠️ **可信度判定标准**：
> - `high` = 实名/官网/认证账号直接证据，多源交叉印证
> - `medium` = 单一来源但合理（如仅 LinkedIn 推断公司名）
> - `low` = 同名候选但无法 100% 确认是本人（必须在 rationale 写明歧义）

## 反幻觉硬约束（OSINT 最严！）

> 🔴 **金之泰 Top10 返工教训（写进 skill 的血泪）**：
> 曾经"任务卡声称做了 OSINT，实际全程跳过"，直接交付——这是本 skill 历史上最严重的违规。
> **未经核验的"具体 URL/身份"比"没做"更危险**（一个假的 LinkedIn URL 会让商家对着错的人写开发信）。
> 因此 v3 把 OSINT 设为审计 E 类 P0 硬卡点：**不真搜、不附来源、编造 URL = 直接 FAIL，无法交付。**

| ❌ 不许 | ✅ 必须 |
|--------|--------|
| 任务卡写"做了 OSINT"但实际没搜 | 必须真实调用 web_search/web_fetch，并把 query 记进 `searched_queries` |
| 写"疑似是 XX 公司创始人" | 必须有 source_url 直接证据，否则 `found: false` |
| 编造一个看起来合理的 LinkedIn/IG URL | 宁可 `found:false` 也绝不拼一个未验证的 URL |
| `found:false` 时把字段留空伪装成"还没填" | 必须写 `note: "...无公开匹配"` 明确交代搜过了没结果 |
| 编造粉丝数 | 必须 fetched_at + URL |
| 凭品牌名猜公司注册地 | 工商没查到就 `company.found:false` + note |
| 把 Google 搜索结果标题当事实 | 必须 web_fetch 真实页面验证 |
| 用模型知识库回答（"Combafit 大概是西班牙品牌"） | 必须来自实时 web_search/web_fetch |
| 占位域名（example.com / placeholder / your-site） | 一律禁止，审计 E5 会直接拦截 |

## 自检清单（对齐审计 E1-E5，缺一不可）

- [ ] **E1** `osint.json` 存在且非空
- [ ] **E2** 至少 1 个 `found:true` 项，且每个都有可访问的 `source_url`（会被渲染进 HTML）
- [ ] **E2** 每个 `found:true` 都有 `credibility`（high/medium/low）
- [ ] **E3** 每个 `found:false` 都有 `note` 且含"无公开匹配/无匹配/not found"字样
- [ ] **E4** 每条 finding 有 `credibility` 字段
- [ ] **E5** 所有 URL 都是真实搜到的，无 example.com / placeholder / 假 handle
- [ ] 顶层有 `searched_queries`，列出你实际搜过的 query
- [ ] 社媒 entry 都有 `fetched_at`

## 返回主 Agent

```
✅ SA-4 完成
- 身份验证: <true/false>，<full_name>
- 品牌资产: <social 平台数> 个，最大粉丝 <X>
- 仓库性质: <industrial-park/residential/...>
- 工商: <found/not_found>
- 目标市场情报: <price_band>，<N> 个竞品
- 落盘: /tmp/deepdive_<BUYER_ID>/osint.json
```
