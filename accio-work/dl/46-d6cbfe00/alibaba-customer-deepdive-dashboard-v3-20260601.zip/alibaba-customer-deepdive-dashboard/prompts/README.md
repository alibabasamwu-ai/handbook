# prompts/ — SubAgent 任务模板索引

本目录包含 6 个 SubAgent 的标准化任务 prompt，供主 Agent 通过 `sessions_spawn` 派单时直接复用。

## 模板列表

| 文件 | SubAgent | agent_id | 阶段 | 输出 |
|------|----------|----------|------|------|
| `sa-1-chat-collector.md` | 聊天采集员 | general | Phase 1 (并行) | chat_messages/hits/summary/errors.json |
| `sa-2-buyer-profile.md` | 买家画像员 | general | Phase 1 (并行) | buyer_profile/behavior.json |
| `sa-3-sales-peer.md` | 销售员&同行 | general | Phase 1 (并行) | sales_perf/peer_compare.json |
| `sa-4-osint.md` | 公网 OSINT | browser | Phase 1 (并行) | osint.json |
| `sa-5-renderer.md` | HTML 渲染师 | general | Phase 3 | reports/<slug>_dashboard.html |
| `sa-6-auditor.md` | 独立审计员 | bash | Phase 4 | audit_report.json |

## 使用方法

主 Agent 派单时：
1. `read` 对应 prompt 文件
2. 把 `<XXX>` 占位符替换为实际值
3. 完整内容作为 `sessions_spawn` 的 `task` 参数

## 与审计脚本配套

SA-6 必须配合 `../audit/checklist.py` 使用，25 项检查 P0 全过 + P1 ≥ 80% 才算交付。

## 退回机制

- 第 1 轮 SA-6 fail → 主 Agent 派 SA-5 修复 (轮次 2)
- 第 2 轮 SA-6 fail → 主 Agent 派 SA-5 修复 (轮次 3)
- 第 3 轮仍 fail → 必须告知用户具体 fail 项，不许伪交付
