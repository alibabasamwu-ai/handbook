// ==================================================================
// 6 个 Chart.js 图表的参数化模板（视觉风格锁定，禁止改动颜色 / 类型）
// 占位符规范：{{...}} 用 JSON 数据替换
// canvas id 锁定：radar / brandStage / catBar / chatBar / peerBar / riskRadar
// ==================================================================

// ===== Chart.js 全局配置 =====
Chart.defaults.color='#a78fc7';
Chart.defaults.borderColor='rgba(255,255,255,.06)';
Chart.defaults.font.family='-apple-system,PingFang SC,Inter,sans-serif';

const rose='#ff3d8a',purple='#9b59ff',gold='#f5c87a',neon='#00ffe0',ok='#19f0a8',warn='#ffb627',danger='#ff4757';

// ------------------------------------------------------------------
// 1. 行为雷达 (radar) — 6 维买家活跃度 vs 同行均值
//    数据源: buyer_behavior.json + 同行 P50 估算
//    labels 锁定 6 维（顺序不可改）
// ------------------------------------------------------------------
new Chart(document.getElementById('radar'),{
  type:'radar',
  data:{
    labels:['浏览深度','登录频次','沟通时长','跨卖家比价','付费意愿','规格专业度'],
    datasets:[
      {label:'{{BUYER_NAME}}',data:{{BUYER_RADAR_DATA}}/* 6 个 0-100 数字 */,
        backgroundColor:'rgba(255,61,138,.2)',borderColor:rose,borderWidth:2,
        pointBackgroundColor:rose,pointRadius:4},
      {label:'同行均值',data:{{PEER_RADAR_DATA}}/* 6 个 0-100 数字 */,
        backgroundColor:'rgba(124,58,237,.15)',borderColor:purple,borderWidth:2,borderDash:[5,5],
        pointBackgroundColor:purple,pointRadius:3}
    ]
  },
  options:{
    plugins:{legend:{position:'bottom',labels:{font:{size:11}}}},
    scales:{r:{
      angleLines:{color:'rgba(255,255,255,.08)'},
      grid:{color:'rgba(255,255,255,.06)'},
      pointLabels:{font:{size:11},color:'#dcd1f0'},
      ticks:{display:false},
      min:0,max:100
    }}
  }
});

// ------------------------------------------------------------------
// 2. 品牌阶段 (brandStage) — doughnut
//    labels 锁定 5 阶段（顺序不可改）
//    data: [品牌设计%, 社媒粉丝%, 产品 PRD%, 首批生产%, 正式销售%]
// ------------------------------------------------------------------
new Chart(document.getElementById('brandStage'),{
  type:'doughnut',
  data:{
    labels:['品牌设计','社媒粉丝','产品 PRD','首批生产','正式销售'],
    datasets:[{data:{{BRAND_STAGE_DATA}}/* 5 个 0-100 数字 */,
      backgroundColor:[gold,rose,purple,warn,'rgba(255,255,255,.1)'],
      borderColor:'rgba(10,6,18,1)',borderWidth:2}]
  },
  options:{
    plugins:{legend:{position:'right',labels:{font:{size:11},boxWidth:10}}},
    cutout:'60%'
  }
});

// ------------------------------------------------------------------
// 3. 品类点击 (catBar) — bar
//    数据源: buyer_behavior.categories
//    建议展示 Top 5-6 品类 + 其他长尾
// ------------------------------------------------------------------
new Chart(document.getElementById('catBar'),{
  type:'bar',
  data:{
    labels:{{CAT_BAR_LABELS}}/* string[] 最多 6 个 */,
    datasets:[{label:'点击次数',data:{{CAT_BAR_DATA}}/* number[] */,
      backgroundColor:[rose,purple,gold,neon,warn,'rgba(255,255,255,.15)'],
      borderRadius:6,borderSkipped:false}]
  },
  options:{
    plugins:{legend:{display:false}},
    scales:{
      x:{grid:{display:false}},
      y:{grid:{color:'rgba(255,255,255,.04)'}}
    }
  }
});

// ------------------------------------------------------------------
// 4. 沟通节奏 (chatBar) — stacked bar
//    数据源: chat_messages.json 按日聚合
//    labels: 沟通发生的日期数组
// ------------------------------------------------------------------
new Chart(document.getElementById('chatBar'),{
  type:'bar',
  data:{
    labels:{{CHAT_BAR_DATES}}/* ['4/29','5/1',...] */,
    datasets:[
      {label:'买家发送',data:{{CHAT_BAR_BUYER}}/* number[] */,
        backgroundColor:rose,borderRadius:4,stack:'s'},
      {label:'店铺发送',data:{{CHAT_BAR_SHOP}}/* number[] */,
        backgroundColor:'rgba(124,58,237,.7)',borderRadius:4,stack:'s'}
    ]
  },
  options:{
    plugins:{legend:{position:'bottom',labels:{font:{size:11},boxWidth:10}}},
    scales:{
      x:{stacked:true,grid:{display:false}},
      y:{stacked:true,grid:{color:'rgba(255,255,255,.04)'}}
    }
  }
});

// ------------------------------------------------------------------
// 5. 同行/子账号对比 (peerBar) — bar + line 双 y 轴
//    数据源: sales_perf.json
//    接待过该买家的销售员名字加 🌟 标记
// ------------------------------------------------------------------
new Chart(document.getElementById('peerBar'),{
  type:'bar',
  data:{
    labels:{{PEER_BAR_LABELS}}/* 子账号名 string[] */,
    datasets:[
      {label:'新买家数',data:{{PEER_BAR_NEW_BUYERS}},
        backgroundColor:gold,borderRadius:4,yAxisID:'y'},
      {label:'5min 回复率 %',data:{{PEER_BAR_5MIN_RATE}},
        backgroundColor:'rgba(255,61,138,.6)',borderRadius:4,yAxisID:'y1',type:'line',
        borderColor:rose,borderWidth:2,pointRadius:5,tension:.3,fill:false}
    ]
  },
  options:{
    plugins:{legend:{position:'bottom',labels:{font:{size:11},boxWidth:10}}},
    scales:{
      x:{grid:{display:false}},
      y:{type:'linear',position:'left',grid:{color:'rgba(255,255,255,.04)'},title:{display:true,text:'新买家'}},
      y1:{type:'linear',position:'right',min:0,max:100,grid:{display:false},title:{display:true,text:'回复率%'}}
    }
  }
});

// ------------------------------------------------------------------
// 6. 风险雷达 (riskRadar) — radar
//    labels 锁定 5 维风险维度（顺序不可改）
//    data: 0-10 评分（diagnosis.risks）
// ------------------------------------------------------------------
new Chart(document.getElementById('riskRadar'),{
  type:'radar',
  data:{
    labels:{{RISK_RADAR_LABELS}}/* string[5] 5 维风险维度 */,
    datasets:[{label:'风险评分(0-10)',data:{{RISK_RADAR_DATA}}/* number[5] */,
      backgroundColor:'rgba(255,71,87,.2)',borderColor:danger,borderWidth:2,
      pointBackgroundColor:danger,pointRadius:5}]
  },
  options:{
    plugins:{legend:{position:'bottom',labels:{font:{size:11}}}},
    scales:{r:{
      angleLines:{color:'rgba(255,255,255,.08)'},
      grid:{color:'rgba(255,255,255,.06)'},
      pointLabels:{font:{size:11},color:'#fed1e1'},
      ticks:{display:false,stepSize:2},
      min:0,max:10
    }}
  }
});
