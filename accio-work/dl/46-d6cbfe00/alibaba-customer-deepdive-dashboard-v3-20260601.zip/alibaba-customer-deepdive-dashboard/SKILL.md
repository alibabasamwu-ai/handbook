---
name: alibaba-customer-deepdive-dashboard
description: 阿里巴巴国际站客户深度背调与跟进策略看板生成器。采用「多 SubAgent 并行 + 主 Agent 串行审计 + 模板锁定 + 信息保留率校验」工业化流程，针对单个买家/客户输出 D 档时尚高饱和（黑底+玫瑰金+霓虹紫红）交互式 HTML 看板，含 9 大 section、6 个 Chart.js 图表、Top 5–6 行动建议。当用户说"做客户背调"、"分析这个买家"、"Virginia 这个客户的看板"、"给我看 XX 客户的完整背景"、"对接 XX 客户需要哪些准备"等表达时触发。
---

# 客户深度背调看板生成器 — 多 SubAgent 工业化版 (v3)

> **版本**：v3.0 · 2026-05-29
> **v3 核心升级**：OSINT 公网交叉验证从"软检查"升级为**审计 E 类 P0 硬卡点**——不真做、不附来源、编造 URL 一律 FAIL，无法交付。审计项 25 → **30 项**（P0 25 + P1 5）。
> 触发本升级的实战教训见 [reference/case-kimtex-top10.md](reference/case-kimtex-top10.md)：曾"声称做了 OSINT 实际跳过"还过审，这是漏洞，v3 已堵死。
> 安装/冷启动指南见 [ONBOARDING.md](ONBOARDING.md)。

## 一、定位与价值

本 skill 解决**重要客户跟进前**的全维度信息整合问题：

- **谁是这个买家**（个人画像 / 品牌 / 数字资产）
- **做了什么**（90 天行为、沟通轨迹、付款记录）
- **谁在接待**（店铺销售员归因 / 同行对比）
- **风险在哪**（沟通延迟 / 信任损耗 / 合规风险）
- **下一步怎么做**（24h / 7d / 30d 行动清单）

最终交付：**单个 HTML 文件 · 800+ 行 · D 档时尚高饱和视觉 · 9 section + 6 chart · 不少于 48KB**。

## 二、为什么必须多 SubAgent

主 Agent 一次性完成会出现：

| 问题 | 表现 | 多 Agent 怎么解 |
|------|------|----------------|
| **数据幻觉** | 编造产品 ID / 编造买家发的话 | 数据 Agent 必须返回原始 JSON 路径，渲染 Agent 必须从 JSON 引用 |
| **采集偏科** | 聊天记录详尽但同行数据缺失 | 4 个并行 SubAgent 各管一块，互不挤占注意力 |
| **风格漂移** | 这次黑底玫瑰金，下次蓝底白字 | template/base.html 锁死 CSS 设计系统 |
| **后段偷懒** | 前 3 个 section 详细，后 6 个草率 | Section 一组一审计，不通过退回 |
| **审计失灵** | 主 Agent 自己写自己审，没看出来漏数据 | 独立 audit-bot 拿 checklist 跑校验脚本 |

## 三、SubAgent 团队架构

```
┌─────────────────────────────────────────────────────┐
│            主 Agent（项目总监 / 总审计长）              │
│  · Phase 0 与用户确认背调对象                          │
│  · 并发派单 / 收件 / 一轮审计 / 装配最终 HTML            │
└──────────────────────┬──────────────────────────────┘
                       │
        ┌──────────────┼──────────────┬───────────────┐
        ▼              ▼              ▼               ▼
   ┌────────┐    ┌──────────┐   ┌──────────┐   ┌─────────┐
   │ SA-1   │    │  SA-2    │   │  SA-3    │   │  SA-4   │
   │ 聊天采集 │    │ 买家画像 │   │ 同行/销售 │   │ 公网背调 │
   │ 专员    │    │ 行为专员 │   │ 绩效专员 │   │ OSINT 员 │
   └────────┘    └──────────┘   └──────────┘   └─────────┘
        │              │              │               │
        └──────────────┴──────────────┴───────────────┘
                       │
                       ▼
              ┌─────────────────┐
              │   主 Agent      │
              │   一轮审计 + 业务诊断 + 行动建议 │
              └────────┬─────────┘
                       │
                       ▼
              ┌─────────────────┐
              │     SA-5        │
              │   HTML 渲染师   │
              │ （只允许照搬模板 + 填数据） │
              └────────┬─────────┘
                       │
                       ▼
              ┌─────────────────┐
              │     SA-6        │
              │   独立审计员    │
              │ （拿 checklist 跑校验脚本） │
              └────────┬─────────┘
                       │
              通过 → 交付   不通过 → 退回 SA-5（最多 2 轮）
```

### 执行时序（重要 — 4 个采集 SubAgent 并行启动）

```
Phase 0  主 Agent ↔ 用户互动确认（必问 3 问）
Phase 1  ⚡并行  SA-1 SA-2 SA-3 SA-4 同时启动（节省 60%+ 时间）
Phase 2  主 Agent 一轮审计 + 业务诊断（核心商业故事 + 风险评估 + 行动建议）
Phase 3  SA-5 HTML 渲染（基于 template/base.html + 主 Agent 给的 JSON）
Phase 4  SA-6 独立审计（运行 audit/checklist.py）
Phase 5  通过 → 交付 / 不通过 → 退回 SA-5 修复（最多 2 轮）
Phase 6  post_skill.py 上报
```

---

## 四、Phase 0：用户互动确认（主 Agent 执行）

### 必问 3 个问题（ask_user mode=form）

| # | 问题 | 选项 | 用途 |
|---|------|------|------|
| Q1 | 背调对象身份 | 买家 aliId / 买家邮箱 / 买家姓名+店铺 | 决定 SA-1 的查询入口 |
| Q2 | 背调深度 | 标准（公网+聊天）/ 深度（含同行对比）/ 战略（全维度+OSINT） | 决定要启动 4 个 SubAgent 中的哪几个 |
| Q3 | 视觉档位 | D 档时尚高饱和（默认）/ 商务专业 / 极简白 | 决定 template 切换 |

**默认值**（用户跳过则使用）：
- Q1：从对话上下文里找最近提到的买家
- Q2：深度
- Q3：D 档（与商家画像 `visual_style_locked` 对齐）

### 启动前必须落盘的输入清单

主 Agent 在派单前把以下信息写入 `/tmp/deepdive_input_<buyer_id>.json`：

```json
{
  "buyer_id": "2034042854643",
  "buyer_name_hint": "Virginia Denegri",
  "shop_sub_accounts": ["Susie Li", "Portia LIAO", "Jimmy Cao", ...],
  "depth": "deep",
  "visual": "D-tide",
  "lookback_days": 90,
  "report_path": "reports/{slug}_dashboard.html",
  "scratch_dir": "/tmp/deepdive_<buyer_id>/"
}
```

---

## 五、4 个采集 SubAgent — 完整任务规范

> **关键约束**：4 个 SubAgent 必须**并行启动**（同一轮内 4 个 `sessions_spawn`）。每个 SubAgent 是独立 session，互不可见，因此 task 必须自包含。

### SA-1 · 聊天采集专员

| 项 | 规范 |
|----|------|
| **agent_id** | `general` |
| **delivery_path** | `/tmp/deepdive_<buyer_id>/` |
| **职责** | 跨 N 个店铺子账号扫出与该买家的全部聊天记录，落盘原始 JSON |
| **必交付物** | `chat_messages.json`（全部消息原文 + 时间戳 + 发送方 + 子账号）<br>`chat_hits.json`（命中的会话列表 + 每会话消息数）<br>`chat_summary.json`（消息总数 / 买家消息数 / 销售消息数 / 沟通天数 / 接待销售员列表） |
| **MCP 工具** | `subaccount_query` → `query_recent_conversation`（每子账号扫近 30 天会话）→ `query_conversation_msg`（命中后翻完整页）|
| **去幻觉硬约束** | 1) 所有消息必须含 `messageId` + `sendTime` + `senderId` + `subAccount`<br>2) 禁止"摘要式描述"，必须原文存盘<br>3) `query_conversation_msg` 的翻页字段是 `nextPointTimeStamp`（不是 `nextTimeStamp`），`forward=false` 是往过去翻页<br>4) 不同店铺账号互不可见，必须用各子账号自己的 `selfAliId` 调接口 |
| **失败兜底** | 某个子账号 401/Permission denied → 写入 `chat_errors.json` 记录哪个账号无权访问，不阻塞其他账号 |

### SA-2 · 买家画像 & 行为专员

| 项 | 规范 |
|----|------|
| **agent_id** | `general` |
| **delivery_path** | `/tmp/deepdive_<buyer_id>/` |
| **职责** | 拉买家在阿里国际站的 90 天行为指数 |
| **必交付物** | `buyer_profile.json`（buyer_id / level / country / city / contact）<br>`buyer_behavior.json`（90 天浏览产品数 / 登录天数 / 沟通天数 / 沟通卖家数 / 主品类点击 / 搜索词 list） |
| **MCP 工具** | `get_buyer_basic_info`（返回 data 为 JSON 字符串，含 buyer_persona）⚠️ 注意 `query_buyer_index`/`get_buyer_behavior_index` **不存在**，详见 [reference/mcp-interfaces.md](reference/mcp-interfaces.md) |
| **去幻觉硬约束** | 所有数值必须来自接口原始字段；接口没有的字段一律写 `null` 不许编造；如果买家没有公开邮箱必须写 `"email": null` |

### SA-3 · 同行 & 销售员绩效专员

| 项 | 规范 |
|----|------|
| **agent_id** | `general` |
| **delivery_path** | `/tmp/deepdive_<buyer_id>/` |
| **职责** | 拉店铺全部子账号近 30 天接待绩效，重点关注接待过该买家的销售员 |
| **必交付物** | `sales_perf.json`（每个子账号：新买家数 / 5min回复率 / AB3率 / RNR率 / 平均回复时长）<br>`peer_compare.json`（同店内排名 / 行业 P25-P75 中位数对比） |
| **MCP 工具** | `subaccount_query` → `query_seller_acct_dim_diag_data` |
| **去幻觉硬约束** | 接待过该买家的销售员必须用红色高亮；行业中位数无法获取时写 `null`，不许用估算值 |

### SA-4 · 公网 OSINT 专员

| 项 | 规范 |
|----|------|
| **agent_id** | `browser` |
| **delivery_path** | `/tmp/deepdive_<buyer_id>/` |
| **职责** | 公网搜买家身份 / 品牌 / 社媒资产 / 仓库地址等 |
| **必交付物** | `osint.json`（结构详见下方） |
| **工具** | `web_search` + `web_fetch` + 选定时 `browser_*` |
| **必查 6 项** | 1) 买家姓名 Google + Linkedin<br>2) 品牌官网 + IG/TikTok/FB（含粉丝数）<br>3) 联系邮箱 / 微信 / WhatsApp<br>4) 仓库/办公地址性质（自有/3PL/虚拟办公）<br>5) 同名公司工商信息（如可查）<br>6) 该买家在目标市场（亚马逊等）的价格带与竞品 |
| **去幻觉硬约束** | 每个 finding 必须带 `source_url`；找不到必须写 `"found": false`，禁止填"疑似"内容；社媒粉丝数必须截图或写明数据获取时间 |

#### SA-4 输出 schema（强制）

```json
{
  "identity": {"found": true, "full_name": "...", "title": "...", "source_url": "..."},
  "brand": {"found": true, "name": "...", "website": "...", "slogan": "...", "source_url": "..."},
  "social": [
    {"platform": "instagram", "handle": "...", "followers": 13000, "verified": false, "url": "...", "fetched_at": "2026-05-28"}
  ],
  "contacts": {"email": "...", "wechat": "...", "whatsapp": null, "source": "..."},
  "address": {"raw": "...", "city": "...", "country": "...", "type": "industrial-park / residential / unknown", "rationale": "..."},
  "market_intel": {"platform": "amazon.es", "price_band_eur": "15-40", "competitors": [...], "source_url": "..."}
}
```

---

## 六、Phase 2：主 Agent 一轮审计 + 业务诊断

并行 4 个 SubAgent 全部返回后，主 Agent 必须**在装配前**完成以下动作：

### 审计动作（主 Agent 必做）

| 检查项 | 怎么做 | 不通过怎么办 |
|--------|--------|-------------|
| 4 份 JSON 文件存在且非空 | `ls /tmp/deepdive_<buyer_id>/*.json` 应有 ≥ 7 个文件 | 缺什么补什么，再派一次单 |
| 聊天消息数 ≥ 10 | 读 `chat_summary.json` | < 10 条说明买家活跃度太低，告知用户改"标准"档 |
| **🔴 OSINT 真做校验（v3 硬卡点）** | 读 `osint.json`：① 文件存在非空；② ≥1 个 `found:true` 带 `source_url`+`credibility`；③ 每个 `found:false` 带"无公开匹配"note；④ 无 example.com/placeholder 等假 URL | 任一不满足 → **退回 SA-4 重搜**，绝不放行（审计 E 类会再卡一次） |
| 销售员绩效覆盖全店子账号 | `sales_perf.json` 行数 = 子账号数 | 缺失账号补查 |
| 时间戳格式统一 | 所有日期字段都转成 `YYYY-MM-DD HH:MM` | 不统一就归一化 |

### 业务诊断（主 Agent 必做，不能交给 SubAgent）

主 Agent 必须基于 4 份 JSON 输出 `diagnosis.json`：

```json
{
  "buyer_grade": "A+",          // 综合评级
  "story_oneliner": "...",       // 一句话核心故事
  "buyer_stage": "Pre-Launch",  // 业务阶段判断
  "risks": [                     // 5 维风险，每项 1-10 分 + rationale
    {"name": "沟通延迟", "score": 7, "evidence": "05-15 至今 13 天无新进展"}
  ],
  "actions": [                   // Top 5-6 行动卡（P0/P1/P2 标签）
    {"priority": "P0", "deadline": "24h", "title": "...", "owner": "Portia", "script": "..."}
  ],
  "kpi_strip": [                 // 顶部 6 个 KPI 卡片数据
    {"label": "综合评级", "value": "A+", "sub": "高质量买家", "tone": "neutral"}
  ],
  "key_quotes": [                // 8 条买家原话证据（必须从 chat_messages.json 引用）
    {"text": "...", "date": "2026-05-07 17:37", "tone": "warn"}
  ]
}
```

**diagnosis 反幻觉规则**：
- `key_quotes[].text` 必须从 `chat_messages.json` 逐字复制，禁止改写
- `actions[].script` 如果含原话引用，必须有出处
- `risks[].evidence` 必须可定位到某个 JSON 字段

---

## 七、Phase 3：SA-5 HTML 渲染师

### SA-5 核心约束（最严）

| 项 | 规范 |
|----|------|
| **agent_id** | `general` |
| **唯一输入** | `template/base.html`（CSS 骨架）+ 7 份 JSON（4 份采集 + diagnosis + buyer_input + osint） |
| **唯一输出** | `reports/{slug}_dashboard.html`（完整 HTML 文件） |
| **绝对禁止** | 1) ❌ 编造任何不在 JSON 里的数字 / 引用 / URL<br>2) ❌ 改动 CSS 设计系统（颜色 / 字号 / 圆角 / 渐变）<br>3) ❌ 跳过任何强制 section / 减少 chart 数量<br>4) ❌ 删减原话证据数量（必须 ≥ 6 条）<br>5) ❌ 把表格截断到 Top 5（应渲染 JSON 里的全部行） |
| **任务交付方式** | 主 Agent 用 `write`（首块 ≤ 12K）+ 多次 `edit append` 分块写入，避免 token 截断 |

### 必出 section 锁定表（任何一次产出都必须包含）

| # | section id | 标题 | 必含组件 | 数据源 |
|---|-----------|------|---------|--------|
| 1 | `#overview` | Hero + KPI 6 卡 | hero 渐变标题 + 6 个 kpi 卡 | diagnosis.kpi_strip |
| 2 | `#persona` | 买家画像 | persona 大卡（avatar+tags+meta 4 格）+ 3 个联系信息小卡 + 6 维行为雷达 chart `radar` | buyer_profile + osint + buyer_behavior |
| 3 | `#brand` | 品牌/公司画像 | 已完成资产卡 + 商业阶段 doughnut chart `brandStage` + 3 个发现卡 | osint.brand + market_intel |
| 4 | `#behavior` | 浏览行为足迹 | 品类点击 bar chart `catBar` + 搜索词标签云 + 诊断结论框 | buyer_behavior |
| 5 | `#chat` | 沟通轨迹 | 沟通节奏 bar chart `chatBar` + ≥10 节点 timeline + 8 条原话 quote | chat_messages + diagnosis.key_quotes |
| 6 | `#sales` | 销售员归因 | 销售员对比表 + 风险诊断框 | chat_summary + sales_perf |
| 7 | `#peer` | 同行业绩对比 | 子账号绩效 bar+line chart `peerBar` + 关键指标排名表 | sales_perf + peer_compare |
| 8 | `#risk` | 风险评估矩阵 | 风险雷达 chart `riskRadar` + 5 维风险条 | diagnosis.risks |
| 9 | `#action` | 行动建议 | Top 5-6 action 卡（带 P0/P1/P2 + data-num 序号） + 一句话总结 alert 框 | diagnosis.actions |

### 6 个 Chart canvas id 锁定（CSS 类型也锁定）

| canvas id | 图表类型 | 数据来源字段 |
|-----------|---------|-------------|
| `radar` | Chart.js radar | buyer_behavior + 同行均值 |
| `brandStage` | Chart.js doughnut | osint.brand stage assessment |
| `catBar` | Chart.js bar | buyer_behavior.categories |
| `chatBar` | Chart.js stacked bar | chat_messages 按日聚合 |
| `peerBar` | Chart.js bar + line（双 y 轴） | sales_perf |
| `riskRadar` | Chart.js radar | diagnosis.risks |

### 模板复用机制

SA-5 必须 `read` 这两个模板文件：

- `template/base.html` — HTML 骨架 + 完整 CSS 设计系统 + 锚点 nav + 6 个 canvas 占位 + 空 section 占位
- `template/chart-snippets.js` — 6 个 Chart.js 实例的完整代码模板（带颜色变量 + 数据占位符）

填充流程：

```
1. write base.html 内容到 reports/{slug}_dashboard.html（头部+空骨架）
2. 按 section 1→9 顺序 edit 注入实际数据（每段 ≤ 6K 字符避免截断）
3. 在末尾 edit 注入 chart-snippets.js 内容并把占位符替换成 JSON 数据
4. edit 收尾 </body></html>
```

---

## 八、Phase 4：SA-6 独立审计员（最强保障）

### 为什么需要独立审计

主 Agent 既写又审 = 自己看不出问题。SA-6 是**独立 session**，只拿 checklist + 校验脚本，不参与生产，确保审计客观。

### SA-6 规范

| 项 | 规范 |
|----|------|
| **agent_id** | `bash`（只能跑脚本 + 读文件，不能写文件不能上网） |
| **输入** | `reports/{slug}_dashboard.html` + `/tmp/deepdive_<buyer_id>/*.json` + `audit/checklist.py` |
| **输出** | `audit_report.json`（每条 check pass/fail + 详细原因） |
| **判定** | 全部 check pass → 通过；任何 P0 check fail → 退回 SA-5 修复 |

### audit/checklist.py 强制检查项（共 30 项 · v3）

> 分类：**P0 = A 结构(7) + B 数据(8) + C 视觉(5) + E OSINT(5) = 25 项必须 100% 通过**；**P1 = D 行动深度(5) 通过率 ≥ 80%**。

#### A. 结构完整性（P0 - 7 项）

| # | check | 检查方法 |
|---|-------|----------|
| A1 | 文件存在且 ≥ 40KB | `os.path.getsize > 40000` |
| A2 | 9 个 section anchor 全部存在 | grep `id="overview\|persona\|brand\|behavior\|chat\|sales\|peer\|risk\|action"` 必须 9 hit |
| A3 | 6 个 canvas id 全部存在 | grep `canvas id="radar\|brandStage\|catBar\|chatBar\|peerBar\|riskRadar"` 必须 6 hit |
| A4 | HTML 标签闭合 | `</html>` `</body>` `</script>` 各 1 个，div 平衡 |
| A5 | Chart.js CDN 引入 | grep `chart.js@4` |
| A6 | 顶部锚点 nav 9 个链接 | nav 内 `<a href="#...">` 计数 ≥ 9 |
| A7 | 移动端 @media 存在 | grep `@media(max-width` |

#### B. 数据真实性（P0 - 8 项）

| # | check | 检查方法 |
|---|-------|----------|
| B1 | KPI 6 张卡片数据与 diagnosis.kpi_strip 一致 | 逐项比对 value |
| B2 | timeline ≥ 10 个 tl-item | grep `tl-item` 计数 |
| B3 | 原话引用 ≥ 6 条 quote | grep `class="quote` 计数 |
| B4 | 每条原话必须能在 chat_messages.json 找到对应文本 | 子串匹配 |
| B5 | 销售员表行数 = 接待过该买家的销售员数 | 与 chat_summary.sales 比对 |
| B6 | 销售员绩效数值与 sales_perf.json 一致 | 抽 3 个数 |
| B7 | 公网信息 source_url 在 HTML 中以链接形式出现 | grep 必须含 osint 里的 URL |
| B8 | 行为指标数值与 buyer_behavior.json 一致 | 抽 3 个数 |

#### C. 视觉一致性（P0 - 5 项）

| # | check | 检查方法 |
|---|-------|----------|
| C1 | 背景色 `#0a0612` | grep `--bg:#0a0612` |
| C2 | 主色金色 `#f5c87a` | grep `--gold:#f5c87a` |
| C3 | 主色玫瑰 `#ff3d8a` | grep `--rose:#ff3d8a` |
| C4 | Hero 渐变标题 `background-clip:text` | grep 必须存在 |
| C5 | persona avatar 圆形带光晕 | grep `box-shadow:0 0 60px rgba(255,61,138` |

#### E. OSINT 交叉验证（P0 - 5 项 · v3 新增硬卡点）🔴

> 这是 v3 的核心。历史漏洞：旧 B7 在 `osint.json` 无 URL 时**直接判 pass**，导致"声称做 OSINT 实际没做"也能交付。E 类把它彻底堵死。

| # | check | 检查方法 | 拦截什么 |
|---|-------|----------|----------|
| E1 | `osint.json` 存在且非空 | `load_json` 后判 len > 0 | 完全跳过 OSINT |
| E2 | ≥1 个 `found:true` 且都带可渲染的 `source_url` | 遍历 finding，URL 必须 startswith http 且出现在 HTML | 有结论但无来源 / 来源没写进报告 |
| E3 | 每个 `found:false` 显式标注"无公开匹配" | note 含 无匹配/not found/no public 等 token | 留空字段伪装成"还没填" |
| E4 | 存在可信度标注（high/medium/low） | JSON 有 credibility 字段 或 HTML 有"可信度" | 不区分确信度，把猜测当事实 |
| E5 | 无编造/占位 URL | 正则查 example.com / placeholder / 假 handle / 模板残留 | 拼一个看起来合理的假 URL |

#### D. 行动深度（P1 - 5 项）

| # | check | 检查方法 |
|---|-------|----------|
| D1 | action 卡 ≥ 5 张 | grep `class="action"` 计数 |
| D2 | 每张 action 含 P0/P1/P2 标签 | grep `action-tag` 计数 = action 数 |
| D3 | 每张 action 含 data-num 序号 | grep `data-num=` |
| D4 | 至少 1 张 action 含可复制话术 quote | quote in action 块 |
| D5 | 末尾一句话总结 alert 框存在 | grep `linear-gradient(135deg,rgba(255,61,138` 在 action section |

### 通过门槛（v3）

- **P0 check 必须 100% 通过**（A+B+C+**E** 共 **25** 项）
- **P1 check 通过率 ≥ 80%**（D 类 5 项至少 4 项通过）
- 失败时 audit_report.json 必须列出**具体哪一行 / 哪个 JSON 字段对不上**，方便 SA-5 修复
- 🔴 **E 类任一 fail = 不得交付**：即使其它 24 项全过，只要 OSINT 没真做（E1-E5 任一 FAIL），整份报告判 FAIL，必须退回 SA-4 重搜 + SA-5 重渲

### 退回机制

```
SA-6 输出 audit_report.json
  ↓
有 P0 fail？
  ├─ Yes → 主 Agent 把 audit_report.json 全文发给 SA-5（用 sessions_send），让 SA-5 修复
  │         修复后重新跑 SA-6
  │         最多重试 2 轮
  │         第 3 轮还不过 → 主 Agent 在交付时**明确告知用户哪些 check 未通过**，不得隐瞒
  └─ No → 通过，进入交付
```

---

## 九、Phase 5：交付 & 上报

### 交付格式（主 Agent 输出）

```
✅ 客户深度背调看板已交付

📄 报告路径：[<slug>_dashboard.html](reports/<slug>_dashboard.html)
📊 文件大小：48 KB | 806 行 | 9 section | 6 chart | 6 action

🎯 一句话核心诊断：<diagnosis.story_oneliner>

🛡️ 审计结果：
- P0 结构/数据/视觉 共 20 项 ✓ 全部通过
- P1 行动深度 5 项 ✓ 5/5 通过
- 数据可追溯性：100%（所有数字均来自 /tmp/deepdive_<buyer_id>/*.json）

🔝 Top 3 行动建议：
1. [P0/24h] <action.title>
2. [P1/7d] <action.title>
3. [P1/7d] <action.title>
```

### post_skill 上报

```bash
python ${agent_core}/skills/plugin-memory-manager/scripts/post_skill.py \
  alibaba-customer-deepdive-dashboard \
  '{"outcome":"...","profile_updates":{...}}'
```

---

## 十、模板文件与脚本（必读）

| 文件 | 用途 |
|------|------|
| `template/base.html` | HTML 骨架 + 完整 CSS 设计系统 + 9 section 占位 + 6 canvas 占位 |
| `template/chart-snippets.js` | 6 个 Chart.js 实例代码模板 |
| `prompts/sa-1-chat-collector.md` | SA-1 任务 prompt 模板 |
| `prompts/sa-2-buyer-profile.md` | SA-2 任务 prompt 模板 |
| `prompts/sa-3-sales-peer.md` | SA-3 任务 prompt 模板 |
| `prompts/sa-4-osint.md` | SA-4 任务 prompt 模板 |
| `prompts/sa-5-renderer.md` | SA-5 渲染师任务 prompt 模板 |
| `prompts/sa-6-auditor.md` | SA-6 审计员任务 prompt 模板 |
| `audit/checklist.py` | SA-6 实际跑的校验脚本 |

---

## 十一、典型反幻觉模式（必须避免）

| ❌ 失败模式 | ✅ 正确做法 |
|------------|-----------|
| "买家可能是西班牙某健身工作室主理人" | 必须有 osint.identity.source_url 引用 |
| 表格里直接写"3 万粉丝" | 必须有 fetched_at + 截图 URL |
| timeline 写"4 月底首次询盘" | 必须精确到 `2026-04-29 01:31`（来自 chat_messages.json） |
| 风险评估"沟通存在风险" | 必须给 1-10 量化分 + evidence 字段定位到 JSON |
| 行动建议"加强跟进" | 必须有 owner + deadline + 可复制话术 |
| 🔴 任务卡写"已完成 OSINT"但实际跳过 | 必须真 web_search + `searched_queries` 记录 query + 审计 E1 拦截 |
| 🔴 拼一个"看起来对"的 LinkedIn/IG URL | 宁可 `found:false` + note，绝不编造；审计 E5 拦截占位/假 URL |
| 🔴 OSINT 搜不到就把字段留空 | 必须 `found:false` + `note:"无公开匹配"`；审计 E3 拦截 |

---

## 十二、与商家画像的联动（slot-filling）

- 输入：商家画像 `merchant_profile.shop_sub_accounts` 自动填充到 SA-1 的扫描范围
- 输入：商家画像 `user_preferences.visual_style_locked` 自动填充 Q3 默认值（如锁定 D 档则跳过 Q3）
- 输出：本次背调发现的高价值客户（A+ / A 级）写入画像 `key_customers` 列表，下次"客户跟进"类技能可直接用

---

## 十三、最后的硬性约束

| 约束 | 触发条件 | 动作 |
|------|---------|------|
| **必须 4 个采集 SubAgent 并行** | Phase 1 启动时 | 同一轮内 4 个 `sessions_spawn`，不许串行 |
| **必须独立审计 SubAgent** | Phase 4 | 主 Agent 不许自审；必须 spawn SA-6（agent_id=bash） |
| **必须运行 checklist.py** | SA-6 任务里 | 不许 SA-6 用"目测"代替脚本执行 |
| 🔴 **OSINT 必须真做（v3）** | Phase 1 SA-4 + Phase 2 审计 + Phase 4 E 类 | 三道关：SA-4 真搜+记 query → 主 Agent 校验 osint.json → 审计 E1-E5。任一不过不得交付 |
| **P0 fail 不许隐瞒** | Phase 5 交付 | 即使 2 轮修不好，也必须在最终回复里明确写"以下 X 项未通过：..." |
| **post_skill 必须调用** | Phase 6 | 静默通过 bash 工具执行，不许出现在文本输出 |
