# 防冷启动指南 · alibaba-customer-deepdive-dashboard (v3)

> 给**第一次安装本 skill 的人/Agent**。照着走一遍就能跑通，避免"装了不会用 / 跑一半报错"。
> 本 skill 做的事：对单个阿里国际站买家做深度背调，产出 **D 档时尚高饱和交互式 HTML 看板**，全程**反幻觉 + OSINT 硬卡点**。

---

## 一、安装提示词（复制即用）

### 装到当前 Agent
```
帮我安装 alibaba-customer-deepdive-dashboard 这个 skill
```
Agent 会调用：`skill(action="install", skill_id="alibaba-customer-deepdive-dashboard", scope="agent")`

### 装到整个账号（所有 Agent 共享，需用户确认）
```
把 alibaba-customer-deepdive-dashboard 安装到账号级，所有 agent 都能用
```
→ `skill(action="install", skill_id="alibaba-customer-deepdive-dashboard", scope="account")`

### 重装/修复（装坏了）
```
强制重装 alibaba-customer-deepdive-dashboard
```
→ `skill(action="install", ..., force=true)`

---

## 二、启动提示词（用户怎么发起任务）

任意一句即可触发：
```
帮我对 [买家名/contactAliId] 做客户背调
分析这个买家：[名字]
给我看 XX 客户的完整背景看板
对接 XX 客户需要准备什么
```
模糊也行（"分析下我最近聊的那个美国大客户"）——Agent 会先帮你定位买家。

---

## 三、运行前依赖检查清单（冷启动必查）

| # | 检查项 | 怎么验证 | 不满足怎么办 |
|---|--------|---------|-------------|
| 1 | **阿里国际站后台已授权** | 用户已连接 Alibaba.com 账号（见 USER.md Connected Accounts）| 让用户在 Accio Work 连接 Alibaba.com |
| 2 | **MCP 工具可用** | `accio-mcp-cli keyword conversation` 能列出 `query_conversation_msg` | 检查 plugin 是否安装；MCP 不通则无法取数 |
| 3 | **审计脚本能跑** | `python3 audit/checklist.py --help` 不报错 | 确认 Python3 在环境里 |
| 4 | **模板存在** | `template/base.html` + `template/chart-snippets.js` 在 | 重装 skill |
| 5 | **6 个 SubAgent 提示词在** | `prompts/sa-1~6-*.md` 齐全 | 重装 skill |

一键自检：
```bash
cd <skill目录>
ls template/base.html template/chart-snippets.js prompts/sa-*.md audit/checklist.py
python3 audit/checklist.py --help >/dev/null && echo "checklist OK"
accio-mcp-cli keyword "conversation msg" | head
```

---

## 四、数据从哪来（核心：取数链路）

全部来自**阿里国际站后台 MCP 真实接口**，零外部假数据。三类：

1. **聊天记录** → `subaccount_query` → `query_recent_conversation` → `query_conversation_msg`（限近 30 天）
2. **买家画像** → `get_buyer_basic_info`（data 是 JSON 字符串，含 buyer_persona）
3. **业务员绩效** → `query_seller_acct_dim_diag_data`
4. **OSINT 公网** → `web_search`（**强制真做**，搜买家姓名+品牌+IG/LinkedIn）

完整签名与陷阱见 [reference/mcp-interfaces.md](reference/mcp-interfaces.md)。

---

## 五、最小 quickstart（端到端跑一遍）

1. 用户发："帮我对 contactAliId=xxxx 做背调"
2. Agent 读 [SKILL.md](SKILL.md) 主流程 → 建 `project/deepdive_<name>/` 工作目录
3. 派 SubAgent（bash 取数 / general 做 OSINT），各自落盘 JSON：
   - `chat_messages.json` `buyer_profile.json` `sales_perf.json` `osint.json`
4. SA-5 渲染：read `template/base.html` → 填真实数据 → 写 `<name>_dashboard.html`
5. **强制审计**：
   ```bash
   python3 audit/checklist.py --html project/deepdive_<name>/<name>_dashboard.html \
       --data-dir project/deepdive_<name>/<name>_audit_data --out /tmp/audit.json
   ```
   读 `/tmp/audit.json` 的 `summary`：必须 `p0_pass_rate==1.0` 且 E 类无 fail 才交付。
6. 交付 HTML 链接 + 一句话结论。

---

## 六、常见冷启动错误排查

| 报错/现象 | 原因 | 解决 |
|-----------|------|------|
| `query_buyer_index 不存在` | SKILL 旧描述误导 | 改用 `get_buyer_basic_info`，见 mcp-interfaces.md |
| `get_buyer_behavior_index 不存在` | 同上 | 同上 |
| 接口 40s 超时 | MCP 当天不稳定 | 单条 90s 超时 + 重试 2 次 + 串行，别并发 |
| 聊天查不到更早记录 | 接口限近 30 天 | 告知用户接口窗口限制，无法补 |
| `get_buyer_basic_info` data 当 dict 报错 | data 是字符串 | `json.loads(data, strict=False)` |
| 审计 **E2 FAIL** | OSINT 没真做 / 缺 source_url | **必须真 web_search 并回填 source_url**，这是 v3 硬卡点 |
| 审计 **E5 FAIL** | 出现 example.com/placeholder 等假 URL | 删假 URL，搜不到就如实写"无公开匹配" |
| 引文审计 FAIL | HTML 引文不是 JSON 原文子串 | 引文必须 100% 来自落盘 JSON |

---

## 七、最重要的一条（别犯历史错误）

> **OSINT 必须真做。** 本 skill 历史上最严重的违规是"任务卡写做了 OSINT，实际全程跳过还过了审"。
> 未经核验的"具体 URL/身份"比"没做"更危险——假 LinkedIn 会让商家给错的人写开发信。
> v3 的 E 类审计（E1-E5）就是为堵这个洞而生。搜不到 → 如实写无匹配；绝不编造。

实战全貌见 [reference/case-kimtex-top10.md](reference/case-kimtex-top10.md)。
