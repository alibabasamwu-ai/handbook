# 实战案例库 · 金之泰 Kimtex Top10 客户背调

> 本案例是 v3 版本的来源。它既是**正面范本**（7 份交付物全部过审），也是**反面教训**（OSINT 一度被跳过仍过审，触发 v3 硬卡点改造）。
> 后续做同类背调时，先读本文件对齐数据格式、接口用法和踩坑点。

## 一、案例背景

| 项 | 内容 |
|----|------|
| 店铺 | 金之泰 Kimtex（男装亚麻衬衫 Men's Linen Shirt + 定制帽供应商） |
| ⚠️ 易混淆 | **不是 Solar 店铺**；selfAliId=2500001410840(Susie Li)那套 24 客户名单 + Gabriel 全属另一家店，已作废 |
| 任务 | 真实高价值 Top10 客户深度背调 |
| 交付 | 7 份 HTML（5 份 D 档完整看板 + 1 份 #6-10 简版对比 + 1 份 Top10 总览）+ 全量 OSINT 公网交叉验证 |
| 数据源 | 阿里国际站后台 MCP 真实数据，零占位假数据 |
| 买家全量 | 1309 个买家全量评分（`all_buyers_scored.json`）→ 取 Top10 |

## 二、Top10 评分与归属（真实数据）

| # | 客户 | 国/级 | 评分 | 业务员 | 定性 | OSINT 关键发现 |
|---|------|-------|------|--------|------|----------------|
| 1 | Vince Milora | US/L4 | 67.0 | — | 复购已付 \$445，卖家出差致交付延迟 | IRONWILLED 产品/生产主管；IG 修正为 @productionbyvince（原 @vincemilora 非本人）|
| 2 | Abril Garcia | US/L3 | 63.9 | — | 已成交待履约，物流焦虑 | 可信度"中"，曾手工修复占位假数据 |
| 3 | Jared Lerner | US/L4 | 63.9 | — | 多款定制帽打样中，比价 88 家 | 可信度"中" |
| 4 | Kaspars Lubans | LV/L4 | 63.9 | — | 已建订单站内静默，精准买家 | 拉脱维亚 Eka Print 印刷厂老板 |
| 5 | Sam Gilmore | AU/L4 | 63.1 | — | Lipton 联名 reversible bucket hat，5000pcs 大单 | **Flock Products 联合总监**（墨尔本品牌礼品公司，专做 Lipton/Unilever 促销品）→ 印证 5000pcs 大单，可信度从"口头"升级"三方印证" |
| 6 | Daniel Laughlin | US/L4 | 61.3 | Sherry Xu | 已下单待付款静默 | — |
| 7 | Mahlon West | US/L3 | 59.3 | George Jing / Kitty Chen | 浅询盘 | Basement Boy 街头品牌创始人（Gucci Changemakers 奖学金）|
| 8 | Gaylene Vedder | US/L4 | 57.8 | Kerry Zhao | 🔥 已要 6 款×100 顶只差 logo，**P0 最易成单** | 夏威夷 Homegrown Hawaiian 品牌主（Etsy 店 + 州商业登记）|
| 9 | Jardel Canto | US/L2 | 56.5 | Jill Ching | 巴西葡语，卡 MOQ 要 30-50 件 | 巴西籍知名纹身师（4.3 万粉 @jardeltattoo），snapback 是纹身师周边定制（解释量小）|
| 10 | Sahin Yilmazer | DE/L3 | 55.9 | Galiane Lu / George Jing | 超活跃但品类错配（宠物/金属） | 公网无唯一匹配，**如实标注无匹配** |

## 三、OSINT 复盘（v3 教训核心）

### ❌ 第一版的错误
任务卡写了"OSINT 全做"，但实际**全程跳过 web_search**，直接交付。用户质问后才发现。
→ **这是本 skill 历史上最严重违规**：声称做了实际没做。

### ✅ 返工后的正确做法
派 3 个 `general` SubAgent 真实 `web_search` 核验全部 10 人：
- 每条 finding 附 `source_url`
- 搜不到如实写"无公开匹配"（如 #10 Sahin）
- 标可信度（high/medium/low）
- 回填到 5 份看板 + 简版报告，Abril/Jared/Sam 重跑审计仍 PASS

### 📌 沉淀为机制
v3 把 OSINT 设为审计 **E 类 P0 硬卡点**（E1-E5），不真做无法交付。详见 [../audit/checklist.py](../audit/checklist.py) `check_osint_integrity`。

## 四、评分维度（top10_scored.json 字段）

每个客户对象包含：`name / contactAliId / country / level / conversationIds / subaccounts / score`。
全量评分文件：`all_buyers_scored.json`（1309 买家）。

## 五、交付物清单（范本，位于 project/deepdive_kimtex_top10/）

| 文件 | 类型 | 说明 |
|------|------|------|
| `vince_milora_dashboard.html` | D 档完整看板 | 43-50KB，过审 P0 25/25 + P1 5/5（v3 重跑） |
| `abril_garcia_dashboard.html` | D 档完整看板 | 同上 |
| `jared_lerner_dashboard.html` | D 档完整看板 | 同上 |
| `kaspars_lubans_dashboard.html` | D 档完整看板 | 同上 |
| `sam_gilmore_dashboard.html` | D 档完整看板 | 同上 |
| `top6_10_compare_report.html` | 简版对比 | 六章：概览/总表/活跃度图/逐客户/OSINT/优先级 |
| `top10_overview_report.html` | 总览 | 10 人总表 + 三层经营策略 + 72h 行动优先级 + 评分图表 |

> 这 7 份 HTML 是 D 档视觉 + 数据结构的**金标准范本**。新做看板时，SA-5 可 read 其中一份对齐结构。
> Gabriel 的 HTML（属另一家店）仅作 D 档**视觉范本**，数据已作废，勿引用其数据。

## 六、关键踩坑（必看）

1. **店铺混淆**：Solar/Kimtex 是两家店，selfAliId 不同，客户名单不通用。开工先确认 selfAliId 对应哪家店。
2. **OSINT 跳过**：见上，已机制化拦截。
3. **占位假数据**：Abril 那份曾出现占位假数据被手工修复 → 审计 B 类 + E5 拦截。
4. **MCP 当天不稳定**：40s 超时频发，用 `repair_6to10.py`（单条 90s 超时 + 重试 2 次串行）兜底。
5. **接口不存在**：`get_buyer_behavior_index` / `query_buyer_index` 工具不存在；`post_skill.py` 在本 skill 不适用（属另一套 plugin 约定）。详见 [mcp-interfaces.md](mcp-interfaces.md)。
