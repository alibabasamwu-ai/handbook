# MCP 接口契约 · 阿里国际站客户背调

> 实战验证过的真实接口签名与陷阱。SA-1/SA-2/SA-3 派单前必读，避免冷启动时用错参数。
> 所有接口通过 `accio-mcp-cli call <tool> --json '{...}'` 调用（bash SubAgent）。

## 一、聊天记录类（SA-1 用）

### `query_conversation_msg` — 拉某会话完整消息
```json
{
  "request": {
    "conversationId": "<id>",
    "selfAliId": <int>,
    "count": 50,
    "forward": false,
    "limitTimeStamp": <ms>
  }
}
```
- ⚠️ **限最近 30 天**（接口硬限制，超出查不到）
- 返回 `data.messages[]`，每条含 `senderAliId / content / timestamp`
- **判断买家消息**：`senderAliId == 买家 aliId` 则该条为 BUYER 发出
- 翻页：`forward=false` 往过去翻；翻页指针字段是 `nextPointTimeStamp`（不是 nextTimeStamp）

### `query_recent_conversation` — 扫某子账号近 30 天会话列表
- 配合 `subaccount_query` 先拿到全部子账号，再逐账号扫
- ⚠️ 不同店铺子账号互不可见，必须用各子账号自己的 `selfAliId` 调接口

### `subaccount_query` — 拿店铺全部子账号
- 输出每个子账号的 `selfAliId` + 名称，供上面两个接口循环使用

## 二、买家画像类（SA-2 用）

### `get_buyer_basic_info` — 买家基础画像
```json
{ "contactAliId": <int> }
```
- 返回 `data`（**是 JSON 字符串**，不是对象），含 `buyer_persona`：90 天浏览 / 登录天 / 联系卖家数 / 品类
- **读取方式**：`json.load(open(...), strict=False)` —— data 字段需二次 parse，且可能有非标字符，必须 `strict=False`

### ⚠️ 不存在的工具（别调，会报错）
- `get_buyer_behavior_index` —— **不存在**
- `query_buyer_index` —— **不存在**（SKILL.md 旧版误写，已知问题；用 `get_buyer_basic_info` 的 buyer_persona 替代）

## 三、销售绩效类（SA-3 用）

### `query_seller_acct_dim_diag_data` — 子账号接待绩效
- 配合 `subaccount_query` 逐账号查
- 字段：新买家数 / 5min 回复率 / AB3 率 / RNR 率 / 平均回复时长
- 行业中位数无法获取时写 `null`，不许估算

## 四、通用陷阱与兜底

| 陷阱 | 现象 | 兜底 |
|------|------|------|
| **MCP 当天不稳定** | 40s 超时频发 | 单条 90s 超时 + 重试 2 次 + 串行（参考 `repair_6to10.py`），不要并发轰接口 |
| **30 天时间窗** | 聊天/会话接口查不到更早数据 | 调用前告知用户接口仅近 30 天；更早数据无法补 |
| **data 是字符串** | `get_buyer_basic_info` 的 data 直接当 dict 用会报错 | `json.loads(data, strict=False)` |
| **子账号隔离** | 用 A 账号 selfAliId 查 B 账号会话拿不到 | 每账号用自己的 selfAliId |
| **post_skill.py 不适用** | 本 skill 没有该上报脚本 | 跳过上报步骤，或用 plugin-memory-manager 路径（若存在） |

## 五、最小调用链（SA-1 完整流程示例）

```
1. subaccount_query                    → 拿到 [{selfAliId, name}, ...]
2. for each 子账号:
     query_recent_conversation          → 近 30 天会话列表
     找出与目标买家 contactAliId 的会话
3. for each 命中会话:
     query_conversation_msg (翻页)       → 落盘全部消息原文
4. 落盘 chat_messages.json / chat_hits.json / chat_summary.json
```
