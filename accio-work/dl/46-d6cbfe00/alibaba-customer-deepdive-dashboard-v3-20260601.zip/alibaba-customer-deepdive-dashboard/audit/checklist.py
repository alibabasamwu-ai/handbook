#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
SA-6 强制审计脚本 — alibaba-customer-deepdive-dashboard (v3)
============================================================
对 SA-5 渲染出的 HTML 报告执行 30 项硬性检查，输出 audit_report.json。

v3 变更（金之泰 Top10 返工教训）：
  - 修复 B7 漏洞：osint.json 无 URL 不再自动 pass
  - 新增 E1-E5 OSINT 交叉验证硬卡点（P0 强制，不真做不能交付）
  分类：A 结构(7) + B 数据(8) + C 视觉(5) + E OSINT(5) = P0 25 项
       D 行动深度(5) = P1
  通过门槛：P0 100%（25/25）+ P1 ≥ 80%（4/5）

Usage:
  python3 checklist.py --html reports/xxx_dashboard.html \\
                       --data-dir /tmp/deepdive_<BUYER_ID>/ \\
                       --out audit_report.json

退出码:
  0 → 所有 P0 通过
  非 0 → 至少一项 P0 失败

每条 check 输出:
  {
    "id": "A1",
    "category": "structure",
    "level": "P0" | "P1",
    "pass": true | false,
    "reason": "...",
    "evidence": "..."
  }
"""

import argparse
import json
import os
import re
import sys
from pathlib import Path


# -------- 工具函数 --------

def load_json(path: Path):
    if not path.exists():
        return None
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception as e:
        return None


def grep_count(html: str, pattern: str, flags=0) -> int:
    return len(re.findall(pattern, html, flags))


def grep_lines(html: str, pattern: str, flags=0):
    return re.findall(pattern, html, flags)


def collect_osint_urls(osint):
    """从 osint.json 收集所有 http(s) URL（兼容 dict / list 嵌套）"""
    urls = []

    def walk(v):
        if isinstance(v, dict):
            for kk, vv in v.items():
                if kk in ("source_url", "website", "url") and isinstance(vv, str) and vv.startswith("http"):
                    urls.append(vv)
                else:
                    walk(vv)
        elif isinstance(v, list):
            for item in v:
                walk(item)

    walk(osint)
    return urls


def iter_osint_findings(osint):
    """遍历 osint.json 中所有"finding"对象（含 found 字段的 dict）。
    返回 [(path, finding_dict), ...]，用于 E 类逐条校验。"""
    findings = []

    def walk(v, path):
        if isinstance(v, dict):
            if "found" in v:
                findings.append((path, v))
            for kk, vv in v.items():
                walk(vv, f"{path}.{kk}" if path else kk)
        elif isinstance(v, list):
            for i, item in enumerate(v):
                walk(item, f"{path}[{i}]")

    walk(osint, "")
    return findings


# 编造 URL 的高风险特征：占位域名 / 明显假路径
FAKE_URL_PATTERNS = [
    r"example\.com", r"example\.org", r"placeholder", r"your-?site",
    r"linkedin\.com/in/(xxx|test|sample|placeholder|name)",
    r"\.\.\.", r"<.*?>", r"\{.*?\}", r"TODO", r"FIXME",
]

# 表示"搜不到/无匹配"的合法标注（中英文）
NO_MATCH_TOKENS = [
    "无公开", "无匹配", "无法确认", "未找到", "无公开匹配", "无可靠匹配",
    "not found", "no public", "no match", "no reliable", "unverified",
    "none found", "无公开信息", "无明确匹配",
]


def make_result(check_id, category, level, ok, reason, evidence=""):
    return {
        "id": check_id,
        "category": category,
        "level": level,
        "pass": bool(ok),
        "reason": reason,
        "evidence": evidence[:400],
    }


# -------- 检查项分组 --------

def check_structure(html: str, html_path: Path):
    """A1-A7: 结构完整性 (P0 全部)"""
    results = []

    # A1: 文件大小 >= 40 KB
    size_kb = html_path.stat().st_size / 1024
    results.append(make_result(
        "A1", "structure", "P0",
        size_kb >= 40,
        f"文件大小 {size_kb:.1f} KB（要求 >= 40 KB）",
        f"size={size_kb:.1f}KB"
    ))

    # A2: 9 个 section id 必须全在
    required_sections = ["overview", "persona", "brand", "behavior", "chat",
                          "sales", "peer", "risk", "action"]
    missing = [s for s in required_sections if f'id="{s}"' not in html]
    results.append(make_result(
        "A2", "structure", "P0",
        not missing,
        f"section 完整性：缺失 {missing}" if missing else "9 个 section 全部存在",
        f"missing={missing}"
    ))

    # A3: 6 个 canvas id
    required_canvas = ["radar", "brandStage", "catBar", "chatBar", "peerBar", "riskRadar"]
    missing_canvas = [c for c in required_canvas if f'canvas id="{c}"' not in html and f"canvas id='{c}'" not in html]
    results.append(make_result(
        "A3", "structure", "P0",
        not missing_canvas,
        f"canvas 缺失 {missing_canvas}" if missing_canvas else "6 个 canvas 全部存在",
        f"missing_canvas={missing_canvas}"
    ))

    # A4: Chart.js CDN
    has_chartjs = "chart.js" in html.lower()
    results.append(make_result(
        "A4", "structure", "P0",
        has_chartjs,
        "Chart.js CDN 已引入" if has_chartjs else "未找到 chart.js 引用",
        ""
    ))

    # A5: nav 链接 >= 9
    nav_links = grep_count(html, r'<a[^>]+href="#(overview|persona|brand|behavior|chat|sales|peer|risk|action)"')
    results.append(make_result(
        "A5", "structure", "P0",
        nav_links >= 9,
        f"nav 锚点链接 {nav_links} 个（要求 >= 9）",
        f"nav_links={nav_links}"
    ))

    # A6: @media 响应式
    has_media = "@media" in html
    results.append(make_result(
        "A6", "structure", "P0",
        has_media,
        "包含 @media 响应式" if has_media else "缺少 @media",
        ""
    ))

    # A7: 占位符已全部替换
    unreplaced = grep_count(html, r"\{\{[A-Z_]+\}\}")
    results.append(make_result(
        "A7", "structure", "P0",
        unreplaced == 0,
        f"未替换的占位符 {unreplaced} 个" if unreplaced else "所有占位符已替换",
        f"unreplaced={unreplaced}"
    ))

    return results


def check_data_truth(html: str, data_dir: Path):
    """B1-B8: 数据真实性 (P0 全部)"""
    results = []

    diagnosis = load_json(data_dir / "diagnosis.json") or {}
    chat_msgs = load_json(data_dir / "chat_messages.json") or []
    sales = load_json(data_dir / "sales_perf.json") or []
    osint = load_json(data_dir / "osint.json") or {}

    # B1: KPI 6 卡数量
    kpi_count = grep_count(html, r'class="kpi[\s"]')
    results.append(make_result(
        "B1", "data", "P0",
        kpi_count >= 6,
        f"KPI 卡 {kpi_count} 个（要求 >= 6）",
        f"kpi_count={kpi_count}"
    ))

    # B2: timeline >= 10
    tl_count = grep_count(html, r'class="tl-item')
    results.append(make_result(
        "B2", "data", "P0",
        tl_count >= 10,
        f"timeline {tl_count} 条（要求 >= 10）",
        f"tl_count={tl_count}"
    ))

    # B3: quote >= 6
    quote_count = grep_count(html, r'class="quote[\s"]')
    results.append(make_result(
        "B3", "data", "P0",
        quote_count >= 6,
        f"原话引用 {quote_count} 条（要求 >= 6）",
        f"quote_count={quote_count}"
    ))

    # B4: quote 必须能在 chat_messages 找到子串
    if isinstance(chat_msgs, list) and chat_msgs:
        all_chat_text = " ".join([
            (m.get("content") or m.get("text") or m.get("message") or "")
            for m in chat_msgs if isinstance(m, dict)
        ])
        # 抓 HTML 中的 quote 文本
        quotes_in_html = re.findall(r'<div class="quote[^"]*">([^<]+)</div>', html)
        # 取前 3 条抽样校验
        sampled = quotes_in_html[:3]
        not_found = []
        for q in sampled:
            q_clean = q.strip().strip('"\'""''')
            if len(q_clean) >= 10:
                # 取前 15 字符做模糊匹配
                key = q_clean[:15]
                if key not in all_chat_text:
                    not_found.append(q_clean[:50])
        results.append(make_result(
            "B4", "data", "P0",
            not not_found,
            f"引用回溯：{len(not_found)} 条疑似编造" if not_found else f"抽样 {len(sampled)} 条引用均可在原始聊天找到",
            f"not_found={not_found}"
        ))
    else:
        results.append(make_result(
            "B4", "data", "P0",
            False,
            "chat_messages.json 不存在或为空",
            ""
        ))

    # B5: 销售员表行数 >= sales_perf 行数
    table_rows = grep_count(html, r'<tr[^>]*>[\s\S]*?</tr>')
    expected_min = max(1, len([s for s in sales if isinstance(s, dict)]))
    results.append(make_result(
        "B5", "data", "P0",
        table_rows >= expected_min,
        f"表格行 {table_rows}（sales_perf 期望至少 {expected_min}）",
        f"table_rows={table_rows}, sales_perf_rows={expected_min}"
    ))

    # B6: 抽 3 个销售员数字校验
    sampled_sales = sales[:3] if isinstance(sales, list) else []
    mismatches = []
    for s in sampled_sales:
        name = s.get("subAccount") or s.get("name")
        if name and name not in html:
            mismatches.append(f"{name} 未出现在 HTML")
    results.append(make_result(
        "B6", "data", "P0",
        not mismatches,
        f"销售员名字校验：{mismatches}" if mismatches else f"抽样 {len(sampled_sales)} 个销售员全部出现",
        f"mismatches={mismatches}"
    ))

    # B7: OSINT URL 在 HTML 中（注意：B7 仅校验"已渲染"，OSINT 完整性卡点见 E 类）
    urls_in_osint = collect_osint_urls(osint)
    if urls_in_osint:
        sampled_urls = urls_in_osint[:3]
        missing_urls = [u for u in sampled_urls if u not in html]
        results.append(make_result(
            "B7", "data", "P0",
            not missing_urls,
            f"OSINT URL 在 HTML 缺失：{missing_urls}" if missing_urls else f"抽样 {len(sampled_urls)} 个 OSINT URL 已渲染",
            f"missing_urls={missing_urls}"
        ))
    else:
        # 修复历史漏洞：无 URL 不再自动 pass，交由 E 类强制判定是否合法（搜不到必须显式标注）
        results.append(make_result(
            "B7", "data", "P0",
            True,
            "osint.json 无 http URL（合法性由 E 类强制校验）",
            ""
        ))

    # B8: hero meta 含买家 ID
    buyer_id_present = bool(re.search(r"aliId\s*[:=]?\s*\d+", html, re.IGNORECASE))
    results.append(make_result(
        "B8", "data", "P0",
        buyer_id_present,
        "HTML 含买家 aliId" if buyer_id_present else "未找到买家 aliId 字样",
        ""
    ))

    return results


def check_visual(html: str):
    """C1-C5: 视觉一致性 (P0 全部)"""
    results = []
    locked_styles = {
        "C1": ("--bg:#0a0612", "主背景色 #0a0612"),
        "C2": ("--gold:#f5c87a", "玫瑰金主色 #f5c87a"),
        "C3": ("--rose:#ff3d8a", "霓虹红 #ff3d8a"),
        "C4": ("--purple:#9b59ff", "霓虹紫 #9b59ff"),
        "C5": ("linear-gradient", "至少一处渐变背景"),
    }
    for cid, (token, label) in locked_styles.items():
        ok = token in html
        results.append(make_result(
            cid, "visual", "P0",
            ok,
            f"{label}：{'✓' if ok else '缺失'}",
            f"token={token}"
        ))
    return results


def check_action_depth(html: str, data_dir: Path):
    """D1-D5: 行动深度 (P1)"""
    results = []
    diagnosis = load_json(data_dir / "diagnosis.json") or {}

    # D1: action 卡 >= 5
    action_count = grep_count(html, r'class="action[\s"]')
    results.append(make_result(
        "D1", "action", "P1",
        action_count >= 5,
        f"action 卡 {action_count} 个（要求 >= 5）",
        f"action_count={action_count}"
    ))

    # D2: 每张含 P0/P1/P2 优先级标签
    pri_count = grep_count(html, r'>P[012]<')
    results.append(make_result(
        "D2", "action", "P1",
        pri_count >= action_count if action_count > 0 else False,
        f"优先级标签 {pri_count} 个（期望 >= {action_count}）",
        f"pri_count={pri_count}"
    ))

    # D3: data-num 大数字编号
    datanum_count = grep_count(html, r'data-num=')
    results.append(make_result(
        "D3", "action", "P1",
        datanum_count >= 5,
        f"data-num 编号 {datanum_count} 个（要求 >= 5）",
        f"datanum_count={datanum_count}"
    ))

    # D4: 至少一张 action 卡内嵌可复制话术 (class="quote" 出现在 action 区域)
    action_section = re.search(r'id="action"[\s\S]*?(?=<section|\Z)', html)
    has_inline_quote = False
    if action_section:
        has_inline_quote = 'class="quote' in action_section.group(0)
    results.append(make_result(
        "D4", "action", "P1",
        has_inline_quote,
        "action 区域内嵌可复制话术" if has_inline_quote else "action 区域未内嵌 quote",
        ""
    ))

    # D5: 末尾一句话总结
    has_oneliner = bool(re.search(r'class="(oneliner|summary-final|final-line)', html))
    results.append(make_result(
        "D5", "action", "P1",
        has_oneliner,
        "含末尾一句话总结" if has_oneliner else "未找到末尾一句话总结样式类",
        ""
    ))

    return results


def check_osint_integrity(html: str, data_dir: Path):
    """E1-E5: OSINT 交叉验证强制卡点 (P0 全部)
    ============================================================
    背景：历史版本 B7 在 osint.json 无 URL 时直接判 pass，导致
    "声称做了 OSINT 实际没做" 也能过审计（金之泰 Top10 返工教训）。
    E 类把 OSINT 从软检查升级为硬卡点——不真做、不留证据、编造 URL
    一律 FAIL，无法交付。
    """
    results = []
    osint = load_json(data_dir / "osint.json")

    # E1: osint.json 必须存在且非空（强制真做 OSINT）
    e1_ok = bool(osint) and (
        (isinstance(osint, dict) and len(osint) > 0) or
        (isinstance(osint, list) and len(osint) > 0)
    )
    results.append(make_result(
        "E1", "osint", "P0",
        e1_ok,
        "osint.json 存在且非空" if e1_ok else "osint.json 缺失或为空——OSINT 未执行，禁止交付",
        f"keys={list(osint.keys()) if isinstance(osint, dict) else ('list:%d' % len(osint)) if isinstance(osint, list) else None}"
    ))

    findings = iter_osint_findings(osint) if osint else []

    # E2: 每条 found=true 的 finding 必须带 source_url 且 URL 在 HTML 中渲染
    e2_violations = []
    found_true = [(p, f) for (p, f) in findings if f.get("found") is True]
    for path, f in found_true:
        url = f.get("source_url") or f.get("url") or f.get("website")
        if not (url and isinstance(url, str) and url.startswith("http")):
            e2_violations.append(f"{path}: found=true 但缺 source_url")
        elif url not in html:
            e2_violations.append(f"{path}: source_url 未渲染到 HTML")
    e2_ok = (len(found_true) > 0) and not e2_violations
    results.append(make_result(
        "E2", "osint", "P0",
        e2_ok,
        (f"{len(found_true)} 条已验证 finding 均带可渲染来源 URL"
         if e2_ok else
         (f"found=true 证据缺陷：{e2_violations}" if e2_violations
          else "无任何 found=true 的 finding——至少需 1 条可验证身份/品牌/社媒")),
        f"violations={e2_violations}"
    ))

    # E3: found=false 的 finding 必须显式标注"无公开匹配"，禁止留空伪装
    e3_violations = []
    found_false = [(p, f) for (p, f) in findings if f.get("found") is False]
    for path, f in found_false:
        note = " ".join(str(x) for x in f.values() if isinstance(x, str)).lower()
        if not any(tok.lower() in note for tok in NO_MATCH_TOKENS):
            e3_violations.append(f"{path}: found=false 但未写明'无公开匹配'类说明")
    e3_ok = not e3_violations
    results.append(make_result(
        "E3", "osint", "P0",
        e3_ok,
        "found=false 均显式标注无匹配" if e3_ok else f"未标注无匹配：{e3_violations}",
        f"found_false={len(found_false)}"
    ))

    # E4: 必须存在可信度标注（high/medium/low 或 高/中/低）
    cred_tokens = ["credibility", "confidence", "可信度", "置信"]
    e4_in_json = any(
        any(ct in str(k).lower() for ct in cred_tokens)
        for (_, f) in findings for k in f.keys()
    )
    e4_in_html = bool(re.search(r"可信度|置信度|credibility|confidence", html, re.IGNORECASE))
    e4_ok = e4_in_json or e4_in_html
    results.append(make_result(
        "E4", "osint", "P0",
        e4_ok,
        "存在可信度标注" if e4_ok else "缺可信度标注（每条 OSINT 须标 高/中/低）",
        f"in_json={e4_in_json} in_html={e4_in_html}"
    ))

    # E5: 禁止编造 URL（占位域名 / 模板残留 / 假 handle）
    all_urls = collect_osint_urls(osint) if osint else []
    fake_hits = []
    for u in all_urls:
        for pat in FAKE_URL_PATTERNS:
            if re.search(pat, u, re.IGNORECASE):
                fake_hits.append(f"{u} ~ /{pat}/")
                break
    e5_ok = not fake_hits
    results.append(make_result(
        "E5", "osint", "P0",
        e5_ok,
        "未检出编造/占位 URL" if e5_ok else f"疑似编造 URL：{fake_hits}",
        f"checked={len(all_urls)} fake={fake_hits}"
    ))

    return results


# -------- 主入口 --------

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--html", required=True, help="HTML 报告路径")
    parser.add_argument("--data-dir", required=True, help="JSON 数据目录")
    parser.add_argument("--out", required=True, help="audit_report.json 输出路径")
    args = parser.parse_args()

    html_path = Path(args.html)
    data_dir = Path(args.data_dir)

    if not html_path.exists():
        print(f"❌ HTML 文件不存在: {html_path}", file=sys.stderr)
        sys.exit(2)
    if not data_dir.exists():
        print(f"❌ 数据目录不存在: {data_dir}", file=sys.stderr)
        sys.exit(2)

    html = html_path.read_text(encoding="utf-8", errors="ignore")

    all_results = []
    all_results.extend(check_structure(html, html_path))
    all_results.extend(check_data_truth(html, data_dir))
    all_results.extend(check_visual(html))
    all_results.extend(check_osint_integrity(html, data_dir))
    all_results.extend(check_action_depth(html, data_dir))

    # 汇总
    p0_total = sum(1 for r in all_results if r["level"] == "P0")
    p0_pass = sum(1 for r in all_results if r["level"] == "P0" and r["pass"])
    p1_total = sum(1 for r in all_results if r["level"] == "P1")
    p1_pass = sum(1 for r in all_results if r["level"] == "P1" and r["pass"])

    p0_fail_items = [r for r in all_results if r["level"] == "P0" and not r["pass"]]
    p1_fail_items = [r for r in all_results if r["level"] == "P1" and not r["pass"]]

    summary = {
        "p0_total": p0_total,
        "p0_pass": p0_pass,
        "p0_pass_rate": round(p0_pass / p0_total * 100, 1) if p0_total else 0,
        "p1_total": p1_total,
        "p1_pass": p1_pass,
        "p1_pass_rate": round(p1_pass / p1_total * 100, 1) if p1_total else 0,
        "verdict": "PASS" if (p0_pass == p0_total and (p1_pass / max(p1_total, 1) >= 0.8)) else "FAIL",
        "p0_fail_ids": [r["id"] for r in p0_fail_items],
        "p1_fail_ids": [r["id"] for r in p1_fail_items],
    }

    report = {
        "html": str(html_path),
        "data_dir": str(data_dir),
        "summary": summary,
        "checks": all_results,
    }

    out_path = Path(args.out)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")

    # 控制台输出
    print(f"\n=== Audit Report ===")
    print(f"HTML: {html_path}")
    print(f"P0: {p0_pass}/{p0_total} ({summary['p0_pass_rate']}%)")
    print(f"P1: {p1_pass}/{p1_total} ({summary['p1_pass_rate']}%)")
    print(f"Verdict: {summary['verdict']}\n")

    if p0_fail_items:
        print("❌ P0 Fail 项（必须修复）:")
        for r in p0_fail_items:
            print(f"  [{r['id']}] {r['reason']}")
            if r['evidence']:
                print(f"      evidence: {r['evidence']}")
    if p1_fail_items:
        print("\n⚠ P1 Fail 项（建议修复）:")
        for r in p1_fail_items:
            print(f"  [{r['id']}] {r['reason']}")

    print(f"\n📄 完整报告: {out_path}\n")

    # 退出码
    sys.exit(0 if not p0_fail_items else 1)


if __name__ == "__main__":
    main()
